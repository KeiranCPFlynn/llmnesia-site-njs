(() => {
  const overlayUrl = chrome.runtime.getURL("assets/search_overlay.js");
  import(overlayUrl).catch((error) => {
    const message = error instanceof Error ? error.message : String(error ?? "Search overlay import failed");
    void chrome.runtime
      .sendMessage({
        type: "LOG_EXTENSION_ERROR",
        payload: {
          source: "search_overlay_loader",
          context: "content.search_overlay_loader.import",
          message,
          stack: error instanceof Error ? error.stack : undefined,
          url: typeof location === "object" ? location.href : ""
        }
      })
      .catch(() => undefined);
    console.error("[LLMnesia] Failed to load search overlay module.", error);
  });
})();
