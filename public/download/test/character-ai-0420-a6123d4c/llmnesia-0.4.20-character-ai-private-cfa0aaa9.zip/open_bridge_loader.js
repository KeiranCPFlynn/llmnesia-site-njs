(() => {
  // Viewer hand-off bridge for the official /open pages. Same pattern as
  // bootstrap_loader.js: content scripts cannot be ES modules, so this classic
  // loader imports the built module out of the extension's own assets.
  const bridgeUrl = chrome.runtime.getURL("assets/open_bridge.js");
  import(bridgeUrl).catch((error) => {
    const message = error instanceof Error ? error.message : String(error ?? "Bridge import failed");
    void chrome.runtime
      .sendMessage({
        type: "LOG_EXTENSION_ERROR",
        payload: {
          source: "open_bridge_loader",
          context: "content.open_bridge_loader.import",
          message,
          stack: error instanceof Error ? error.stack : undefined,
          url: typeof location === "object" ? location.href : ""
        }
      })
      .catch(() => undefined);
    console.error("[LLMnesia] Failed to load the viewer hand-off bridge.", error);
  });
})();
