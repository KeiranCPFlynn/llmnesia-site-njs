(() => {
  // Keep the document-start URL before the asynchronous module import. Google
  // can replace a restored thread's ID while that import is still loading.
  // Symbol storage stays in the content script's isolated world, not page DOM.
  const requestedUrlKey = Symbol.for("llmnesia.requestedDocumentUrl");
  if (typeof globalThis[requestedUrlKey] !== "string") {
    globalThis[requestedUrlKey] = location.href;
  }
  const bootstrapUrl = chrome.runtime.getURL("assets/bootstrap.js");
  import(bootstrapUrl).catch((error) => {
    const message = error instanceof Error ? error.message : String(error ?? "Bootstrap import failed");
    void chrome.runtime
      .sendMessage({
        type: "LOG_EXTENSION_ERROR",
        payload: {
          source: "bootstrap_loader",
          context: "content.bootstrap_loader.import",
          message,
          stack: error instanceof Error ? error.stack : undefined,
          url: typeof location === "object" ? location.href : ""
        }
      })
      .catch(() => undefined);
    console.error("[LLMnesia] Failed to load content bootstrap module.", error);
  });
})();
