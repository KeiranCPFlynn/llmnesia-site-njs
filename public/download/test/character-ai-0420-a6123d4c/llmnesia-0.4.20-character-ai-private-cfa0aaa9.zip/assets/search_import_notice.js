import{c}from"./backfill.js";function o(a,e){return a.active&&!a.paused&&e?.phase!=="done"&&e?.phase!=="cancelled"}function n(a,e){return a?`Importing chats${e?` from ${c(e)}`:""}. You can keep searching your saved chats.`:null}export{n as a,o as s};
//# sourceMappingURL=search_import_notice.js.map
