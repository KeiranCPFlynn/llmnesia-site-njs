const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/index.js","assets/packed-index.js","assets/vault_support_errors.js","assets/preload-helper.js"])))=>i.map(i=>d[i]);
import"./modulepreload-polyfill.js";import{_ as pn}from"./preload-helper.js";import{c as Kd,v as Yd,p as Wd,a as Jd}from"./report_capture.js";import{b as Xd}from"./backfill_tab.js";import{v as Qd,Q as Zd,b as ec,c as tc,V as oc,w as nc,r as rc,f as ac,i as sc,a as ic,d as mn,s as lc,e as dc}from"./vault_status_summary.js";import{c as cc,L as ae,p as el,l as pc,a as uc,b as fc,s as gc,i as mc,r as yc,d as hc,o as bc,f as vc,e as xc,u as wc,g as kc,h as tl,j as ol,S as Sc,k as Cc,m as Ec,n as $c,q as Re,t as nl,v as rl,w as zn,x as Ac,y as Lc,z as al,H as _a,A as sl,B as Ic,C as Tc,D as Rc,E as il,F as ll,G as dl,I as Pc,J as ks,K as _c,M as Nc,N as Mc,O as Oc,P as Bc,Q as qc}from"./db.js";import{u as Na,s as cl,n as Vc,v as Uc,a as Ma,b as zc,c as K,d as lo,e as pl}from"./vault_support_errors.js";import{s as Fc,M as Dc,l as Gc,a as Ss,p as jc,b as Hc}from"./search_invite.js";import{c as Kc,G as Cs,b as Yc}from"./corpus_native_failure.js";import{a as Wc}from"./rolling_backup.js";import{g as ul,i as Jc,r as Xc,a as Qc}from"./google_ai_mode_access.js";import{C as ta,i as fl,a as Zc,b as gl,V as ep,c as tp,d as op,M as np,I as Es,S as $s,e as As,f as Nt,g as rp,l as ap,h as sp,j as Ls,k as Is}from"./conversation_counter.js";import{i as ip,c as fo}from"./analytics.js";import{O as lp,o as dp,c as ml}from"./organisation_scope.js";import{V as cp}from"./vault_hook.js";import{V as ft,v as pp,a as yl,b as xo,c as wo,d as up}from"./continue_targets.js";import{e as fp,f as gp}from"./chatgpt.js";import{i as mp,T as p}from"./theme.js";import{E as yp,f as hp}from"./error_logging.js";import{c as bp}from"./site_health.js";import{b as vp,a as xp,B as wp,c as kp}from"./backfill.js";import{g as Sp}from"./platform_styles.js";import"./google_ai_mode_page.js";import"./capture_provenance.js";function Cp(e){let t=67108864;const o=Na(e,{filter:a=>!/\.(png|jpe?g|webp|gif)$/i.test(a.name)||a.originalSize>Dc||a.originalSize<=0||a.originalSize>t||a.name.split("/").includes("..")?!1:(t-=a.originalSize,!0)}),n=new Map;for(const[a,r]of Object.entries(o)){const s=a.split(".").at(-1).toLowerCase(),i=s==="jpg"?"jpeg":s;let l="";for(let y=0;y<r.length;y+=8192)l+=String.fromCharCode(...r.subarray(y,y+8192));const m=Fc(`data:image/${i};base64,${btoa(l)}`);m&&n.set(a,m)}return n}function hl(e,t){if(typeof e!="string"||!/^(?:sediment|file-service):\/\//.test(e))return;const o=e.replace(/^(?:sediment|file-service):\/\//,"").split("/").at(-1);if(!o||o==="..")return;const n=[...t].filter(([a])=>{const r=a.split("/").at(-1);return r===o||r.startsWith(`${o}-`)||r.startsWith(`${o}_`)||r.startsWith(`${o}.`)});return n.length===1?n[0][1]:void 0}function Ep(e,t){if(!e||typeof e!="object"||!t.size)return!1;const o=e.mapping;return!o||typeof o!="object"?!1:Object.values(o).some(n=>Array.isArray(n?.message?.content?.parts)&&n.message.content.parts.some(a=>a?.content_type==="image_asset_pointer"&&hl(a.asset_pointer,t)))}const Ts=e=>e instanceof Error?e.message:String(e),Rs=64,$p=6;function Ps(e){return e?e.reason==="restore_timeout"?"Google timed out":e.reason==="completion_unconfirmed"?"completion unconfirmed":e.reason==="unbalanced_transcript"?"reply missing":e.status==="complete"?"older messages unconfirmed":e.status:"no import record"}function Ap(e){const t=e.diagnostic,o=t?t.reason==="restore_timeout"?"Google restore timed out":t.reason==="completion_unconfirmed"?"Google completion unconfirmed":t.reason==="unbalanced_transcript"?"reply missing":t.status==="complete"?"saved rendered messages; coverage unknown":`${t.status}; coverage ${t.coverage??"unknown"}`:"saved chat; no retained import diagnostic; coverage unknown",n=t?.capturedMessageCount===void 0?"capture count unavailable":`${t?.capturedMessageCount} captured messages`,a=e.storedMessageCount??t?.savedMessageCount,r=a===void 0?"stored count unavailable":`${a} stored messages`,s=t?.sourceRetrieval==="used"?"; source response used, coverage unknown":t?.sourceRetrieval==="failed"?"; source response unavailable, using rendered snapshot, coverage unknown":"";return`${e.title||"Untitled chat"} (${o}${s}, ${n}, ${r}, ID ${e.sourceId})`}function Lp(){const e=()=>document.querySelector("#google-import-retry-filter"),t=()=>document.querySelector("#google-import-retry-detail");function o(){const r=document.querySelector("#google-import-retry-chat"),s=t();if(!r||!s)return;const i=r.selectedOptions[0];s.textContent=i&&!i.hidden?i.title:""}function n(){const r=document.querySelector("#google-import-retry-chat"),s=document.querySelector("#retry-google-import-chat");if(!r||!s)return;const i=(e()?.value??"").trim().toLowerCase(),l=[...r.options].filter(d=>!d.dataset.placeholder);for(const d of l)d.hidden=i!==""&&!(d.dataset.search??"").includes(i);const m=l.filter(d=>!d.hidden);l.length>0&&!m.some(d=>d.value===r.value)&&(r.value=m[0]?.value??""),s.disabled=r.disabled||r.value==="";const y=t();i!==""&&l.length>0&&m.length===0?y&&(y.textContent="No saved Google chats match that search."):o()}async function a(){const r=document.querySelector("#google-import-retry-chat"),s=document.querySelector("#retry-google-import-chat");if(!r||!s)return;const i=r.value;try{const l=await chrome.runtime.sendMessage({type:"LIST_GOOGLE_IMPORT_RETRY_CHATS"});if(!l?.ok||!Array.isArray(l.chats))throw new Error(l?.error??"Could not read saved chats");const m=l.chats.sort((d,v)=>+(d.diagnostic?.status==="complete")-+(v.diagnostic?.status==="complete")),y=new Map;for(const d of m){const v=d.title||"Untitled chat";y.set(v,(y.get(v)??0)+1)}r.replaceChildren();for(const d of m){const v=document.createElement("option");v.value=d.sourceId;const b=d.title||"Untitled chat",h=b.length>Rs?`${b.slice(0,Rs-1)}…`:b,w=d.storedMessageCount??d.diagnostic?.savedMessageCount,C=[h];w!==void 0&&C.push(`${w} messages`),C.push(Ps(d.diagnostic)),(y.get(b)??0)>1&&C.push(`#${d.sourceId.slice(-$p)}`),v.textContent=C.join(" · "),v.title=Ap(d),v.dataset.search=`${b} ${d.sourceId} ${Ps(d.diagnostic)}`.toLowerCase(),r.append(v)}if(m.some(d=>d.sourceId===i)&&(r.value=i),r.disabled=s.disabled=m.length===0,!m.length){const d=document.createElement("option");d.textContent="No saved Google chats with a retryable ID or retained import diagnostics",d.dataset.placeholder="1",r.append(d)}n()}catch(l){r.disabled=s.disabled=!0;const m=document.querySelector("#google-import-retry-status");m&&(m.textContent=`Could not load Google chats: ${Ts(l)}`)}}return e()?.addEventListener("input",n),document.querySelector("#google-import-retry-chat")?.addEventListener("change",o),document.querySelector("#refresh-google-import-chats")?.addEventListener("click",()=>{a()}),document.querySelector("#retry-google-import-chat")?.addEventListener("click",async()=>{const r=document.querySelector("#google-import-retry-chat"),s=document.querySelector("#retry-google-import-chat"),i=document.querySelector("#google-import-retry-status");if(!(!r?.value||!s||!i)){s.disabled=!0;try{const l=await chrome.runtime.sendMessage({type:"RETRY_GOOGLE_IMPORT_CHAT",sourceId:r.value});i.textContent=l.ok?"Retry started for the selected chat only. Follow its progress or cancel in the popup.":l.error??"Could not start this retry."}catch(l){i.textContent=`Could not start this retry: ${Ts(l)}`}finally{await a()}}}),a}const _s=16*1024*1024,oa=128*1024*1024,bl=2e3,Ns="https://aistudio.google.com/";function Dt(e){return e&&typeof e=="object"&&!Array.isArray(e)?e:null}function Fn(e){return typeof e=="string"?e:""}function Ms(e){return e.isThought===!0||e.thought===!0}function yn(e){if(Ms(e))return"";const t=Array.isArray(e.parts)?e.parts.map(Dt).filter(o=>!!o):[];return t.some(o=>typeof o.text=="string")?t.filter(o=>!Ms(o)).map(o=>Fn(o.text)).join("").trim():Fn(e.text).trim()}function Os(e){return e==="model"||e==="assistant"?"assistant":e==="user"||e==="system"?e:null}function Bs(e){const t=typeof e=="string"?Date.parse(e):NaN;return Number.isFinite(t)&&t>0?t:void 0}async function Ip(e){const t=await crypto.subtle.digest("SHA-256",new TextEncoder().encode(e));return Array.from(new Uint8Array(t),o=>o.toString(16).padStart(2,"0")).join("")}async function Tp(e,t){const o=Dt(e),n=Dt(o?.chunkedPrompt);if(!o||!n||!Array.isArray(n.chunks))return null;const a=n.chunks.map(Dt).filter(h=>!!h),r=[],s=Dt(o.systemInstruction),i=s?yn(s):"";i&&r.push({role:"system",text:i.replace(/\s+/g," "),formattedText:i,order:0});const l=[];for(const h of a){const w=Os(h.role),C=yn(h);if(!w||!C)continue;r.push({role:w,text:C.replace(/\s+/g," "),formattedText:C,order:r.length});const A=Bs(h.createTime);A!==void 0&&l.push(A)}if(!r.some(h=>h.role==="user"||h.role==="assistant"))return null;const m=a.find(h=>Os(h.role)==="user"&&yn(h)),y=m&&Bs(m.createTime)!==void 0?JSON.stringify([m.createTime,yn(m)]):JSON.stringify(r.map(h=>[h.role,h.formattedText])),d=`drive-export-${await Ip(y)}`,v=Fn(Dt(o.runSettings)?.model).replace(/^models\//,"").trim(),b=Fn(o.title).trim()||t.split(/[\\/]/).pop()?.replace(/\.(?:json|txt)$/i,"").trim()||"AI Studio conversation";return{platform:"ai_studio",sourceId:d,title:b,url:Ns,baseUrl:Ns,isDeeplinkable:!1,...l.length?{createdAt:l.reduce((h,w)=>Math.min(h,w)),updatedAt:l.reduce((h,w)=>Math.max(h,w))}:{},...v&&v.length<=160?{models:[v]}:{},messages:r.map(h=>h.role==="assistant"&&v&&v.length<=160?{...h,model:v}:h)}}function Rp(e){return!e.endsWith("/")&&!/(^|\/)(?:__MACOSX|\.DS_Store|\._[^/]*)($|\/)/.test(e)&&!/\.(?:png|jpe?g|gif|webp|avif|svg|mp[34]|wav|ogg|webm|mov|pdf|zip)$/i.test(e)}async function Pp(e){if(e.size>oa)throw new Error("Choose downloads smaller than 128 MB, or split the folder into smaller batches.");const t=new Uint8Array(await e.arrayBuffer());if(t[0]===80&&t[1]===75){let o=0,n=0;const a=Na(t,{filter:r=>{if(!Rp(r.name))return!1;if(o+=r.originalSize,n+=1,r.originalSize>_s||o>oa||n>bl)throw new Error("That ZIP is too large. Import up to 2,000 files per batch, with each chat below 16 MB and total text below 128 MB.");return!0}});return Object.entries(a).sort(([r],[s])=>r.localeCompare(s)).map(([r,s])=>({name:r,bytes:s}))}if(t.length>_s)throw new Error("That chat exceeds 16 MB. Choose a smaller AI Studio download.");return[{name:e.name,bytes:t}]}async function _p(e,t){const o={saved:0,unchanged:0,skipped:0,failed:0,processed:0,total:0,cancelled:!1};let n=0;for(const a of e){if(t.shouldCancel?.()){o.cancelled=!0;break}let r;try{r=await Pp(a)}catch(s){o.failed+=1,o.error=s instanceof Error?s.message:"That download could not be opened.",t.onProgress?.({...o});continue}o.total+=r.length,r.length||(o.skipped+=1);for(const s of r){if(t.shouldCancel?.()){o.cancelled=!0;break}if(n+=s.bytes.length,n>oa||o.processed>=bl)return o.failed+=1,o.error="Batch limit reached. Import remaining chats in a smaller batch (up to 2,000 files and 128 MB of text).",o;try{const i=JSON.parse(cl(s.bytes).replace(/^\uFEFF/,"")),l=await Tp(i,s.name);if(!l)o.skipped+=1;else{const m=await t.index(l);if(!m.ok)throw new Error(m.error||"A chat could not be saved. Try importing it again.");m.changed===!1?o.unchanged+=1:o.saved+=1}}catch(i){o.failed+=1,o.error=i instanceof SyntaxError?"Some files were not readable AI Studio JSON downloads.":i instanceof Error?i.message:"A chat could not be saved."}o.processed+=1,t.onProgress?.({...o})}if(o.cancelled)break}return o}const Np=`
  <section id="import-ai-studio-section" class="settings-section" data-settings-section data-settings-group="data" data-settings-label="AI Studio history" data-settings-search="Google AI Studio Drive download JSON zip import older chats" style="margin-top:16px;border:1px solid #dbe2cf;border-left:4px solid #3d6fa8;border-radius:12px;padding:14px 16px;background:#eef4fb;">
    <h2 style="margin:0 0 10px;font-size:16px;">Import Google AI Studio chats</h2>
    <p class="settings-card-description">For direct history import, <a href="https://aistudio.google.com/library" target="_blank" rel="noreferrer">open AI Studio</a> and choose <strong>Index older chats</strong> in LLMnesia. You can also import downloaded files below.</p>
    <p class="settings-card-description">Download saved chats from the <strong>Google AI Studio</strong> folder in Google Drive, then choose the files or the folder's ZIP below. Files without an extension work too.</p>
    <p style="color:#4f6576;font-size:12.5px;line-height:1.5;">Files are read on this device. No Google Drive connection is required. Only conversation text and system instructions are imported; images, audio, videos and tool activity are excluded. If Vault is enabled, imported chats sync using your existing settings.</p>
    <div class="settings-actions" style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;">
      <button id="import-ai-studio" class="settings-primary-action" type="button">Choose AI Studio files or ZIP</button>
      <button id="import-ai-studio-cancel" type="button" style="display:none;">Stop</button>
      <input id="import-ai-studio-files" type="file" multiple style="display:none;" />
    </div>
    <progress id="ai-studio-import-progress" max="1" value="0" style="display:none;width:100%;height:10px;margin-top:10px;"></progress>
    <div id="ai-studio-import-status" class="settings-status-panel" role="status" style="margin-top:10px;color:#2f4654;overflow-wrap:anywhere;">No import yet.</div>
    <details style="margin-top:10px;"><summary>How to download your chats</summary>
      <ol style="color:#526771;font-size:12px;line-height:1.5;">
        <li>Open Google Drive using the same Google account as AI Studio.</li>
        <li>Find the Google AI Studio folder and download individual chat files, or download the folder as a ZIP.</li>
        <li>Choose the downloaded files here. Importing the same download again updates its saved copy without creating another imported copy.</li>
      </ol>
      <p style="color:#526771;font-size:12px;">Drive downloads usually omit their original chat IDs, so imported copies do not link back to AI Studio and may be separate from chats previously saved with the browser pill. Keep the original files in Drive: downloading is enough.</p>
    </details>
  </section>`;function Mp(e){const t=document.querySelector("#import-ai-studio"),o=document.querySelector("#import-ai-studio-files"),n=document.querySelector("#import-ai-studio-cancel"),a=document.querySelector("#ai-studio-import-progress"),r=document.querySelector("#ai-studio-import-status");if(!t||!o||!n||!a||!r)return;let s=!1,i=!1;t.addEventListener("click",()=>o.click()),n.addEventListener("click",()=>{i=!0,n.disabled=!0,r.textContent="Stopping after the current chat..."}),o.addEventListener("change",()=>{const l=Array.from(o.files??[]);o.value="",!(s||!l.length)&&(s=!0,i=!1,t.disabled=!0,n.disabled=!1,n.style.display="inline-block",a.style.display="block",a.removeAttribute("value"),r.textContent="Reading your AI Studio downloads...",(async()=>{let m=0,y=!1;try{await e.markStarted(),y=!0;const d=await _p(l,{shouldCancel:()=>i,index:async b=>await chrome.runtime.sendMessage({type:"INDEX_CONVERSATION",indexingMode:"backfill",kind:"playground",conversation:b})??{ok:!1,error:"The extension did not confirm this save. Reload LLMnesia and import the file again."},onProgress:b=>{m=b.saved,a.max=Math.max(1,b.total),a.value=b.processed,i||(r.textContent=`Reading ${b.processed} of ${b.total} files: ${b.saved} ${b.saved===1?"chat":"chats"} saved.`)}});m=d.saved;const v=d.cancelled?"Import stopped.":d.failed?"Import finished with errors.":d.saved+d.unchanged===0?"No AI Studio chats found.":"Import complete.";r.textContent=`${v} ${d.saved} ${d.saved===1?"chat":"chats"} saved, ${d.unchanged} already up to date, ${d.skipped} empty or unsupported files skipped, ${d.failed} failed.${d.error?` ${d.error}`:""}${d.cancelled?" Choose the same files again to resume.":""}`}catch(d){r.textContent=`Import failed: ${d instanceof Error?d.message:"Could not read those files."}`}finally{y&&await e.finalize(m).catch(()=>{}),await e.refreshStats().catch(()=>{}),a.style.display="none",n.style.display="none",t.disabled=!1,s=!1}})())})}const Op="llmnesia-fs-handles",Ge="handles",Oa={claude_code:"claude-code-projects",codex:"codex-sessions",zcode:"zcode-db"};function pr(e){if(ae[e].nativeHostOnly)throw new Error(`${ae[e].label} sessions sync through the LLMnesia helper only.`)}const Bp=3,qs=32;function qp(){return typeof globalThis.showDirectoryPicker=="function"}function Ba(){return new Promise((e,t)=>{const o=indexedDB.open(Op,1);o.onupgradeneeded=()=>{const n=o.result;n.objectStoreNames.contains(Ge)||n.createObjectStore(Ge)},o.onsuccess=()=>e(o.result),o.onerror=()=>t(o.error)})}function Vp(e,t){return new Promise((o,n)=>{t.onsuccess=()=>o(t.result),t.onerror=()=>n(t.error)})}async function Up(e,t){const o=await Ba();try{const n=o.transaction(Ge,"readwrite");n.objectStore(Ge).put(t,Oa[e]),await new Promise((a,r)=>{n.oncomplete=()=>a(),n.onerror=()=>r(n.error),n.onabort=()=>r(n.error)})}finally{o.close()}}async function vl(e){const t=await Ba();try{const o=t.transaction(Ge,"readonly");return await Vp(o.objectStore(Ge),o.objectStore(Ge).get(Oa[e]))??null}finally{t.close()}}async function zp(e){const t=await Ba();try{const o=t.transaction(Ge,"readwrite");o.objectStore(Ge).delete(Oa[e]),await new Promise((n,a)=>{o.oncomplete=()=>n(),o.onerror=()=>a(o.error)})}finally{t.close()}await cc(e)}let xl=class extends Error{};async function Fp(e){pr(e);const t=globalThis.showDirectoryPicker;if(!t)throw new Error("showDirectoryPicker is unavailable in this page.");let o;try{o=await t({id:`llmnesia-${e}`,mode:"read"})}catch(n){throw n instanceof Error&&n.name==="AbortError"?new xl("Folder selection cancelled."):n}return await Up(e,o),o}async function In(e,t){try{return await e.getDirectoryHandle(t)}catch{return null}}async function Dp(e){for await(const t of e.values())if(t.kind==="directory"){for await(const o of t.values())if(o.kind==="file"&&o.name.endsWith(".jsonl"))return!0}return!1}const Gp=/^\d{4}$/,Vs=/^\d{1,2}$/;async function jp(e){const t=[];for await(const o of e.values())if(o.kind==="file"){if(o.name.endsWith(".jsonl")&&o.name!=="session_index.jsonl")return!0}else Gp.test(o.name)&&t.push(o);for(const o of t)for await(const n of o.values())if(!(n.kind!=="directory"||!Vs.test(n.name))){for await(const a of n.values())if(!(a.kind!=="directory"||!Vs.test(a.name))){for await(const r of a.values())if(r.kind==="file"&&r.name.endsWith(".jsonl"))return!0}}return!1}async function Hp(e,t){pr(e);const[o,n]=e==="claude_code"?[".claude","projects"]:[".codex","sessions"],a=e==="claude_code"?Dp:jp,r=await In(t,o),s=[r?await In(r,n):null,await In(t,n),r,t];for(const i of s)if(i&&await a(i))return i;return null}async function qa(e,{prompt:t}){const o={mode:"read"};return!!(await e.queryPermission(o)==="granted"||t&&await e.requestPermission(o)==="granted")}async function wl(e,t,o=Bp,n=[]){const{sessionIdFromFilename:a}=ae[e],r=[];for await(const s of t.values())if(s.kind==="file"){if(s.name.endsWith(".jsonl")&&s.name!=="session_index.jsonl"){const i=s;n.push({sessionId:a(s.name),getFile:()=>i.getFile()})}}else o>0&&r.push(s);for(const s of r)await wl(e,s,o-1,n);return n}async function Kp(e){for(const t of[await In(e,".codex"),e])if(t)try{const o=await(await t.getFileHandle("session_index.jsonl")).getFile();return el(await o.text())}catch{}return new Map}async function kl(e,t,o,n,a={}){const r=await pc(),s=await uc(),{parse:i}=ae[e],l={processed:0,total:t.length,indexed:0,skipped:0,empty:0};let m=0,y=0,d=0,v=!1;const b=async(h=!1)=>{if(!(y===0||d===0||!h&&d<qs)){if(d=0,v)try{await yc()}catch{return}await hc(r,s),y=0,v=!1}};for(const{sessionId:h,getFile:w}of t){l.processed+=1;try{const C=await w(),A=fc(e,h),I=r[A],S=o.get(h);if(!a.force&&I!==void 0&&C.lastModified<=I&&!await gc(e,h,S,s))l.skipped+=1;else{const W=i(await C.text(),h,{title:S??s[A]??null});W?(await mc(W,{origin:"import",kind:"archived"}),v=!0,l.indexed+=1):l.empty+=1,r[A]=C.lastModified,y+=1,d+=1}S&&s[A]!==S&&(s[A]=S,y+=1,d+=1),d>=qs&&await b()}catch{m+=1}n?.(l)}return await b(!0),{...l,failed:m}}function Sl(e){const{label:t,pickerHintPath:o,posixPath:n}=ae[e];return new Error(`Couldn't find any ${t} sessions there — select your ${o} folder (or ${n}), not a parent folder.`)}async function Va(e,t,o,n={}){pr(e);const a=await Hp(e,t);if(!a)throw Sl(e);const r=e==="codex"?await Kp(t):new Map;return kl(e,await wl(e,a),r,o,n)}async function Yp(e,t,o,n={}){pr(e);const{sessionIdFromFilename:a}=ae[e],r=Array.from(t),s=e==="codex"?await(async()=>{const l=r.find(m=>m.name==="session_index.jsonl");return l?el(await l.text()):new Map})():new Map,i=r.filter(l=>l.name.endsWith(".jsonl")&&l.name!=="session_index.jsonl").map(l=>({sessionId:a(l.name),getFile:async()=>l}));if(i.length===0)throw Sl(e);return kl(e,i,s,o,n)}const Wp="Reload the extension to finish connecting.",Jp="Enable automatic sync above to reconnect.",Xp="Setup isn't finished. Run the install command below to connect your desktop AI app.",Qp="The desktop connector was set up for a different copy of the extension. Run the install command below to repair it.",Zp="The desktop connector couldn't start. Check Node.js is installed, then run the install command below.",eu="The desktop connector didn't answer. This retries on its own, so no action is needed unless it keeps happening.";function Ua(e){switch(Kc(e)){case"permission_missing":return Jp;case"worker_pre_grant":return Wp;case"host_not_installed":return Xp;case"host_forbidden":return Qp;case"host_start_failed":return Zp;case"host_unreachable":return eu;default:return e}}const tu={applied:"Filed","already-applied":"Already filed",missing:"No longer in your library",stale:"Needs refresh",refused:"Refused"},ou={"unknown-source":"Reopen a Claude chat to detect this source again.","source-limit":"The local source limit was reached. Existing chats are unchanged.","untrusted-sender":"Only LLMnesia's own pages can do this.","invalid-input":"The request was not valid.","invalid-selection":"The selection was not valid.","invalid-scope":"That scope was not valid.","unknown-space":"That space no longer exists. Pick a space that does.","not-found":"That space no longer exists.","unknown-handoff":"That handoff already expired. Start again from search.","expired-handoff":"That handoff already expired. Start again from search.",duplicate:"A space with that identity already exists.","stale-revision":"This changed in another view. The list has been refreshed; try again.",protected:"Personal cannot be removed.",referenced:"This space still has chats placed in it (or rules pointing at it). Move those chats first, or keep the space.","missing-destination":"That space no longer exists. Pick a space that does.","unknown-preview":"This preview expired. Prepare it again to continue.","expired-preview":"This preview expired. Prepare it again to continue.","stale-placement":"This chat changed since the preview. Refresh the preview to review it again.","stale-destination":"The destination changed since the preview. Refresh the preview to review it again.","stale-lifetime":"A chat or space was removed and recreated since the preview. Refresh the preview to review it again.","identity-mismatch":"This chat changed since the preview. Refresh the preview to review it again.","missing-space":"The destination space was removed. Refresh the preview and pick another space.","rule-changed":"The rule behind this chat changed. Refresh the preview to review it again.","review-not-cleared":"This chat is under review; resolving it needs an explicit correction.","unresolved-decision":"This chat could not be filed from the current preview.","missing-conversation":"No longer in your library.","transaction-aborted":"The change did not complete. Nothing was half-applied; try again."};function ie(e){return e?ou[e]??e:""}function g(e,t,o){const n=document.createElement(e);return t&&(n.className=t),o!==void 0&&(n.textContent=o),n}function Le(e,t){const o=e.find(a=>a.id===t);return o?e.filter(a=>a.name===o.name).length>1?`${o.name} (${o.id.slice(-4)})`:o.name:"Removed space"}function fe(e){return chrome.runtime.sendMessage(e)}const Us="llmnesia-organisation-section-style";function nu(){if(document.getElementById(Us))return;const e=document.createElement("style");e.id=Us,e.textContent=`
    .llmorg-row { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; }
    .llmorg-list { margin: 8px 0 0; padding: 0; list-style: none; }
    .llmorg-list li { display: flex; align-items: center; gap: 8px; padding: 5px 0; flex-wrap: wrap; }
    .llmorg-space-name { font-weight: 600; color: #385066; }
    .llmorg-space-personal { font-size: 11px; color: #637785; }
    .llmorg-input { padding: 5px 8px; border-radius: 7px; border: 1px solid #c6d0b0; background: #fff; font-size: 12.5px; }
    .llmorg-button { padding: 6px 12px; border-radius: 8px; border: 1px solid #9fb08a; background: #fff; color: #385066; cursor: pointer; font-size: 12.5px; }
    .llmorg-button:hover:not(:disabled) { background: #f0f4ea; }
    .llmorg-button:disabled { opacity: 0.55; cursor: default; }
    .llmorg-button-primary { border-color: #2f7f99; background: #2f7f99; color: #fff; font-weight: 600; }
    .llmorg-button-primary:hover:not(:disabled) { background: #286d85; }
    .llmorg-button-danger { border-color: #b3563a; color: #8f3f27; }
    .llmorg-status { margin-top: 6px; font-size: 11.5px; color: #637785; }
    .llmorg-status[data-error="true"] { color: #8f3f27; }
    .llmorg-table { margin-top: 8px; border: 1px solid #dbe2cf; border-radius: 8px; overflow: hidden; }
    .llmorg-table table { border-collapse: collapse; width: 100%; font-size: 12.5px; }
    .llmorg-table th { text-align: left; background: #eef2e6; color: #526771; font-weight: 600; padding: 6px 10px; }
    .llmorg-table td { padding: 6px 10px; border-top: 1px solid #e6ebdc; color: #385066; word-break: break-word; }
    .llmorg-outcome { font-size: 11.5px; color: #526771; }
    .llmorg-block { margin-top: 12px; padding-top: 12px; border-top: 1px solid #e6ebdc; }
    .llmorg-heading { margin: 0 0 4px; font-size: 13px; color: #385066; }
    .llmorg-scope-option { display: inline-flex; align-items: center; gap: 6px; font-size: 12.5px; color: #385066; cursor: pointer; }
    .llmorg-note { margin: 6px 0 0; font-size: 11.5px; color: #65766a; line-height: 1.5; }
  `,document.head.appendChild(e)}function ru(e,t,o){nu();let n=null,a=null,r=null,s=null,i=!1,l=null,m=null,y=!1,d=[];const v=g("div","llmorg-root"),b=g("div"),h=document.createElement("input");h.type="checkbox",h.id="organisation-preview-toggle";const w=g("label","llmorg-scope-option");w.htmlFor="organisation-preview-toggle",w.append(h,document.createTextNode("Organise chats into Personal and work spaces"));const C=g("div","llmorg-block"),A=g("h3","llmorg-heading","Search scope"),I=g("div","llmorg-row"),S=g("p","llmorg-status");C.append(A,I,S);const W=g("div","llmorg-block"),Ce=g("h3","llmorg-heading","Spaces"),Ee=g("ul","llmorg-list"),oe=g("input","llmorg-input");oe.type="text",oe.placeholder="New space name, for example Acme",oe.setAttribute("aria-label","New space name");const ut=g("button","llmorg-button","Create space");ut.type="button";const z=g("p","llmorg-status"),ho=g("div","llmorg-row");ho.append(oe,ut),W.append(Ce,Ee,ho,z);const Ot=g("div","llmorg-block"),qd=g("h3","llmorg-heading","Organise existing chats"),Ye=g("div"),gn=g("p","llmorg-status");Ot.append(qd,Ye,gn);const ys=g("p","llmorg-note");ys.textContent="Organisation is saved on this browser. Your existing sync and assistant access are unchanged. Another browser or device, a reinstall, or a restore without these local records does not carry this organisation. A named work space is private: it does not create an employer account, a paid plan or a team.";const q=g("p","llmorg-status"),$r=g("div","llmorg-block"),Vd=g("h3","llmorg-heading","File new chats automatically"),Bt=g("div"),qt=g("p","llmorg-status");$r.append(Vd,Bt,qt),v.append(b,ys,C,W,$r,Ot,q),e.append(v);function Ud(){if($r.hidden=n?.enabled!==!0,Bt.textContent="",!n?.enabled)return;Bt.append(g("p","llmorg-note","Connect a detected Claude source once. Only chats created after connecting are filed automatically. Older chats keep their current placement. One source can be active in this preview; connecting another pauses the previous one. Account switching and paid workspaces are still being verified. ChatGPT automatic filing is unavailable until account identity is verified.")),n.sources?.length||Bt.append(g("p","llmorg-note","Open or continue a Claude chat to detect its source. There are no IDs or chat labels to enter."));for(const u of n.sources??[]){const P=g("div","llmorg-row"),x=`Claude source (${u.workspaceId.slice(-8)})`;P.append(g("span",void 0,x));const N=g("select","llmorg-input");N.setAttribute("aria-label",`Destination for ${x}`);for(const $ of n.spaces){const E=g("option",void 0,Le(n.spaces,$.id));E.value=$.id,E.selected=$.id===u.destinationSpaceId,N.append(E)}const L=g("button","llmorg-button",u.paused?"Connect source":"Save destination");L.type="button",L.disabled=n.spaces.length===0;const B=async $=>{L.disabled=!0;try{const E=await fe({type:"ORGANISATION_CONNECT_SOURCE",sourceKey:u.sourceKey,destinationSpaceId:$,expectedRevision:u.revision});qt.textContent=E.ok?$===null?"Source paused. Previously filed chats stay where they are.":"Connected. New chats created from now on will file here. Existing chats are unchanged.":ie(E.error),qt.dataset.error=String(!E.ok)}catch{qt.textContent="Could not save the source connection. Try again."}await $e()};if(L.addEventListener("click",()=>{B(N.value)}),P.append(N,L,g("span",void 0,u.paused?"Not active":"Connected")),!u.paused){const $=g("button","llmorg-button","Pause source");$.type="button",$.addEventListener("click",()=>{$.disabled=!0,B(null)}),P.append($)}Bt.append(P)}const f=g("button","llmorg-button","Retry unfinished filing");f.type="button",f.addEventListener("click",async()=>{f.disabled=!0;try{const u=await fe({type:"ORGANISATION_RETRY_CAPTURES"});qt.textContent=u.ok?`${u.completed??0} saved filing operations completed. Chats whose source is still unknown are checked again when you reopen or continue them.`:ie(u.error)}catch{qt.textContent="Could not retry filing. Saved chats are unchanged."}await $e()}),Bt.append(f)}h.addEventListener("change",async()=>{h.disabled=!0,q.removeAttribute("data-error"),q.textContent="";try{const f=await fe({type:"ORGANISATION_SET_PREVIEW_ENABLED",enabled:h.checked});f?.ok||(h.checked=n?.enabled===!0,q.dataset.error="true",q.textContent=ie(f?.error))}catch(f){h.checked=n?.enabled===!0,q.dataset.error="true",q.textContent=f instanceof Error?f.message:"Could not save the setting."}finally{h.disabled=!1,await $e()}}),ut.addEventListener("click",async()=>{const f=oe.value.trim();if(!f){z.dataset.error="true",z.textContent="Give the space a name first.";return}ut.disabled=!0,z.removeAttribute("data-error"),z.textContent="";try{const u=await fe({type:"ORGANISATION_CREATE_SPACE",name:f});u?.ok?oe.value="":(z.dataset.error="true",z.textContent=ie(u?.error))}catch(u){z.dataset.error="true",z.textContent=u instanceof Error?u.message:"Could not create the space."}finally{ut.disabled=!1,await $e()}});async function bo(f){S.removeAttribute("data-error"),S.textContent="";try{const u=await fe({type:"ORGANISATION_SET_SCOPE",scope:f});u?.ok||(S.dataset.error="true",S.textContent=ie(u?.error))}catch(u){S.dataset.error="true",S.textContent=u instanceof Error?u.message:"Could not save the scope."}await $e()}function Ar(f,u,P){const x=document.createElement("input");return x.type="radio",x.name=P,x.value=f,x.checked=u,x.addEventListener("change",()=>{x.checked&&(f==="unclassified"?(y=!1,bo({kind:"unclassified"})):f==="selected"?(y=!0,hs()):n&&(y=!1,bo({kind:"space",spaceId:f})))}),x}function hs(){if(I.textContent="",!n)return;if(!n.enabled){C.hidden=!0;return}C.hidden=!1;const f=n.scope,u="llmorg-scope",P=f.kind==="space"?f.spaceId:null,x=f.kind==="spaces"||y,N=g("label","llmorg-scope-option"),L=Ar("unclassified",!x&&f.kind==="unclassified",u);L.id="llmorg-scope-unclassified",N.htmlFor="llmorg-scope-unclassified",N.append(L,document.createTextNode("Unclassified")),I.append(N);for(const E of n.spaces){const O=g("label","llmorg-scope-option"),F=Ar(E.id,!x&&P===E.id,u);F.id=`llmorg-scope-${E.id}`,O.htmlFor=F.id,O.append(F,document.createTextNode(Le(n.spaces,E.id))),I.append(O)}const B=g("label","llmorg-scope-option"),$=Ar("selected",x,u);if($.id="llmorg-scope-selected",B.htmlFor="llmorg-scope-selected",B.append($,document.createTextNode("Search selected spaces")),I.append(B),x){const E=f.kind==="spaces"?f:{spaceIds:f.kind==="space"?[f.spaceId]:[],includeUnclassified:f.kind==="unclassified"},O=g("div","llmorg-row");O.style.marginTop="6px";const F=E.includeUnclassified,pe=document.createElement("input");pe.type="checkbox",pe.id="llmorg-combo-unclassified",pe.checked=F,pe.addEventListener("change",()=>{bo({kind:"spaces",spaceIds:E.spaceIds,includeUnclassified:pe.checked})});const Y=g("label","llmorg-scope-option","Unclassified");Y.htmlFor="llmorg-combo-unclassified",O.append(pe,Y);for(const ue of n.spaces){const se=document.createElement("input");se.type="checkbox",se.id=`llmorg-combo-${ue.id}`,se.checked=E.spaceIds.includes(ue.id),se.addEventListener("change",()=>{const Ae=new Set(E.spaceIds);se.checked?Ae.add(ue.id):Ae.delete(ue.id),bo({kind:"spaces",spaceIds:Array.from(Ae),includeUnclassified:E.includeUnclassified})});const j=g("label","llmorg-scope-option");j.htmlFor=se.id,j.append(se,document.createTextNode(Le(n.spaces,ue.id))),O.append(j)}I.append(O),E.spaceIds.length===0&&!F&&(S.dataset.error="true",S.textContent="No spaces selected: scoped search shows nothing until you pick at least one.")}n.missingSpaceIds.length>0&&(S.dataset.error="true",S.textContent="A selected space was removed. Choose a replacement scope; search stays narrowed until you do."),S.textContent===""&&(S.textContent=`Current scope: ${dp(f,E=>Le(n.spaces,E))}. Changing the scope never changes where new chats are saved.`)}function vo(){if(Ee.textContent="",!n||!n.enabled){W.hidden=!0;return}W.hidden=!1;for(const f of n.spaces){const u=g("li"),P=g("span","llmorg-space-name",Le(n.spaces,f.id));if(u.append(P),f.personal&&u.append(g("span","llmorg-space-personal","Personal is always available and cannot be removed")),m===f.id){const x=g("input","llmorg-input");x.type="text",x.value=f.name,x.setAttribute("aria-label",`New name for ${f.name}`);const N=g("button","llmorg-button llmorg-button-primary","Save name");N.type="button";const L=g("button","llmorg-button","Cancel");L.type="button",N.addEventListener("click",async()=>{const B=x.value.trim();if(!B)return;const $=await fe({type:"ORGANISATION_RENAME_SPACE",id:f.id,name:B,expectedRevision:f.revision});$?.ok?(m=null,z.removeAttribute("data-error"),z.textContent=""):(z.dataset.error="true",z.textContent=ie($?.error)),await $e()}),L.addEventListener("click",()=>{m=null,vo()}),u.append(x,N,L),window.setTimeout(()=>x.focus(),0)}else{const x=g("button","llmorg-button","Rename");x.type="button",x.addEventListener("click",()=>{m=f.id,l=null,vo()}),u.append(x)}if(f.personal){Ee.append(u);continue}if(l===f.id){const x=g("span","llmorg-outcome","Remove this space? Chats stay in your library."),N=g("button","llmorg-button llmorg-button-danger","Confirm remove");N.type="button";const L=g("button","llmorg-button","Cancel");L.type="button",N.addEventListener("click",async()=>{const B=await fe({type:"ORGANISATION_REMOVE_SPACE",id:f.id});B?.ok?(l=null,z.removeAttribute("data-error"),z.textContent="",a===f.id&&(a=null)):(l=null,z.dataset.error="true",z.textContent=ie(B?.error)),await $e()}),L.addEventListener("click",()=>{l=null,vo()}),u.append(x,N,L)}else{const x=g("button","llmorg-button llmorg-button-danger","Remove");x.type="button",x.addEventListener("click",()=>{l=f.id,m=null,vo()}),u.append(x)}Ee.append(u)}}function ne(f,u=!1){u?gn.dataset.error="true":gn.removeAttribute("data-error"),gn.textContent=f}async function zd(f){try{const u=await fe({type:"ORGANISATION_CLAIM_ORGANISER_HANDOFF",token:f});u?.ok&&u.documentIds?(r=null,s=null,d=Array.from(new Set(u.documentIds)),ne(`${d.length} ${d.length===1?"chat":"chats"} selected from search. Pick a destination, then preview.`)):ne(ie(u?.error??"unknown-handoff"),!0)}catch(u){ne(u instanceof Error?u.message:"Could not load the selection.",!0)}We()}async function Fd(f){try{const u=await fe({type:"ORGANISATION_CLAIM_SCOPE_HANDOFF",token:f});u?.ok&&u.scope?(y=u.scope.kind==="spaces",q.removeAttribute("data-error"),q.textContent="Applying the scope chosen in your search bar...",await bo(u.scope),S.dataset.error||(q.textContent="Search scope updated from your search bar.")):(q.dataset.error="true",q.textContent=ie(u?.error??"unknown-handoff"))}catch(u){q.dataset.error="true",q.textContent=u instanceof Error?u.message:"Could not apply the requested scope."}}async function Dd(){if(!n||i||d.length===0)return;const f=a??n.spaces[0]?.id??null;if(!f){ne("Create a space first, or use Personal.",!0);return}a=f,i=!0,s=null,ne("Preparing preview..."),We();try{const u=await fe({type:"ORGANISATION_PREPARE_PREVIEW",documentIds:d,destinationSpaceId:f});if(!u?.ok||!u.preview||!u.previewId)ne(ie(u?.error)||"Could not prepare the preview.",!0);else{const P=u.titles??{},x=u.preview.documents.map(L=>{const B=L.placement;let $;if(B.state==="placed"){const E=B.placement?.spaceId;$=E?Le(n.spaces,E):"Placed"}else B.state==="needs-review"?$="Needs review":$="Unclassified";return{documentId:L.documentId,title:P[L.documentId]??L.documentId,current:$}});r={previewId:u.previewId,destinationSpaceId:u.preview.destinationSpaceId,documents:x,missingDocumentIds:u.preview.missingDocumentIds,confirmed:new Set(x.map(L=>L.documentId)),requestedCount:u.preview.requestedCount};const N=r.missingDocumentIds.length;ne(`Preview ready: ${x.length} ${x.length===1?"chat":"chats"} would move to ${Le(n.spaces,r.destinationSpaceId)}.`+(N>0?` ${N} ${N===1?"chat is":"chats are"} no longer in your library.`:""))}}catch(u){ne(u instanceof Error?u.message:"Could not prepare the preview.",!0)}finally{i=!1,We()}}async function Gd(){if(!(!n||!r||i||r.confirmed.size===0)){i=!0,ne("Filing selected chats..."),We();try{const f=await fe({type:"ORGANISATION_APPLY_PREVIEW",previewId:r.previewId,confirmedDocumentIds:Array.from(r.confirmed)});if(!f?.ok||!f.report)ne(ie(f?.error)||"Could not apply the preview.",!0);else{s={...f.report,titles:{...jd()}};const u=s.counts,P=[];u.applied&&P.push(`${u.applied} filed`),u.alreadyApplied&&P.push(`${u.alreadyApplied} already filed`),u.missing&&P.push(`${u.missing} missing`),u.stale&&P.push(`${u.stale} need a refreshed preview`),u.refused&&P.push(`${u.refused} refused`),ne(P.length>0?`Done: ${P.join(", ")}.`:"Nothing was applied.")}}catch(f){ne(f instanceof Error?f.message:"Could not apply the preview.",!0)}finally{i=!1,We()}}}function jd(){const f={};if(r)for(const u of r.documents)f[u.documentId]=u.title;return f}function We(){if(Ye.textContent="",!n||!n.enabled){Ot.hidden=!0;return}if(Ot.hidden=!1,d.length===0){const O=g("p","llmorg-note");O.textContent="No chats selected yet. In search, tick the chats to organise, then choose Organise selected chats.";const F=g("button","llmorg-button","Open search");F.type="button",F.addEventListener("click",()=>{chrome.tabs.create({url:chrome.runtime.getURL("search.html")})}),Ye.append(O,F);return}const f=g("p","llmorg-note");f.textContent=`${d.length} ${d.length===1?"chat":"chats"} selected.`;const u=g("div","llmorg-row"),P=g("label","llmorg-scope-option");P.htmlFor="llmorg-organiser-destination",P.append(document.createTextNode("Destination"));const x=g("select","llmorg-input");x.id="llmorg-organiser-destination";for(const O of n.spaces){const F=document.createElement("option");F.value=O.id,F.textContent=Le(n.spaces,O.id),x.append(F)}const N=a??n.spaces[0]?.id??"";x.value=N,a=N||null,x.addEventListener("change",()=>{a=x.value,r=null,s=null,ne("Destination changed. Prepare a new preview to continue."),We()}),u.append(P,x);const L=g("div","llmorg-row");L.style.marginTop="8px";const B=g("button","llmorg-button llmorg-button-primary",r?"Refresh preview":"Preview");B.type="button",B.disabled=i,B.addEventListener("click",()=>{Dd()});const $=g("button","llmorg-button llmorg-button-primary","Apply to selected chats");$.type="button",$.disabled=i||!r||r.confirmed.size===0,$.addEventListener("click",()=>{Gd()});const E=g("button","llmorg-button","Clear selection");if(E.type="button",E.disabled=i,E.addEventListener("click",()=>{d=[],r=null,s=null,ne(""),We()}),L.append(B,$,E),Ye.append(f,u,L),r){const O=g("div","llmorg-table"),F=document.createElement("table"),pe=document.createElement("thead"),Y=document.createElement("tr");for(const j of["Include","Chat","Current","After"]){const Ae=document.createElement("th");Ae.scope="col",Ae.textContent=j,Y.append(Ae)}pe.append(Y);const ue=document.createElement("tbody");for(const j of r.documents){const Ae=document.createElement("tr"),bs=document.createElement("td"),Vt=document.createElement("input");Vt.type="checkbox",Vt.checked=r.confirmed.has(j.documentId),Vt.setAttribute("aria-label",`Include ${j.title}`),Vt.addEventListener("change",()=>{Vt.checked?r.confirmed.add(j.documentId):r.confirmed.delete(j.documentId),$.disabled=i||r.confirmed.size===0,se.textContent=`${r.confirmed.size} of ${r.documents.length} selected chats will be filed.`}),bs.append(Vt);const vs=document.createElement("td");vs.textContent=j.title;const xs=document.createElement("td");xs.textContent=j.current;const ws=document.createElement("td");ws.textContent=Le(n.spaces,r.destinationSpaceId),Ae.append(bs,vs,xs,ws),ue.append(Ae)}F.append(pe,ue),O.append(F),Ye.append(O);const se=g("p","llmorg-status");if(se.textContent=`${r.confirmed.size} of ${r.documents.length} selected chats will be filed to ${Le(n.spaces,r.destinationSpaceId)}. Preparing a preview changes nothing until you apply it.`,Ye.append(se),r.missingDocumentIds.length>0){const j=g("p","llmorg-status");j.dataset.error="true",j.textContent=`${r.missingDocumentIds.length} selected ${r.missingDocumentIds.length===1?"chat is":"chats are"} no longer in your library and will stay unchanged.`,Ye.append(j)}}if(s){const O=g("div","llmorg-block"),F=g("h3","llmorg-heading","Last result");O.append(F);const pe=g("ul","llmorg-list");for(const Y of s.items){const ue=g("li"),se=s.titles[Y.documentId]??Y.documentId,j=tu[Y.outcome];ue.append(g("span","llmorg-space-name",se)),ue.append(g("span","llmorg-outcome",j+(Y.reason&&(Y.outcome==="stale"||Y.outcome==="refused")?`: ${ie(Y.reason)}`:""))),pe.append(ue)}if(O.append(pe),s.counts.stale>0){const Y=g("p","llmorg-note");Y.textContent="Some chats changed after the preview. That needs an explicit refresh: use Refresh preview, review the new preview, then apply again. Nothing was filed twice.",O.append(Y)}Ye.append(O)}}function Hd(){b.textContent="",b.append(w),h.checked=n?.enabled===!0,hs(),vo(),Ud(),We()}async function $e(){try{const f=await fe({type:"ORGANISATION_GET_STATE"});f?.ok?(n={ok:!0,enabled:f.enabled,scope:f.scope??lp,missingSpaceIds:f.missingSpaceIds??[],spaces:f.spaces??[],sources:f.sources??[],revisionToken:f.revisionToken??""},q.removeAttribute("data-error"),q.textContent=""):(q.dataset.error="true",q.textContent=ie(f?.error)||"Could not load organisation state.")}catch(f){q.dataset.error="true",q.textContent=f instanceof Error?f.message:"Could not load organisation state."}Hd()}return chrome.runtime.onMessage.addListener(f=>{f?.type==="ORGANISATION_CHANGED"&&$e()}),t&&zd(t),(async()=>(await $e(),o&&await Fd(o)))(),{refresh:$e}}const au=5e3;function su(e,t={}){const o=t.now??Date.now,n=t.cooldownMs??au;let a=0,r=null;return async()=>{if(r)return r;const s=o();if(s<a)return{kind:"cooldown",retryAt:a};a=s+n,r=e().then(i=>({kind:"response",response:i}));try{return await r}finally{r=null}}}function zs(e,t){return e?t===null?"unknown":t?"present":"absent":"absent"}function iu(e){const t=[],o=zs(e.vaultAvailable,e.vaultBackupExists);o==="present"?t.push("Your encrypted Vault backup is not deleted, and you can restore it to this browser or another one later."):o==="unknown"&&t.push("If you have set up Vault, its encrypted backup is not deleted and you can restore it later.");const n=zs(e.companionAvailable,e.companionCorpusExists);return n==="present"?t.push("The copy the desktop companion keeps on this computer is not deleted either; remove that folder yourself if you want it gone."):n==="unknown"&&t.push("If you set up the desktop companion, the copy it keeps on this computer is not deleted either."),t}function za(e){const t=iu(e),o=t.length>0?` ${t.join(" ")}`:"";return{description:`Permanently remove every indexed chat and saved memory from this browser.${o}`,confirm:`Delete all indexed conversations, messages, and token data from this browser profile?${o}`,done:t.length>0?`This browser's data is deleted.${o}`:"This browser's data is deleted."}}const Fa="Delete all cancelled. Nothing was deleted.",lu="Deleting this browser's data...",du="No destructive actions run.",Da="DELETE",cu=`Type ${Da} to enable the delete button.`;function pu(e){return e.trim().toUpperCase()===Da}function Ga(e){return e.filter(t=>t.source==="agent"&&!t.enabled&&t.agentReview!=="accepted"&&t.agentReview!=="rejected")}function Cl(e){return e.filter(t=>t.source!=="agent"||t.enabled||t.agentReview==="accepted")}async function uu(e,t){for(const o of Ga(e))await t(o.memoryId,!0)}const fu="llmnesia-extension-biometric-unlock",gu=1,xt="enrolments",ja=1,na=32,El=12,Fs=6e4;class mu{store;credentials;randomBytes;constructor(t={}){this.store=t.store??new yu,this.credentials=t.credentials??hu(),this.randomBytes=t.randomBytes??bu}async hasEnrollment(t){try{const o=await this.store.read(t);return!o||!js(o)||o.accountId!==t?(o&&await this.store.remove(t,o.enrolmentId),!1):!0}catch{return!1}}async prepareEnrollment(t,o){if(!t||!this.credentials||o.length===0)return null;const n=this.randomBytes(na);let a=null;try{const r=await this.credentials.create({publicKey:{challenge:le(this.randomBytes(32)),rp:{name:"LLMnesia"},user:{id:le(this.randomBytes(32)),name:"LLMnesia",displayName:"LLMnesia"},pubKeyCredParams:[{type:"public-key",alg:-7},{type:"public-key",alg:-257}],authenticatorSelection:{authenticatorAttachment:"platform",residentKey:"required",userVerification:"required"},timeout:Fs,extensions:{prf:{}}}});if(!Ds(r)||r.getClientExtensionResults().prf?.enabled!==!0||(a=await this.assertPrf(r.rawId,le(n)),!a))return null;const{nonce:s,ciphertext:i}=await xu(t,o,a,this.randomBytes);return{record:{version:ja,accountId:t,enrolmentId:Array.from(this.randomBytes(16)),credentialId:Array.from(new Uint8Array(r.rawId)),salt:Array.from(n),nonce:Array.from(s),ciphertext:Array.from(i)}}}catch{return null}finally{n.fill(0),a?.fill(0)}}async save(t){await this.store.save(t.record)}async unlock(t){if(!t||!this.credentials)return null;let o=null;try{const n=await this.store.read(t);return!n||!js(n)||n.accountId!==t?(n&&await this.store.remove(t,n.enrolmentId),null):(o=await this.assertPrf(le(new Uint8Array(n.credentialId)),le(new Uint8Array(n.salt))),o?await wu(t,n,o):null)}catch{return null}finally{o?.fill(0)}}async remove(t,o){await this.store.remove(t,o?.record.enrolmentId)}async assertPrf(t,o){if(!this.credentials)return null;const n=await this.credentials.get({publicKey:{challenge:le(this.randomBytes(32)),allowCredentials:[{type:"public-key",id:t}],userVerification:"required",timeout:Fs,extensions:{prf:{eval:{first:o}}}}});if(!Ds(n))return null;const a=n.getClientExtensionResults().prf?.results?.first,r=a?ku(a):null;return r?.byteLength===na?r:null}}class yu{async read(t){const o=await Lr();try{const n=await o.get(xt,t);return Gs(n)?n:null}finally{o.close()}}async save(t){const o=await Lr();try{await o.put(xt,t,t.accountId)}finally{o.close()}}async remove(t,o){const n=await Lr();try{if(!o){await n.delete(xt,t);return}const a=n.transaction(xt,"readwrite"),r=a.objectStore(xt),s=await r.get(t);Gs(s)&&vu(s.enrolmentId,o)&&await r.delete(t),await a.done}finally{n.close()}}}function Lr(){return bc(fu,gu,{upgrade(e){e.objectStoreNames.contains(xt)||e.createObjectStore(xt)}})}function hu(){return typeof navigator<"u"&&navigator.credentials?navigator.credentials:null}function bu(e){const t=new Uint8Array(e);return crypto.getRandomValues(t),t}function Ds(e){return e!==null&&"rawId"in e&&typeof e.getClientExtensionResults=="function"}function Gs(e){if(!e||typeof e!="object")return!1;const t=e;return t.version===ja&&typeof t.accountId=="string"&&Array.isArray(t.enrolmentId)&&Array.isArray(t.credentialId)&&Array.isArray(t.salt)&&Array.isArray(t.nonce)&&Array.isArray(t.ciphertext)}function js(e){return e.accountId.length>0&&e.enrolmentId.length===16&&e.credentialId.length>0&&e.salt.length===na&&e.nonce.length===El&&e.ciphertext.length>16&&[e.enrolmentId,e.credentialId,e.salt,e.nonce,e.ciphertext].every(t=>t.every(o=>Number.isInteger(o)&&o>=0&&o<=255))}function vu(e,t){if(e.length!==t.length)return!1;let o=0;for(let n=0;n<e.length;n++)o|=e[n]^t[n];return o===0}async function xu(e,t,o,n){const a=await crypto.subtle.importKey("raw",le(o),{name:"AES-GCM"},!1,["encrypt"]),r=n(El),s=new Uint8Array(await crypto.subtle.encrypt({name:"AES-GCM",iv:le(r),additionalData:$l(e)},a,le(t)));return{nonce:r,ciphertext:s}}async function wu(e,t,o){const n=await crypto.subtle.importKey("raw",le(o),{name:"AES-GCM"},!1,["decrypt"]);return new Uint8Array(await crypto.subtle.decrypt({name:"AES-GCM",iv:le(new Uint8Array(t.nonce)),additionalData:$l(e)},n,le(new Uint8Array(t.ciphertext))))}function $l(e){return le(new TextEncoder().encode(`llmnesia-extension-biometric-unlock:v${ja}:${e}`))}function le(e){const t=new Uint8Array(e.byteLength);return t.set(e),t.buffer}function ku(e){if(e instanceof ArrayBuffer)return new Uint8Array(e.slice(0));const t=e;return new Uint8Array(new Uint8Array(t.buffer,t.byteOffset,t.byteLength))}const Su="llmnesia-fs-handles",it="handles",Ha="mcp-corpus-root";function Al(){return typeof globalThis.showDirectoryPicker=="function"}function Ka(){return new Promise((e,t)=>{const o=indexedDB.open(Su,1);o.onupgradeneeded=()=>{const n=o.result;n.objectStoreNames.contains(it)||n.createObjectStore(it)},o.onsuccess=()=>e(o.result),o.onerror=()=>t(o.error)})}async function Cu(e){const t=await Ka();try{const o=t.transaction(it,"readwrite");o.objectStore(it).put(e,Ha),await new Promise((n,a)=>{o.oncomplete=()=>n(),o.onerror=()=>a(o.error),o.onabort=()=>a(o.error)})}finally{t.close()}}async function Ll(){const e=await Ka();try{const t=e.transaction(it,"readonly");return await new Promise((n,a)=>{const r=t.objectStore(it).get(Ha);r.onsuccess=()=>n(r.result),r.onerror=()=>a(r.error)})??null}finally{e.close()}}async function Eu(){const e=await Ka();try{const t=e.transaction(it,"readwrite");t.objectStore(it).delete(Ha),await new Promise((o,n)=>{t.oncomplete=()=>o(),t.onerror=()=>n(t.error)})}finally{e.close()}await vc()}class Il extends Error{}async function $u(){const e=globalThis.showDirectoryPicker;if(!e)throw new Error("showDirectoryPicker is unavailable in this page.");let t;try{t=await e({id:"llmnesia-corpus",mode:"readwrite"})}catch(o){throw o instanceof Error&&o.name==="AbortError"?new Il("Folder selection cancelled."):o}return await Cu(t),t}async function Au(e,{prompt:t}){const o={mode:"readwrite"};return await e.queryPermission(o)==="granted"||await e.requestPermission(o)==="granted"}async function Lu(e,t={}){const o=t.full===!0,n=await xc({full:o,compress:!0});if(!n.result)return wc(o,n.priorWatermark);const a=await e.getDirectoryHandle("inbox",{create:!0});for(const s of n.result.chunks){const l=await(await a.getFileHandle(s.filename,{create:!0})).createWritable();try{await l.write(s.blob)}finally{await l.close()}}const r=await kc(n);return{full:o,conversationCount:n.result.conversationCount,messageCount:n.result.messageCount,chunkCount:n.result.chunks.length,watermark:r,upToDate:!1}}function Tl(e,t){e.input.type=t?"text":"password",e.button.textContent=t?"Hide":"Show",e.button.setAttribute("aria-pressed",String(t)),e.button.setAttribute("aria-label",`${t?"Hide":"Show"} ${e.label}`)}function Iu(e){e.button.addEventListener("click",()=>{const t=e.input.type==="password";Tl(e,t),e.input.focus()})}function ra(e){if(!e||typeof e!="object"||Array.isArray(e))return null;const t=e;return typeof t.conversation_id=="string"&&t.conversation_id?t.conversation_id:typeof t.id=="string"&&t.id?t.id:null}function Tu(e,t=new Map){if(!e||typeof e!="object"||Array.isArray(e))return null;const o=e,n=ra(e);if(!n)return null;const a=o.mapping&&typeof o.mapping=="object"?Object.fromEntries(Object.entries(o.mapping).map(([i,l])=>{if(!l||typeof l!="object")return[i,l];const m=l,y=m.message?.content?.parts;return Array.isArray(y)?[i,{...m,message:{...m.message,content:{...m.message.content,parts:y.map(d=>{if(d?.content_type!=="image_asset_pointer")return d;const v=hl(d.asset_pointer,t);return v?{...d,image_url:v}:d})}}}]:[i,l]})):o.mapping,r={...o,mapping:a,conversation_id:n},s=new URL(`https://chatgpt.com/c/${encodeURIComponent(n)}`);return fp(r,s)}const aa=new Set(["anthropic_console","generic"]),sa="llmnesia.search.recentLimit",Rl=30,Ru=[30,50,100,250,500];function ur(e){return e?new Date(e).toLocaleString():"Never"}function Dn(e){return e<1024?`${e} B`:e<1024*1024?`${(e/1024).toFixed(1)} KB`:e<1024*1024*1024?`${(e/(1024*1024)).toFixed(1)} MB`:`${(e/(1024*1024*1024)).toFixed(2)} GB`}function k(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#39;")}function Je(e,t,o,n){return`
    <div class="options-stat-card" data-stat="${e}">
      <div class="options-stat-label">${t}</div>
      <strong class="options-stat-value"${n===void 0?"":` data-val="${n}"`}>${o}</strong>
    </div>
  `}function Pl(){const e='<div class="options-stat-card"><span class="stats-skel" style="height:9px; width:64%; margin-bottom:8px;"></span><span class="stats-skel" style="height:16px; width:46%;"></span></div>',t=Array.from({length:8},()=>e).join(""),o='<div style="display:grid; grid-template-columns:120px 1fr auto; gap:10px; align-items:center;"><span class="stats-skel" style="height:10px; width:72%;"></span><span class="stats-skel" style="height:14px; border-radius:7px;"></span><span class="stats-skel" style="height:10px; width:70px;"></span></div>',n=Array.from({length:4},()=>o).join("");return`<div style="display:grid; grid-template-columns:repeat(auto-fit,minmax(180px,1fr)); gap:8px; align-items:stretch;">${t}</div><div style="margin-top:12px; border-top:1px dashed #d7dfcb; padding-top:10px;"><span class="stats-skel" style="height:11px; width:150px; margin-bottom:12px;"></span><div style="display:grid; gap:7px;">${n}</div></div>`}const hn=[{key:"d7",label:"7 days"},{key:"d30",label:"30 days"},{key:"d90",label:"90 days"},{key:"all",label:"All time"}],Pu=[{key:"chats",label:"Chats"},{key:"msgs",label:"Messages"}];let lt=[],Pt="all",Gn="chats";function _u(e,t,o){if(t.startsWith("y")){const n=e.byYear[t.slice(1)];return n?o==="chats"?n.chats:n.msgs:0}return o==="chats"?t==="d7"?e.chats7:t==="d30"?e.chats30:t==="d90"?e.chats90:e.chatsAll:t==="d7"?e.msgs7:t==="d30"?e.msgs30:t==="d90"?e.msgs90:e.msgsAll}function ia(e=3){const t=new Set;for(const o of lt)for(const n of Object.keys(o.byYear))t.add(n);return Array.from(t).sort((o,n)=>Number(n)-Number(o)).slice(0,e)}function _l(e){if(!e)return"no date";const t=Date.now()-e,o=864e5;if(t<o)return"today";const n=Math.floor(t/o);return n<7?`${n}d ago`:n<30?`${Math.floor(n/7)}w ago`:n<365?`${Math.floor(n/30)}mo ago`:`${Math.floor(n/365)}y ago`}const la="width .5s cubic-bezier(.22,.61,.36,1), opacity .4s ease",Nl="transform .45s cubic-bezier(.22,.61,.36,1), opacity .35s ease";function Ml(){return typeof window.matchMedia=="function"&&window.matchMedia("(prefers-reduced-motion: reduce)").matches}function Ol(e){return e?"background:#1f6fd6 !important; color:#fff !important; border:1px solid #1a5fb8 !important; font-weight:600 !important;":"background:#fff !important; color:#3a4b58 !important; border:1px solid #d3dcc4 !important; font-weight:400 !important;"}const Bl="padding:4px 10px; border-radius:7px !important; cursor:pointer; font-size:12px; transition:background .2s ease, color .2s ease, border-color .2s ease; ";function Hs(e,t){e.setAttribute("aria-pressed",String(t)),e.style.cssText=Bl+Ol(t)}function Ks(e,t,o,n){return`<button type="button" data-${t}="${o}" aria-pressed="${e}" style="${Bl}${Ol(e)}">${n}</button>`}function ql(){const e=(s,i)=>`<div style="display:flex; align-items:center; gap:6px;"><span style="font-size:12px; color:#7a8a96;">${s}</span><div style="display:flex; gap:4px; flex-wrap:wrap;">${i}</div></div>`,t=ia().map(s=>({key:`y${s}`,label:s})),o=hn.findIndex(s=>s.key==="all"),a=(o>=0?[...hn.slice(0,o),...t,...hn.slice(o)]:[...hn,...t]).map(s=>Ks(Pt===s.key,"range",s.key,s.label)).join(""),r=Pu.map(s=>Ks(Gn===s.key,"metric",s.key,s.label)).join("");return`<div style="display:flex; flex-wrap:wrap; gap:16px; align-items:center; margin-top:8px;">${e("Active in",a)}${e("Show",r)}</div>`}function Ys(e,t){const o=Sp(e.platform),n=Pt==="all";return`<div class="pf-row" data-platform="${k(e.platform)}" style="display:grid; grid-template-columns:120px 1fr auto; gap:10px; align-items:center; transition:${Nl};"><div style="overflow:hidden; text-overflow:ellipsis; white-space:nowrap; font-weight:600;">${k(o.label)}</div><div style="height:14px; border-radius:7px; background:${o.pillBg}; overflow:hidden;"><div class="pf-fill" style="height:100%; width:${t.barPct}%; border-radius:7px; background:${o.accent}; opacity:${t.barOpacity.toFixed(2)}; transition:${la};"></div></div><div style="font-variant-numeric:tabular-nums; white-space:nowrap; color:#3a4b58;"><strong class="pf-value" data-val="${t.value}">${t.value.toLocaleString()}</strong> <span class="pf-pct" style="color:#7a8a96;">(${t.pct}%)</span><span class="pf-last" style="color:#9aa8b4; margin-left:8px; font-weight:400;${n?"":" display:none;"}">${n?k(_l(e.lastUsedAt)):""}</span></div></div>`}function Vl(e,t,o){return{value:e,pct:o>0?Math.round(e/o*100):0,barPct:e>0&&t>0?Math.max(2,Math.round(e/t*100)):0,barOpacity:t>0?.5+.5*(e/t):.5}}function Ul(){const e=lt.map(n=>({u:n,value:_u(n,Pt,Gn)})).sort((n,a)=>a.value-n.value||a.u.chatsAll-n.u.chatsAll||n.u.platform.localeCompare(a.u.platform)),t=e.reduce((n,a)=>Math.max(n,a.value),0),o=e.reduce((n,a)=>n+a.value,0);return{ordered:e,max:t,total:o}}function zl(e=!1){const t={value:0,pct:0,barPct:0,barOpacity:.5},o=Ul();return`<div id="platform-breakdown-rows" style="margin-top:10px; display:grid; gap:7px;">${e?o.ordered.map(({u:a,value:r})=>Ys(a,Vl(r,o.max,o.total))).join(""):[...lt].sort((a,r)=>r.chatsAll-a.chatsAll||a.platform.localeCompare(r.platform)).map(a=>Ys(a,t)).join("")}<div id="platform-breakdown-empty" style="color:#496073; display:none;"></div></div>`}function Fl(){const e=String(new Date().getFullYear()),t=["J","F","M","A","M","J","J","A","S","O","N","D"],o=["January","February","March","April","May","June","July","August","September","October","November","December"];let n=0,a=0,r=0;const s=new Array(12).fill(0);for(const b of lt){const h=b.byYear[e];h&&(n+=h.chats,a+=h.msgs,r+=1);for(let w=0;w<12;w+=1){const C=b.byMonth[`${e}-${String(w+1).padStart(2,"0")}`];C&&(s[w]+=C.chats)}}if(n===0)return"";const i=Math.max(...s),l=i>0?s.indexOf(i):-1,m=s.map((b,h)=>{const w=b>0?Math.max(6,Math.round(b/i*100)):0,C=h===l;return`<div class="year-bar-col"><div class="year-bar-track" title="${o[h]} ${e}: ${b.toLocaleString()} chat${b===1?"":"s"}"><div class="year-bar${C?" peak":""}" style="height:${w}%;"></div></div><span class="year-bar-label">${t[h]}</span></div>`}).join(""),y=(b,h)=>`<div><div class="year-stat-num">${b}</div><div class="year-stat-label">${h}</div></div>`,d=r===1?"AI":"AIs",v=l>=0?`<div class="year-caption">Busiest in <strong>${o[l]}</strong> · ${i.toLocaleString()} chat${i===1?"":"s"}.</div>`:"";return`<div class="year-card"><div class="year-card-head">Your ${e} in AI</div><div class="year-stats">${y(n.toLocaleString(),"chats")}${y(a.toLocaleString(),"messages")}${y(String(r),d+" used")}</div><div class="year-spark">${m}</div>${v}</div>`}function Nu(){return`<div id="year-summary-slot">${Fl()}</div><strong>Usage by platform</strong><div id="platform-controls-slot">${ql()}</div><div id="platform-rows-slot">${zl()}</div>`}function Mu(e,t,o,n){if(n){e.style.transition=la,e.style.width=`${t}%`,e.style.opacity=o.toFixed(2);return}e.style.transition="none",e.style.width=`${t}%`,e.style.opacity=o.toFixed(2),e.offsetWidth,e.style.transition=la}function Dl(e,t,o){const n=Number(e.dataset.val??"0");if(e.dataset.val=String(t),!o||n===t){e.textContent=t.toLocaleString();return}const a=performance.now(),r=450,s=i=>{const l=Math.min(1,(i-a)/r),m=1-Math.pow(1-l,3);e.textContent=Math.round(n+(t-n)*m).toLocaleString(),l<1&&requestAnimationFrame(s)};requestAnimationFrame(s)}function jn(e){const t=document.querySelector("#platform-breakdown-rows"),o=document.querySelector("#platform-breakdown-empty");if(!t)return;const n=e&&!Ml(),a=y=>t.querySelector(`.pf-row[data-platform="${y}"]`),{ordered:r,max:s,total:i}=Ul(),l=lt.length===0;o&&(l&&(o.textContent="No chats indexed yet."),o.style.display=l?"":"none");const m=new Map;n&&lt.forEach(y=>{const d=a(y.platform);d&&m.set(y.platform,d.getBoundingClientRect().top)}),r.forEach(y=>{const d=a(y.u.platform);d&&t.appendChild(d)}),o&&t.appendChild(o),r.forEach(y=>{const d=a(y.u.platform);if(!d)return;const v=d.querySelector(".pf-fill"),b=d.querySelector(".pf-value"),h=d.querySelector(".pf-pct"),w=d.querySelector(".pf-last"),C=Vl(y.value,s,i);h&&(h.textContent=`(${C.pct}%)`),w&&(w.textContent=Pt==="all"?_l(y.u.lastUsedAt):"",w.style.display=Pt==="all"?"":"none"),b&&Dl(b,y.value,n),v&&Mu(v,C.barPct,C.barOpacity,n),n||(d.style.opacity=y.value===0?"0.4":"1")}),n&&(r.forEach(y=>{const d=a(y.u.platform),v=m.get(y.u.platform);if(!d||v===void 0)return;const b=v-d.getBoundingClientRect().top;d.style.transition="none",d.style.transform=b?`translateY(${b}px)`:""}),requestAnimationFrame(()=>{r.forEach(y=>{const d=a(y.u.platform);d&&(d.style.transition=Nl,d.style.transform="",d.style.opacity=y.value===0?"0.4":"1")})}))}function Ws(){const e=document.querySelector("#platform-breakdown-block");e&&(e.querySelectorAll("[data-range]").forEach(t=>{t.addEventListener("click",()=>{const o=t.getAttribute("data-range");!o||o===Pt||(Pt=o,e.querySelectorAll("[data-range]").forEach(n=>{Hs(n,n.getAttribute("data-range")===o)}),jn(!0))})}),e.querySelectorAll("[data-metric]").forEach(t=>{t.addEventListener("click",()=>{const o=t.getAttribute("data-metric");!o||o===Gn||(Gn=o,e.querySelectorAll("[data-metric]").forEach(n=>{Hs(n,n.getAttribute("data-metric")===o)}),jn(!0))})}))}function Gl(e){const t=Number(e);return Ru.includes(t)?t:Rl}function U(e,t="Unknown runtime error"){return e instanceof Error?e.message:t}mp("options_page","options");ip();const jl=document.querySelector("#app");if(!jl)throw new Error("Options app root not found");const ke=/win/i.test(navigator.userAgent),Mt=/mac/i.test(navigator.userAgent),Ou=ke?"https://www.llmnesia.com/download/node/windows":Mt?"https://www.llmnesia.com/download/node/macos":"https://nodejs.org/en/download",Bu=ke?"Download Node.js for Windows":Mt?"Download Node.js for Mac":"Download the current Node.js LTS release",Ir=ke?"PowerShell":Mt?"Terminal":"your terminal",Hl=ke?"Open PowerShell: press the Windows key, type PowerShell, then select Windows PowerShell. Do not choose Run as administrator.":Mt?"Open Terminal: press Command + Space, type Terminal, then press Return.":"Open your terminal app.",qu=ke?"In PowerShell, right-click once to paste, then press Enter.":Mt?"In Terminal, press Command + V to paste, then press Return.":"Paste it in your terminal, then press Enter.",Js=ke?"Fully quit every browser window, then reopen your browser.":Mt?"Fully quit your browser with Command + Q—not just the window—then reopen it.":"Fully quit your browser, then reopen it.",Vu=ke?' <a href="https://www.llmnesia.com/download/node/windows-arm64" target="_blank" rel="noopener" style="color: #2b6588;">Running Windows on an ARM device or in VMware on an Apple-silicon Mac? Use the ARM installer instead.</a>':"",Uu="https://www.llmnesia.com/download/claude/llmnesia.mcpb",Kl=3,zu=Kl+1,Fu="Search for memory, backup, MCP, Vault…";let Yl=null,Wl=null;function Ya(){return{vaultAvailable:!0,vaultBackupExists:Yl,companionAvailable:!0,companionCorpusExists:Wl}}const Wa=ke?`cmd.exe /d /c npx --yes --loglevel=error --no-update-notifier @llmnesia/mcp@latest install ${chrome.runtime.id}`:`npx --yes --loglevel=error --no-update-notifier @llmnesia/mcp@latest install ${chrome.runtime.id}`,Xe=`padding: 6px 10px; border-radius: 8px; border: 1px solid ${p.tealEdge} !important; background: #fff !important; color: #1c5a6e !important; cursor: pointer; font-weight: 600; white-space: nowrap;`;jl.innerHTML=`
	  <style>
      :root {
        color-scheme: light;
      }
	    html, body {
	      margin: 0;
	      padding: 0;
	      overflow-x: hidden;
        background:
          radial-gradient(circle at 12% 0%, rgba(78, 138, 91, 0.08), transparent 28rem),
          radial-gradient(circle at 92% 12%, rgba(47, 127, 153, 0.07), transparent 25rem),
          ${p.paper};
	    }

	    *, *::before, *::after {
	      box-sizing: border-box;
	    }
      #llmnesia-options-root {
        color: ${p.ink} !important;
      }
      #llmnesia-options-root h1,
      #llmnesia-options-root h2 {
        color: #11273a;
        letter-spacing: 0;
      }
      #llmnesia-options-root a {
        color: #2b6588;
      }
      #llmnesia-options-root a:focus-visible,
      #llmnesia-options-root button:focus-visible,
      #llmnesia-options-root input:focus-visible,
      #llmnesia-options-root select:focus-visible,
      #llmnesia-options-root summary:focus-visible {
        outline: 3px solid rgba(47, 127, 153, 0.34);
        outline-offset: 2px;
      }
      #llmnesia-options-root section[data-settings-section],
      #llmnesia-options-root details[data-settings-section] {
        scroll-margin-top: 18px;
      }
      #llmnesia-options-root {
        display: flex;
        flex-direction: column;
      }
      .settings-header {
        order: 1;
        max-width: 760px;
        margin-bottom: 18px;
      }
      .settings-setup-card {
        order: 2;
        margin: 0 0 16px;
        border: 1px solid #254d52;
        border-radius: 16px;
        padding: 18px;
        background: linear-gradient(135deg, #17364e 0%, #24515a 54%, #315f4c 100%);
        box-shadow: 0 10px 28px rgba(18, 48, 59, 0.16);
      }
      .settings-setup-head {
        display: flex;
        align-items: baseline;
        justify-content: space-between;
        gap: 12px;
        flex-wrap: wrap;
      }
      .settings-setup-eyebrow,
      .settings-nav-label {
        color: #5f8669;
        font-size: 10px;
        font-weight: 700;
        letter-spacing: 0.08em;
        text-transform: uppercase;
      }
      .settings-setup-title {
        margin: 0;
        color: #fff !important;
        font-size: 18px;
      }
      .settings-setup-description {
        margin: 6px 0 14px;
        color: #dce9e4;
        font-size: 12.5px;
      }
      .settings-setup-card .settings-setup-eyebrow {
        color: #c8e9d4;
      }
      .settings-setup-card .settings-setup-head > span {
        color: #dcebe5 !important;
      }
      .settings-setup-grid {
        display: grid;
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 10px;
      }
      .settings-setup-link {
        position: relative;
        display: grid;
        grid-template-columns: 26px minmax(0, 1fr) auto;
        gap: 10px;
        align-items: center;
        min-width: 0;
        padding: 13px 14px;
        border: 1px solid rgba(255, 255, 255, 0.6);
        border-radius: 11px;
        background: #ffffff;
        color: #1c3d2a !important;
        text-decoration: none;
        box-shadow: 0 2px 6px rgba(10, 30, 40, 0.22);
        transition: border-color 0.15s ease, box-shadow 0.15s ease, transform 0.15s ease;
        overflow: hidden;
      }
      /* Every destination section opens with a 4px coloured left bar, so the
         tiles repeat that signature (colours set per accent below). */
      .settings-setup-link::before {
        content: "";
        position: absolute;
        left: 0;
        top: 0;
        bottom: 0;
        width: 4px;
        background: var(--setup-accent, #6fae85);
      }
      .settings-setup-link:hover {
        border-color: #6fae85;
        box-shadow: 0 4px 12px rgba(10, 30, 40, 0.3);
        transform: translateY(-1px);
      }
      .settings-setup-link:focus-visible {
        outline: 2px solid #fff;
        outline-offset: 2px;
      }
      /* Each accent mirrors the destination section's RENDERED palette. The
         sections' inline colours are overridden by the group rules above
         (.settings-section forces var(--settings-accent) with !important), so
         these match the vars, not the inline styles: vault = indigo (#506fca),
         green = connections cards (MCP and local sessions both render the
         connections green), blue = data cards (backup). */
      .settings-setup-link[data-accent="vault"] {
        --setup-accent: #506fca;
        border-color: #a3b4e8;
        background: linear-gradient(180deg, #ffffff, #f5f7ff);
        color: #294b9c !important;
      }
      .settings-setup-link[data-accent="vault"]:hover {
        border-color: #506fca;
      }
      .settings-setup-link[data-accent="green"] {
        --setup-accent: #4f8a5b;
        border-color: #a9cdb0;
        background: linear-gradient(180deg, #ffffff, #f3faf4);
        color: #244b32 !important;
      }
      .settings-setup-link[data-accent="green"]:hover {
        border-color: #315a3e;
      }
      .settings-setup-link[data-accent="blue"] {
        --setup-accent: #3d6fa8;
        border-color: #a8c2df;
        background: linear-gradient(180deg, #ffffff, #f3f8fd);
        color: #1d4f78 !important;
      }
      .settings-setup-link[data-accent="blue"]:hover {
        border-color: #4c88b8;
      }
      .settings-setup-number {
        display: inline-flex;
        width: 26px;
        height: 26px;
        align-items: center;
        justify-content: center;
        border-radius: 8px;
        background: #2e7d4f;
        color: #fff;
        font-size: 13px;
        font-weight: 800;
        box-shadow: inset 0 -1px 0 rgba(10, 30, 40, 0.25);
      }
      [data-accent="vault"] .settings-setup-number {
        background: #3956a7;
      }
      [data-accent="green"] .settings-setup-number {
        background: #315a3e;
      }
      [data-accent="blue"] .settings-setup-number {
        background: #3d6fa8;
      }
      [data-accent="vault"] .settings-setup-arrow { color: #506fca; }
      [data-accent="green"] .settings-setup-arrow { color: #315a3e; }
      [data-accent="blue"] .settings-setup-arrow { color: #3d6fa8; }
      .settings-setup-copy {
        min-width: 0;
      }
      .settings-setup-copy strong,
      .settings-setup-copy small {
        display: block;
      }
      .settings-setup-copy strong {
        font-size: 13.5px;
        font-weight: 750;
      }
      .settings-setup-copy small {
        margin-top: 3px;
        color: #3d5266;
        font-size: 12px;
        line-height: 1.4;
      }
      .settings-setup-arrow {
        color: #6fae85;
        font-size: 18px;
        font-weight: 700;
        transition: transform 0.15s ease;
      }
      .settings-setup-link:hover .settings-setup-arrow {
        transform: translateX(3px);
      }
      .settings-nav {
        position: sticky;
        top: 0;
        z-index: 4;
        order: 3;
        margin: 0 0 4px;
        padding: 11px 14px;
        border: 1px solid #d4ddd7;
        border-radius: 13px;
        background: rgba(255, 255, 255, 0.92);
        box-shadow: 0 5px 16px rgba(38, 61, 72, 0.08);
        backdrop-filter: blur(8px);
      }
      .settings-search-row {
        display: flex;
        align-items: center;
        gap: 8px;
      }
      .settings-search-label {
        flex: 0 0 auto;
        color: #2f4654;
        font-size: 12.5px;
        font-weight: 600;
      }
      .settings-search-wrap {
        position: relative;
        flex: 1 1 260px;
        min-width: 0;
      }
      .settings-search-wrap::before {
        position: absolute;
        top: 50%;
        left: 11px;
        color: #7a8a96;
        content: "⌕";
        font-size: 18px;
        line-height: 1;
        transform: translateY(-53%);
      }
      #settings-search {
        width: 100%;
        min-width: 0;
        padding: 8px 42px 8px 31px !important;
        border: 1px solid #cbd6d0 !important;
        border-radius: 8px;
        box-shadow: inset 0 1px 2px rgba(28, 54, 67, 0.05);
        font-size: 13px;
      }
      .settings-search-key {
        position: absolute;
        top: 50%;
        right: 8px;
        padding: 2px 5px;
        border: 1px solid #dbe2cf;
        border-radius: 4px;
        background: #f7f9f1;
        color: #7a8a96;
        font-family: "IBM Plex Mono", "SF Mono", "Consolas", monospace;
        font-size: 10px;
        transform: translateY(-50%);
      }
      #settings-search-status {
        margin: 6px 0 0 76px;
        color: #506271;
        font-family: "IBM Plex Mono", "SF Mono", "Consolas", monospace;
        font-size: 11px;
      }
      .settings-nav-links {
        display: flex;
        flex-wrap: wrap;
        gap: 5px;
        align-items: center;
        margin-top: 7px;
        padding-top: 7px;
        border-top: 1px solid #edf0ea;
      }
      .settings-nav-links a {
        padding: 4px 8px;
        border: 1px solid transparent;
        border-radius: 999px;
        color: #526b79;
        font-size: 11.5px;
        text-decoration: none;
      }
      .settings-nav-links a:hover,
      .settings-nav-links a[aria-current="true"] {
        border-color: #b7d8d0;
        background: #eaf5f2;
        color: #1c5a6e;
        font-weight: 600;
      }
      .settings-nav-links a[data-settings-nav="vault-card"] {
        border-color: #c4d0f3;
        background: #f2f5ff;
        color: #294b9c;
        font-weight: 650;
      }
      .settings-nav-links a[data-settings-nav="vault-card"]:hover,
      .settings-nav-links a[data-settings-nav="vault-card"][aria-current="true"] {
        border-color: #7b97df;
        background: #e3ebff;
        color: #1c3d8f;
      }
      .settings-group-heading {
        display: grid;
        grid-template-columns: auto 1fr;
        gap: 10px;
        align-items: center;
        margin: 28px 2px 0;
        color: #58706a;
      }
      .settings-group-heading[hidden] {
        display: none !important;
      }
      .settings-group-heading::after {
        height: 1px;
        background: linear-gradient(90deg, #cad5ce, transparent);
        content: "";
      }
      .settings-group-heading strong {
        color: #284459;
        font-size: 12px;
        letter-spacing: 0.075em;
        text-transform: uppercase;
      }
      .settings-group-heading span {
        display: block;
        margin-top: 2px;
        color: #526675;
        font-size: 11.5px;
        font-weight: 400;
        letter-spacing: 0;
        text-transform: none;
      }
      .settings-group-heading[data-settings-group-heading="overview"] strong { color: #4d6b39; }
      .settings-group-heading[data-settings-group-heading="knowledge"] strong { color: #23677d; }
      .settings-group-heading[data-settings-group-heading="connections"] strong { color: #315a3e; }
      .settings-group-heading[data-settings-group-heading="data"] strong { color: #315f91; }
      .settings-group-heading[data-settings-group-heading="advanced"] strong { color: #526771; }
      .settings-section {
        --settings-accent: #7a9b57;
        --settings-action: #4d6b39;
        --settings-edge: #b8c99c;
        --settings-tint: rgba(122, 155, 87, 0.13);
        --settings-label-tint: #edf4e2;
        order: 10;
        margin-top: 12px !important;
        border: 1px solid var(--settings-edge) !important;
        border-left: 6px solid var(--settings-accent) !important;
        border-radius: 14px !important;
        padding: 18px 19px !important;
        background: linear-gradient(105deg, var(--settings-tint) 0%, #fff 54%) !important;
        box-shadow: 0 4px 13px rgba(30, 55, 65, 0.08), inset 0 1px rgba(255, 255, 255, 0.82);
      }
      .settings-section[data-settings-group="knowledge"] {
        --settings-accent: #2f7f99;
        --settings-action: #23677d;
        --settings-edge: #9ac8d5;
        --settings-tint: rgba(47, 127, 153, 0.14);
        --settings-label-tint: #e1f2f6;
      }
      .settings-section[data-settings-group="connections"] {
        --settings-accent: #4f8a5b;
        --settings-action: #315a3e;
        --settings-edge: #a9cdb0;
        --settings-tint: rgba(79, 138, 91, 0.14);
        --settings-label-tint: #e5f2e7;
      }
      /* Google AI Mode inherits the connections group palette (green bar,
         label pill, tinted gradient) like the other connections cards; the
         old grey muting override hid all of it and made the card read as a
         bare box. Only the state pill and toggle get card-specific styles. */
      #llmnesia-options-root #google-ai-mode-state {
        display: inline-flex;
        align-items: center;
        padding: 4px 10px;
        border: 1px solid var(--settings-edge) !important;
        border-radius: 999px;
        background: var(--settings-label-tint) !important;
        color: var(--settings-action) !important;
        font-size: 11px !important;
        font-weight: 750 !important;
        letter-spacing: 0.05em;
        text-transform: uppercase;
      }
      #llmnesia-options-root #google-ai-mode-state[data-state="on"] {
        border-color: #a7d6bf !important;
        background: #f0faf4 !important;
        color: #20543b !important;
      }
      #llmnesia-options-root #google-ai-mode-state[data-state="off"] {
        border-color: #d5dedf !important;
        background: #f4f7f7 !important;
        color: #526771 !important;
      }
      #llmnesia-options-root #google-ai-mode-state[data-state="error"] {
        border-color: #e8c8a8 !important;
        background: #fdf3ea !important;
        color: #9a5b1c !important;
      }
      #llmnesia-options-root #google-ai-mode-toggle:disabled {
        opacity: 0.6;
        cursor: not-allowed;
        filter: none !important;
      }
      .settings-section[data-settings-group="data"] {
        --settings-accent: #3d6fa8;
        --settings-action: #315f91;
        --settings-edge: #a8c2df;
        --settings-tint: rgba(61, 111, 168, 0.14);
        --settings-label-tint: #e6eff9;
      }
      .settings-section[data-settings-group="advanced"] {
        --settings-accent: #87969d;
        --settings-action: #526771;
        --settings-edge: #c4cfd3;
        --settings-tint: rgba(90, 111, 122, 0.11);
        --settings-label-tint: #edf1f2;
      }
      #danger-zone-section {
        --settings-accent: #b83d3d;
        --settings-action: #983434;
        --settings-edge: #dfadad;
        --settings-tint: rgba(184, 61, 61, 0.12);
        --settings-label-tint: #fbeaea;
      }
      .settings-section[data-settings-label]::before {
        display: inline-flex;
        width: fit-content;
        margin-bottom: 5px;
        padding: 3px 7px;
        border: 1px solid var(--settings-edge);
        border-radius: 999px;
        background: var(--settings-label-tint);
        color: var(--settings-action);
        content: attr(data-settings-label);
        font-size: 10.5px;
        font-weight: 750;
        letter-spacing: 0.075em;
        text-transform: uppercase;
      }
      .settings-section:not(#corpus-native-card):not(#vault-card) > h2,
      .settings-section:not(#corpus-native-card):not(#vault-card) > div:first-child h2 {
        margin-top: 0 !important;
        color: #183346 !important;
        font-size: 17px !important;
        line-height: 1.3;
      }
      #danger-zone-section > h2 {
        color: #702525 !important;
      }
      .settings-card-description {
        max-width: 780px;
        margin-top: 6px !important;
        margin-bottom: 13px !important;
        color: #4d6254 !important;
        font-size: 13px;
        line-height: 1.58 !important;
      }
      .settings-card-description strong {
        color: #2a4533;
      }
      .settings-actions {
        display: flex;
        gap: 8px;
        align-items: center;
        flex-wrap: wrap;
      }
      .settings-status-panel {
        margin-top: 11px !important;
        padding: 9px 11px;
        border: 1px solid #d5dfd7;
        border-left: 3px solid var(--settings-accent);
        border-radius: 8px;
        background: #f7faf8;
        color: #344d3b !important;
        font-size: 12.5px;
        line-height: 1.5;
        overflow-wrap: anywhere;
        word-break: break-word;
      }
      .settings-status-panel:empty {
        display: none;
      }
      .settings-subpanel {
        border: 1px solid #d8e1da !important;
        border-radius: 10px !important;
        background: rgba(255, 255, 255, 0.82) !important;
      }
      .settings-section[data-settings-group="connections"] .settings-subpanel > div:first-child {
        color: var(--settings-action) !important;
      }
      .settings-section details > summary {
        color: #365166 !important;
        font-weight: 600;
      }
      #llmnesia-options-root input[type="text"],
      #llmnesia-options-root input[type="email"],
      #llmnesia-options-root input[type="search"],
      #llmnesia-options-root textarea,
      #llmnesia-options-root select {
        border-color: #bdcbc1 !important;
        border-radius: 8px !important;
        background: #fff !important;
        color: #203d2b !important;
      }
      #llmnesia-options-root .settings-primary-action {
        border-color: var(--settings-action) !important;
        background: var(--settings-action) !important;
        color: #fff !important;
        font-weight: 700 !important;
      }
      #llmnesia-options-root .settings-danger-action {
        border-color: #a13a3a !important;
        background: #a13a3a !important;
        color: #fff !important;
        font-weight: 700 !important;
      }
      /* The armed delete button only looks dangerous once the typed phrase
         matches; until then it reads as inert, not clickable. */
      #llmnesia-options-root .settings-danger-action:disabled {
        border-color: #d6a7a7 !important;
        background: #f1e3e3 !important;
        color: #a38383 !important;
        font-weight: 600 !important;
        cursor: not-allowed !important;
        filter: none !important;
      }
      #llmnesia-options-root button:not(:disabled):hover,
      #llmnesia-options-root .settings-setup-link:hover {
        filter: brightness(0.97);
      }
      .vault-paywall {
        display: flex;
        flex-direction: column;
        gap: 10px;
        margin-top: 12px;
      }
      .vault-paywall-status-card {
        display: grid;
        grid-template-columns: 30px minmax(0, 1fr);
        gap: 11px;
        padding: 13px 14px;
        border: 1px solid #d8c98a;
        border-radius: 10px;
        background: #fffaf0;
      }
      .vault-paywall-status-icon {
        display: inline-grid;
        width: 28px;
        height: 28px;
        border-radius: 50%;
        place-items: center;
        background: #8b6417;
        color: #fff;
        font-size: 17px;
        font-weight: 800;
        line-height: 1;
      }
      .vault-paywall-status-icon::before {
        content: "!";
      }
      .vault-paywall[data-state="never_subscribed"] .vault-paywall-status-card {
        border-color: #bad5df;
        background: #f3f9fb;
      }
      .vault-paywall[data-state="never_subscribed"] .vault-paywall-status-icon {
        background: #2f7187;
      }
      .vault-paywall[data-state="never_subscribed"] .vault-paywall-status-icon::before {
        content: "i";
        font-family: Georgia, serif;
      }
      #vault-paywall-status-line {
        color: #183346;
        font-size: 15px;
        font-weight: 750;
        line-height: 1.4;
      }
      #vault-paywall-account-line {
        margin-top: 3px;
        color: #556771;
        font-size: 11.5px;
        line-height: 1.4;
        overflow-wrap: anywhere;
      }
      .vault-paywall-reassurance {
        margin: 0;
        padding: 11px 13px;
        border: 1px solid #cfe0d2;
        border-left: 3px solid #4f8a5b;
        border-radius: 9px;
        background: #f5faf6;
        color: #314d3a;
        font-size: 12.5px;
        line-height: 1.55;
      }
      .vault-paywall-free-line {
        display: flex;
        gap: 7px;
        align-items: baseline;
        margin: 0;
        padding: 9px 11px;
        border: 1px solid #cfe0d2;
        border-radius: 9px;
        background: #f5faf6;
        color: #26402f;
        font-size: 11.5px;
        line-height: 1.5;
      }
      .vault-paywall-free-line::before {
        content: "✓";
        color: #4f8a5b;
        font-weight: 800;
      }
      .vault-plan-toggle {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 10px;
        margin-top: 2px;
      }
      .vault-plan-option {
        position: relative;
        display: flex;
        flex-direction: column;
        align-items: flex-start;
        gap: 3px;
        padding: 15px 14px 12px;
        border: 1.5px solid #c5d4f5;
        border-radius: 12px;
        background: #fff;
        color: #41564a;
        text-align: left;
        cursor: pointer;
        transition: border-color 120ms ease, box-shadow 120ms ease, background 120ms ease;
      }
      .vault-plan-option:hover {
        border-color: #8fa7e0;
      }
      .vault-plan-option.selected {
        border-color: #294b9c;
        background: linear-gradient(165deg, #f2f6ff 0%, #ffffff 72%);
        box-shadow: 0 0 0 1px #294b9c, 0 6px 14px rgba(35, 59, 136, 0.14);
      }
      .vault-plan-option.selected::after {
        content: "✓";
        position: absolute;
        top: 10px;
        right: 13px;
        display: grid;
        place-items: center;
        width: 16px;
        height: 16px;
        border-radius: 50%;
        background: #294b9c;
        color: #fff;
        font-size: 10px;
        font-weight: 800;
        line-height: 1;
      }
      .vault-plan-flag {
        position: absolute;
        top: -10px;
        left: 12px;
        padding: 2.5px 8px;
        border-radius: 999px;
        background: linear-gradient(135deg, #294b9c 0%, #172a62 100%);
        color: #fff;
        font-size: 9px;
        font-weight: 800;
        letter-spacing: 0.07em;
        text-transform: uppercase;
        box-shadow: 0 2px 6px rgba(23, 42, 98, 0.28);
      }
      .vault-plan-name {
        color: #5a6b92;
        font-size: 10.5px;
        font-weight: 750;
        letter-spacing: 0.06em;
        text-transform: uppercase;
      }
      .vault-plan-option.selected .vault-plan-name {
        color: #294b9c;
      }
      .vault-plan-price {
        color: #172a62;
        font-size: 19px;
        font-weight: 800;
        line-height: 1.15;
      }
      .vault-plan-per {
        color: #5a6b92;
        font-size: 11px;
        font-weight: 650;
      }
      .vault-plan-billed {
        color: #5a6b92;
        font-size: 10.5px;
        line-height: 1.4;
      }
      .vault-paywall-actions {
        display: flex;
        margin-top: 2px;
      }
      #llmnesia-options-root #vault-paywall-cta {
        flex: 1;
        min-height: 44px;
        padding: 11px 18px;
        border: 0 !important;
        border-radius: 11px !important;
        background: linear-gradient(135deg, #294b9c 0%, #172a62 100%) !important;
        color: #fff !important;
        font-size: 13.5px !important;
        font-weight: 750 !important;
        letter-spacing: 0.01em;
        box-shadow: 0 8px 18px rgba(23, 42, 98, 0.26), 0 2px 4px rgba(23, 42, 98, 0.16) !important;
        transition: filter 120ms ease, transform 120ms ease;
      }
      #llmnesia-options-root #vault-paywall-cta:hover {
        filter: brightness(1.09);
      }
      #llmnesia-options-root #vault-paywall-cta:active {
        transform: translateY(1px);
      }
      .vault-paywall-plan-note {
        margin: 0;
        color: #5b6e78;
        font-size: 11px;
        line-height: 1.5;
        text-align: center;
      }
      .vault-paywall-utilities {
        display: flex;
        gap: 18px;
        align-items: center;
        justify-content: center;
        flex-wrap: wrap;
        margin: 0;
      }
      #llmnesia-options-root .vault-paywall-utility {
        padding: 2px 0;
        border: 0 !important;
        border-radius: 3px !important;
        background: transparent !important;
        color: #536b77 !important;
        cursor: pointer;
        font-size: 11.5px;
        font-weight: 500;
        text-decoration: underline;
        text-decoration-color: #b5c3c9;
        text-underline-offset: 3px;
      }
      #llmnesia-options-root .vault-paywall-utility:hover {
        color: #294a5a !important;
        text-decoration-color: currentColor;
      }
      .vault-paywall-live-status {
        display: none;
        margin-top: 8px;
        color: #506a76;
        font-size: 11.5px;
        line-height: 1.5;
      }
      #corpus-sync-card {
        padding: 11px 16px !important;
      }
      #vault-card,
      #corpus-native-card {
        border-left-width: 1px !important;
        overflow: hidden;
      }
      #vault-card {
        --settings-accent: #506fca;
        --settings-action: #294b9c;
        --settings-edge: #3956a7;
        --settings-tint: rgba(80, 111, 202, 0.12);
        margin-top: 18px !important;
        padding: 0 !important;
        border: 1px solid #3956a7 !important;
        background: #fff !important;
        box-shadow: 0 10px 28px rgba(35, 59, 136, 0.18), 0 2px 5px rgba(30, 55, 65, 0.08) !important;
      }
      .vault-card-header {
        padding: 18px 18px 16px;
        background:
          radial-gradient(circle at 92% 8%, rgba(148, 178, 255, 0.35), transparent 26%),
          linear-gradient(135deg, #172a62 0%, #294b9c 58%, #506fca 100%);
        color: #fff;
      }
      .vault-card-kicker-row {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 8px;
        flex-wrap: wrap;
        margin-bottom: 8px;
      }
      .vault-card-badge {
        display: inline-flex;
        align-items: center;
        gap: 5px;
        padding: 4px 8px;
        border: 1px solid rgba(255, 255, 255, 0.48);
        border-radius: 999px;
        color: #fff;
        font-size: 10.5px;
        font-weight: 750;
        letter-spacing: 0.08em;
        text-transform: uppercase;
      }
      .vault-card-badge::before {
        content: "✦";
        font-size: 11px;
      }
      .vault-card-encryption-note {
        color: #fff;
        font-size: 12px;
        font-weight: 650;
      }
      #vault-card .vault-card-title {
        margin: 0 0 7px !important;
        color: #fff !important;
        font-size: 20px !important;
        line-height: 1.25;
      }
      #vault-card .vault-card-description {
        max-width: 690px;
        margin: 0 !important;
        color: #f7f9ff !important;
        font-size: 13.5px;
        line-height: 1.55 !important;
      }
      .vault-card-flow {
        display: flex;
        align-items: center;
        flex-wrap: wrap;
        gap: 7px;
        margin-top: 12px;
        padding: 9px 10px;
        border: 1px solid rgba(255, 255, 255, 0.52);
        border-radius: 9px;
        background: rgba(255, 255, 255, 0.97);
        color: #24365f;
        font-size: 12px;
      }
      .vault-card-flow strong {
        color: #1b3478;
      }
      .vault-card-flow-arrow {
        color: #6682cf;
        font-weight: 800;
      }
      .vault-card-flow-vault {
        padding: 4px 7px;
        border-radius: 6px;
        background: #e5edff;
        color: #24489d;
        font-weight: 750;
      }
      .vault-card-trust-note {
        margin: 9px 0 0;
        color: #f5f8ff;
        font-size: 12px;
        line-height: 1.5;
      }
      .vault-card-body {
        padding: 16px 18px 18px;
        background: linear-gradient(115deg, #f4f7ff 0%, #fff 42%);
      }
      #vault-card .vault-card-body > .vault-card-privacy {
        margin: 0 0 13px;
        padding: 10px 12px;
        border: 1px solid #c5d4f5;
        border-left: 4px solid #506fca;
        border-radius: 8px;
        background: #f8faff;
        color: #263d68;
        font-size: 12.5px;
        line-height: 1.55;
      }
      #vault-card .vault-card-body > .vault-card-privacy strong {
        color: #203d8a;
      }
      .vault-signin-success {
        display: none;
        align-items: flex-start;
        gap: 10px;
        margin-bottom: 14px;
        padding: 11px 13px;
        border: 1px solid #a7d6bf;
        border-radius: 10px;
        background: #f0faf4;
        color: #20543b;
        font-size: 13px;
        line-height: 1.45;
      }
      .vault-signin-success::before {
        content: "✓";
        display: grid;
        flex: 0 0 22px;
        height: 22px;
        place-items: center;
        border-radius: 50%;
        background: #287750;
        color: #fff;
        font-weight: 800;
      }
      .vault-ready-card {
        display: flex;
        align-items: flex-start;
        gap: 13px;
        padding: 16px;
        border: 1px solid #a9d6bd;
        border-radius: 12px;
        background: linear-gradient(135deg, #f0faf4, #fff 76%);
        box-shadow: 0 3px 12px rgba(32, 84, 59, 0.08);
      }
      .vault-ready-icon {
        display: grid;
        flex: 0 0 36px;
        height: 36px;
        place-items: center;
        border-radius: 10px;
        background: #287750;
        color: #fff;
        font-size: 21px;
        font-weight: 750;
      }
      .vault-ready-content { min-width: 0; }
      .vault-ready-kicker {
        color: #27684b;
        font-size: 10px;
        font-weight: 800;
        letter-spacing: 0.08em;
        text-transform: uppercase;
      }
      .vault-ready-title {
        margin: 2px 0 2px;
        color: #173b2a;
        font-size: 17px;
        line-height: 1.3;
      }
      #vault-account-line {
        overflow-wrap: anywhere;
        color: #3b5968;
        font-size: 13px;
      }
      .vault-ready-badges {
        display: flex;
        flex-wrap: wrap;
        gap: 7px;
        margin-top: 11px;
      }
      .vault-ready-badge {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 5px 9px;
        border: 1px solid #b9dcc8;
        border-radius: 999px;
        background: #fff;
        color: #20543b;
        font-size: 12px;
        font-weight: 700;
      }
      .vault-ready-badge::before {
        content: "✓";
        font-weight: 850;
      }
      /* Manage Vault actions: quiet gradient buttons with a soft hover lift,
         so the row reads as a finished control group instead of bare inputs.
         The global "#llmnesia-options-root button" rule forces background,
         colour, border, and radius on every button with !important, so these
         selectors carry the root prefix and !important to win the cascade
         (same pattern as ".settings-primary-action" above). */
      #llmnesia-options-root .vault-manage-btn {
        display: inline-flex !important;
        align-items: center !important;
        gap: 7px !important;
        padding: 9px 14px !important;
        border: 1px solid ${p.tealEdge} !important;
        border-radius: 10px !important;
        background: linear-gradient(180deg, #ffffff, #eaf3f6) !important;
        color: #17546a !important;
        font-size: 12.5px !important;
        font-weight: 650 !important;
        letter-spacing: 0.01em !important;
        white-space: nowrap;
        cursor: pointer;
        box-shadow: 0 1px 2px rgba(20, 36, 48, 0.16);
        transition: border-color 140ms ease, background 140ms ease, box-shadow 140ms ease, transform 140ms ease;
      }
      #llmnesia-options-root .vault-manage-btn:hover {
        border-color: ${p.teal} !important;
        background: linear-gradient(180deg, #ffffff, #dceef3) !important;
        box-shadow: 0 3px 8px rgba(47, 127, 153, 0.22);
        transform: translateY(-1px);
      }
      #llmnesia-options-root .vault-manage-btn:active {
        transform: translateY(0);
        box-shadow: 0 1px 2px rgba(20, 36, 48, 0.16);
      }
      #llmnesia-options-root .vault-manage-btn:focus-visible {
        outline: 2px solid ${p.teal} !important;
        outline-offset: 2px;
      }
      #llmnesia-options-root .vault-manage-btn:disabled {
        opacity: 0.55;
        cursor: default;
        transform: none;
        box-shadow: none;
      }
      #llmnesia-options-root .vault-manage-btn--primary {
        border-color: #26718a !important;
        background: linear-gradient(180deg, #358aa6, ${p.teal} 55%, #29708a) !important;
        color: #fff !important;
        text-shadow: 0 1px 0 rgba(20, 36, 48, 0.18);
        box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.22), 0 1px 2px rgba(20, 36, 48, 0.18);
      }
      #llmnesia-options-root .vault-manage-btn--primary:hover {
        border-color: #215f75 !important;
        background: linear-gradient(180deg, #3b95b3, #2f7f99 55%, #29708a) !important;
        box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.22), 0 3px 8px rgba(47, 127, 153, 0.3);
      }
      #llmnesia-options-root .vault-manage-btn--danger {
        border-color: #d7b1b1 !important;
        background: linear-gradient(180deg, #ffffff, #fdf0f0) !important;
        color: #8a2424 !important;
      }
      #llmnesia-options-root .vault-manage-btn--danger:hover {
        border-color: #b83d3d !important;
        background: linear-gradient(180deg, #ffffff, #fbe9e9) !important;
        box-shadow: 0 3px 8px rgba(184, 61, 61, 0.18);
      }
      /* The locked-panel and setup-walk buttons carry their sizes in inline
         styles (the global rule does not force padding), but their teal and
         white-on-teal colours need these winning rules to render at all. */
      #llmnesia-options-root #vault-unlock-btn,
      #llmnesia-options-root #vault-recover-submit,
      #llmnesia-options-root #vault-firstsync-btn,
      #llmnesia-options-root #vault-backup-btn {
        border-color: #26718a !important;
        background: linear-gradient(180deg, #358aa6, ${p.teal} 55%, #29708a) !important;
        color: #fff !important;
        font-weight: 650 !important;
        text-shadow: 0 1px 0 rgba(20, 36, 48, 0.18);
        box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.22), 0 1px 2px rgba(20, 36, 48, 0.18);
      }
      #llmnesia-options-root #vault-unlock-btn:hover,
      #llmnesia-options-root #vault-recover-submit:hover,
      #llmnesia-options-root #vault-firstsync-btn:hover,
      #llmnesia-options-root #vault-backup-btn:hover {
        background: linear-gradient(180deg, #3b95b3, #2f7f99 55%, #29708a) !important;
      }
      #llmnesia-options-root #vault-restore-btn {
        border-color: ${p.tealEdge} !important;
        background: linear-gradient(180deg, #ffffff, #eaf3f6) !important;
        color: #17546a !important;
        font-weight: 650 !important;
        box-shadow: 0 1px 2px rgba(20, 36, 48, 0.16);
      }
      #llmnesia-options-root #vault-restore-btn:hover {
        border-color: ${p.teal} !important;
        background: linear-gradient(180deg, #ffffff, #dceef3) !important;
      }
      .vault-sync-summary {
        margin-top: 12px;
        padding: 11px 13px;
        border: 1px solid #d5e0ed;
        border-radius: 10px;
        background: #fff;
        color: #3d5668;
        font-size: 12.5px;
        line-height: 1.5;
      }
      /* The Vault status pill in the page header, and its anchored panel.
         Same contract and vocabulary as the popup's pill; this surface simply
         anchors its recovery actions to the Vault card instead of a separate
         Settings page. */
      #vault-status-pill {
        display: none;
        position: relative;
        margin-top: 10px;
        max-width: 420px;
      }
      #vault-status-pill[data-visible="true"] { display: block; }
      #vault-status-pill-button {
        display: flex;
        align-items: center;
        gap: 7px;
        width: 100%;
        padding: 6px 12px;
        border: 1px solid #d5e0ed;
        border-radius: 999px;
        background: #f2f7f5;
        color: #2f5e53;
        font-size: 12px;
        font-weight: 700;
        line-height: 1.35;
        text-align: left;
        cursor: pointer;
      }
      #vault-status-pill-button:hover { background: #e9f2ef; }
      #vault-status-pill[data-tone="attention"] #vault-status-pill-button {
        background: #fdf3f3;
        border-color: #e5c9c9;
        color: #7a2626;
      }
      #vault-status-pill[data-tone="ok"] #vault-status-pill-button {
        background: #eef6f0;
        border-color: #cfe3d6;
        color: #2b5a3c;
      }
      .vault-status-pill-dot {
        flex: none;
        width: 8px;
        height: 8px;
        border-radius: 50%;
        background: currentColor;
        opacity: 0.55;
      }
      #vault-status-pill[data-tone="ok"] .vault-status-pill-dot { opacity: 0.8; }
      #vault-status-pill[data-busy="true"] .vault-status-pill-dot {
        animation: vault-status-pulse 1.1s ease-in-out infinite;
      }
      @keyframes vault-status-pulse {
        0%, 100% { opacity: 0.3; }
        50% { opacity: 0.95; }
      }
      @media (prefers-reduced-motion: reduce) {
        #vault-status-pill[data-busy="true"] .vault-status-pill-dot { animation: none; }
      }
      #vault-status-pill-panel {
        position: absolute;
        top: calc(100% + 6px);
        left: 0;
        right: 0;
        z-index: 80;
        padding: 16px;
        border: 1px solid #d8e4e0;
        border-radius: 12px;
        background: #fff;
        box-shadow: 0 8px 22px rgba(18, 48, 59, 0.14);
        color: #3d5668;
        font-size: 12.5px;
        line-height: 1.5;
      }
      #vault-status-pill-button::after { content: ""; width: 5px; height: 5px; border-right: 1.5px solid currentColor; border-bottom: 1.5px solid currentColor; transform: rotate(45deg); margin-left: auto; flex: none; }
      #vault-status-pill-button[aria-expanded="true"]::after { transform: rotate(225deg); }
      .vault-status-pill-actions {
        display: flex;
        flex-wrap: wrap;
        gap: 8px;
        margin-top: 14px;
        padding-top: 14px;
        border-top: 1px solid #e2ebe7;
      }
      .vault-status-pill-actions button {
        padding: 5px 12px;
        border: 1px solid #c4d6d0;
        border-radius: 8px;
        background: #f6faf8;
        color: #24413a;
        font-size: 12px;
        font-weight: 600;
        cursor: pointer;
      }
      .vault-status-pill-actions button:hover { background: #e9f2ef; }
      #vault-status-pill-sync-now, #vault-status-pill-recovery { background: #2f5e53; border-color: #2f5e53; color: #fff; }
      #vault-status-pill-sync-now:hover, #vault-status-pill-recovery:hover { background: #244a41; }
      .vault-status-pill-actions button:disabled { opacity: 0.6; cursor: default; }
      #vault-sync-line { font-weight: 700; }
      #vault-auto-sync-note { margin-top: 3px; }
      #vault-join-devices-line {
        margin-top: 12px;
        padding-left: 1px;
        color: #536b7c;
        font-size: 12.5px;
        line-height: 1.5;
      }
      #vault-card #vault-paywall-account-line,
      #vault-card .vault-paywall-live-status {
        color: #3f5059;
        font-size: 12.5px;
      }
      #vault-card #vault-status-line {
        color: #3d4f65 !important;
        font-size: 11.5px !important;
      }
      #settings-group-overview { order: 9; }
      #indexing-status { order: 10; }
      #backfill-section { order: 15; }
      #search-results-section { order: 20; }
      #search-results-section {
        margin-top: 8px !important;
        padding: 10px 14px !important;
        box-shadow: none;
      }
      #search-results-section h2 {
        margin: 0 !important;
        font-size: 14px !important;
      }
      #settings-group-connections { order: 29; }
      #vault-card { order: 30; }
      #corpus-native-card { order: 40; }
      #local-sessions-card { order: 50; }
      #google-ai-mode-card { order: 55; }
      #settings-group-knowledge { order: 59; }
      #memory-section { order: 60; }
      #starred-section { order: 70; }
      #settings-group-data { order: 79; }
      #backup-restore-section { order: 80; }
      #import-chatgpt-export-section { order: 90; }
      #import-ai-studio-section { order: 91; }
      #settings-group-advanced { order: 99; }
      #report-problem-section { order: 100; }
      #support-section { order: 110; }
      #founding-card { order: 115; }
      #technical-errors-section { order: 120; }
      #corpus-sync-card { order: 125; }
      #danger-zone-section { order: 130; }
      .settings-filter-empty {
        display: none;
        order: 1000;
        margin: 12px 0 18px;
        padding: 18px;
        border: 1px dashed #c6d0b0;
        border-radius: 10px;
        background: #fbfcf7;
        color: #4f6576;
        text-align: center;
      }
      @media (max-width: 620px) {
        .settings-setup-card {
          padding: 16px;
        }
        .settings-setup-grid {
          grid-template-columns: 1fr;
        }
        .settings-nav {
          position: static;
        }
        .settings-search-row {
          align-items: flex-start;
          flex-direction: column;
        }
        .settings-search-wrap {
          flex: 0 0 auto;
          width: 100%;
        }
        #settings-search-status {
          margin-left: 0;
        }
        .settings-group-heading {
          margin-top: 22px;
        }
        .settings-section {
          padding: 15px !important;
        }
        .settings-card-description {
          font-size: 12.5px;
        }
        .settings-status-panel {
          padding: 8px 10px;
        }
        .vault-paywall-actions {
          display: grid;
          grid-template-columns: minmax(0, 1fr);
        }
        .vault-plan-toggle {
          grid-template-columns: minmax(0, 1fr);
          gap: 12px;
        }
        #vault-paywall-cta {
          width: 100%;
        }
        .vault-paywall-utilities {
          align-items: flex-start;
          flex-direction: column;
          gap: 7px;
        }
      }
      @media (prefers-reduced-motion: reduce) {
        .settings-setup-link {
          transition: none;
        }
        .settings-setup-link:hover {
          transform: none;
        }
      }
      #llmnesia-options-root button {
        border-color: ${p.rule} !important;
        border-radius: ${p.rSm} !important;
        background: ${p.card} !important;
        color: ${p.ink2} !important;
        font: inherit;
      }
      #corpus-native-card {
        padding: 0 !important;
      }
      #llmnesia-options-root #corpus-native-enable,
      #llmnesia-options-root #corpus-native-copy-install {
        border-color: #244b32 !important;
        background: #315a3e !important;
        color: #fff !important;
        font-weight: 700 !important;
      }
      #report-problem,
      #founding-join {
        border-color: ${p.teal} !important;
        background: ${p.teal} !important;
        color: #fff !important;
        font-weight: 600 !important;
      }
      /* The pause control is deliberately a text link, not a solid button;
         its inline look needs !important to survive the global button rule. */
      #llmnesia-options-root #toggle-indexing {
        border: none !important;
        background: none !important;
        color: #6b8a5a !important;
      }
      #delete-all,
      #clear-error-logs {
        border-color: #d7b1b1 !important;
        background: #fff4f4 !important;
        color: #7a2626 !important;
      }
      #stats-content,
      #health-status,
      #migration-status,
      #backfill-status-text,
      #pin-status,
      #backup-status,
      #delete-status,
      #recent-limit-status,
      #error-log-status {
        color: ${p.ink3} !important;
        font-family: inherit !important;
        font-size: 12px !important;
        line-height: 1.5 !important;
        letter-spacing: 0 !important;
      }
      #llmnesia-options-root input,
      #llmnesia-options-root select {
        border-color: ${p.rule} !important;
        background: ${p.card} !important;
        color: ${p.ink} !important;
        font: inherit;
      }
      #llmnesia-options-root input[type="number"],
      #llmnesia-options-root select {
        font-family: "IBM Plex Mono", "SF Mono", "Consolas", monospace;
        font-size: 12px;
      }
      .options-stat-card {
        min-width: 0;
        overflow: hidden;
        border: 1px solid ${p.ruleSoft};
        border-left: 3px solid ${p.tealEdge};
        border-radius: ${p.rSm};
        background: ${p.card};
        padding: 8px;
      }
      .options-stat-label {
        color: ${p.ink3};
        font-family: "IBM Plex Mono", "SF Mono", "Consolas", monospace;
        font-size: 9.5px;
        font-weight: 600;
        line-height: 1;
        letter-spacing: 0;
        margin-bottom: 5px;
        text-transform: uppercase;
      }
      .options-stat-value {
        display: block;
        color: #163046;
        font-family: "IBM Plex Mono", "SF Mono", "Consolas", monospace;
        font-size: 16px;
        font-weight: 700;
        line-height: 1.2;
        letter-spacing: -0.01em;
        overflow-wrap: anywhere;
        word-break: break-word;
      }
      /* Pulsing placeholder blocks the stats skeleton is built from. */
      @keyframes stats-skel-pulse {
        0%, 100% { opacity: 0.5; }
        50% { opacity: 1; }
      }
      .stats-skel {
        display: block;
        border-radius: 4px;
        background: ${p.ruleSoft};
        animation: stats-skel-pulse 1.6s ease-in-out infinite;
      }
      @media (prefers-reduced-motion: reduce) {
        .stats-skel { animation: none; }
      }
      .year-card {
        border: 1px solid ${p.ruleSoft};
        border-left: 3px solid ${p.teal};
        border-radius: ${p.rSm};
        background: linear-gradient(180deg, ${p.card} 0%, ${p.tealSoft} 100%);
        padding: 14px 16px;
        margin-bottom: 16px;
      }
      .year-card-head {
        color: ${p.teal};
        font-family: "IBM Plex Mono", "SF Mono", "Consolas", monospace;
        font-size: 10px;
        font-weight: 700;
        letter-spacing: 0.05em;
        text-transform: uppercase;
        margin-bottom: 12px;
      }
      .year-stats {
        display: flex;
        flex-wrap: wrap;
        gap: 26px;
        align-items: flex-end;
      }
      .year-stat-num {
        color: #163046;
        font-size: 26px;
        font-weight: 700;
        line-height: 1;
        letter-spacing: -0.01em;
        font-variant-numeric: tabular-nums;
      }
      .year-stat-label {
        color: ${p.ink3};
        font-size: 11px;
        margin-top: 5px;
      }
      .year-spark {
        margin-top: 16px;
        display: flex;
        gap: 5px;
        align-items: flex-end;
      }
      .year-bar-col {
        flex: 1;
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 5px;
      }
      .year-bar-track {
        width: 100%;
        height: 46px;
        display: flex;
        align-items: flex-end;
      }
      .year-bar {
        width: 100%;
        min-height: 2px;
        border-radius: 3px 3px 2px 2px;
        background: ${p.tealEdge};
      }
      .year-bar.peak {
        background: ${p.teal};
      }
      .year-bar-label {
        color: ${p.ink3};
        font-size: 9px;
        font-variant-numeric: tabular-nums;
      }
      .year-caption {
        margin-top: 11px;
        color: ${p.ink3};
        font-size: 11.5px;
      }
      .year-caption strong {
        color: ${p.ink2};
        font-weight: 600;
      }
      .options-chip {
        display: inline-flex;
        align-items: center;
        max-width: 100%;
        border: 1px solid ${p.ruleSoft};
        border-radius: ${p.rPill};
        background: ${p.paperSoft};
        color: ${p.ink2};
        font-family: "IBM Plex Mono", "SF Mono", "Consolas", monospace;
        font-size: 10.5px;
        font-weight: 700;
        line-height: 1;
        padding: 4px 7px;
        white-space: nowrap;
      }
      .options-result-card {
        border: 1px solid ${p.ruleSoft};
        border-left: 3px solid ${p.tealEdge};
        border-radius: ${p.rSm};
        padding: 8px;
        background: ${p.card};
        width: 100%;
        max-width: 100%;
      }
      .options-memory-card {
        transition: border-color 0.12s ease, box-shadow 0.12s ease;
      }
      .options-memory-card:hover {
        border-left-color: ${p.teal};
        box-shadow: 0 1px 4px rgba(20, 49, 71, 0.07);
      }
      .options-memory-card:hover .memory-view-hint {
        color: ${p.teal};
      }
      .options-card-meta {
        color: ${p.ink3};
        font-family: "IBM Plex Mono", "SF Mono", "Consolas", monospace;
        font-size: 10.5px;
        line-height: 1.35;
        letter-spacing: 0;
      }
      .options-progress-track {
        margin-top: 8px;
        height: 8px;
        border: 1px solid ${p.ruleSoft} !important;
        border-radius: ${p.rPill};
        background: ${p.paperSoft} !important;
        overflow: hidden;
      }
      #backfill-progress-fill {
        background: linear-gradient(90deg, ${p.teal} 0%, #5f9cac 100%) !important;
      }
      /* The two long-running vault walks — uploading the existing corpus, and
         restoring it onto a new device — share one visual language: a calm
         pulsing dot, never a ticking counter. Either can take minutes over
         hundreds of conversations, and a number that visibly climbs turns
         background work into something the user feels obliged to sit and watch.
         Class-based rather than per-id so the second row cost no CSS at all.
         Shipped unconditionally since PV-01: the public store build now reaches
         the sign-in flow, so the walk-dot styles must be there too. */
      @keyframes vault-walk-pulse {
        0%, 100% { opacity: 0.28; }
        50% { opacity: 1; }
      }
      .vault-walk-dot {
        width: 8px;
        height: 8px;
        border-radius: 50%;
        background: ${p.teal};
        flex: 0 0 auto;
      }
      .vault-walk-dot[data-state="running"] {
        animation: vault-walk-pulse 1.8s ease-in-out infinite;
      }
      .vault-walk-dot[data-state="idle"] { background: ${p.tealEdge}; }
      .vault-walk-progress-fill {
        background: linear-gradient(90deg, ${p.teal} 0%, #5f9cac 100%) !important;
      }
      @keyframes vault-status-spin { to { transform: rotate(360deg); } }
      .vault-status-spinner {
        display: inline-block;
        width: 9px;
        height: 9px;
        margin-right: 5px;
        border: 1.5px solid ${p.tealEdge};
        border-top-color: ${p.teal};
        border-radius: 50%;
        vertical-align: -1px;
        animation: vault-status-spin 700ms linear infinite;
      }
      .vault-status-spinner[hidden] { display: none; }
      @media (prefers-reduced-motion: reduce) {
        .vault-walk-dot[data-state="running"] { animation: none; opacity: 0.7; }
        .vault-status-spinner { animation: none; opacity: 0.7; }
      }
      ${cp}
	  ${Qd}
	  </style>
	  <div id="llmnesia-options-root" style="max-width: 1000px; margin: 30px auto 52px; padding: 0 16px; font: 14px/1.5 'IBM Plex Sans', sans-serif; color: #102030; overflow-x: clip;">
    <div class="settings-header">
      <div style="color: #487852; font-size: 10px; font-weight: 700; letter-spacing: 0.08em; text-transform: uppercase;">Control center</div>
      <div class="settings-title-row">
        <h1 style="margin: 3px 0 8px; font-size: 28px;">LLMnesia Settings</h1>
        <div id="vault-status-pill" data-visible="true" data-condition="checking" data-tone="quiet" data-busy="true">
          <button id="vault-status-pill-button" type="button" aria-expanded="false" aria-controls="vault-status-pill-panel">
            ${Zd}
            <span class="settings-vault-label" aria-hidden="true">Vault</span>
            <span id="vault-status-pill-label" aria-live="polite">Checking Vault…</span>
          </button>
          <div id="vault-status-pill-panel" hidden>
            <div class="vault-status-panel-head">
              <span class="vault-status-heading">Vault sync</span>
              <button id="vault-status-pill-sync-now" type="button" aria-label="Sync now" title="Sync now" hidden>Sync now</button>
            </div>
            <div class="vault-status-panel-body"><div id="vault-status-pill-facts"></div></div>
            <div class="vault-status-pill-actions">
              <button id="vault-status-pill-recovery" type="button" hidden></button>
            </div>
          </div>
        </div>
      </div>
      <p style="margin: 0; color: #395063;">Your LLMnesia history stays under your control. Manage search, saved context, connections, and backups here.</p>
      <button id="vault-status-attention" class="vault-status-attention" type="button" hidden></button>
    </div>

    <section class="settings-setup-card" aria-labelledby="settings-setup-title">
      <div class="settings-setup-head">
        <div>
          <div class="settings-setup-eyebrow">Start here</div>
          <h2 id="settings-setup-title" class="settings-setup-title">Setup essentials</h2>
        </div>
        <span style="color: #6a7f90; font-size: 11px;">One-time setup, then mostly hands-off</span>
      </div>
      <p class="settings-setup-description">The most important connections live here so you don’t have to hunt through the page.</p>
      <div class="settings-setup-grid">
        
        <a class="settings-setup-link" data-accent="vault" href="#vault-card">
          <span class="settings-setup-number">1</span>
          <span class="settings-setup-copy"><strong>Protect with Vault</strong><small>Encrypted sync, recovery, and every-device access</small></span>
          <span class="settings-setup-arrow" aria-hidden="true">→</span>
        </a>
        
        <a class="settings-setup-link" data-accent="green" href="#corpus-native-card">
          <span class="settings-setup-number">2</span>
          <span class="settings-setup-copy"><strong>Connect desktop AI</strong><small>MCP setup for Claude, Codex, and more</small></span>
          <span class="settings-setup-arrow" aria-hidden="true">→</span>
        </a>
        <a class="settings-setup-link" data-accent="green" href="#local-sessions-card">
          <span class="settings-setup-number">${Kl}</span>
          <span class="settings-setup-copy"><strong>Add local AI sessions</strong><small>Bring Claude Code and Codex chats into search</small></span>
          <span class="settings-setup-arrow" aria-hidden="true">→</span>
        </a>
        <a class="settings-setup-link" data-accent="blue" href="#backup-restore-section">
          <span class="settings-setup-number">${zu}</span>
          <span class="settings-setup-copy"><strong>Make a local backup</strong><small>Export before switching devices or profiles</small></span>
          <span class="settings-setup-arrow" aria-hidden="true">→</span>
        </a>
      </div>
    </section>

    <nav class="settings-nav" id="settings-navigation" aria-label="Settings navigation">
      <div class="settings-search-row">
        <label class="settings-search-label" for="settings-search">Find a setting</label>
        <div class="settings-search-wrap">
          <input id="settings-search" type="search" autocomplete="off" spellcheck="false" placeholder="${Fu}" />
          <span class="settings-search-key" aria-hidden="true">/</span>
        </div>
      </div>
      <div id="settings-search-status" role="status" aria-live="polite">Showing all settings</div>
      <div class="settings-nav-links">
        <span class="settings-nav-label">Jump to</span>
        <a href="#vault-card" data-settings-nav="vault-card">Vault</a>
        <a href="#corpus-native-card" data-settings-nav="corpus-native-card">MCP</a>
        <a href="#indexing-status" data-settings-nav="indexing-status">Overview</a>
        <a href="#memory-section" data-settings-nav="memory-section">Search &amp; memory</a>
        <a href="#local-sessions-card" data-settings-nav="local-sessions-card">Local sessions</a>
        <a href="#backup-restore-section" data-settings-nav="backup-restore-section">Backup</a>
        <a href="#report-problem-section" data-settings-nav="report-problem-section">Support</a>
        <a href="#danger-zone-section" data-settings-nav="danger-zone-section">Danger zone</a>
      </div>
    </nav>

    <div id="settings-filter-empty" class="settings-filter-empty" role="status">No settings match that search. Try a broader term.</div>

    <div id="settings-group-overview" class="settings-group-heading" data-settings-group-heading="overview">
      <div><strong>Overview</strong><span>Health, search behavior, and indexing progress</span></div>
    </div>
    <div id="settings-group-knowledge" class="settings-group-heading" data-settings-group-heading="knowledge">
      <div><strong>Your knowledge</strong><span>Reusable memories and conversations worth keeping close</span></div>
    </div>
    <div id="settings-group-connections" class="settings-group-heading" data-settings-group-heading="connections">
      <div><strong>Connections</strong><span>Optional sources, local sessions, and desktop AI apps</span></div>
    </div>
    <div id="settings-group-data" class="settings-group-heading" data-settings-group-heading="data">
      <div><strong>Data &amp; recovery</strong><span>Move, restore, and protect your history</span></div>
    </div>
    <div id="settings-group-advanced" class="settings-group-heading" data-settings-group-heading="advanced">
      <div><strong>Help &amp; advanced</strong><span>Support, diagnostics, and sensitive actions</span></div>
    </div>

    <section id="indexing-status" class="settings-section" data-settings-section data-settings-group="overview" data-settings-label="Search health" data-settings-search="overview indexing status search health migration semantic meaning pause refresh" style="border: 1px solid #dbe2cf; border-left: 4px solid #7a9b57; border-radius: 12px; padding: 14px 16px; background: #fafcf4;">
      <div style="display: flex; gap: 8px; justify-content: space-between; align-items: center; flex-wrap: wrap;">
        <h2 style="margin: 0; font-size: 17px;">Indexing status</h2>
        <button id="refresh-stats" type="button" style="padding: 8px 12px; border-radius: 8px; border: 1px solid #c6d0b0; background: #fff; cursor: pointer;">Refresh</button>
      </div>
      <p class="settings-card-description" style="margin: 8px 0 0; color: #4f6576;">See whether your history is captured and ready to search.</p>
      <div id="stats-content" class="settings-status-panel" style="margin-top: 12px; color: #2f4654;">${Pl()}</div>
      <div style="margin-top: 10px; display: flex; gap: 14px; flex-wrap: wrap; align-items: baseline;">
        <button id="toggle-indexing" type="button" title="Temporarily stop indexing new conversations, e.g. while you're on a chat you don't want saved. Search still works on what's already indexed." style="padding: 2px 0; border: none; background: none; color: #6b8a5a; font-size: 12.5px; text-decoration: underline; text-underline-offset: 2px; cursor: pointer;">Pause indexing</button>
      </div>
      <div class="settings-subpanel" style="margin-top:12px; padding:12px; border-top:1px dashed #d7dfcb;">
        <div style="font-weight:600; color:#2f4654;">Smarter search — find chats by meaning</div>
        <div id="semantic-coverage" style="color:#4f6576; margin-top:4px;">Search by meaning: checking…</div>
        <div style="display:flex; gap:10px; align-items:center; flex-wrap:wrap; margin-top:8px;">
          
        </div>
        
      </div>
      <div id="health-status" class="settings-status-panel" style="margin-top: 10px; color: #2f4654; overflow-wrap: anywhere; word-break: break-word;"></div>
      <div id="migration-status" class="settings-status-panel" style="display: none; margin-top: 6px; color: #516776; overflow-wrap: anywhere; word-break: break-word;">Migration status: checking...</div>
    </section>

    <section id="google-ai-mode-card" class="settings-section" data-settings-section data-settings-group="connections" data-settings-label="Google AI Mode" data-settings-search="Google AI Mode optional site access permission capture search conversations" style="margin-top: 16px;">
      <div style="display: flex; gap: 10px; justify-content: space-between; align-items: center; flex-wrap: wrap;">
        <h2 style="margin: 0; font-size: 16px;">Google AI Mode</h2>
        <span id="google-ai-mode-state" data-state="checking">Checking...</span>
      </div>
      <p class="settings-card-description" style="margin: 8px 0 0; color: #4f6576; line-height: 1.5;">Optional. Enable this only if you want LLMnesia to save full-page Google AI Mode conversations automatically.</p>
      <div style="display: flex; gap: 10px; align-items: center; flex-wrap: wrap; margin-top: 10px;">
        <button id="google-ai-mode-toggle" class="settings-primary-action" type="button" disabled style="padding: 8px 12px;">Checking access...</button>
        <span id="google-ai-mode-status" role="status" aria-live="polite" style="color: #526771; font-size: 12px;">Google site access is off.</span>
      </div>
      <details style="margin-top: 10px;">
        <summary style="cursor: pointer; font-size: 12px;">Why Chrome asks for Google site access</summary>
        <p style="margin: 7px 0 0; color: #4f6576; font-size: 12px; line-height: 1.55;">Chrome grants access at the Google domain level because it cannot limit a permission to the AI Mode URL parameter. LLMnesia activates conversation capture only on Google Search pages in AI Mode and ignores ordinary searches.</p>
      </details>
    </section>

    <section id="chatgpt-temporary-card" class="settings-section" data-settings-section data-settings-group="connections" data-settings-label="ChatGPT Temporary Chats" data-settings-search="ChatGPT temporary chats save opt in capture anonymous logged out privacy consent viewer" style="margin-top: 16px;">
      <h2 style="margin: 0; font-size: 16px;">ChatGPT Temporary Chats</h2>
      <p class="settings-card-description" style="margin: 8px 0 0; color: #4f6576; line-height: 1.5;">Preserve copies of Temporary Chats in LLMnesia. These chats have no original ChatGPT link and always open in the viewer.</p>
      <div style="display: flex; gap: 10px; align-items: center; flex-wrap: wrap; margin-top: 10px;">
        <label style="display: inline-flex; gap: 8px; align-items: center; cursor: pointer; font-weight: 700; font-size: 13px;">
          <input id="chatgpt-temporary-toggle" type="checkbox" />
          Save ChatGPT Temporary Chats
        </label>
        <span id="chatgpt-temporary-status" role="status" aria-live="polite" style="color: #526771; font-size: 12px;"></span>
      </div>
      <details style="margin-top: 10px;">
        <summary style="cursor: pointer; font-size: 12px;">What enabling this means</summary>
        <p style="margin: 7px 0 0; color: #4f6576; font-size: 12px; line-height: 1.55;">Off by default. Enabling this keeps a copy of each Temporary Chat in LLMnesia while you chat: enabling it preserves a copy in your index, and Vault sync may copy saved records to your other signed-in devices. Turning it off later stops future captures but does not delete copies already saved; delete those from search results as usual.</p>
      </details>
    </section>

    <section id="local-sessions-card" class="settings-section" data-settings-section data-settings-group="connections" data-settings-label="Local sources" data-settings-search="local coding sessions Claude Code Codex ZCode z.ai terminal IDE desktop app helper folder sync import" style="margin-top: 16px; border: 1px solid #ecccb9; border-left: 4px solid #d97757; border-radius: 12px; padding: 14px 16px; background: #fdf6f2;">
      <h2 style="margin: 0 0 10px; font-size: 16px; color: #8a4b2e;">Local coding sessions</h2>
      <p class="settings-card-description" style="margin: 0 0 10px; color: #4f6576;">Bring Claude Code, Codex, and ZCode chats into search. LLMnesia keeps only your prompts and the assistant’s replies—not commands, file reads, or tool output.</p>
      <div id="ls-helper-setup" class="settings-subpanel" style="display: none; margin: 0 0 12px; padding: 12px 14px; border: 1px solid #e6cdbb; border-radius: 10px; background: #fff8f3;">
        <div style="font-weight: 700; color: #315a3e; margin-bottom: 4px;">Recommended: keep all your tools in sync automatically</div>
        <p style="margin: 0 0 8px; color: #4d6254; font-size: 12.5px; line-height: 1.55;">Run one command, restart your browser, then connect the helper. After that, Claude Code, Codex, and ZCode sessions stay up to date without folder picking.</p>
        <div style="display: flex; gap: 8px; align-items: center; flex-wrap: wrap; margin-bottom: 8px;">
          <code id="ls-install-cmd" style="flex: 1 1 260px; min-width: 0; overflow-x: auto; white-space: nowrap; background: #fff; border: 1px solid #e0cdbf; border-radius: 6px; padding: 6px 9px; font-size: 12px; color: #5f4636;">npx -y @llmnesia/local-agent-host@latest</code>
          <button id="ls-copy-install" type="button" style="padding: 6px 12px; border-radius: 7px; border: 1px solid #d97757; background: #fff; color: #8a4b2e; cursor: pointer; font-weight: 600;">Copy</button>
        </div>
        <ol style="margin: 0 0 10px; padding: 0 0 0 18px; color: #4d6254; font-size: 12px; line-height: 1.6;">
          <li>Paste it into ${Ir} and run it (requires <a href="https://nodejs.org/" target="_blank" rel="noopener">Node.js 18+</a>).</li>
          <li>${Js}</li>
          <li>Return here and select <strong>Connect helper</strong>.</li>
        </ol>
        <button id="ls-connect" class="settings-primary-action" type="button" style="padding: 8px 12px; border-radius: 8px; border: 1px solid #d97757; background: #fff; color: #8a4b2e; cursor: pointer; font-weight: 600;">Connect helper</button>
        <details style="margin-top: 9px;">
          <summary style="cursor: pointer; font-size: 12px;">What the helper installs</summary>
          <p style="margin: 7px 0 0; color: #5d6f62; font-size: 12px;">One small script in <code>~/.llmnesia</code>, registered with your browser. It reads only Claude Code, Codex, and ZCode session data, has no network access, and keeps everything on this computer.</p>
        </details>
      </div>

      <div class="settings-subpanel" style="margin-top: 12px; padding: 12px 14px; border: 1px solid #eddbcf; border-radius: 10px; background: #fffdfb;">
        <div style="font-weight: 600; color: #8a4b2e; margin-bottom: 2px;">Claude Code</div>
        <p id="ls-hint-claude_code" style="margin: 0 0 8px; color: #6a7f90; font-size: 12px;">Add your local Claude Code sessions to search.</p>
        <div style="display: flex; gap: 8px; flex-wrap: wrap;">
          <button id="ls-choose-claude_code" class="settings-primary-action" type="button" style="padding: 8px 12px; border-radius: 8px; border: 1px solid #d97757; background: #fff; color: #8a4b2e; cursor: pointer; font-weight: 600;">Choose folder</button>
          <button id="ls-copy-path-claude_code" type="button" style="display: none; padding: 8px 12px; border-radius: 8px; border: 1px solid #c6d0b0; background: #fff; color: #3f5568; cursor: pointer;">Copy path</button>
          <button id="ls-rescan-claude_code" type="button" style="display: none; padding: 8px 12px; border-radius: 8px; border: 1px solid #c6d0b0; background: #fff; cursor: pointer;">Rescan for new sessions</button>
          <button id="ls-forget-claude_code" type="button" style="display: none; padding: 8px 12px; border-radius: 8px; border: 1px solid #d7b1b1; background: #fff4f4; color: #7a2626; cursor: pointer;">Forget folder</button>
          <input id="ls-dir-input-claude_code" type="file" webkitdirectory multiple style="display: none;" />
        </div>
        <div id="ls-status-claude_code" class="settings-status-panel" style="margin-top: 10px; color: #2f4654; overflow-wrap: anywhere; word-break: break-word;">Not connected.</div>
      </div>

      <div class="settings-subpanel" style="margin-top: 10px; padding: 12px 14px; border: 1px solid #e0e3e7; border-radius: 10px; background: #fbfbfc;">
        <div style="font-weight: 600; color: #3f4753; margin-bottom: 2px;">Codex</div>
        <p id="ls-hint-codex" style="margin: 0 0 8px; color: #6a7f90; font-size: 12px;">Add your local Codex sessions to search.</p>
        <div style="display: flex; gap: 8px; flex-wrap: wrap;">
          <button id="ls-choose-codex" class="settings-primary-action" type="button" style="padding: 8px 12px; border-radius: 8px; border: 1px solid #98a0ab; background: #fff; color: #3f4753; cursor: pointer; font-weight: 600;">Choose folder</button>
          <button id="ls-copy-path-codex" type="button" style="display: none; padding: 8px 12px; border-radius: 8px; border: 1px solid #c6d0b0; background: #fff; color: #3f5568; cursor: pointer;">Copy path</button>
          <button id="ls-rescan-codex" type="button" style="display: none; padding: 8px 12px; border-radius: 8px; border: 1px solid #c6d0b0; background: #fff; cursor: pointer;">Rescan for new sessions</button>
          <button id="ls-forget-codex" type="button" style="display: none; padding: 8px 12px; border-radius: 8px; border: 1px solid #d7b1b1; background: #fff4f4; color: #7a2626; cursor: pointer;">Forget folder</button>
          <input id="ls-dir-input-codex" type="file" webkitdirectory multiple style="display: none;" />
        </div>
        <div id="ls-status-codex" class="settings-status-panel" style="margin-top: 10px; color: #2f4654; overflow-wrap: anywhere; word-break: break-word;">Not connected.</div>
      </div>

      <div class="settings-subpanel" style="margin-top: 10px; padding: 12px 14px; border: 1px solid #e6c6d0; border-radius: 10px; background: #fdf9fa;">
        <div style="font-weight: 600; color: #732840; margin-bottom: 2px;">ZCode (z.ai)</div>
        <p id="ls-hint-zcode" style="margin: 0 0 8px; color: #6a7f90; font-size: 12px;">Add your local ZCode sessions to search.</p>
        <div style="display: flex; gap: 8px; flex-wrap: wrap;">
          <button id="ls-choose-zcode" class="settings-primary-action" type="button" style="display: none; padding: 8px 12px; border-radius: 8px; border: 1px solid #8c3049; background: #fff; color: #732840; cursor: pointer; font-weight: 600;">Sync now</button>
          <button id="ls-copy-path-zcode" type="button" style="display: none; padding: 8px 12px; border-radius: 8px; border: 1px solid #c6d0b0; background: #fff; color: #3f5568; cursor: pointer;">Copy path</button>
          <button id="ls-rescan-zcode" type="button" style="display: none; padding: 8px 12px; border-radius: 8px; border: 1px solid #c6d0b0; background: #fff; cursor: pointer;">Rescan for new sessions</button>
          <button id="ls-forget-zcode" type="button" style="display: none; padding: 8px 12px; border-radius: 8px; border: 1px solid #d7b1b1; background: #fff4f4; color: #7a2626; cursor: pointer;">Forget folder</button>
          <input id="ls-dir-input-zcode" type="file" webkitdirectory multiple style="display: none;" />
        </div>
        <div id="ls-status-zcode" class="settings-status-panel" style="margin-top: 10px; color: #2f4654; overflow-wrap: anywhere; word-break: break-word;">Not connected.</div>
      </div>

      <div id="ls-brave-help" style="display: none; margin-top: 12px; padding: 10px 12px; border: 1px solid #e6d3c6; border-radius: 8px; background: #fbf1ea; font-size: 12px; color: #5f4636; line-height: 1.55;">
        <strong>Optional, Brave only:</strong> the one-time helper above is the smoothest path (it syncs in the background). But if you'd rather not run a terminal command, you can upgrade <strong>Choose folder</strong> so Brave remembers the folder and rescans on its own. Turn on Brave's File System Access flag — Brave blocks links to its flags page, so:
        <div style="display: flex; gap: 8px; align-items: center; flex-wrap: wrap; margin: 8px 0;">
          <code style="background: #fff; border: 1px solid #e0cdbf; border-radius: 6px; padding: 3px 7px;">brave://flags/#file-system-access-api</code>
          <button id="ls-copy-flag" type="button" style="padding: 5px 10px; border-radius: 7px; border: 1px solid #d0b9a8; background: #fff; cursor: pointer;">Copy address</button>
        </div>
        <ol style="margin: 0 0 0 18px; padding: 0;">
          <li>Paste it into Brave's address bar and press Enter (typing it yourself is the only way — links to it are blocked).</li>
          <li>Set the flag to <strong>Enabled</strong>, then click <strong>Relaunch</strong>.</li>
          <li>Reopen this Settings page — <strong>Choose folder</strong> now remembers your folder and rescans on its own. (If the flag isn't listed, search "File System Access" on that page.)</li>
        </ol>
      </div>
    </section>

    <section id="backfill-section" class="settings-section" data-settings-section data-settings-group="overview" data-settings-label="Import progress" data-settings-search="older chats backfill import progress pause" style="display: none; margin-top: 16px; border: 1px solid #dbe2cf; border-left: 4px solid #c98a2e; border-radius: 12px; padding: 14px 16px; background: #fdf6e8;">
      <h2 style="margin: 0; font-size: 16px;">Indexing older chats</h2>
      <div class="options-progress-track" style="margin-top: 8px; height: 8px; border: 1px solid #cbd9e6; border-radius: 999px; background: #edf3f8; overflow: hidden;">
        <div id="backfill-progress-fill" style="height: 100%; width: 0%; background: linear-gradient(90deg, #2f7f99 0%, #49b08f 100%); transition: width 0.4s ease;"></div>
      </div>
      <div id="backfill-status-text" class="settings-status-panel" style="margin-top: 6px; color: #4f6576;">Working…</div>
      <p style="margin: 8px 0 0; color: #7a8a96; font-size: 13px;">Start or pause imports from the extension popup on a supported AI tab.</p>
    </section>

    <section id="memory-section" class="settings-section" data-settings-section data-settings-group="knowledge" data-settings-label="Reusable context" data-settings-search="memory memories save import ChatGPT Claude auto every new chat" style="margin-top: 16px; border: 1px solid #dbe2cf; border-left: 4px solid #2f7f99; border-radius: 12px; padding: 14px 16px; background: #eef6f8;">
      <div style="display: flex; justify-content: space-between; align-items: center; gap: 8px; flex-wrap: wrap;">
        <h2 style="margin: 0; font-size: 16px;">Memory <span style="font-size: 11px; font-weight: 400; color: #8a7a5a; background: #faf5e4; border: 1px solid #e8dfc0; border-radius: 4px; padding: 2px 6px; vertical-align: middle;">Beta</span></h2>
      </div>
      <p class="settings-card-description" style="margin: 8px 0 0; color: #4f6576;">Save something once, then reuse it in any new AI chat.</p>

      <div id="memory-example-chips" style="margin-top: 12px;">
        <div style="font-weight: 600; color: #2f4419; margin-bottom: 4px;">What should every AI know about you?</div>
        <div style="display: flex; gap: 6px; flex-wrap: wrap;">
          <button type="button" class="memory-example-chip" data-example="I prefer concise, direct answers — skip the preamble and get to the point." style="padding: 6px 12px; border-radius: 999px; border: 1px solid #c3d29a; background: #f5f9e9; color: #2f4419; cursor: pointer; font-size: 12.5px;">How I like answers</button>
          <button type="button" class="memory-example-chip" data-example="My role: e.g. a software engineer working mostly in TypeScript." style="padding: 6px 12px; border-radius: 999px; border: 1px solid #c3d29a; background: #f5f9e9; color: #2f4419; cursor: pointer; font-size: 12.5px;">My role</button>
          <button type="button" class="memory-example-chip" data-example="A project I'm currently working on: e.g. rebuilding our onboarding flow." style="padding: 6px 12px; border-radius: 999px; border: 1px solid #c3d29a; background: #f5f9e9; color: #2f4419; cursor: pointer; font-size: 12.5px;">A current project</button>
          <button type="button" class="memory-example-chip" data-example="A preference: e.g. always write plain TypeScript, no frameworks unless I ask." style="padding: 6px 12px; border-radius: 999px; border: 1px solid #c3d29a; background: #f5f9e9; color: #2f4419; cursor: pointer; font-size: 12.5px;">A coding preference</button>
        </div>
      </div>

      <button id="toggle-add-form" type="button" hidden style="margin-top: 12px; padding: 7px 12px; border-radius: 8px; border: 1px solid #c6d0b0; background: #fff; color: #3f5568; cursor: pointer; font-size: 13px;">+ Add memory</button>

      <div id="memory-add-form-wrap" class="settings-subpanel" style="margin-top: 12px; display: grid; gap: 8px; border: 1px solid #e3e9d6; border-radius: 10px; padding: 12px; background: #fcfdf7;">
        <textarea id="memory-text" placeholder="The memory itself, in your own words (e.g. I prefer concise answers and vanilla TypeScript, no frameworks)." rows="3" style="width: 100%; box-sizing: border-box; padding: 8px; border-radius: 8px; border: 1px solid #c6d0b0; resize: vertical; font-family: inherit;"></textarea>
        <input id="memory-label" type="text" placeholder="Optional label (e.g. Code style) — leave blank to use the start of the memory" style="width: 100%; box-sizing: border-box; padding: 8px; border-radius: 8px; border: 1px solid #c6d0b0; font-family: inherit; font-size: 13px;" />
        <div style="display: flex; gap: 12px; align-items: center; flex-wrap: wrap;">
          <label for="memory-pinned" style="display: inline-flex; align-items: center; gap: 6px; color: #3f5568; cursor: pointer; font-size: 13px;">
            <input id="memory-pinned" type="checkbox" />
            <span>Auto — add to every new chat</span>
          </label>
          <button id="add-memory" class="settings-primary-action" type="button" style="margin-left: auto; padding: 8px 14px; border-radius: 8px; border: 1px solid #9fb37e; background: #eef4dd; color: #2f4419; cursor: pointer; font-weight: 600;">Save memory</button>
        </div>
        <div style="color: #8a97a0; font-size: 11.5px;">Auto memories are added to every new chat automatically, so they use a few tokens. Leave off to keep a memory available to pick from the pill when you want it.</div>
      </div>

      <details style="margin-top: 10px;">
        <summary style="cursor: pointer; color: #4f6576; font-size: 13px; padding: 4px 0;">Already saved in ChatGPT or Claude? Import it instead</summary>
        <div class="settings-subpanel" style="margin-top: 10px; display: grid; gap: 8px; border: 1px solid #c3d29a; border-radius: 10px; padding: 12px; background: #f5f9e9;">
          <div style="font-weight: 600; color: #2f4419;">Paste your exported memory</div>
          <div style="display: flex; gap: 8px; align-items: center; flex-wrap: wrap;">
            <label for="memory-import-platform" style="color: #4f6576; font-size: 13px;">From</label>
            <select id="memory-import-platform" style="flex: 0 1 auto; padding: 8px; border-radius: 8px; border: 1px solid #c6d0b0; background: #fff;">
              <option value="chatgpt">ChatGPT</option>
              <option value="claude">Claude</option>
              <option value="gemini">Gemini</option>
              <option value="copilot">Copilot</option>
              <option value="deepseek">DeepSeek</option>
              <option value="kimi">Kimi</option>
              <option value="generic">Other</option>
            </select>
          </div>
          <div id="memory-import-hint" style="color: #4f6576; font-size: 12px;"></div>
          <textarea id="memory-import-text" rows="5" placeholder="Paste the memory here..." style="width: 100%; box-sizing: border-box; padding: 8px; border-radius: 8px; border: 1px solid #c6d0b0; resize: vertical; font-family: inherit;"></textarea>
          <div style="display: flex; gap: 8px; align-items: center; flex-wrap: wrap;">
            <button id="copy-export-prompt" type="button" style="padding: 8px 12px; border-radius: 8px; border: 1px solid #c6d0b0; background: #fff; cursor: pointer; font-size: 13px;">Copy export prompt</button>
            <button id="import-memory" class="settings-primary-action" type="button" style="margin-left: auto; padding: 8px 16px; border-radius: 8px; border: 1px solid #9fb37e; background: #eef4dd; color: #2f4419; cursor: pointer; font-weight: 600;">Save this memory</button>
          </div>
          <div id="memory-import-status" style="color: #2f4654; font-size: 12px; overflow-wrap: anywhere;"></div>
        </div>
      </details>

      <div id="pending-memory-review" class="settings-subpanel" style="margin-top: 14px; border: 1px solid #d7dfc8; border-radius: 10px; padding: 12px; background: #fbfcf7;">
        <div style="display: flex; justify-content: space-between; align-items: center; gap: 10px; flex-wrap: wrap;">
          <div>
            <h3 style="margin: 0; color: #2f4419; font-size: 14px;">Pending review</h3>
            <p style="margin: 3px 0 0; color: #5f7066; font-size: 12px;">Suggestions from connected assistants stay off until you enable them.</p>
          </div>
          <button id="enable-all-pending-memories" type="button" hidden style="padding: 7px 12px; border-radius: 8px; border: 1px solid #9fb37e; background: #eef4dd; color: #2f4419; cursor: pointer; font-weight: 600; font-size: 12px;">Enable all</button>
        </div>
        <div id="pending-memory-list" style="margin-top: 9px; display: grid; gap: 8px;">Loading suggestions...</div>
      </div>

      <div id="memory-manage-tools" hidden style="margin-top: 12px; display: flex; gap: 8px; align-items: center;">
        <input id="memory-filter" type="text" placeholder="Filter memories..." style="flex: 1 1 200px; min-width: 0; padding: 8px; border-radius: 8px; border: 1px solid #c6d0b0;" />
        <button id="refresh-memories" type="button" style="padding: 8px 12px; border-radius: 8px; border: 1px solid #c6d0b0; background: #fff; cursor: pointer;">Refresh</button>
      </div>
      <div id="memory-list" style="margin-top: 10px; display: grid; gap: 8px; max-height: 420px; overflow-y: auto; overflow-x: hidden; padding-right: 2px;">Loading memories...</div>
      <div id="memory-status" class="settings-status-panel" style="margin-top: 10px; color: #2f4654; overflow-wrap: anywhere;"></div>
    </section>

	    <section id="starred-section" class="settings-section" data-settings-section data-settings-group="knowledge" data-settings-label="Quick access" data-settings-search="starred starred conversations pins favorites quick access cleanup" style="margin-top: 16px; border: 1px solid #dbe2cf; border-left: 4px solid #b8901f; border-radius: 12px; padding: 14px 16px; background: #fdf8e8;">
	      <div style="display: flex; justify-content: space-between; align-items: center; gap: 8px; flex-wrap: wrap;">
	        <h2 style="margin: 0; font-size: 16px;">Starred Conversations</h2>
	        <div style="display: flex; gap: 8px; align-items: center; flex-wrap: wrap;">
	          <label for="pin-only" style="display: inline-flex; align-items: center; gap: 6px; color: #3f5568;">
	            <input id="pin-only" type="checkbox" checked />
	            <span>Starred only</span>
	          </label>
	          <button id="refresh-pins" type="button" style="padding: 8px 12px; border-radius: 8px; border: 1px solid #c6d0b0; background: #fff; cursor: pointer;">Refresh list</button>
	        </div>
	      </div>
	      <p class="settings-card-description" style="margin: 8px 0 0; color: #4f6576;">Star important chats to keep them easy to find.</p>
	      <div style="margin-top: 10px; display: flex; gap: 8px; align-items: center; flex-wrap: wrap;">
	        <input id="pin-filter" type="text" placeholder="Filter by title/platform..." style="flex: 1 1 280px; min-width: 0; padding: 8px; border-radius: 8px; border: 1px solid #c6d0b0;" />
	        <button id="clear-pin-filter" type="button" style="padding: 8px 12px; border-radius: 8px; border: 1px solid #c6d0b0; background: #fff; cursor: pointer;">Clear</button>
	      </div>
	      <div id="pin-list" style="margin-top: 10px; display: grid; gap: 8px; max-height: 420px; overflow-y: auto; overflow-x: hidden; padding-right: 2px;">Loading conversations...</div>
	      <div id="pin-status" class="settings-status-panel" style="margin-top: 10px; color: #2f4654; overflow-wrap: anywhere;">Star a chat to keep it close. Unstar it to remove the mark.</div>
	    </section>

    <section id="search-results-section" class="settings-section" data-settings-section data-settings-group="overview" data-settings-label="Search display" data-settings-search="search results matches limit performance speed" style="margin-top: 8px; border: 1px solid #dbe2cf; border-left: 4px solid #7a8a96; border-radius: 12px; padding: 10px 14px; background: #f7f9fa;">
      <div style="display: flex; align-items: center; justify-content: space-between; gap: 10px; flex-wrap: wrap;">
        <div>
          <h2>Search results</h2>
          <div style="margin-top: 1px; color: #637785; font-size: 11.5px;">Also available in the main search window.</div>
        </div>
        <label for="recent-limit" style="display: inline-flex; align-items: center; gap: 7px; color: #385066; font-size: 12px; white-space: nowrap;">
          <span>Max results</span>
          <select id="recent-limit" aria-label="Maximum search results" style="padding: 5px 8px; border-radius: 7px; border: 1px solid #c6d0b0; background: #fff; min-width: 74px;">
          <option value="30">30</option>
          <option value="50">50</option>
          <option value="100">100</option>
          <option value="250">250</option>
          <option value="500">500</option>
        </select>
        </label>
      </div>
      <div id="recent-limit-status" style="margin-top: 4px; color: #637785; font-size: 11.5px;">Applies to recent and typed searches.</div>
    </section>

    

    <section id="report-problem-section" class="settings-section" data-settings-section data-settings-group="advanced" data-settings-label="Help" data-settings-search="report problem support contact diagnostics snapshot search misses indexing stops" style="margin-top: 16px; border: 1px solid #dbe2cf; border-left: 4px solid #c26a2e; border-radius: 12px; padding: 16px 18px; background: #fdf3ea;">
      <h2 style="margin: 0 0 10px; font-size: 16px;">Report a Problem</h2>
      <p class="settings-card-description" style="margin: 0 0 12px; color: #4f6576; line-height: 1.5;">Open the contact form with a pre-filled report when chats are missing or indexing stops.</p>
      <div class="settings-actions" style="display: flex; gap: 10px; align-items: center; flex-wrap: wrap;">
        <button id="report-problem" class="settings-primary-action" type="button" style="padding: 8px 14px; border-radius: 8px; border: 1px solid #2f7f99; background: #2f7f99; color: #fff; cursor: pointer; font-weight: 600;">Report a problem</button>
        <label style="display: flex; align-items: center; gap: 6px; font-size: 12px; color: #4e6578; cursor: pointer;">
          <input id="options-snapshot-toggle" type="checkbox" checked />
          Include diagnostic snapshot (no message text)
        </label>
      </div>
      <p style="margin: 9px 0 0; font-size: 11.5px; color: #65766a; line-height: 1.5;">You can edit everything before submitting. The snapshot is structural only: no message text and no URLs.</p>
      <details style="margin-top: 10px;">
        <summary style="cursor: pointer;">Try quick fixes first</summary>
        <p style="margin: 7px 0 0; color: #526771; font-size: 12px;">Refresh the AI page, re-enable its site permission, and check the <a href="https://github.com/nicholasgriffintn/llmnesia#supported-sites" target="_blank" rel="noopener">supported sites list</a>.</p>
      </details>
    </section>

    <section id="backup-restore-section" class="settings-section" data-settings-section data-settings-group="data" data-settings-label="Local recovery" data-settings-search="backup restore export import file device browser profile local" style="margin-top: 16px; border: 1px solid #dbe2cf; border-left: 4px solid #3d6fa8; border-radius: 12px; padding: 14px 16px; background: #eef4fb;">
      <h2 style="margin: 0 0 10px; font-size: 16px;">Backup & Restore</h2>
      <p class="settings-card-description" style="margin: 0 0 10px; color: #4f6576;">Download a backup before switching devices or browser profiles. Import brings one back.</p>
      <div class="settings-actions" style="display: flex; gap: 8px; flex-wrap: wrap; align-items: center;">
        <button id="export-backup" class="settings-primary-action" type="button" style="padding: 8px 12px; border-radius: 8px; border: 1px solid #c6d0b0; background: #fff; cursor: pointer;">Export backup</button>
        <button id="import-backup" type="button" style="padding: 8px 12px; border-radius: 8px; border: 1px solid #c6d0b0; background: #fff; cursor: pointer;">Import backup</button>
        <button id="import-backup-cancel" type="button" style="display: none; padding: 8px 12px; border-radius: 8px; border: 1px solid #d5b0b0; background: #fff; color: #a23c3c; cursor: pointer;">Stop</button>
        <input id="import-backup-file" type="file" accept=".jsonl,.jsonl.gz,.json,application/json,application/gzip" style="display: none;" />
      </div>
      <progress id="backup-progress" max="100" value="0" style="display: none; width: 100%; height: 10px; margin-top: 10px;"></progress>
      <div id="backup-status" class="settings-status-panel" style="margin-top: 10px; color: #2f4654; overflow-wrap: anywhere; word-break: break-word;">No backup action yet.</div>
      <div style="margin-top: 14px; padding-top: 12px; border-top: 1px solid #dbe2cf;">
        <h3 style="margin: 0 0 6px; font-size: 13.5px;">Automatic daily backup (opt-in)</h3>
        <p style="margin: 0 0 8px; color: #4f6576; font-size: 12.5px; line-height: 1.45;">
          Keep up to 3 verified backup versions inside this Chrome profile, refreshed about once a day.
          The newest backup is only kept after its checksum verifies; a failed write never touches the
          previous versions. Because the copies live inside the browser profile, they do not protect
          against a full disk, a wiped profile, or drive failure: use <strong>Export backup</strong> for
          a copy outside the browser.
        </p>
        <label style="display: flex; align-items: center; gap: 8px; margin-bottom: 8px; cursor: pointer;">
          <input id="rolling-backup-enabled" type="checkbox" style="cursor: pointer;" />
          <span style="font-size: 12.5px;">Back up my chats automatically (daily)</span>
        </label>
        <div class="settings-actions" style="display: flex; gap: 8px; flex-wrap: wrap; align-items: center;">
          <button id="rolling-backup-now" type="button" style="padding: 8px 12px; border-radius: 8px; border: 1px solid #c6d0b0; background: #fff; cursor: pointer;">Back up now</button>
          <button id="rolling-backup-restore" type="button" style="padding: 8px 12px; border-radius: 8px; border: 1px solid #c6d0b0; background: #fff; cursor: pointer;">Restore from latest backup</button>
        </div>
        <div id="rolling-backup-status" class="settings-status-panel" style="margin-top: 10px; color: #2f4654; overflow-wrap: anywhere; word-break: break-word;">Automatic backups are off.</div>
      </div>
    </section>

    <section id="import-chatgpt-export-section" class="settings-section" data-settings-section data-settings-group="data" data-settings-label="Complete history" data-settings-search="ChatGPT history export data controls zip import older chats" style="margin-top: 16px; border: 1px solid #dbe2cf; border-left: 4px solid #3d6fa8; border-radius: 12px; padding: 14px 16px; background: #eef4fb;">
      <h2 style="margin: 0 0 10px; font-size: 16px;">Import your full ChatGPT history</h2>
      <p class="settings-card-description" style="margin: 0 0 10px; color: #4f6576;">Import ChatGPT’s data-export <code>.zip</code> for the most complete copy of older chats. Existing chats are not duplicated.</p>
      <div class="settings-actions" style="display: flex; gap: 8px; flex-wrap: wrap; align-items: center;">
        <button id="import-chatgpt-export" class="settings-primary-action" type="button" style="padding: 8px 12px; border-radius: 8px; border: 1px solid #c6d0b0; background: #fff; cursor: pointer;">Choose ChatGPT export .zip</button>
        <button id="import-chatgpt-export-cancel" type="button" style="display: none; padding: 8px 12px; border-radius: 8px; border: 1px solid #d5b0b0; background: #fff; color: #a23c3c; cursor: pointer;">Stop</button>
        <input id="import-chatgpt-export-file" type="file" accept=".zip,application/zip" style="display: none;" />
      </div>
      <progress id="chatgpt-export-progress" max="100" value="0" style="display: none; width: 100%; height: 10px; margin-top: 10px;"></progress>
      <div id="chatgpt-export-status" class="settings-status-panel" style="margin-top: 10px; color: #2f4654; overflow-wrap: anywhere; word-break: break-word;">No import yet.</div>
      <details style="margin-top: 10px;">
        <summary style="cursor: pointer;">How to get the export file</summary>
        <p style="margin: 7px 0 0; color: #526771; font-size: 12px;">In ChatGPT, open <strong>Settings → Data controls → Export data</strong>. ChatGPT emails the file later—usually within a few hours, but occasionally after a day or two. LLMnesia reads only the chat text.</p>
      </details>
    </section>

    ${Np}

    

    <section id="technical-errors-section" class="settings-section" data-settings-section data-settings-group="advanced" data-settings-label="Diagnostics" data-settings-search="technical error log errors adapter logs export clear diagnostics google ai mode import retry report missing older messages" style="margin-top: 16px; border: 1px solid #dbe2cf; border-left: 4px solid #9a6b6b; border-radius: 12px; padding: 12px 16px; background: #faf5f5;">
      <div style="display: flex; justify-content: space-between; align-items: center; gap: 8px; flex-wrap: wrap;">
        <h2 style="margin: 0; font-size: 14px;">Technical error log</h2>
        <div style="display: flex; gap: 8px; flex-wrap: wrap;">
          <button id="refresh-error-logs" type="button" style="padding: 8px 12px; border-radius: 8px; border: 1px solid #c6d0b0; background: #fff; cursor: pointer;">Refresh logs</button>
          <button id="copy-error-logs" type="button" style="padding: 8px 12px; border-radius: 8px; border: 1px solid #c6d0b0; background: #fff; cursor: pointer;">Copy logs</button>
          <button id="export-error-logs" type="button" style="padding: 8px 12px; border-radius: 8px; border: 1px solid #c6d0b0; background: #fff; cursor: pointer;">Export JSON</button>
          <button id="clear-error-logs" type="button" style="padding: 8px 12px; border-radius: 8px; border: 1px solid #d7b1b1; background: #fff4f4; color: #7a2626; cursor: pointer;">Clear logs</button>
        </div>
      </div>
      <p class="settings-card-description" style="margin: 8px 0 0; color: #4f6576;">For troubleshooting and bug reports. You can ignore this unless support asks for it.</p>
      <div style="margin-top: 12px;">
        <strong style="font-size: 13px;">Last adapter errors</strong>
        <div id="adapter-errors-list" style="margin-top: 6px; display: grid; gap: 4px; min-width: 0; color: #2f4654;">No adapter errors recorded.</div>
      </div>
      <div id="error-log-status" class="settings-status-panel" style="margin-top: 12px; color: #2f4654; overflow-wrap: anywhere;">Captures recent extension errors automatically.</div>
      <div id="error-log-list" style="margin-top: 10px; display: grid; gap: 8px; max-height: 320px; overflow-y: auto; overflow-x: hidden; padding-right: 2px;">Loading error logs...</div>
      <details style="margin-top: 16px; border-top: 1px solid #ecdcdc; padding-top: 12px;">
        <summary style="cursor: pointer; font-size: 13px;">Google AI Mode imports</summary>
        <p class="settings-card-description" style="margin: 8px 0 10px; color: #4f6576;">Missing older messages in a Google chat? Retry it here. Google may not return everything.</p>
        <label for="google-import-retry-filter" style="display: block; font-size: 12px; color: #4f6576;">Chat to retry</label>
        <input id="google-import-retry-filter" type="search" placeholder="Search by title or ID" autocomplete="off" style="display: block; width: 100%; box-sizing: border-box; margin: 6px 0; padding: 8px 10px; font: inherit; font-size: 12px;" />
        <select id="google-import-retry-chat" size="7" aria-label="Google chats available to retry" style="display: block; width: 100%; max-width: 100%; box-sizing: border-box; margin: 0; padding: 4px; font: inherit; font-size: 12px;" disabled></select>
        <div id="google-import-retry-detail" style="margin: 6px 0 10px; color: #637785; font-size: 12px; overflow-wrap: anywhere;"></div>
        <div style="display: flex; gap: 8px; flex-wrap: wrap;">
          <button id="refresh-google-import-chats" type="button" style="padding: 8px 12px; border-radius: 8px; border: 1px solid #c6d0b0; background: #fff; cursor: pointer;">Refresh list</button>
          <button id="retry-google-import-chat" type="button" style="padding: 8px 12px; border-radius: 8px; border: 1px solid #c6d0b0; background: #fff; cursor: pointer;" disabled>Retry chat</button>
        </div>
        <div id="google-import-retry-status" role="status" style="margin-top: 8px;"></div>
        <p style="margin: 8px 0 0; color: #637785; font-size: 12px;">Keep a Google AI Mode tab open. Follow progress or stop a retry from the LLMnesia toolbar icon.</p>
        <div style="margin-top: 14px; padding-top: 12px; border-top: 1px dashed #d9c7c7;">
          <button id="export-google-import-report" type="button" style="padding: 8px 12px; border-radius: 8px; border: 1px solid #c6d0b0; background: #fff; cursor: pointer;">Export import report</button>
          <span style="margin-left: 8px; color: #637785; font-size: 12px;">Titles, chat IDs and message counts only. No message text.</span>
          <div id="google-import-report-status" role="status" style="margin-top: 8px;"></div>
        </div>
      </details>
    </section>

    ${`
    <section id="vault-card" class="settings-section" data-settings-section data-settings-group="connections" data-settings-search="Vault encrypted sync backup recovery passphrase email device restore lock subscription billing payment invoice cancellation" style="margin-top: 16px; border: 1px solid ${p.tealEdge}; border-left: 4px solid ${p.teal}; border-radius: 12px; padding: 14px 16px; background: ${p.tealSoft};">
      <div class="vault-card-header">
        <div class="vault-card-kicker-row">
          <span class="vault-card-badge">Vault</span>
          <span class="vault-card-encryption-note">End-to-end encrypted</span>
        </div>
        <h2 class="vault-card-title">Keep your history safe on every device</h2>
        <p class="vault-card-description">Vault keeps an encrypted copy of your conversations and memories, ready to restore on a new device and stay in sync wherever you work.</p>
        <div class="vault-card-flow" role="group" aria-label="Your conversations are encrypted in Vault and available only on your devices">
          <strong>Your conversations</strong>
          <span class="vault-card-flow-arrow" aria-hidden="true">→</span>
          <span class="vault-card-flow-vault">Encrypted Vault</span>
          <span class="vault-card-flow-arrow" aria-hidden="true">→</span>
          <strong>Your devices</strong>
        </div>
        <p class="vault-card-trust-note">Only your devices can decrypt your data. LLMnesia cannot read your conversations.</p>
      </div>
      <div class="vault-card-body">
      <p class="vault-card-privacy"><strong>Your passphrase stays private.</strong> LLMnesia cannot recover a lost passphrase, so you stay in control of your encrypted history.</p>
      <div id="vault-signin-success" class="vault-signin-success" role="status" aria-live="polite"></div>

      <div id="vault-signed-out" style="display: none;">
        <p style="margin: 0 0 8px; color: #3d5f6c; font-size: 12.5px;">New to Vault? Enter the email you want to use and we will send a sign-in code. Already subscribed on the website? Use the email you used at checkout.</p>
        <p style="margin: 0 0 10px; color: #5b7683; font-size: 12px; line-height: 1.5;">Already have a Vault on another device or browser? Continue with the email address it was created under, then unlock it here with the same passphrase. You won't create a second Vault.</p>
        <div style="display: flex; gap: 8px; flex-wrap: wrap;">
          <input id="vault-email" type="email" aria-label="Vault email address" autocomplete="email" placeholder="you@example.com" style="flex: 1; min-width: 200px; padding: 8px 10px; border-radius: 8px;" />
          <button id="vault-send-code" type="button" style="padding: 8px 12px; border-radius: 8px; border: 1px solid ${p.teal}; background: ${p.teal}; color: #fff; cursor: pointer; font-weight: 600;">Continue with email</button>
        </div>
      </div>

      <div id="vault-code-step" style="display: none;">
        <p style="margin: 0 0 8px; color: #3d5f6c;">Check <strong id="vault-code-email"></strong> for your sign-in code, including your spam folder. Use the code from the most recent email.</p>
        <div style="display: flex; gap: 8px; flex-wrap: wrap;">
          <input id="vault-code" type="text" aria-label="Vault sign-in code" inputmode="numeric" autocomplete="one-time-code" placeholder="8-digit code" style="width: 140px; padding: 8px 10px; border-radius: 8px;" />
          <button id="vault-verify-code" type="button" style="padding: 8px 12px; border-radius: 8px; border: 1px solid ${p.teal}; background: ${p.teal}; color: #fff; cursor: pointer; font-weight: 600;">Confirm email</button>
          <button id="vault-resend-code" type="button" style="padding: 8px 12px; border-radius: 8px; border: 1px solid ${p.tealEdge}; background: #fff; cursor: pointer;">Resend</button>
          <button id="vault-cancel-code" type="button" style="padding: 8px 12px; border-radius: 8px; border: 1px solid ${p.tealEdge}; background: #fff; cursor: pointer;">Use a different email</button>
        </div>
      </div>

      <div id="vault-create-step" style="display: none;">
        <p style="margin: 0 0 8px; color: #3d5f6c;"><strong>Create your private passphrase.</strong> It is separate from your email code, stays on your device, and cannot be reset by LLMnesia.</p>
        <div style="display: flex; gap: 8px; flex-wrap: wrap; margin-bottom: 6px;">
          <input id="vault-new-passphrase" type="password" placeholder="Passphrase" spellcheck="false" autocapitalize="off" autocorrect="off" style="flex: 1; min-width: 180px; padding: 8px 10px; border-radius: 8px;" />
          <button id="vault-new-passphrase-visibility" type="button" aria-controls="vault-new-passphrase" aria-pressed="false" aria-label="Show passphrase" style="${Xe}">Show</button>
          <input id="vault-confirm-passphrase" type="password" placeholder="Confirm passphrase" spellcheck="false" autocapitalize="off" autocorrect="off" style="flex: 1; min-width: 180px; padding: 8px 10px; border-radius: 8px;" />
          <button id="vault-confirm-passphrase-visibility" type="button" aria-controls="vault-confirm-passphrase" aria-pressed="false" aria-label="Show confirm passphrase" style="${Xe}">Show</button>
        </div>
        <div id="vault-passphrase-strength" style="margin: 0 0 10px; font-size: 11.5px; color: #5b7683;"></div>
        <button id="vault-create-continue" type="button" style="padding: 8px 12px; border-radius: 8px; border: 1px solid ${p.teal}; background: ${p.teal}; color: #fff; cursor: pointer; font-weight: 600;">Continue to recovery key</button>

        <div id="vault-recovery-key-block" style="display: none; margin-top: 14px; padding: 12px 14px; border: 1px solid ${p.tealEdge}; border-radius: 10px; background: #fff;">
          <div style="font-weight: 600; color: #1c5a6e; margin-bottom: 6px;">Save your recovery key</div>
          <p style="margin: 0 0 8px; color: #3d5f6c; font-size: 12.5px; line-height: 1.55;">Store this somewhere safe. It is the only way to regain access if you forget your passphrase.</p>
          <div style="display: flex; gap: 8px; align-items: center; flex-wrap: wrap; margin-bottom: 10px;">
            <code id="vault-recovery-key" style="flex: 1 1 260px; min-width: 0; overflow-wrap: anywhere; white-space: normal; background: ${p.paperSoft}; border: 1px solid ${p.ruleSoft}; border-radius: 6px; padding: 8px 10px; font-size: 12.5px; letter-spacing: 0.02em;"></code>
            <button id="vault-copy-recovery" type="button" style="padding: 6px 12px; border-radius: 7px; border: 1px solid ${p.teal}; background: #fff; color: #1c5a6e; cursor: pointer; font-weight: 600;">Copy</button>
          </div>
          <label style="display: flex; gap: 8px; align-items: flex-start; font-size: 12.5px; color: #3d5f6c; cursor: pointer;">
            <input id="vault-ack-checkbox" type="checkbox" style="margin-top: 2px;" />
            <span>I've saved this recovery key somewhere safe. If I lose both my passphrase and this key, my data cannot be recovered.</span>
          </label>
          <button id="vault-confirm-create" type="button" disabled style="margin-top: 10px; padding: 8px 12px; border-radius: 8px; border: 1px solid ${p.teal}; background: ${p.teal}; color: #fff; cursor: pointer; font-weight: 600; opacity: 0.5;">Finish setting up Vault</button>
        </div>
      </div>

      <div id="vault-unlock-step" style="display: none;">
        <p id="vault-unlock-copy" style="margin: 0 0 8px; color: #3d5f6c; font-size: 12.5px;">You already have a Vault for this email. Enter its passphrase to open it on this device.</p>
        <div id="vault-biometric-unlock" style="display: none; margin: 0 0 10px;">
          <button id="vault-biometric-unlock-btn" type="button" style="padding: 8px 12px; border-radius: 8px; border: 1px solid ${p.teal}; background: ${p.teal}; color: #fff; cursor: pointer; font-weight: 600;">Unlock with biometrics</button>
          <div style="display: inline-block; margin: 0 8px; color: #5b7683; font-size: 12px;">or use your passphrase</div>
        </div>
        <div style="display: flex; gap: 8px; flex-wrap: wrap;">
          <input id="vault-unlock-passphrase" type="password" placeholder="Your private passphrase" spellcheck="false" autocapitalize="off" autocorrect="off" style="flex: 1; min-width: 180px; padding: 8px 10px; border-radius: 8px;" />
          <button id="vault-unlock-passphrase-visibility" type="button" aria-controls="vault-unlock-passphrase" aria-pressed="false" aria-label="Show passphrase" style="${Xe}">Show</button>
          <button id="vault-unlock-btn" type="button" style="padding: 8px 12px; border-radius: 8px; border: 1px solid ${p.teal}; background: ${p.teal}; color: #fff; cursor: pointer; font-weight: 600;">Unlock Vault</button>
        </div>
        <button id="vault-recover-toggle" type="button" style="margin-top: 12px; padding: 0; border: 0; background: none; color: #1c5a6e; text-decoration: underline; cursor: pointer;">Forgot passphrase? Use recovery key</button>
        <div id="vault-recover-form" style="display: none; margin-top: 12px; padding: 12px 14px; border: 1px solid ${p.tealEdge}; border-radius: 10px; background: #fff;">
          <p style="margin: 0 0 10px; color: #3d5f6c; font-size: 12.5px; line-height: 1.55;">Enter the recovery key you saved when creating this Vault, then choose a new passphrase. The key has 14 dash-separated groups: 13 groups of four symbols and a final group of three. Keep the key private. Recovery requires an internet connection.</p>
          <label for="vault-recover-key" style="display: block; margin-bottom: 4px; font-size: 12.5px; font-weight: 600;">Recovery key</label>
          <input id="vault-recover-key" type="password" autocomplete="off" spellcheck="false" style="box-sizing: border-box; width: 100%; padding: 8px 10px; margin-bottom: 8px;" />
          <button id="vault-recover-show-key" type="button" style="margin-bottom: 10px; padding: 0; border: 0; background: none; color: #1c5a6e; text-decoration: underline; cursor: pointer;">Show recovery key</button>
          <label for="vault-recover-passphrase" style="display: block; margin-bottom: 4px; font-size: 12.5px; font-weight: 600;">New passphrase</label>
          <div style="display: flex; gap: 8px; align-items: stretch; margin-bottom: 10px;">
            <input id="vault-recover-passphrase" type="password" autocomplete="new-password" spellcheck="false" autocapitalize="off" autocorrect="off" style="flex: 1; min-width: 0; box-sizing: border-box; padding: 8px 10px;" />
            <button id="vault-recover-passphrase-visibility" type="button" aria-controls="vault-recover-passphrase" aria-pressed="false" aria-label="Show new passphrase" style="${Xe}">Show</button>
          </div>
          <label for="vault-recover-confirm" style="display: block; margin-bottom: 4px; font-size: 12.5px; font-weight: 600;">Confirm new passphrase</label>
          <div style="display: flex; gap: 8px; align-items: stretch; margin-bottom: 10px;">
            <input id="vault-recover-confirm" type="password" autocomplete="new-password" spellcheck="false" autocapitalize="off" autocorrect="off" style="flex: 1; min-width: 0; box-sizing: border-box; padding: 8px 10px;" />
            <button id="vault-recover-confirm-visibility" type="button" aria-controls="vault-recover-confirm" aria-pressed="false" aria-label="Show confirm new passphrase" style="${Xe}">Show</button>
          </div>
          <div><button id="vault-recover-submit" type="button" style="padding: 8px 12px; border-radius: 8px; border: 1px solid ${p.teal}; background: ${p.teal}; color: #fff; cursor: pointer; font-weight: 600;">Reset passphrase and unlock</button></div>
        </div>
      </div>

      <div id="vault-unlocked-panel" style="display: none;">
        <div class="vault-ready-card">
          <span class="vault-ready-icon" aria-hidden="true">✓</span>
          <div class="vault-ready-content">
            <div class="vault-ready-kicker">Vault connected</div>
            <h3 class="vault-ready-title">Your Vault is unlocked</h3>
            <div id="vault-account-line"></div>
            <div class="vault-ready-badges" aria-label="Vault status">
              <span class="vault-ready-badge">Subscription active</span>
              <span class="vault-ready-badge">Unlocked on this device</span>
            </div>
          </div>
        </div>
        <div class="vault-sync-summary">
          <div id="vault-sync-line"><span id="vault-sync-spinner" class="vault-status-spinner" aria-hidden="true" hidden></span><span id="vault-sync-text"></span></div>
          <div id="vault-sync-error-line" style="display: none; color: #7a2626;"></div>
          <div id="vault-auto-sync-note">Sync is automatic. Vault keeps this device up to date in the background.</div>
        </div>
        <div id="vault-join-devices-line">To use this Vault on another device or browser, sign in there with this email and unlock it with the same passphrase.</div>
        <div id="vault-phone-pair-card" style="display: none; margin-top: 12px; border: 1px solid #cfdcd4; border-radius: 12px; background: linear-gradient(160deg, #f4f9f6 0%, #eef4f8 100%); padding: 12px; gap: 12px; align-items: center; flex-wrap: wrap;">
          <div id="vault-phone-pair-qr" style="flex: 0 0 auto; line-height: 0;"></div>
          <div style="flex: 1 1 200px; min-width: 0;">
            <strong style="display: block; color: #1d3a2b; font-size: 13.5px;">Take your archive to your phone</strong>
            <p style="margin: 4px 0 0; color: #4c6355; font-size: 12px; line-height: 1.5;">Scan with your phone's camera to open the Vault web app with your email already filled in. Enter your passphrase once there, then turn on Face ID or fingerprint for one-tap return.</p>
            <a href="https://vault.llmnesia.com" target="_blank" rel="noopener noreferrer" style="display: inline-block; margin-top: 6px; color: #2b6588; font-size: 12px;">vault.llmnesia.com &rarr;</a>
          </div>
        </div>
        <div id="vault-firstsync-row" style="margin-top: 8px; display: none; align-items: center; gap: 8px; flex-wrap: wrap;">
          <span id="vault-firstsync-dot" class="vault-walk-dot" data-state="idle"></span>
          <span id="vault-firstsync-text" style="color: #5b7683; font-size: 12.5px; flex: 1 1 240px; min-width: 0;"></span>
          <button id="vault-firstsync-btn" type="button" style="padding: 6px 12px; border-radius: 8px; border: 1px solid ${p.teal}; background: ${p.teal}; color: #fff; cursor: pointer; font-weight: 600; font-size: 12.5px;"></button>
        </div>
        <div id="vault-firstsync-progress" style="display: none; margin-top: 6px;">
          <div class="options-progress-track">
            <div id="vault-firstsync-progress-fill" class="vault-walk-progress-fill" style="height: 100%; width: 0%; transition: width 220ms ease;"></div>
          </div>
        </div>
        <div id="vault-backup-row" style="margin-top: 8px; display: none; align-items: center; gap: 8px; flex-wrap: wrap;">
          <span id="vault-backup-dot" class="vault-walk-dot" data-state="idle"></span>
          <span id="vault-backup-text" style="color: #5b7683; font-size: 12.5px; flex: 1 1 240px; min-width: 0;"></span>
          <button id="vault-backup-btn" type="button" style="padding: 6px 12px; border-radius: 8px; border: 1px solid ${p.teal}; background: ${p.teal}; color: #fff; cursor: pointer; font-weight: 600; font-size: 12.5px;"></button>
        </div>
        <div id="vault-backup-progress" style="display: none; margin-top: 6px;">
          <div class="options-progress-track">
            <div id="vault-backup-progress-fill" class="vault-walk-progress-fill" style="height: 100%; width: 0%; transition: width 220ms ease;"></div>
          </div>
        </div>
        <div id="vault-restore-row" style="margin-top: 8px; display: none; align-items: center; gap: 8px; flex-wrap: wrap;">
          <span id="vault-restore-dot" class="vault-walk-dot" data-state="idle"></span>
          <span id="vault-restore-text" style="color: #5b7683; font-size: 12.5px; flex: 1 1 240px; min-width: 0;"></span>
          <button id="vault-restore-btn" type="button" style="padding: 6px 12px; border-radius: 8px; border: 1px solid ${p.teal}; background: #fff; color: #1c5a6e; cursor: pointer; font-weight: 600; font-size: 12.5px;"></button>
        </div>
        <div id="vault-restore-progress" style="display: none; margin-top: 6px;">
          <div class="options-progress-track">
            <div id="vault-restore-progress-fill" class="vault-walk-progress-fill" style="height: 100%; width: 0%; transition: width 220ms ease;"></div>
          </div>
        </div>
        <div id="vault-incoming-row" style="margin-top: 8px; display: none; align-items: center; gap: 8px; flex-wrap: wrap;">
          <span id="vault-incoming-dot" class="vault-walk-dot" data-state="running"></span>
          <span id="vault-incoming-text" style="color: #5b7683; font-size: 12.5px; flex: 1 1 240px; min-width: 0;"></span>
        </div>
        <div id="vault-incoming-progress" style="display: none; margin-top: 6px;">
          <div class="options-progress-track">
            <div id="vault-incoming-progress-fill" class="vault-walk-progress-fill" style="height: 100%; width: 0%; transition: width 220ms ease;"></div>
          </div>
        </div>
        <details style="margin-top: 10px; color: #3d5f6c; font-size: 12.5px;">
          <summary style="cursor: pointer;">Manage Vault</summary>
          <p style="margin: 8px 0 0;">Manage billing, invoices, or cancellation securely through Stripe.</p>
          <div style="margin-top: 8px; display: flex; gap: 8px; flex-wrap: wrap;">
            <button id="vault-manage-subscription-btn" class="vault-manage-btn vault-manage-btn--primary" type="button">Manage subscription</button>
            <button id="vault-lock-btn" class="vault-manage-btn" type="button">Lock Vault</button>
            <button id="vault-biometric-toggle" class="vault-manage-btn" type="button">Enable biometric unlock</button>
            <button id="vault-change-passphrase-toggle" class="vault-manage-btn" type="button">Change passphrase</button>
            <button id="vault-sign-out-btn" class="vault-manage-btn vault-manage-btn--danger" type="button">Sign out</button>
          </div>
        <div id="vault-change-passphrase-form" style="display: none; margin-top: 12px; padding: 12px 14px; border: 1px solid ${p.tealEdge}; border-radius: 10px; background: #fff;">
          <div style="display: flex; gap: 8px; flex-wrap: wrap; margin-bottom: 8px;">
            <input id="vault-old-passphrase" type="password" placeholder="Current passphrase" spellcheck="false" autocapitalize="off" autocorrect="off" style="flex: 1; min-width: 160px; padding: 8px 10px; border-radius: 8px;" />
            <button id="vault-old-passphrase-visibility" type="button" aria-controls="vault-old-passphrase" aria-pressed="false" aria-label="Show current passphrase" style="${Xe}">Show</button>
          </div>
          <div style="display: flex; gap: 8px; flex-wrap: wrap; margin-bottom: 8px;">
            <input id="vault-newer-passphrase" type="password" placeholder="New passphrase" spellcheck="false" autocapitalize="off" autocorrect="off" style="flex: 1; min-width: 160px; padding: 8px 10px; border-radius: 8px;" />
            <button id="vault-newer-passphrase-visibility" type="button" aria-controls="vault-newer-passphrase" aria-pressed="false" aria-label="Show new passphrase" style="${Xe}">Show</button>
            <input id="vault-newer-confirm" type="password" placeholder="Confirm new passphrase" spellcheck="false" autocapitalize="off" autocorrect="off" style="flex: 1; min-width: 160px; padding: 8px 10px; border-radius: 8px;" />
            <button id="vault-newer-confirm-visibility" type="button" aria-controls="vault-newer-confirm" aria-pressed="false" aria-label="Show confirm new passphrase" style="${Xe}">Show</button>
          </div>
          <button id="vault-change-passphrase-submit" class="vault-manage-btn vault-manage-btn--primary" type="button">Change passphrase</button>
        </div>
        </details>
      </div>

      <div id="vault-status-line" role="status" aria-live="polite" style="margin-top: 10px; color: ${p.ink3}; font-family: 'IBM Plex Mono', 'SF Mono', 'Consolas', monospace; font-size: 10.5px; line-height: 1.35; overflow-wrap: anywhere;"><span id="vault-status-spinner" class="vault-status-spinner" aria-hidden="true"></span><span id="vault-status-text">Loading Vault…</span></div>

      <!-- Shown to signed-in, non-entitled users, in place of the Vault panel
           (PV-01 routes here; PV-03 fills it in). It takes the whole seat
           rather than sitting beside a disabled panel: a Vault card with
           buttons that would fail server-side is worse than no card, because
           the failure only shows up after the click.
           The data line is the load-bearing one. A lapsed owner keeps the local
           index but cannot use the encrypted remote copy until renewal, so the
           copy in shared/vault_paywall.ts states both facts directly. -->
      <div id="vault-paywall-seat" class="vault-paywall" style="display: none;" data-state="never_subscribed">
        <div class="vault-paywall-status-card">
          <span class="vault-paywall-status-icon" aria-hidden="true"></span>
          <div>
            <div id="vault-paywall-status-line"></div>
            <div id="vault-paywall-account-line"></div>
          </div>
        </div>
        <div id="vault-paywall-data-line" class="vault-paywall-reassurance" style="display: none;"></div>
        <div class="vault-paywall-free-line">${pp({mcp:!0})}</div>
        <div class="vault-plan-toggle" id="vault-plan-toggle" role="group" aria-label="Billing frequency">
          <button id="vault-plan-annual" type="button" class="vault-plan-option selected" aria-pressed="true">
            <span class="vault-plan-flag">${ft.annualFlag}</span>
            <span class="vault-plan-name">Yearly</span>
            <span class="vault-plan-price">${ft.annualPrice}<span class="vault-plan-per">${ft.annualPer}</span></span>
            <span class="vault-plan-billed">${ft.annualBilled}</span>
          </button>
          <button id="vault-plan-monthly" type="button" class="vault-plan-option" aria-pressed="false">
            <span class="vault-plan-name">Monthly</span>
            <span class="vault-plan-price">${ft.monthlyPrice}<span class="vault-plan-per">${ft.monthlyPer}</span></span>
            <span class="vault-plan-billed">${ft.monthlyBilled}</span>
          </button>
        </div>
        <div class="vault-paywall-actions">
          <button id="vault-paywall-cta" type="button">Continue to checkout</button>
        </div>
        <p class="vault-paywall-plan-note">Opens Stripe's secure checkout — cancel anytime.</p>
        <div class="vault-paywall-utilities" aria-label="Vault account actions">
          <button id="vault-paywall-recheck-btn" class="vault-paywall-utility" type="button">I've subscribed, check again</button>
          <button id="vault-paywall-sign-out-btn" class="vault-paywall-utility" type="button">Sign out</button>
        </div>
        <div id="vault-paywall-recheck-status" class="vault-paywall-live-status" role="status" aria-live="polite"></div>
      </div>
      </div>
    </section>
    `}
    ${`
    <section id="corpus-native-card" class="settings-section" data-settings-section data-settings-group="connections" data-settings-search="MCP desktop AI Claude Desktop Claude Code Codex Cursor local access sync Node.js terminal install command permission extension" style="margin-top: 18px; border: 1px solid #315a3e; border-radius: 14px; padding: 0; background: #fff; overflow: hidden; box-shadow: 0 8px 24px rgba(31, 67, 43, 0.12);">
      <div style="padding: 18px 18px 16px; background: linear-gradient(135deg, #173f2a 0%, #2d6140 100%);">
        <div style="display: flex; align-items: center; justify-content: space-between; gap: 8px; flex-wrap: wrap; margin-bottom: 8px;">
          <span style="display: inline-flex; align-items: center; padding: 4px 8px; border: 1px solid rgba(255,255,255,0.38); border-radius: 999px; color: #fff; font-size: 10.5px; font-weight: 750; letter-spacing: 0.08em; text-transform: uppercase;">MCP connection</span>
          <span style="color: #dcebe1; font-size: 11.5px; font-weight: 600;">Runs on this computer</span>
        </div>
        <h2 style="margin: 0 0 7px; font-size: 20px; line-height: 1.25; color: #fff;">Use your chat history in desktop AI apps</h2>
        <p style="margin: 0; color: #e5f0e8; line-height: 1.55;">Search and reopen past chats from Claude, ChatGPT, Codex, Cursor, and other compatible apps.</p>
      <div id="corpus-native-flow" role="group" aria-label="Your chats pass through LLMnesia on this computer to your desktop AI using a local connection" style="display: flex; align-items: center; flex-wrap: wrap; gap: 7px; margin: 12px 0 9px; padding: 9px 10px; border: 1px solid rgba(255,255,255,0.5); border-radius: 9px; background: #fff; color: #243c30; font-size: 12px;">
        <span style="display: inline-flex; align-items: center; gap: 6px; font-weight: 600; white-space: nowrap;">
          <svg aria-hidden="true" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#487852" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M7 8h10a3 3 0 0 1 3 3v2a3 3 0 0 1-3 3h-5l-4 3v-3H7a3 3 0 0 1-3-3v-2a3 3 0 0 1 3-3Z"/><path d="M8 12h.01M12 12h.01M16 12h.01"/></svg>
          Your chats
        </span>
        <span aria-hidden="true" style="color: #66816d; font-weight: 800;">→</span>
        <span style="display: inline-flex; align-items: center; gap: 6px; padding: 4px 7px; border-radius: 6px; background: #e9f4ea; color: #285233; font-weight: 700; white-space: nowrap;">
          <svg aria-hidden="true" width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="#285233" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="10" width="14" height="10" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></svg>
          LLMnesia <span style="font-weight: 500; color: #5a7260;">on this computer</span>
        </span>
        <span aria-hidden="true" style="color: #66816d; font-weight: 800;">→</span>
        <span style="display: inline-flex; align-items: center; gap: 6px; font-weight: 600; white-space: nowrap;">
          <svg aria-hidden="true" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#487852" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="13" rx="2"/><path d="M8 21h8M12 17v4"/></svg>
          Desktop AI
        </span>
        <span style="display: inline-flex; align-items: center; gap: 4px; margin-left: auto; color: #487852; font-weight: 600; white-space: nowrap;">
          <svg aria-hidden="true" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#487852" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m5 12 4 4L19 6"/></svg>
          Local connection
        </span>
      </div>
        <p style="margin: 0; color: #dcebe1; font-size: 11.5px; line-height: 1.5;">LLMnesia keeps the index and connection local. Your AI app’s privacy terms apply to results it uses.</p>
      </div>
      <div style="padding: 15px 18px 18px;">
        <div style="padding: 10px 12px; border: 1px solid #c9d8cd; border-left: 4px solid #315a3e; border-radius: 8px; background: #f4f8f5;">
          <div style="margin-bottom: 2px; color: #52705b; font-size: 10.5px; font-weight: 750; letter-spacing: 0.07em; text-transform: uppercase;">Connection status</div>
          <div id="corpus-native-status" style="color: #203d2b; font-weight: 650; overflow-wrap: anywhere; word-break: break-word;">Checking…</div>
          <div id="corpus-native-lastsync" style="margin-top: 3px; color: #647a6a; font-size: 12px;"></div>
      </div>
      <div id="corpus-native-install" style="display: block; margin-top: 14px; padding: 14px; background: #fff; border: 1px solid #c7d5ca; border-radius: 10px;">
        <div id="corpus-native-install-steps" style="display: block;">
          <div style="display: flex; align-items: center; gap: 9px; font-weight: 700; color: #203d2b; margin-bottom: 5px;"><span aria-hidden="true" style="display: inline-flex; align-items: center; justify-content: center; flex: 0 0 28px; width: 28px; height: 28px; border-radius: 50%; background: #315a3e; color: #fff; font-size: 13px;">1</span><span>Install the desktop connector <span id="corpus-native-connector-state" style="display: none; margin-left: 4px; color: #2f7544;">✓ Done</span></span></div>
          <p style="margin: 0 0 9px 37px; color: #4d6254; font-size: 13px;">This command installs the connector and connects supported apps on this computer.</p>
          <div id="corpus-native-node-help" style="margin: 7px 0 11px 37px; padding: 10px 11px; border: 1px solid #d8cba5; border-radius: 8px; background: #fffaf0; color: #4c4a3f; font-size: 12.5px;">
            <div style="display: flex; align-items: flex-start; gap: 8px;">
              <span aria-hidden="true" style="display: inline-flex; align-items: center; justify-content: center; flex: 0 0 24px; width: 24px; height: 24px; border-radius: 6px; background: #e9f4ea; color: #285233;">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3v12M7 10l5 5 5-5"/><path d="M5 21h14"/></svg>
              </span>
              <div><strong>Node.js 22.13 or newer is required.</strong> Already have it? Skip this download.</div>
            </div>
            <a href="${Ou}" target="_blank" rel="noopener" style="display: inline-block; margin-top: 7px; padding: 6px 9px; border: 1px solid #b9cdb8; border-radius: 6px; background: #fff; color: #285233; text-decoration: none; font-weight: 600;">${Bu}</a>
            <p style="margin: 6px 0 0; color: #6b6759; font-size: 12px;">Use the installer’s default options, then continue below. Docker is not needed.${Vu}</p>
          </div>
          <p id="corpus-native-install-copy" style="display: flex; align-items: flex-start; gap: 8px; margin: 8px 0 8px 37px; color: #344d3b; font-size: 13px;">
            <span aria-hidden="true" style="display: inline-flex; align-items: center; justify-content: center; flex: 0 0 24px; width: 24px; height: 24px; border-radius: 6px; background: #edf2f5; color: #365166;">
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="16" rx="2"/><path d="m7 9 3 3-3 3M13 15h4"/></svg>
            </span>
            <strong id="corpus-native-install-copy-text">Next: ${Hl}</strong>
          </p>
          <div style="margin: 0 0 7px 37px; color: #203d2b; font-size: 13px; font-weight: 700;">Run this command in ${Ir}:</div>
          <code id="corpus-native-install-cmd" style="display: block; margin: 0 0 9px 37px; padding: 10px; background: #182c21; border: 1px solid #182c21; border-radius: 7px; color: #f1faf4; font-size: 12px; line-height: 1.5; white-space: pre-wrap; overflow-wrap: anywhere;">${Wa}</code>
          <button id="corpus-native-copy-install" type="button" style="margin-left: 37px; padding: 9px 13px; border-radius: 7px; border: 1px solid #244b32; background: #315a3e; color: #fff; cursor: pointer; font-weight: 700;">Copy install command</button>
          <p style="margin: 8px 0 0 37px; color: #617064; font-size: 12px;">${qu} It may take up to a minute. Keep ${Ir} open until it says Done.</p>
          <p style="margin: 9px 0 0 37px; padding: 8px 10px; border-left: 3px solid #ad7927; background: #fff8e8; color: #624b22; font-size: 12px;"><strong>Important:</strong> plain <code>npm install @llmnesia/mcp</code> only downloads the package. It does not register the browser connector. Run the exact <code>npx … install</code> command above.</p>

          <div style="margin-top: 15px; padding-top: 15px; border-top: 1px solid #d5ded7;">
            <div style="display: flex; align-items: center; gap: 9px; font-weight: 700; color: #203d2b; margin-bottom: 5px;"><span aria-hidden="true" style="display: inline-flex; align-items: center; justify-content: center; flex: 0 0 28px; width: 28px; height: 28px; border-radius: 50%; background: #315a3e; color: #fff; font-size: 13px;">2</span><span>Restart your browser</span></div>
            <p style="margin: 0 0 9px 37px; color: #4d6254; font-size: 13px;">${Js} This lets the browser find the newly installed connector.</p>
          </div>

          <div style="margin-top: 15px; padding-top: 15px; border-top: 1px solid #d5ded7;">
            <div style="display: flex; align-items: center; gap: 9px; font-weight: 700; color: #203d2b; margin-bottom: 5px;"><span aria-hidden="true" style="display: inline-flex; align-items: center; justify-content: center; flex: 0 0 28px; width: 28px; height: 28px; border-radius: 50%; background: #315a3e; color: #fff; font-size: 13px;">3</span><span>Enable automatic sync <span id="corpus-native-permission-state" style="display: none; margin-left: 4px; color: #2f7544;">✓ Done</span></span></div>
            <p style="margin: 0 0 9px 37px; color: #4d6254; font-size: 13px;">Allow LLMnesia to use the connector and keep your desktop AI copy up to date.</p>
            <button id="corpus-native-enable" type="button" style="margin-left: 37px; padding: 9px 13px; border-radius: 8px; border: 1px solid #244b32; background: #315a3e; color: #fff; cursor: pointer; font-weight: 700;">I’ve installed and restarted — enable sync</button>
          </div>

          <div id="corpus-native-finish" style="display: none; align-items: flex-start; gap: 8px; margin: 12px 0 0 37px; padding: 10px 12px; border-radius: 7px; background: #eaf5ed; color: #203d2b; font-size: 13px;"><span aria-hidden="true" style="display: inline-flex; align-items: center; justify-content: center; flex: 0 0 22px; width: 22px; height: 22px; border-radius: 50%; background: #315a3e; color: #fff; font-weight: 700;">✓</span><span>${ke?"<strong>Connected.</strong> Your browser can reach the local connector. Supported desktop AI apps found during setup can now use LLMnesia. If you use Claude Desktop, complete step 4 below.":"<strong>Connected.</strong> Your browser can reach the local connector. Reopen your connected AI app, then ask it to <em>“Search my LLMnesia history for…”</em>"}</span></div>
          ${ke?`
          <div id="corpus-native-claude-windows" style="margin-top: 15px; padding-top: 15px; border-top: 1px solid #d5ded7;">
            <div style="display: flex; align-items: center; gap: 9px; font-weight: 700; color: #203d2b; margin-bottom: 5px;"><span aria-hidden="true" style="display: inline-flex; align-items: center; justify-content: center; flex: 0 0 28px; width: 28px; height: 28px; border-radius: 50%; background: #315a3e; color: #fff; font-size: 13px;">4</span><span>Add Claude Desktop on Windows</span></div>
            <p style="margin: 0 0 9px 37px; color: #4d6254; font-size: 13px;">Claude needs one extra, one-time extension install. Other supported apps do not.</p>
            <a href="${Uu}" target="_blank" rel="noopener" style="display: inline-block; margin-left: 37px; padding: 9px 13px; border-radius: 7px; background: #315a3e; color: #fff; text-decoration: none; font-weight: 700;">Download LLMnesia for Claude</a>
            <p style="margin: 8px 0 0 37px; color: #4d6254; font-size: 13px;">In Claude Desktop, open <strong>Settings → Extensions → Advanced settings → Install extension</strong>, choose the downloaded file, then fully quit and reopen Claude.</p>
          </div>`:""}
        </div>
      </div>
      <details id="corpus-native-details" style="display: none; margin-top: 12px; color: #4d6254; font-size: 12px;">
        <summary style="cursor: pointer;">Connection details</summary>
        <div id="corpus-native-location" style="display: none; margin-top: 8px; overflow-wrap: anywhere; word-break: break-word;"></div>
        <span id="corpus-native-manual" style="display: none; margin-top: 8px;">Need to update it now?
          <button id="corpus-native-sync-now" type="button" style="padding: 4px 8px; border-radius: 6px; border: 1px solid #c6d0b0; background: #fff; cursor: pointer; font-size: 12px;">Sync now</button>
          <button id="corpus-native-full-sync" type="button" style="padding: 4px 8px; border-radius: 6px; border: 1px solid #c6d0b0; background: #fff; cursor: pointer; font-size: 12px;">Rebuild local history</button>
        </span>
      </details>
      </div>
    </section>
    `}
    
    <section id="danger-zone-section" class="settings-section" data-settings-section data-settings-group="advanced" data-settings-label="Permanent action" data-settings-search="danger zone delete remove all data conversations memories permanent" style="margin-top: 16px; border: 1px solid #ecc6c6; border-left: 4px solid #b83d3d; border-radius: 12px; padding: 14px 16px; background: #fff8f8;">
      <h2 style="margin: 0 0 10px; font-size: 16px; color: #6f1d1d;">Danger Zone</h2>
      <p id="delete-all-description" class="settings-card-description" style="margin: 0 0 10px; color: #7a3b3b;">${k(za(Ya()).description)}</p>
      <button id="delete-all" class="settings-danger-action" type="button" style="padding: 8px 12px; border-radius: 8px; border: 1px solid #d6a7a7; background: #fff; cursor: pointer;">Delete data on this browser</button>
      <div id="delete-all-confirm" style="display: none; margin-top: 10px; padding: 10px 12px; border: 1px solid #ecc6c6; border-radius: 8px; background: #fff;">
        <label for="delete-all-confirm-input" style="display: block; margin: 0 0 8px; font-size: 12px; color: #7a3b3b;">${k(cu)}</label>
        <input id="delete-all-confirm-input" type="text" autocomplete="off" autocapitalize="none" spellcheck="false" placeholder="${k(Da)}" style="width: 140px; padding: 6px 8px; border-radius: 6px; border: 1px solid #d6a7a7; font-size: 13px; letter-spacing: 0.08em;" />
        <button id="delete-all-confirm-btn" class="settings-danger-action" type="button" disabled style="margin-left: 8px; padding: 6px 12px; border-radius: 8px; border: 1px solid #d6a7a7; cursor: not-allowed;">Delete this browser's data</button>
        <button id="delete-all-cancel-btn" type="button" style="margin-left: 8px; padding: 6px 12px; border-radius: 8px; border: 1px solid #d6a7a7; background: #fff; color: #6f1d1d; cursor: pointer;">Cancel</button>
      </div>
      <div id="delete-status" class="settings-status-panel" style="margin-top: 10px; color: #6a3333; overflow-wrap: anywhere; word-break: break-word;">${k(du)}</div>
    </section>

    <section id="support-section" class="settings-section" data-settings-section data-settings-group="advanced" data-settings-label="Contact" data-settings-search="support contact privacy help" style="margin-top: 16px; border: 1px solid #dbe2cf; border-left: 4px solid #8a9aa3; border-radius: 12px; padding: 12px 16px; background: #f7f9fa;">
      <h2 style="margin: 0 0 8px; font-size: 14px;">Support</h2>
      <p class="settings-card-description" style="margin: 0; color: #466173;">Get help or report a problem.</p>
      <div class="settings-actions">
        <a href="https://llmnesia.com/#contact" target="_blank" rel="noopener" style="display: inline-block; padding: 8px 12px; border: 1px solid #526771; border-radius: 8px; background: #526771; color: #fff; text-decoration: none; font-weight: 700;">Open contact form</a>
      </div>
    </section>
  </div>
`;const Zt=document.querySelector("#settings-search"),Xs=document.querySelector("#settings-search-status"),Qs=document.querySelector("#settings-filter-empty"),Zs=Array.from(document.querySelectorAll("[data-settings-section]")),Du=Array.from(document.querySelectorAll("[data-settings-group-heading]")),Ja=Array.from(document.querySelectorAll("[data-settings-nav]"));function ei(e){return e.style.display!=="none"&&!e.hidden}function Xa(){const e=window.location.hash.replace(/^#/,"");for(const t of Ja)t.setAttribute("aria-current",String(t.dataset.settingsNav===e))}function Qa(e){const t=e.trim().toLocaleLowerCase();let o=0;for(const n of Zs){const a=`${n.dataset.settingsSearch??""} ${n.textContent??""}`.toLocaleLowerCase(),r=t.length===0||a.includes(t);n.hidden=!r,r&&ei(n)&&(o+=1)}for(const n of Ja){const a=document.getElementById(n.dataset.settingsNav??""),r=a?`${a.dataset.settingsSearch??""} ${a.textContent??""}`.toLocaleLowerCase():"";n.hidden=t.length>0&&!r.includes(t)}for(const n of Du){const a=n.dataset.settingsGroupHeading,r=Zs.some(s=>s.dataset.settingsGroup===a&&ei(s));n.hidden=t.length>0&&!r}Qs&&(Qs.style.display=t.length>0&&o===0?"block":"none"),Xs&&(Xs.textContent=t.length===0?`Showing ${o} settings sections`:o===0?"No matching settings":`${o} matching settings section${o===1?"":"s"}`)}Zt?.addEventListener("input",()=>{Qa(Zt.value)});Zt?.addEventListener("keydown",e=>{e.key==="Escape"&&(Zt.value="",Qa(""),Zt.blur())});for(const e of Ja)e.addEventListener("click",()=>{window.setTimeout(Xa,0)});window.addEventListener("hashchange",Xa);document.addEventListener("keydown",e=>{const o=e.target?.matches("input, textarea, select, [contenteditable='true']")??!1;e.key==="/"&&!o&&(e.preventDefault(),Zt?.focus())});Qa("");Xa();const be=document.querySelector("#stats-content"),ko=document.querySelector("#refresh-stats"),Eo=document.querySelector("#toggle-indexing"),we=document.querySelector("#google-ai-mode-toggle"),eo=document.querySelector("#google-ai-mode-state"),me=document.querySelector("#google-ai-mode-status"),jt=document.querySelector("#chatgpt-temporary-toggle"),to=document.querySelector("#chatgpt-temporary-status");function Jl(e){to&&(to.textContent=e?"Enabled. Temporary Chats are saved while open; each copy opens in the viewer.":"Off. Temporary Chats are not saved.",to.style.color=e?"#315a3e":"#526771")}async function Gu(){if(jt){try{const e=await chrome.storage.local.get(ta);jt.checked=e[ta]===!0}catch{jt.checked=!1}Jl(jt.checked)}}jt?.addEventListener("change",()=>{const e=jt.checked===!0;chrome.storage.local.set({[ta]:e}).then(()=>Jl(e)).catch(()=>{to&&(to.textContent="Could not save the setting. Try again.",to.style.color="#8a4b2e")})});Gu();const gt=document.querySelector("#semantic-coverage"),mt=document.querySelector("#semantic-engine-check"),da=document.querySelector("#semantic-probe-query"),yt=document.querySelector("#semantic-probe-run"),ht=document.querySelector("#semantic-selftest"),bt=document.querySelector("#export-eval-corpus"),R=document.querySelector("#semantic-eval-output"),ti=document.querySelector("#health-status"),Ht=document.querySelector("#migration-status"),oi=document.querySelector("#backfill-section"),Tr=document.querySelector("#backfill-progress-fill"),ni=document.querySelector("#backfill-status-text");let Rr=null,Oe=null,Gt=null,ca=!1,Za=null;function So(e){return e?kp(e):wp.join("/")}function ju(e,t){if(!Tr)return;let o=0,n="linear-gradient(90deg, #2f7f99 0%, #49b08f 100%)";e?.active?(t?.phase==="running"&&t.total>0?o=Math.max(2,Math.min(100,Math.round(t.processed/t.total*100))):t?.phase==="done"?o=100:o=18,e.paused&&(n="#9aa8b4")):t?.phase==="done"&&(o=100),Tr.style.width=`${o}%`,Tr.style.background=n}function Hu(e){const{state:t,progress:o,activeTabPlatform:n,queue:a}=e;if(t.active){const r=So(t.platform);if(n&&t.platform&&n!==t.platform)return a.find(i=>i.platform===n)?`${r} is indexing. ${So(n)} is queued.`:`${r} is indexing. Queue ${So(n)} from this tab if needed.`;if(t.paused)return"Paused.";if(o?.phase==="running"){const s=o.total>0?` (${o.processed}/${o.total})`:"";if(o.lastIndexedTitle){const i=vp(!!o.lastIndexedChanged,!!o.lastIndexedIsNew),l=o.lastIndexedPartialDepth?t.platform==="google_ai_mode"?" (captured in part, click Start after this run to retry)":" (partial depth, will retry)":"";return`${i}: ${o.lastIndexedTitle}${l}${s}`}return o.lastSkippedTitle?`Skipped: ${o.lastSkippedTitle} (${o.lastSkippedReason??"not indexable"})${s}`:`Indexing older chats on ${r}…${s}`}if(o?.phase==="collecting"){const s=o.total>0?` (${o.total} found so far)`:"";return`Fetching your ${r} chat list…${s}`}return o?.phase==="pruning"?"Checking what's already indexed…":`Indexing older chats on ${r}…`}if(n&&a.find(s=>s.platform===n))return`${So(n)} is queued.`;if(n==="ai_studio"){const r=Jd(o?.lastError);if(r)return r}return o?.lastError==="history_list_unavailable"?`Couldn’t reach your ${So(n)} chat history. Try the import again later.`:o?.phase==="done"?xp(o,n??t.platform):n?"Ready to index older chats.":"Open a supported AI tab, then start from the extension popup."}async function Ku(){let e;try{e=await chrome.tabs.query({active:!0,currentWindow:!0})}catch{return null}const t=e[0],o=typeof t?.id=="number"?t.id:null,n=t?await Xd(t):null;return!n||typeof o!="number"||o<=0?null:{platform:n,seedTabId:o}}async function ri(){let e;try{e=await chrome.runtime.sendMessage({type:"GET_BACKFILL_STATUS"})}catch{return}if(!e.ok)return;const o=(await Ku())?.platform??null,{state:n,progress:a,queue:r,progressByPlatform:s}=e;if(oi&&(oi.style.display=n.active?"":"none"),!n.active)return;const i=o&&s[o]?s[o]??null:a,l=o&&n.platform!==o?null:n;ju(l,i),ni&&(ni.textContent=Hu({state:n,progress:i,activeTabPlatform:o,queue:r}))}function Yu(){ri(),Rr!==null&&clearInterval(Rr),Rr=setInterval(()=>{ri()},1200)}const en=document.querySelector("#export-backup"),tn=document.querySelector("#import-backup"),on=document.querySelector("#import-backup-cancel"),Tn=document.querySelector("#import-backup-file"),ai=document.querySelector("#backup-status"),bn=document.querySelector("#backup-progress");let pa=!1;const Me=document.querySelector("#rolling-backup-enabled"),Pr=document.querySelector("#rolling-backup-now"),_r=document.querySelector("#rolling-backup-restore"),V=document.querySelector("#rolling-backup-status");function es(e){if(!e.enabled)return"Automatic backups are off.";const t=[];return e.lastCompletedAt?t.push(`Last completed ${new Date(e.lastCompletedAt).toLocaleString()} (${e.versions[0]?.conversationCount??0} conversations).`):t.push("No backup completed yet."),e.lastError&&t.push(`Last problem: ${e.lastError}`),t.push(`${e.versions.length}/${e.retentionCount} versions kept in the browser profile.`),t.join(" ")}async function Wu(){if(!(!V||!Me))try{const e=await chrome.runtime.sendMessage({type:"GET_ROLLING_BACKUP_STATUS"});if(!e?.ok){V.textContent="Could not read backup status.";return}Me.checked=e.status.enabled,V.textContent=es(e.status)}catch(e){V.textContent=`Could not read backup status: ${e instanceof Error?e.message:String(e)}`}}Me?.addEventListener("change",async()=>{if(!Me||!V)return;const e=Me.checked;Me.disabled=!0,e&&(V.textContent="Starting your first local backup...");try{const t=await chrome.runtime.sendMessage({type:"SET_ROLLING_BACKUP_ENABLED",enabled:e});t?.ok?V.textContent=es(t.status):(Me.checked=!e,V.textContent=`Could not ${e?"enable":"disable"} automatic backups.`)}catch(t){Me.checked=!e,V.textContent=`Could not update automatic backups: ${t instanceof Error?t.message:String(t)}`}finally{Me.disabled=!1}});Pr?.addEventListener("click",async()=>{if(V){Pr?.setAttribute("disabled","true"),V.textContent="Backing up...";try{const e=await chrome.runtime.sendMessage({type:"RUN_ROLLING_BACKUP_NOW"});e?.ok?V.textContent=es(e.status):V.textContent=`Backup failed: ${e?.error??"no response"}`}catch(e){V.textContent=`Backup failed: ${e instanceof Error?e.message:String(e)}`}finally{Pr?.removeAttribute("disabled")}}});_r?.addEventListener("click",async()=>{if(V){_r?.setAttribute("disabled","true"),V.textContent="Looking for a verified backup...";try{const e=await Wc();if(!e){V.textContent="No verified backup found. Nothing was changed. Run a backup first, or check whether backups are enabled.";return}V.textContent=`Restoring ${e.name}...`,await br();const t=new File([e.blob],e.name,{type:"application/gzip"}),o=await rd(()=>tl(t,void 0,{shouldCancel:()=>!1}));await _t(o.imported);const n=o.alreadyImported>0?` (${o.alreadyImported} already present, skipped)`:"";V.textContent=`Restore finished: ${o.imported}/${o.total} conversations restored${n}`+(o.failed>0?`, ${o.failed} failed.`:". Existing chats were not changed."),await Se()}catch(e){await _t(1),V.textContent=`Restore failed: ${e instanceof Error?e.message:String(e)} Existing chats were not changed.`}finally{_r?.removeAttribute("disabled")}}});Wu();const ua=document.querySelector("#import-chatgpt-export"),nn=document.querySelector("#import-chatgpt-export-cancel"),Rn=document.querySelector("#import-chatgpt-export-file"),vn=document.querySelector("#chatgpt-export-progress"),si=document.querySelector("#chatgpt-export-status");let $o=!1;Mp({markStarted:br,finalize:_t,refreshStats:Se});const Ju=document.querySelector("#local-sessions-card"),Ze=document.querySelector("#ls-connect"),Hn=document.querySelector("#ls-brave-help"),Xu=document.querySelector("#ls-copy-flag"),Kn=document.querySelector("#ls-helper-setup"),Kt=document.querySelector("#ls-install-cmd"),Qu=document.querySelector("#ls-copy-install");function Nr(e){return{chooseBtn:document.querySelector(`#ls-choose-${e}`),rescanBtn:document.querySelector(`#ls-rescan-${e}`),forgetBtn:document.querySelector(`#ls-forget-${e}`),copyPathBtn:document.querySelector(`#ls-copy-path-${e}`),dirInput:document.querySelector(`#ls-dir-input-${e}`),statusNode:document.querySelector(`#ls-status-${e}`),hintNode:document.querySelector(`#ls-hint-${e}`)}}const ee={claude_code:Nr("claude_code"),codex:Nr("codex"),zcode:Nr("zcode")},qe=document.querySelector("#delete-all"),ii=document.querySelector("#delete-status"),Yn=document.querySelector("#delete-all-confirm"),ot=document.querySelector("#delete-all-confirm-input"),Wn=document.querySelector("#delete-all-confirm-btn"),Zu=document.querySelector("#delete-all-cancel-btn"),ef=document.querySelector("#refresh-pins"),oo=document.querySelector("#pin-filter"),tf=document.querySelector("#clear-pin-filter"),fr=document.querySelector("#pin-only"),nt=document.querySelector("#pin-list"),li=document.querySelector("#pin-status"),re=document.querySelector("#memory-list"),xn=document.querySelector("#pending-memory-list"),Ao=document.querySelector("#enable-all-pending-memories"),di=document.querySelector("#memory-status"),Xl=document.querySelector("#memory-filter"),of=document.querySelector("#refresh-memories"),Ve=document.querySelector("#memory-text"),Mr=document.querySelector("#memory-label"),Or=document.querySelector("#memory-pinned"),nf=document.querySelector("#add-memory"),ci=document.querySelector("#memory-example-chips"),_o=document.querySelector("#memory-add-form-wrap"),pi=document.querySelector("#memory-manage-tools"),Yt=document.querySelector("#toggle-add-form"),wn=document.querySelector("#memory-import-text"),rf=document.querySelector("#import-memory"),Lo=document.querySelector("#copy-export-prompt"),gr=document.querySelector("#memory-import-platform"),kn=document.querySelector("#memory-import-hint"),ui=document.querySelector("#memory-import-status"),rn={chatgpt:"ChatGPT",claude:"Claude",gemini:"Gemini",copilot:"Copilot",deepseek:"DeepSeek",kimi:"Kimi",generic:"Other AI"},fi=`Export everything you know about me — both your saved memories and anything you've learned about me from past conversations. Keep my own words verbatim where you can, especially for instructions and preferences.

Output these categories, in this order:
1. Instructions — rules I've asked you to follow (tone, format, style, always/never do X) and corrections to your behaviour.
2. Identity — name, location, background, languages, interests.
3. Career — current and past roles, companies, skill areas.
4. Projects — things I've built or committed to (one entry per project: what it does, status, key decisions). Start each with the project name.
5. Preferences — opinions, tastes, and working-style preferences.

Format: a section header per category. Under each, one entry per line as:
[YYYY-MM-DD] - entry
Use [unknown] if no date is known. Wrap the whole thing in one code block. After it, tell me whether that's everything or more remains.`,no=document.querySelector("#recent-limit"),gi=document.querySelector("#recent-limit-status"),af=document.querySelector("#refresh-error-logs"),sf=document.querySelector("#export-error-logs"),lf=document.querySelector("#copy-error-logs"),df=document.querySelector("#clear-error-logs"),mi=document.querySelector("#adapter-errors-list"),yi=document.querySelector("#error-log-status"),wt=document.querySelector("#error-log-list"),hi=document.querySelector("#founding-card"),cf=document.querySelector("#founding-join"),pf=document.querySelector("#founding-not-now"),uf=document.querySelector("#report-problem"),ff=document.querySelector("#options-snapshot-toggle");async function gf(){try{const e=await chrome.storage.local.get([Es,$s,As]);return{indexingEnabled:e[Es]!==!1,semanticSearchEnabled:e[$s]===!0,memoryLayerEnabled:e[As]!==!1}}catch{return{}}}async function mf(){let e;try{e=(await chrome.tabs.query({})).filter(n=>{if(!n.url)return!1;try{return fl(new URL(n.url))!==null}catch{return!1}}).sort((n,a)=>(a.lastAccessed??0)-(n.lastAccessed??0))[0]}catch{return null}return typeof e?.id!="number"?null:{tab:e,result:await Kd(e.id)}}uf?.addEventListener("click",()=>{(async()=>{const e=bp("general"),t=await gf();let o="general",n=window.location.href,a=null,r=null,s=null;if(ff?.checked){const l=await mf();if(l){s=l.result,r=l.result.capture,a=r?.snapshot??"(Page capture unavailable. See capture error codes above.)",n=l.tab.url??n;try{o=new URL(n).hostname,e.hostname=o,e.adapter_version=fl(new URL(n))??"n/a"}catch{}}else a="(No supported chat tab was found. Open the affected AI page and try again.)"}const i=ec({hostname:o,fullUrl:n,healthRecord:e,snapshot:a,environment:t,liveDiagnostic:r,captureResult:s});chrome.tabs.create({url:i})})()});let Ql=!1,de=[];function et(e){ti&&(ti.textContent=e)}function Br(e){Ht&&(Ht.textContent=e)}function ve(e){ai&&(ai.textContent=e)}function Jn(e,t,o){const n=e>=0&&t>0;bn&&(bn.style.display=n?"block":"none",n&&(bn.max=t,bn.value=Math.min(e,t))),on&&(on.style.display=n&&o?"inline-block":"none")}function ge(e){si&&(si.textContent=e)}function Sn(e,t){const o=e>=0&&t>0;vn&&(vn.style.display=o?"block":"none",o&&(vn.max=t,vn.value=Math.min(e,t))),nn&&(nn.style.display=o?"inline-block":"none")}function kt(e){ii&&(ii.textContent=e)}function Zl(){const e=document.querySelector("#delete-all-description");e&&(e.textContent=za(Ya()).description)}function Ue(e){li&&(li.textContent=e)}function Xn(e){gi&&(gi.textContent=e)}function ze(e){yi&&(yi.textContent=e)}function ed(e){return e.length===0?"<div style='color:#4f6576;'>No errors captured yet.</div>":e.map(t=>{const o=new Date(t.at).toLocaleString(),n=[t.url,t.line?`line ${t.line}`:"",t.column?`col ${t.column}`:""].filter(Boolean).join(" • "),a=t.stack?`<pre style="margin: 6px 0 0; padding: 6px; border: 1px solid #e2e8ef; border-radius: 8px; background: #f8fbff; color: #2d4158; font: 11px/1.4 'IBM Plex Mono', monospace; white-space: pre-wrap; overflow-wrap: anywhere;">${k(t.stack)}</pre>`:"",r=t.details?`<div style="margin-top: 4px; color: #4f6576; font-size: 12px; overflow-wrap: anywhere;">${k(t.details)}</div>`:"";return`
        <article style="border: 1px solid #d7dfcb; border-radius: 10px; padding: 8px; background: #fff;">
          <div style="display: flex; justify-content: space-between; gap: 8px; flex-wrap: wrap;">
            <strong style="color: #17364e; overflow-wrap: anywhere;">${k(t.message)}</strong>
            <span style="color: #5f7384; font-size: 12px;">${o}</span>
          </div>
          <div style="margin-top: 4px; color: #4f6576; font-size: 12px; overflow-wrap: anywhere;">
            ${k(t.source)} • ${k(t.context)}
          </div>
          ${n?`<div style="margin-top: 4px; color: #4f6576; font-size: 12px; overflow-wrap: anywhere;">${k(n)}</div>`:""}
          ${r}
          ${a}
        </article>
      `}).join("")}function td(e){Ql=e,hi&&(hi.style.display="none")}async function yf(e){try{await chrome.runtime.sendMessage({type:"UPDATE_FOUNDING_STATS_SNAPSHOT",conv_count:e.conversationCount,msg_count:e.messageCount})}catch{}}async function hf(){}function mr(e,t){const o=URL.createObjectURL(t),n=document.createElement("a");n.href=o,n.download=e,n.click(),window.setTimeout(()=>URL.revokeObjectURL(o),2e3)}const bf=Lp();document.querySelector("#export-google-import-report")?.addEventListener("click",async()=>{const e=document.querySelector("#google-import-report-status");try{const t=await chrome.storage.local.get(Cs),o=Yc(t[Cs],chrome.runtime.getManifest().version),n=new Date().toISOString().replace(/[:.]/g,"-");mr(`llmnesia-google-import-report-${n}.json`,new Blob([JSON.stringify(o,null,2)],{type:"application/json"})),e&&(e.textContent=`Exported ${o.partial.length} partial, ${o.failed.length} failed and ${o.unresolved.length} unfinished chats. ${o.unknownCoverage.length} with unknown coverage. ${o.entries.length} chat attempts recorded.`)}catch(t){e&&(e.textContent=`Could not export the Google import report: ${U(t)}`)}});async function ts(){if(!wt)return;wt.textContent="Loading error logs...";let e;try{e=await chrome.runtime.sendMessage({type:"GET_EXTENSION_ERROR_LOGS",limit:yp})}catch(t){wt.textContent=`Failed to load logs: ${U(t)}`,ze("Error log unavailable.");return}if(!e.ok){wt.textContent=`Failed to load logs: ${e.error}`,ze("Error log unavailable.");return}de=e.logs,wt.innerHTML=ed(de),ze(de.length===0?"No errors captured yet.":`Showing ${de.length} most recent error entr${de.length===1?"y":"ies"}.`)}async function vf(){if(window.confirm("Clear all captured extension error logs?")){ze("Clearing logs...");try{const t=await chrome.runtime.sendMessage({type:"CLEAR_EXTENSION_ERROR_LOGS"});if(!t.ok){ze(`Failed to clear logs: ${t.error}`);return}de=[],wt&&(wt.innerHTML=ed(de)),ze("Error logs cleared.")}catch(t){ze(`Failed to clear logs: ${U(t)}`)}}}async function xf(){if(de.length===0&&await ts(),de.length===0){ze("No logs available to export.");return}const e=new Date().toISOString().replace(/[:.]/g,"-"),t=new Blob([JSON.stringify(de,null,2)],{type:"application/json"});mr(`llmnesia-error-logs-${e}.json`,t),ze(`Exported ${de.length} log entr${de.length===1?"y":"ies"}.`)}async function yr(){if(Eo)try{const e=await chrome.runtime.sendMessage({type:"GET_INDEXING_ENABLED"});if(!e.ok){Eo.textContent="Indexing status error";return}Eo.textContent=e.enabled?"Pause indexing":"Resume indexing"}catch{Eo.textContent="Indexing status error"}}let Qn=null;function fa(e,t){Qn=e,we&&(we.disabled=!1,we.textContent=e?"Disable Google AI Mode":"Enable Google AI Mode"),eo&&(eo.textContent=e?"Enabled":"Off",eo.dataset.state=e?"on":"off"),me&&(me.textContent=t??(e?"Google AI Mode conversations are captured automatically.":"Google site access is off."))}async function an(){try{fa(await Jc())}catch(e){Qn=null,we&&(we.disabled=!0,we.textContent="Access unavailable"),eo&&(eo.textContent="Unavailable",eo.dataset.state="error"),me&&(me.textContent=`Could not check Google access: ${U(e)}`)}}async function wf(){if(!(!we||Qn===null)){if(we.disabled=!0,!Qn){we.textContent="Waiting for Chrome...",me&&(me.textContent="Approve Google site access in Chrome to enable capture.");try{const e=await Xc();fa(e,e?"Enabled. Any open Google AI Mode conversation is ready to capture.":"Permission was not granted. Google site access remains off.")}catch(e){await an(),me&&(me.textContent=`Google capture could not start: ${U(e)}`)}return}we.textContent="Removing access...",me&&(me.textContent="Removing Google site access...");try{const e=await Qc();fa(!e,e?"Google site access was removed. Existing saved conversations remain in your index.":"Chrome did not remove all Google site access. Check the extension's site access settings.")}catch(e){await an(),me&&(me.textContent=`Could not remove Google access: ${U(e)}`)}}}let rt=null,Zn=!1,qr="",Vr="";function Ur(){return lt.map(e=>e.platform).sort().join("|")}function od(e){return be?.querySelector(`[data-stat="${e}"] .options-stat-value`)??null}function Co(e,t){const o=od(e);o&&(o.textContent=t)}function zr(e,t){const o=od(e);o&&Dl(o,t,!Ml())}function kf(e){return`
    <div id="stats-cards-grid" style="display:grid; grid-template-columns:repeat(auto-fit,minmax(180px,1fr)); gap:8px; align-items:stretch;">
      ${Je("estimated-bytes","Estimated bytes",Dn(e.totalEstimatedBytes))}
      ${Je("budget","Budget",Dn(e.budgetBytes))}
      ${Je("conversations","Conversations",String(e.conversationCount),e.conversationCount)}
      ${Je("messages","Messages",String(e.messageCount),e.messageCount)}
      ${Je("hot-warm","Hot / Warm",`${e.hotCount} / ${e.warmCount}`)}
      ${Je("tokens","Tokens",String(e.tokenCount),e.tokenCount)}
      ${Je("avg-postings","Avg postings/token",e.averagePostingsPerToken.toFixed(2))}
      ${Je("last-indexed","Last indexed",ur(e.lastIndexedAt))}
    </div>
  `}function Sf(e){if(!be)return;const t=be.querySelector("#stats-cards-grid");if(Zn&&t){Co("estimated-bytes",Dn(e.totalEstimatedBytes)),Co("budget",Dn(e.budgetBytes)),zr("conversations",e.conversationCount),zr("messages",e.messageCount),Co("hot-warm",`${e.hotCount} / ${e.warmCount}`),zr("tokens",e.tokenCount),Co("avg-postings",e.averagePostingsPerToken.toFixed(2)),Co("last-indexed",ur(e.lastIndexedAt));const o=be.querySelector("#year-summary-slot");o&&(o.innerHTML=Fl());const n=ia().join(",");if(n!==Vr){const r=be.querySelector("#platform-controls-slot");r&&(r.innerHTML=ql()),Vr=n,Ws()}const a=Ur()!==qr;if(a){const r=be.querySelector("#platform-rows-slot");r&&(r.innerHTML=zl(!0)),qr=Ur()}jn(!a);return}be.innerHTML=`
    ${kf(e)}
    <div id="platform-breakdown-block" style="margin-top:12px; border-top:1px dashed #d7dfcb; padding-top:10px; min-width:0;">${Nu()}</div>
  `,Zn=!0,qr=Ur(),Vr=ia().join(","),Ws(),requestAnimationFrame(()=>jn(!0))}function bi(e){if(Zn){et(`Failed to refresh stats: ${e}`);return}be&&(be.textContent=`Failed to load stats: ${e}`)}async function Se(){if(!be)return;Zn||(be.innerHTML=Pl());let e;try{e=await chrome.runtime.sendMessage({type:"GET_INDEX_STATS",detail:"full"})}catch(i){bi(i instanceof Error?i.message:"Unknown runtime error");return}if(!e.ok){bi(e.error);return}const{conversationCount:t,usageByPlatform:o,lastErrorByPlatform:n}=e.stats,a=rt===null;rt=t,a&&Cd(),lt=o.filter(i=>!aa.has(i.platform));const r=Object.entries(n).filter(([i])=>!aa.has(i)).sort((i,l)=>l[1].at-i[1].at).slice(0,8),s=r.length===0?"<div style='color:#496073; overflow-wrap:anywhere; word-break:break-word;'>No adapter errors recorded.</div>":r.map(([i,l])=>`<div style='overflow-wrap:anywhere; word-break:break-word;'><strong>${k(i)}</strong>: ${k(l.error)} <span style='color:#5f7384'>(${new Date(l.at).toLocaleString()})</span></div>`).join("");Sf(e.stats),mi&&(mi.innerHTML=s),await yf(e.stats),Ql||await hf(),await yr(),await Tf(),await go()}async function Cf(){if(!gt)return;let e,t;try{[e,t]=await Promise.all([chrome.runtime.sendMessage({type:"GET_SEMANTIC_COVERAGE"}),chrome.runtime.sendMessage({type:"GET_SEMANTIC_SEARCH_ENABLED"})])}catch(a){gt.textContent=`Search by meaning: unavailable (${a instanceof Error?a.message:"runtime error"})`;return}if(!e.ok){gt.textContent=`Search by meaning: unavailable (${e.error})`;return}t.ok&&!t.enabled&&chrome.runtime.sendMessage({type:"SET_SEMANTIC_SEARCH_ENABLED",enabled:!0});const{embedded:o,total:n}=e.coverage;Za={embedded:o,total:n},n===0?gt.textContent="Search by meaning is on — nothing indexed yet.":o>=n?gt.textContent=`Search by meaning is on — all ${n} chats ready.`:gt.textContent=`Search by meaning is on — getting ready in the background (${o} of ${n} chats ready).`}function go(){if(Gt)return Gt;const e=Cf().finally(()=>{Gt===e&&(Gt=null);const t=ca;if(ca=!1,t&&!document.hidden&&ol(Za)!==Sc){go();return}Ef()});return Gt=e,e}function Ef(){if(Oe!==null&&(window.clearTimeout(Oe),Oe=null),!gt||document.hidden)return;const e=ol(Za);e!==null&&(Oe=window.setTimeout(()=>{Oe=null,go()},e))}document.addEventListener("visibilitychange",()=>{if(document.hidden){Oe!==null&&(window.clearTimeout(Oe),Oe=null);return}go()});try{chrome.storage.onChanged.addListener((e,t)=>{if(t!=="local"||document.hidden)return;const o=!!e[Zc],n=e[Cc]?.newValue==="dirty";if(o||n){if(Gt){ca=!0;return}if(Oe!==null)return;go()}})}catch{}function $f(e){if(!e.ok)return e.note;const t=r=>`${Math.round(r*100)}%`,o=e.auc>=.85?"STRONG":e.auc>=.7?"OK":e.auc>=.6?"WEAK":"POOR (near random)",n=e.floorSweep.map(r=>`  ${r.floor.toFixed(2)}   prec ${t(r.precision).padStart(4)}   recall ${t(r.recall).padStart(4)}   F1 ${r.f1.toFixed(2)}`).join(`
`),a=r=>r.map(s=>`  "${s.term}" (${s.relevant} chats) AUC ${s.auc.toFixed(2)}, recall@20 ${t(s.recallAt20)}, median score ${s.medianRelevantScore.toFixed(2)}`).join(`
`);return[`Semantic self-test — ${e.embeddedDocs} embedded / ${e.corpusSize} chats, ${e.probeTerms} probe terms`,"",`Separability (AUC): ${e.auc.toFixed(3)}  → ${o}`,`Recall@10 ${t(e.recallAt10)}   Recall@20 ${t(e.recallAt20)}   MRR ${e.mrr.toFixed(3)}   nDCG@10 ${e.ndcg10.toFixed(3)}`,"",`Relevant-chat scores:    p25 ${e.relevantScore.p25.toFixed(2)}  p50 ${e.relevantScore.p50.toFixed(2)}  p75 ${e.relevantScore.p75.toFixed(2)}  p90 ${e.relevantScore.p90.toFixed(2)}`,`Irrelevant-chat scores:  p50 ${e.irrelevantScore.p50.toFixed(2)}  p90 ${e.irrelevantScore.p90.toFixed(2)}  p99 ${e.irrelevantScore.p99.toFixed(2)}`,"","Floor sweep (precision/recall of relevant chats at each cutoff):",n,"","Weakest topics:",a(e.weakestProbes),"","Strongest topics:",a(e.strongestProbes),"",e.note].join(`
`)}async function Af(){if(!mt||!R)return;mt.disabled=!0;const e=mt.textContent;mt.textContent="Testing…",R.style.display="block",R.textContent="Loading the semantic engine and embedding a few test phrases…";try{const t=await chrome.runtime.sendMessage({type:"RUN_SEMANTIC_ENGINE_CHECK"});if(!t.ok){R.textContent=`❌ Semantic engine FAILED to load:

${t.error}`;return}const o=t.check,n=o.dim===384&&o.margin>.1;R.textContent=[n?"✅ Semantic engine works.":"⚠️ Engine loaded, but results look off.","",`Model: ${t.modelId}`,`Vector size: ${o.dim}  (expected 384)`,`Model load: ${o.loadMs} ms   ·   3 embeds: ${o.embedMs} ms`,`Related phrases scored ${o.relatedScore.toFixed(3)} vs unrelated ${o.unrelatedScore.toFixed(3)} (gap ${o.margin.toFixed(3)} — bigger is better).`].join(`
`)}catch(t){R.textContent=`❌ Semantic engine FAILED:

${t instanceof Error?t.message:"Unknown error"}`}finally{mt.disabled=!1,mt.textContent=e??"Test semantic engine"}}async function nd(){if(!da||!yt||!R)return;const e=da.value.trim();if(!e)return;yt.disabled=!0;const t=yt.textContent;yt.textContent="Probing…",R.style.display="block",R.textContent=`Finding chats closest in meaning to "${e}"…`;try{const o=await chrome.runtime.sendMessage({type:"SEMANTIC_SEARCH_PROBE",query:e});if(!o.ok){R.textContent=`Probe failed: ${o.error}`;return}if(o.hits.length===0){R.textContent='No semantic results. Is the index built and the engine working? Check the coverage line above and "Test semantic engine" first.';return}const n=o.hits.map((a,r)=>{const s=a.score>=o.floor?"✓":"·";return`${String(r+1).padStart(2)}. ${a.score.toFixed(3)} ${s} [${a.platform}] ${a.title}`});R.textContent=[`Closest chats by meaning to: "${o.query}"`,`✓ = above the ${o.floor.toFixed(2)} floor (would surface in search)   ·  · = below floor (hidden)`,"",...n].join(`
`)}catch(o){R.textContent=`Probe failed: ${o instanceof Error?o.message:"Unknown error"}`}finally{yt.disabled=!1,yt.textContent=t??"Probe meaning"}}async function Lf(){if(!ht||!R)return;ht.disabled=!0;const e=ht.textContent;ht.textContent="Running…",R.style.display="block",R.textContent="Running semantic self-test against your local index…";try{const t=await chrome.runtime.sendMessage({type:"RUN_SEMANTIC_EVAL"});if(!t.ok){R.textContent=`Self-test failed: ${t.error}`;return}console.log("[LLMnesia] semantic self-test",t.report),R.textContent=$f(t.report)}catch(t){R.textContent=`Self-test failed: ${t instanceof Error?t.message:"Unknown error"}`}finally{ht.disabled=!1,ht.textContent=e??"Run semantic self-test"}}async function If(){if(!bt)return;bt.disabled=!0;const e=bt.textContent;bt.textContent="Exporting…";try{const t=await chrome.runtime.sendMessage({type:"EXPORT_EVAL_CORPUS"});if(!t.ok){R&&(R.style.display="block",R.textContent=`Eval corpus export failed: ${t.error}`);return}mr("corpus-eval.json",new Blob([JSON.stringify(t.corpus)],{type:"application/json"}))}catch(t){R&&(R.style.display="block",R.textContent=`Eval corpus export failed: ${t instanceof Error?t.message:"Unknown error"}`)}finally{bt.disabled=!1,bt.textContent=e??"Export eval corpus"}}async function Tf(){try{const e=await Ec();if(e.state==="done"){Ht&&(Ht.style.display="none");return}if(Ht&&(Ht.style.display=""),e.state==="in_progress"){Br(`Migration status: in progress${e.cursor?` (last doc: ${e.cursor})`:""}.`);return}Br("Migration status: pending (runs automatically on DB use).")}catch(e){const t=e instanceof Error?e.message:"Unknown error";Br(`Migration status unavailable: ${t}`)}}async function Rf(){et("Updating indexing state...");let e;try{e=await chrome.runtime.sendMessage({type:"TOGGLE_INDEXING_ENABLED"})}catch(t){et(`Failed to toggle indexing: ${U(t)}`);return}if(!e.ok){et(`Failed to toggle indexing: ${e.error}`);return}et(`Indexing is now ${e.enabled?"active":"paused"}.`),await yr()}async function rd(e){let t=!1;try{const o=await chrome.runtime.sendMessage({type:"GET_INDEXING_ENABLED"});t=o.ok&&o.enabled}catch{t=!1}if(t)try{await chrome.runtime.sendMessage({type:"SET_INDEXING_ENABLED",enabled:!1})}catch(o){throw new Error(`Failed to pause indexing: ${U(o)}`)}try{return await e()}finally{if(t)try{await chrome.runtime.sendMessage({type:"SET_INDEXING_ENABLED",enabled:!0})}catch(o){et(`Warning: failed to resume indexing: ${U(o)}`)}await yr()}}async function Pf(){ve("Preparing backup export..."),en?.setAttribute("disabled","true"),tn?.setAttribute("disabled","true");let e=0;try{const t=await Ac({chunkBytes:Number.MAX_SAFE_INTEGER,compress:!0,onProgress:({conversationsDone:a,conversationsTotal:r})=>{Jn(a,r,!1);const s=Date.now();s-e<150||(e=s,ve(`Exporting… ${a} of ${r} conversations.`))}});if(t.chunks.length===0){ve("Nothing to export — index is empty.");return}const o=t.chunks[0],n=o.filename.replace(/-part-\d+/,"");mr(n,o.blob),ve(`Exported ${t.conversationCount} conversations and ${t.messageCount} messages.`)}catch(t){const o=t instanceof Error?t.message:"Unknown backup export error";ve(`Export failed: ${o}`)}finally{Jn(-1,0,!1),en?.removeAttribute("disabled"),tn?.removeAttribute("disabled")}}async function _f(e){pa=!1,ve(`Importing ${e.name}...`),en?.setAttribute("disabled","true"),tn?.setAttribute("disabled","true"),on?.removeAttribute("disabled");try{await br();let t=0;const o=()=>pa,n=s=>{Jn(s.total,s.totalHint??Math.max(s.total,1),!0);const i=Date.now();if(i-t<150)return;t=i;const l=s.alreadyImported>0?`, ${s.alreadyImported} already had`:"";ve(`Importing ${e.name} — ${s.imported} saved${l}, ${s.total} processed…`)},a=await rd(async()=>{if(e.name.toLowerCase().endsWith(".json")){const s=JSON.parse(await e.text());return Lc(s,n,{shouldCancel:o})}return tl(e,n,{shouldCancel:o})});await _t(a.imported);const r=a.alreadyImported>0?` (${a.alreadyImported} already imported, skipped)`:"";a.cancelled?ve(`Import stopped: ${a.imported}/${a.total} conversations imported${r} (${a.failed} failed). Choose the same file again to resume.`):ve(`Import complete: ${a.imported}/${a.total} conversations imported${r} (${a.failed} failed).`),await Se()}catch(t){await _t(1);const o=t instanceof Error?t.message:"Unknown backup import error";ve(`Import failed: ${o}`)}finally{Jn(-1,0,!1),en?.removeAttribute("disabled"),tn?.removeAttribute("disabled")}}function vi(e){const t=e.split("/").pop()??e;return t==="conversations.json"||/^conversations-\d+\.json$/.test(t)}function Nf(e){const t=Na(e,{filter:n=>vi(n.name)}),o=Object.keys(t).filter(vi).sort();return o.length===0?null:o.map(n=>t[n])}async function Mf(e){$o=!1,ge(`Reading ${e.name}…`),ua?.setAttribute("disabled","true"),nn?.removeAttribute("disabled");try{const t=new Uint8Array(await e.arrayBuffer());ge("Unpacking your chats from the export…");let o;try{o=Nf(t)}catch(A){const I=A instanceof Error?A.message:String(A);ge(`That .zip couldn't be opened (${I}). Make sure it's the unmodified file ChatGPT emailed you.`);return}if(!o){ge("Couldn't find your conversations inside that .zip. Make sure it's the export from ChatGPT's Settings → Data controls → Export data.");return}const n=[];try{for(const A of o){const I=JSON.parse(cl(A));Array.isArray(I)&&n.push(...I)}}catch{ge("That export's conversation list couldn't be read. It may be incomplete — try exporting from ChatGPT again.");return}if(n.length===0){ge("That file didn't look like a ChatGPT export (no conversations inside).");return}const a=Cp(t),r=n.length;let s=0,i=0,l=0,m=0,y=0;ge("Checking which chats are already imported…");const d=[];for(const A of n){const I=ra(A);I&&d.push(I)}let v=null;try{const A=new Set,I=2e3;for(let S=0;S<d.length;S+=I){const W=d.slice(S,S+I),Ce=await chrome.runtime.sendMessage({type:"LIST_INDEXED_SOURCE_IDS",platform:"chatgpt",sourceIds:W});if(!Ce?.ok||!Array.isArray(Ce.unindexedSourceIds))throw new Error("skip-check unavailable");for(const Ee of Ce.unindexedSourceIds)A.add(Ee)}v=A}catch{v=null}Sn(0,r);for(let A=0;A<n.length&&!$o;A+=1){const I=n[A],S=ra(I);if(v&&S&&!v.has(S)&&!Ep(I,a))m+=1;else{const Ee=Tu(I,a);if(!Ee)i+=1;else try{(await chrome.runtime.sendMessage({type:"INDEX_CONVERSATION",indexingMode:"backfill",conversation:Ee}))?.ok?s+=1:l+=1}catch{l+=1}}const W=s+i+l+m,Ce=Date.now();Ce-y>150&&(y=Ce,Sn(W,r),ge(`Importing your ChatGPT history… ${W} of ${r} chats read, ${s} saved.`))}Sn(-1,r);const b=`${s} of ${r} chats saved from your export.`,h=m>0?` ${m} were already imported.`:"",w=i>0?` ${i} had no text to save (image-only or empty).`:"",C=l>0?` ${l} could not be saved.`:"";ge($o?`Import stopped. ${b}${h}${w}${C} Choose the same .zip again to resume.`:`Import complete: ${b}${h}${w}${C}`),fo("export_import_completed","chatgpt",{count:s,skipped:i,failed:l,outcome:$o?"stopped":"completed"}),await Se()}catch(t){const o=t instanceof Error?t.message:"Unknown import error";ge(`Import failed: ${o}`)}finally{Sn(-1,0),ua?.removeAttribute("disabled")}}function T(e,t){const o=ee[e].statusNode;o&&(o.textContent=t)}function ad(e){Ze&&(Ze.style.background=e?"#d97757":"#fff",Ze.style.color=e?"#fff":"#8a4b2e")}function sd(){Kt&&(Kt.textContent=Wt),ad(!1),Kn?.style.setProperty("display","block");for(const e of Re){if(ae[e].nativeHostOnly)continue;const t=ee[e];t.copyPathBtn?.style.setProperty("display","inline-block"),t.hintNode&&(t.hintNode.innerHTML=`<strong>Prefer not to use the terminal?</strong> Click <strong>Choose folder</strong>, then in the file dialog ${ld}, paste the copied path (<code>${ns(e)}</code>), press Enter, and choose <strong>Open</strong>. Your browser won't let you pick your Home folder, so this points it straight at your sessions.`)}}function Of(){Kn?.style.setProperty("display","none");for(const e of Re)ee[e].copyPathBtn?.style.setProperty("display","none")}function Bf(e){const t=[`Indexed ${e.indexed} session${e.indexed===1?"":"s"}`];return e.skipped&&t.push(`${e.skipped} unchanged`),e.empty&&t.push(`${e.empty} with no chat content`),e.failed&&t.push(`${e.failed} failed to read`),`${t.join(" · ")}. Search updates as embeddings backfill.`}function id(e){const t=ee[e];t.chooseBtn?.style.setProperty("display","none"),t.rescanBtn?.style.setProperty("display","inline-block"),t.forgetBtn?.style.setProperty("display","inline-block")}const os=qp(),qf=ke,Vf=Mt;function ns(e){const t=ae[e];return qf?t.windowsPath:t.posixPath}const ld=Vf?"press <strong>⌘⇧G</strong> (Go to Folder)":"press <strong>Ctrl+L</strong>",Wt=`npx -y @llmnesia/local-agent-host@latest ${chrome.runtime.id}`;let ga=null,hr=!1;chrome.storage.onChanged.addListener((e,t)=>{t!=="local"||!e[$c]||!hr||il().then(o=>{for(const n of o)ee[n.source].chooseBtn?.hasAttribute("disabled")||T(n.source,ll(n))})});const rs={claude_code:{connected:"claude_code_connected",importCompleted:"claude_code_import_completed"},codex:{connected:"codex_connected",importCompleted:"codex_import_completed"},zcode:{connected:"zcode_connected",importCompleted:"zcode_import_completed"}};async function _t(e){if(e<=0){await chrome.storage.local.remove(gl);return}await chrome.runtime.sendMessage({type:"FINALIZE_CONVERSATION_IMPORT",imported:e}).catch(()=>{})}async function br(){await chrome.storage.local.set({[gl]:!0})}async function co(e,t,o){const n=ee[e];n.rescanBtn?.setAttribute("disabled","true"),n.chooseBtn?.setAttribute("disabled","true");const a=r=>{T(e,`Scanning ${r.processed}/${r.total} — indexed ${r.indexed}, skipped ${r.skipped}…`)};try{await br();const r=await o(a),s=t==="native"?(await il()).find(i=>i.source===e):void 0;T(e,`${Bf(r)}${s?` ${ll(s)}`:""}`),await _t(r.indexed),r.indexed>0&&fo(rs[e].importCompleted,void 0,{method:t,count:r.indexed,skipped:r.skipped})}catch(r){await _t(1),T(e,`Scan failed: ${r instanceof Error?r.message:String(r)}`)}finally{n.rescanBtn?.removeAttribute("disabled"),n.chooseBtn?.removeAttribute("disabled")}}async function Uf(e){if(hr){await co(e,"native",o=>dl(o,{force:!1,sources:[e]}));return}if(ae[e].nativeHostOnly){T(e,`${ae[e].label} sessions sync through the helper. Set up the one-time helper above, then click Connect helper.`);return}if(!os){ee[e].dirInput?.click();return}T(e,"Opening folder picker…");let t;try{t=await Fp(e)}catch(o){o instanceof xl?T(e,"No folder chosen."):T(e,`Couldn't open the folder picker: ${o instanceof Error?o.message:String(o)}`);return}if(!await qa(t,{prompt:!0})){T(e,"Read permission denied.");return}id(e),fo(rs[e].connected,void 0,{method:"folder"}),await co(e,"folder",o=>Va(e,t,o,{force:!0}))}async function zf(e){const t=ee[e].dirInput,o=t?.files;if(!o||o.length===0){T(e,"No folder chosen.");return}await co(e,"folder",n=>Yp(e,o,n)),t&&(t.value="")}async function Ff(e){const t=await vl(e);if(!t){T(e,"No folder connected — choose one first.");return}if(!await qa(t,{prompt:!0})){T(e,"Read permission denied — reconnect the folder.");return}await co(e,"folder",o=>Va(e,t,o,{force:!1}))}async function Df(e){await zp(e);const t=ee[e];t.chooseBtn?.style.setProperty("display","inline-block"),t.rescanBtn?.style.setProperty("display","none"),t.forgetBtn?.style.setProperty("display","none"),hr||sd(),T(e,"Folder forgotten. Already-indexed sessions remain searchable — delete them in Manage or Danger Zone.")}async function dd(e){hr=!0;const t=e>=_a,o=e>=sl;chrome.runtime.sendMessage({type:"ENABLE_CLAUDE_CODE_AUTOSYNC"}).catch(()=>{}),Hn&&(Hn.style.display="none"),Of();const n=["claude_code"];t&&n.push("codex"),o&&n.push("zcode");for(const a of n){const r=ee[a];r.chooseBtn&&(r.chooseBtn.textContent="Sync now",r.chooseBtn.style.setProperty("display","inline-block")),r.rescanBtn?.style.setProperty("display","none"),r.forgetBtn?.style.setProperty("display","none"),r.hintNode&&(r.hintNode.textContent=`The LLMnesia helper is installed — your ${ae[a].label} sessions sync automatically, in the background too. Click Sync now to check for new ones right away.`),T(a,`Helper connected. Syncing ${ae[a].label} sessions…`)}if(!t){const a=ee.codex;a.hintNode&&(a.hintNode.innerHTML=`Your installed helper predates Codex support. Re-run <code>${Wt}</code> in your terminal (then fully quit and reopen your browser) to sync Codex automatically too — or connect the folder below.`),T("codex","Helper installed, but too old for Codex."),Kn?.style.setProperty("display","block"),Kt&&(Kt.textContent=Wt)}if(!o){const a=ee.zcode;a.hintNode&&(a.hintNode.innerHTML=`Your installed helper predates ZCode support. Re-run <code>${Wt}</code> in your terminal (then fully quit and reopen your browser) to sync ZCode automatically too.`),T("zcode","Helper installed, but too old for ZCode."),Kn?.style.setProperty("display","block"),Kt&&(Kt.textContent=Wt)}for(const a of n)await co(a,"native",r=>dl(r,{force:!1,sources:[a]}))}async function Gf(){Ze?.setAttribute("disabled","true");for(const a of Re)T(a,"Requesting browser permission…");let e;try{e=await chrome.permissions.request({permissions:["nativeMessaging"]})}catch(a){const r=`Permission request failed: ${a instanceof Error?a.message:String(a)}`;for(const s of Re)T(s,r);Ze?.removeAttribute("disabled");return}if(!e){for(const a of Re)T(a,"Permission denied — click Connect helper to allow it, or use Choose folder instead.");Ze?.removeAttribute("disabled");return}for(const a of Re)T(a,"Looking for the helper…");const t=await al();if(t!==null){for(const a of Re)a==="codex"&&t<_a||a==="zcode"&&t<sl||fo(rs[a].connected,void 0,{method:"native"});await dd(t);return}const n=ga!==null&&Date.now()-ga<1800*1e3?"Permission granted, but the helper isn't answering yet — this usually means the browser wasn't fully quit and reopened after running the command. Fully quit (not just close the window), reopen, then click Connect helper again.":"Permission granted, but the helper isn't answering yet. Copy the command above, run it in a terminal, fully quit and reopen your browser, then click Connect helper again. Need Node first? nodejs.org has an installer.";for(const a of Re)T(a,n);Ze?.removeAttribute("disabled")}async function xi(e){const t="Not connected. Set up the one-time helper above, or use Choose folder.";if(ae[e].nativeHostOnly){const n=ee[e];n.chooseBtn?.style.setProperty("display","none"),n.copyPathBtn?.style.setProperty("display","none"),n.rescanBtn?.style.setProperty("display","none"),n.forgetBtn?.style.setProperty("display","none"),n.hintNode&&(n.hintNode.textContent=`${ae[e].label} sessions sync through the LLMnesia helper above — there is no folder to pick.`),T(e,"Not connected. Set up the one-time helper above.");return}if(!os){const n=ee[e].hintNode;n&&(n.innerHTML=`<strong>Prefer not to use the terminal?</strong> Click <strong>Choose folder</strong>, ${ld}, paste the copied path (<code>${ns(e)}</code>), and choose <strong>Upload</strong>. Brave re-reads only new chats each time — to have it remember the folder and rescan on its own, turn on the flag below.`),T(e,t);return}const o=await vl(e);if(!o){T(e,t);return}id(e),await qa(o,{prompt:!1})?(T(e,"Folder connected. Checking for new sessions…"),await co(e,"folder",n=>Va(e,o,n,{force:!1}))):T(e,"Folder connected but needs permission again — click Rescan to reconnect.")}async function jf(){if(Ju){if(Ic()&&await Tc()){const e=await al();if(e!==null){await dd(e),e<_a&&await xi("codex");return}}sd(),!os&&Hn&&(Hn.style.display="block");for(const e of Re)await xi(e)}}async function as(){try{const e=await chrome.runtime.sendMessage({type:"VAULT_STATUS"});return e.ok&&e.status.lastSyncedAt!==null}catch{return!1}}const dt=document.querySelector("#vault-card"),sn=document.querySelector("#vault-signed-out"),No=document.querySelector("#vault-email"),Pn=document.querySelector("#vault-send-code"),ma=document.querySelector("#vault-code-step"),wi=document.querySelector("#vault-code-email"),He=document.querySelector("#vault-code"),Fe=document.querySelector("#vault-signin-success"),un=document.querySelector("#vault-verify-code"),fn=document.querySelector("#vault-resend-code"),cd=document.querySelector("#vault-cancel-code"),ya=document.querySelector("#vault-create-step"),De=document.querySelector("#vault-new-passphrase"),Hf=document.querySelector("#vault-new-passphrase-visibility"),St=document.querySelector("#vault-confirm-passphrase"),Kf=document.querySelector("#vault-confirm-passphrase-visibility"),er=document.querySelector("#vault-passphrase-strength"),Ct=document.querySelector("#vault-create-continue"),tr=document.querySelector("#vault-recovery-key-block"),ha=document.querySelector("#vault-recovery-key"),Ut=document.querySelector("#vault-copy-recovery"),Mo=document.querySelector("#vault-ack-checkbox"),xe=document.querySelector("#vault-confirm-create"),ba=document.querySelector("#vault-unlock-step"),ki=document.querySelector("#vault-unlock-copy"),Cn=document.querySelector("#vault-biometric-unlock"),_n=document.querySelector("#vault-biometric-unlock-btn"),at=document.querySelector("#vault-unlock-passphrase"),Yf=document.querySelector("#vault-unlock-passphrase-visibility"),va=document.querySelector("#vault-unlock-btn"),Wf=document.querySelector("#vault-recover-toggle"),Oo=document.querySelector("#vault-recover-form"),Lt=document.querySelector("#vault-recover-key"),Bo=document.querySelector("#vault-recover-show-key"),qo=document.querySelector("#vault-recover-passphrase"),Jf=document.querySelector("#vault-recover-passphrase-visibility"),Vo=document.querySelector("#vault-recover-confirm"),Xf=document.querySelector("#vault-recover-confirm-visibility"),xa=document.querySelector("#vault-recover-submit"),wa=document.querySelector("#vault-unlocked-panel"),Fr=document.querySelector("#vault-phone-pair-card"),Si=document.querySelector("#vault-phone-pair-qr"),or=document.querySelector("#vault-account-line"),zt=document.querySelector("#vault-sync-line"),Dr=document.querySelector("#vault-sync-text"),Ci=document.querySelector("#vault-sync-spinner"),Ft=document.querySelector("#vault-sync-error-line"),Io=document.querySelector("#vault-manage-subscription-btn"),Qf=document.querySelector("#vault-lock-btn"),ln=document.querySelector("#vault-biometric-toggle"),Zf=document.querySelector("#vault-change-passphrase-toggle"),eg=document.querySelector("#vault-sign-out-btn"),Nn=document.querySelector("#vault-change-passphrase-form"),Uo=document.querySelector("#vault-old-passphrase"),tg=document.querySelector("#vault-old-passphrase-visibility"),zo=document.querySelector("#vault-newer-passphrase"),og=document.querySelector("#vault-newer-passphrase-visibility"),Fo=document.querySelector("#vault-newer-confirm"),ng=document.querySelector("#vault-newer-confirm-visibility"),ka=document.querySelector("#vault-change-passphrase-submit"),Ei=document.querySelector("#vault-status-text"),$i=document.querySelector("#vault-status-spinner"),Et=document.querySelector("#vault-paywall-seat"),Ai=document.querySelector("#vault-paywall-account-line"),Li=document.querySelector("#vault-paywall-status-line"),Gr=document.querySelector("#vault-paywall-data-line"),Te=document.querySelector("#vault-paywall-cta"),Sa=document.querySelector("#vault-plan-annual"),Ca=document.querySelector("#vault-plan-monthly");let pd="annual";const Mn=document.querySelector("#vault-paywall-recheck-btn"),jr=document.querySelector("#vault-paywall-recheck-status"),Ii=su(()=>chrome.runtime.sendMessage({type:"VAULT_REFRESH_ENTITLEMENT"})),rg=document.querySelector("#vault-paywall-sign-out-btn"),Ea=document.querySelector("#vault-firstsync-row"),ag=document.querySelector("#vault-firstsync-dot"),Ti=document.querySelector("#vault-firstsync-text"),Jt=document.querySelector("#vault-firstsync-btn"),Hr=document.querySelector("#vault-firstsync-progress"),Ri=document.querySelector("#vault-firstsync-progress-fill"),$a=document.querySelector("#vault-backup-row"),sg=document.querySelector("#vault-backup-dot"),Pi=document.querySelector("#vault-backup-text"),D=document.querySelector("#vault-backup-btn"),Kr=document.querySelector("#vault-backup-progress"),_i=document.querySelector("#vault-backup-progress-fill"),dn=document.querySelector("#vault-restore-row"),ig=document.querySelector("#vault-restore-dot"),Ni=document.querySelector("#vault-restore-text"),tt=document.querySelector("#vault-restore-btn"),Yr=document.querySelector("#vault-restore-progress"),Mi=document.querySelector("#vault-restore-progress-fill"),Wr=document.querySelector("#vault-incoming-row"),Jr=document.querySelector("#vault-incoming-text"),En=document.querySelector("#vault-incoming-progress"),Oi=document.querySelector("#vault-incoming-progress-fill");let Do=null,Aa=0,po=null,$t=null;const At=new mu;let Ke=null,M=null,G=0,La=!1;function ct(){Ke?.fill(0),Ke=null}function Bi(e){_n?.toggleAttribute("disabled",e),_n&&(_n.textContent=e?"Waiting for biometrics…":"Unlock with biometrics")}async function lg(e){if(!(!e||Ke))try{const t=await chrome.storage.session.get([Ls,Is]);if(M!==e||t[Is]!==e)return;const o=t[Ls];typeof o=="string"&&o.length>0&&(Ke=Uint8Array.from(atob(o),n=>n.charCodeAt(0)))}catch{}}async function nr(e,t){if(!e){La=!1,Cn&&(Cn.style.display="none");return}const o=await At.hasEnrollment(e);M===e&&(La=o,ln&&(ln.textContent=o?"Disable biometric unlock":"Enable biometric unlock"),Cn&&(Cn.style.display=!t&&o?"":"none"),ki&&!t&&(ki.textContent=o?"You already have a Vault for this email. Use your device biometrics, or enter its passphrase.":"You already have a Vault for this email. Enter its passphrase to open it on this device."))}function vr(e){let t="";for(const o of e)t+=String.fromCharCode(o);return btoa(t)}function c(e,t=!1){Ei&&(Ei.textContent=e),$i&&($i.hidden=!t)}function dg(){Fe&&(Fe.style.display="none",Fe.textContent="",delete Fe.dataset.email)}function xr(){for(const e of[sn,ma,ya,ba,wa,Et])e&&(e.style.display="none")}function qi(e){dt&&(dt.style.display=""),xr(),c(e)}function cg(e){if(e.length===0)return"";if(e.length<8)return"Too short — use at least 8 characters";const t=[/[a-z]/,/[A-Z]/,/[0-9]/,/[^a-zA-Z0-9]/].filter(o=>o.test(e)).length;return e.length>=16&&t>=3?"Strong":e.length>=12&&t>=2?"Good":"OK — longer or more varied is stronger"}const ud=[];function pt(e,t,o){if(!e||!t)return;const n={input:e,button:t,label:o};ud.push(n),Iu(n)}function wr(...e){for(const t of e){const o=ud.find(n=>n.input===t);o&&Tl(o,!1)}}function fd(){$t?.vaultKey.fill(0),$t=null,De&&(De.value="",De.removeAttribute("disabled")),St&&(St.value="",St.removeAttribute("disabled")),wr(De,St),er&&(er.textContent=""),tr&&(tr.style.display="none"),Mo&&(Mo.checked=!1),xe&&(xe.setAttribute("disabled","true"),xe.style.opacity="0.5"),Ct&&(Ct.style.display="")}function rr(){Oo&&(Oo.style.display="none"),Lt&&(Lt.value="",Lt.type="password"),qo&&(qo.value=""),Vo&&(Vo.value=""),wr(qo,Vo),Bo&&(Bo.textContent="Show recovery key")}function pg(e){const t=Date.now()-e,o=Math.round(t/6e4);if(o<1)return"just now";if(o<60)return`${o}m ago`;const n=Math.round(o/60);if(n<24)return`${n}h ago`;const a=Math.round(n/24);return a<7?`${a}d ago`:new Date(e).toLocaleDateString()}let ar=null,sr=null,cn=!1;function uo(e,t){ar=e,sr=t;const o=Yd(t);if(o){const n=Wd(o);zt&&(zt.style.display="none"),Ft&&(Ft.style.display="",Ft.textContent=n.tone==="attention"?`⚠ ${n.text}`:n.text,Ft.title=t?`${t.message} (${ur(t.at)})`:"");return}if(Ft&&(Ft.style.display="none"),zt&&(zt.style.display="",Ci&&(Ci.hidden=!cn),Dr)){const n=ss?.copy,a=cn?"Syncing now":n??(e?`Vault last synced ${pg(e)}`:"Vault is ready to sync");if(Aa>0){const r=Aa;Dr.textContent=`${a} · Some saved items need checking. Use Restore again.`,zt.title=`${r} ${r===1?"item was":"items were"} skipped in earlier syncs. Restore again rechecks the Vault and shows why any still cannot be added here.`}else Dr.textContent=a,zt.title=""}}const Be=document.querySelector("#vault-status-pill"),ro=document.querySelector("#vault-status-pill-button"),ug=document.querySelector("#vault-status-pill-panel"),Ia=document.querySelector("#vault-status-pill-facts"),Xt=document.querySelector("#vault-status-pill-sync-now"),It=document.querySelector("#vault-status-pill-recovery");let ss=null;const kr=tc({root:Be,button:ro,panel:ug,syncNow:Xt,render:fg,refresh:mo,async runSync(){return(await chrome.runtime.sendMessage({type:"VAULT_SYNC_NOW"}))?.ok===!0}});let Vi=0;function Ta(e){kr.clear(),ss=null,rc({root:Be,button:ro,facts:Ia,syncNow:Xt,recovery:It,label:document.querySelector("#vault-status-pill-label"),attention:document.querySelector("#vault-status-attention")},e)}Ta("checking");async function mo(){if(!Be)return;const e=++Vi,t=await ac();if(e!==Vi)return;if(!t){Ta("unavailable");return}if(!sc(t)){Ta(t.status.available?"setup":"unavailable");return}const o=ic(t,Date.now());kr.update(o)}function fg(e){if(!Be)return;ss=e,Be.dataset.visible="true",Be.dataset.tone=e.tone,Be.dataset.condition=e.condition;const t=document.querySelector("#vault-status-attention");t&&(t.hidden=e.tone!=="attention",t.textContent=mn(e)),Be.dataset.busy=e.busy?"true":"false",ro?.setAttribute("aria-label",`Vault status: ${e.copy}`),ro&&(ro.title=mn(e));const o=document.querySelector("#vault-status-pill-label");if(o&&o.textContent!==mn(e)&&(o.textContent=mn(e)),Xt&&(Xt.hidden=!1,Xt.disabled=e.busy||!e.canSyncNow,lc(Xt,e.busy)),It){const n={signin:"Go to sign-in",unlock:"Go to unlock",subscription:"Review subscription",update:"How to update"},a=e.recovery;It.hidden=a===null,It.textContent=a===null?"":n[a]}Ia&&dc(Ia,e,()=>{kr.close(),dt?.scrollIntoView({behavior:"smooth",block:"start"}),ls().then(()=>{dn?.style.display!=="none"&&dn?.scrollIntoView({behavior:"smooth",block:"center"}),tt?.style.display!=="none"&&tt?.focus({preventScroll:!0})})}),uo(ar,sr)}Be&&ro&&(document.querySelector("#vault-status-attention")?.addEventListener("click",()=>It?.click()),It&&It.addEventListener("click",()=>{kr.close(),dt?.scrollIntoView({behavior:"smooth",block:"start"}),dt?.focus?.()}),chrome.storage.onChanged.addListener((e,t)=>{t==="local"&&(ep in e||tp in e||op in e||oc.some(o=>o in e))&&gg()}),nc(()=>{mo()}));let $n=null;function gg(){$n&&clearTimeout($n),$n=setTimeout(()=>{$n=null,mo()},200)}async function Ui(e){Et&&(Et.style.display="");const t=up({email:e.email,hasVault:e.hasVault===!0||e.unlocked,lastSyncedAt:e.lastSyncedAt,lastSyncErrorKind:e.lastSyncError?.kind??null});Et&&(Et.dataset.state=t.state),Ai&&(Ai.textContent=t.accountLine),Li&&(Li.textContent=t.statusLine),Gr&&(Gr.textContent=t.dataLine,Gr.style.display=t.dataLine?"":"none"),Te&&(Te.textContent=t.actionLabel)}function Pe(e){jr&&(jr.textContent=e,jr.style.display=e?"":"none")}async function zi(){if(!(!Ii||Mn?.disabled)){Mn?.setAttribute("disabled","true"),Pe(wo.checking);try{const e=await Ii();if(e.kind==="cooldown"){Pe(wo.cooldown);return}if(e.response.ok&&e.response.entitled===!0){Pe(wo.confirmed),await te();return}Pe(wo.unconfirmed)}catch{Pe(wo.failed)}finally{Mn?.removeAttribute("disabled")}}}async function mg(){if(!Te||Te.disabled)return;const e=Te.textContent??"Continue to checkout";Te.setAttribute("disabled","true"),Te.textContent=xo.opening,Pe("");let t;try{t=await chrome.runtime.sendMessage({type:"VAULT_CREATE_CHECKOUT",plan:pd})}catch{t={ok:!1,error:"checkout_unavailable"}}if(Te.textContent=e,Te.removeAttribute("disabled"),!t||typeof t.ok!="boolean"){Pe(xo.unavailable);return}if(!t.ok){if(t.error==="subscription_already_exists"){Pe(xo.alreadySubscribed),chrome.tabs.create({url:yl});return}Pe(xo.unavailable);return}await chrome.tabs.create({url:t.url}),Pe(xo.opened)}function Fi(e){pd=e,Sa?.classList.toggle("selected",e==="annual"),Sa?.setAttribute("aria-pressed",e==="annual"?"true":"false"),Ca?.classList.toggle("selected",e==="monthly"),Ca?.setAttribute("aria-pressed",e==="monthly"?"true":"false")}async function yg(){if(!Io||Io.disabled)return;Io.setAttribute("disabled","true");let e;try{e=await chrome.runtime.sendMessage({type:"VAULT_CREATE_PORTAL"})}catch{e=void 0}finally{Io.removeAttribute("disabled")}if(e?.ok&&typeof e.url=="string"){await chrome.tabs.create({url:e.url});return}await chrome.tabs.create({url:yl})}function hg(e){return e.available?e.signedIn?e.lastSyncedAt!==null?!0:e.hasVault:null:!1}let Di=null,Gi=!1;async function bg(e){if(!Fr||!Si)return;const t=e?.trim().toLowerCase()||null;if(!(Di===t&&Fr.style.display!=="none"))try{const{vaultPairingQrSvg:o,vaultPairingUrl:n}=await pn(async()=>{const{vaultPairingQrSvg:a,vaultPairingUrl:r}=await import("./vault_pair_qr.js");return{vaultPairingQrSvg:a,vaultPairingUrl:r}},[]);Si.innerHTML=o(n(t),{pixels:136}),Fr.style.display="flex",Di=t,Gi||(Gi=!0,fo("vault_phone_qr_shown"))}catch{}}async function gd(e){if(Yl=hg(e),Zl(),!dt)return;(!e.signedIn||e.email?.toLowerCase()!==Fe?.dataset.email)&&dg();const t=e.signedIn?e.accountId:null;if(t!==M&&(G++,ct(),rr(),M=t),e.unlocked||(ct(),Nn?.style.display!=="none"&&ds()),e.unlocked&&rr(),Ed(),ye("hidden","",null),Qe(),J("hidden","",null),vt(),X("hidden","",null),Bg(),Ro(null),Tg(),uo(null,null),mo(),dt.style.display="",xr(),!e.available){c("Vault is temporarily unavailable. Reload Settings to try again.");return}if(!e.signedIn){sn&&(sn.style.display=""),c("");return}if(e.entitled===null){c("Checking your Vault subscription…",!0);return}if(e.entitled!==!0){await Ui(e),c("");return}if(e.unlocked){wa&&(wa.style.display=""),or&&(or.textContent=e.email??"Account email unavailable"),bg(e.email),uo(e.lastSyncedAt,e.lastSyncError),Cd(),Og(),Ig(),wd(),await lg(e.accountId),await nr(e.accountId,!0),c("");return}c("Checking for an existing Vault…",!0);let o;try{o=await chrome.runtime.sendMessage({type:"VAULT_GET_WRAPPED_KEY"})}catch(n){c(`Could not check Vault status: ${U(n)}`);return}if(!o.ok){if(/vault_not_entitled|not[_ ]entitled/i.test(o.error)){await Ui({...e}),c("");return}c(`Could not check Vault status: ${o.error}`);return}if(c(""),o.wrappedVaultKey){ba&&(ba.style.display=""),wr(at),await nr(e.accountId,!1);try{(await chrome.storage.local.get("llmnesia.vault.deviceKeyUnreadable"))["llmnesia.vault.deviceKeyUnreadable"]===!0&&c("This device needs your passphrase again")}catch{}}else fd(),ya&&(ya.style.display="")}async function te(e={}){if(!dt)return;let t;try{t=await chrome.runtime.sendMessage({type:"VAULT_STATUS"})}catch(o){qi(`Vault status unavailable: ${U(o)}`);return}if(!t.ok){qi(`Vault status unavailable: ${t.error}`);return}if(await gd(t.status),e.forceEntitlement){try{await chrome.runtime.sendMessage({type:"VAULT_REFRESH_ENTITLEMENT"})}catch{}await te()}}async function md(){if(Pn?.disabled)return;const e=Vc(No?.value??"");if(!Uc(e)){c("Enter a valid email address.");return}c("Sending code…",!0),Pn?.setAttribute("disabled","true");try{const t=await chrome.runtime.sendMessage({type:"VAULT_REQUEST_CODE",email:e});if(!t.ok){c(t.error);return}po=e,No&&(No.value=e),wi&&(wi.textContent=e),He&&(He.value=""),xr(),ma&&(ma.style.display=""),c("")}catch(t){c(Ma(t,"send"))}finally{Pn?.removeAttribute("disabled")}}function ir(e){for(const t of[fn,un,cd,He])t&&(t.disabled=e)}async function vg(){if(!(!po||fn?.disabled||un?.disabled)){c("Resending code…",!0),ir(!0);try{const e=await chrome.runtime.sendMessage({type:"VAULT_REQUEST_CODE",email:po});e.ok&&He&&(He.value=""),c(e.ok?"New code sent. Use the code in the most recent email.":e.error)}catch(e){c(Ma(e,"send"))}finally{ir(!1)}}}function xg(){fn?.disabled||un?.disabled||(po=null,xr(),sn&&(sn.style.display=""),c(""),He&&(He.value=""),No?.focus())}async function yd(){if(un?.disabled||fn?.disabled)return;const e=po,t=zc(He?.value??"");if(!e){c("Start over. Enter your email again.");return}if(!/^\d{6,8}$/.test(t)){c("Enter the code from your email.");return}c("Verifying…",!0),ir(!0);try{const o=await chrome.runtime.sendMessage({type:"VAULT_VERIFY_CODE",email:e,code:t});if(!o.ok){c(o.error);return}po=null,await te(),Fe&&(Fe.textContent=`Email confirmed. You're signed in to Vault as ${e}.`,Fe.dataset.email=e.toLowerCase(),Fe.style.display="flex")}catch(o){c(Ma(o,"verify"))}finally{ir(!1)}}async function wg(){const e=De?.value??"",t=St?.value??"";if(e.length<8){c("Passphrase must be at least 8 characters.");return}if(e!==t){c("Passphrases don't match.");return}c("Securing your Vault…",!0),Ct?.setAttribute("disabled","true");try{const o=await pn(()=>import("./index.js"),__vite__mapDeps([0,1,2,3])),n=o.generateVaultKey(),a=await o.deriveWrappingKey(e),r=await o.wrapVaultKey(n,a),s=o.encodeRecoveryKey(n);a.key.fill(0),$t={vaultKey:n,wrappedVaultKey:r},ha&&(ha.textContent=s),tr&&(tr.style.display=""),De?.setAttribute("disabled","true"),St?.setAttribute("disabled","true"),Ct&&(Ct.style.display="none"),c("")}catch(o){c(U(o))}finally{Ct?.removeAttribute("disabled")}}async function kg(){if($t){c("Finishing Vault setup…",!0),xe?.setAttribute("disabled","true");try{const e=await chrome.runtime.sendMessage({type:"VAULT_SET_KEY",vaultKey:vr($t.vaultKey),expectedUserId:M??void 0,wrappedVaultKey:$t.wrappedVaultKey});if(!e.ok){c(e.error);return}ct(),Ke=new Uint8Array($t.vaultKey),fo("vault_created"),fd(),await te()}catch(e){c(U(e))}finally{xe?.removeAttribute("disabled")}}}async function hd(){const e=M,t=G,o=at?.value??"";if(!o){c("Enter your passphrase.");return}if(!e){c(K("U09"));return}c("Unlocking your Vault…",!0),va?.setAttribute("disabled","true");let n="U01",a=null;try{const r=await chrome.runtime.sendMessage({type:"VAULT_GET_WRAPPED_KEY"});if(!r.ok){c(lo(r.error,"U01"));return}if(!r.wrappedVaultKey){c(K("U08"));return}n="U06";const s=await pn(()=>import("./index.js"),__vite__mapDeps([0,1,2,3]));try{a=await s.unlockVaultKey(r.wrappedVaultKey,o)}catch(l){c(pl(l));return}if(t!==G||e!==M){a.fill(0),c(K("U09"));return}n="U07";const i=await chrome.runtime.sendMessage({type:"VAULT_SET_KEY",vaultKey:vr(a),expectedUserId:e,expectedWrappedKeyId:JSON.stringify(r.wrappedVaultKey)});if(!i.ok){a.fill(0),c(lo(i.error,"U07"));return}if(t!==G||e!==M){a.fill(0);return}ct(),Ke=a,a=null,at&&(at.value=""),c(""),await te()}catch{c(K(n))}finally{a?.fill(0),va?.removeAttribute("disabled")}}async function Sg(){const e=Lt?.value??"",t=qo?.value??"",o=Vo?.value??"",n=M,a=G;if(!n){c(K("R06"));return}if(t.length<8){c(K("R02"));return}if(t!==o){c(K("R02"));return}c("Checking recovery key and securing your Vault…",!0),xa?.setAttribute("disabled","true");let r=null,s="R07";try{const i=await pn(()=>import("./index.js"),__vite__mapDeps([0,1,2,3]));try{r=i.decodeRecoveryKey(e)}catch(b){if(b instanceof i.RecoveryKeyError)if(b.reason==="wrong length"){const h=i.recoveryKeySymbolCount(e);c(`Recovery key has ${h} symbols after removing separators; this key format uses ${i.RECOVERY_KEY_SYMBOLS}. (Support code: R01)`)}else if(b.reason==="no key found in text"){const h=i.recoveryKeySymbolCount(e);c(`The pasted text has ${h} symbols after removing separators. No checksum-valid 55-symbol recovery key was found in it. (Support code: R01)`)}else b.reason==="multiple keys"?c("The pasted text contains more than one valid recovery key. Paste only the key for this Vault. (Support code: R01)"):b.reason==="too much text"?c("The pasted text is too long. Copy only the recovery key and its nearby label. (Support code: R01)"):b.reason==="invalid character"?c("Recovery key contains a character outside its letters and numbers. Check for note formatting or extra text. (Support code: R01)"):c("Recovery key has the right length, but its checksum does not match. Check your saved copy for a changed character. (Support code: R01)");else c(K("R01"));return}s="R03";const l=await chrome.runtime.sendMessage({type:"VAULT_GET_WRAPPED_KEY"});if(!l.ok){c(lo(l.error,"R03"));return}if(!l.wrappedVaultKey){c(K("R11"));return}const m=JSON.stringify(l.wrappedVaultKey);s="R07";const y=await i.deriveWrappingKey(t);let d;try{d=await i.wrapVaultKey(r,y)}finally{y.key.fill(0)}if(a!==G||n!==M){c(K("R06"));return}s="R08";const v=await chrome.runtime.sendMessage({type:"VAULT_RECOVER_KEY",vaultKey:vr(r),wrappedVaultKey:d,expectedUserId:n,expectedWrappedKeyId:m});if(!v.ok){c(lo(v.error,"R08"));return}if(a!==G||n!==M){c(K("R13"));return}s="R09",ct(),Ke=new Uint8Array(r),at&&(at.value=""),rr(),await te(),c("Passphrase reset. Vault unlocked.")}catch{c(K(s))}finally{r?.fill(0),xa?.removeAttribute("disabled")}}async function Cg(){const e=M,t=G;if(!e)return;c("Confirm with your device biometrics to unlock."),Bi(!0);let o=null;try{if(o=await At.unlock(e),t!==G||e!==M)return;if(!o){c("Biometrics could not unlock this Vault. Use your passphrase.");return}const n=await chrome.runtime.sendMessage({type:"VAULT_SET_KEY",vaultKey:vr(o),expectedUserId:e});if(t!==G||e!==M)return;if(!n.ok){c(n.error);return}ct(),Ke=o,o=null,await te()}catch{t===G&&e===M&&c("Biometrics could not unlock this Vault. Use your passphrase.")}finally{o?.fill(0),Bi(!1)}}async function Eg(){const e=M,t=G;if(e){ln?.setAttribute("disabled","true");try{if(La){await At.remove(e),await nr(e,!0),c("Biometric unlock disabled on this device.");return}const o=Ke;if(!o){c("Lock your Vault, then use your passphrase before enabling biometrics on this device.");return}c("Confirm with your device biometrics to enable biometric unlock.");const n=await At.prepareEnrollment(e,o);if(!n||t!==G||e!==M){c("Biometric unlock could not be enabled on this device.");return}if(await At.save(n),t!==G||e!==M){await At.remove(e,n);return}await nr(e,!0),c("Biometric unlock enabled on this device.")}catch{c("Biometric unlock could not be enabled on this device.")}finally{ln?.removeAttribute("disabled")}}}async function $g(){G++,ct(),await chrome.runtime.sendMessage({type:"VAULT_LOCK"}),await te()}async function bd(){window.confirm("Sign out of Vault? Your local index stays intact and nothing is deleted — you can sign back in any time.")&&(G++,ct(),M&&await At.remove(M).catch(()=>{}),await chrome.runtime.sendMessage({type:"VAULT_SIGN_OUT"}),await te())}let Xr=null;async function lr(e){const t=Xr===null,o=Xr===e;Xr=e,!(t||o)&&await Se()}function Ag(e){const{pushed:t,incoming:o,formatUpgradeQueued:n=0,formatUpgradeContinuing:a=!1}=e,r=(l,m)=>`${l} ${m}${l===1?"":"s"}`,s=[];if(t>0&&s.push(`${r(t,"change")} saved to your Vault`),o.applied>0&&s.push(`${r(o.applied,"conversation")} added from your other devices`),o.deleted>0&&s.push(`${r(o.deleted,"conversation")} removed`),o.failed>0&&s.push(`${r(o.failed,"record")} couldn't be read`),n>0){const l=a?" The rest will continue in the background.":"";return`Preparing richer message formatting for ${r(n,"conversation")}.${l}`}if(s.length===0)return"Vault synced. Everything was already up to date.";const i=o.complete?"":" Still catching up, this will continue in the background.";return`Vault synced. ${s.join(", ")}.${i}`}async function Lg(){c("Syncing your Vault…");const e=D?.textContent??"";D&&(D.textContent="Syncing…",D.setAttribute("disabled","true"));try{const t=await chrome.runtime.sendMessage({type:"VAULT_SYNC_NOW"});if(!t){c("Vault did not return a sync result. Check the status above.");return}if(!t.ok){c(t.error);return}if("deduped"in t||!("result"in t)||!t.result?.incoming){await te(),c("A background Vault sync was already running. Check the status above.");return}await te(),c(Ag(t.result));const{applied:o,deleted:n}=t.result.incoming;(o>0||n>0)&&await Se()}catch(t){c(U(t))}finally{D&&(D.textContent=e||"Sync now",D.removeAttribute("disabled")),mo()}}let Go=null,To=!1;function Ig(){Go===null&&(Go=window.setInterval(async()=>{try{const e=await chrome.runtime.sendMessage({type:"VAULT_SYNC_STATUS"});if(!e.ok)return;e.syncing&&!To?(To=!0,cn=!0,uo(ar,sr),D&&!st&&(D.textContent="Syncing…",D.setAttribute("disabled","true"))):!e.syncing&&To&&(To=!1,cn=!1,uo(ar,sr),D&&!st&&(D.textContent="Sync now",D.removeAttribute("disabled")))}catch{}},2e3))}function Tg(){Go!==null&&(window.clearInterval(Go),Go=null,To=!1,cn=!1)}let st=!1,On=!1,jo=null;const is=45e3;function J(e,t,o){if($a){if($a.style.display=e==="hidden"?"none":"flex",e==="hidden"){Ie(null);return}sg?.setAttribute("data-state",e),Pi&&(Pi.textContent=t),D&&(D.style.display=o?"":"none",D.textContent=o??"",D.removeAttribute("disabled"))}}function Ie(e){if(!Kr||!_i)return;if(!e||e.total<=0){Kr.style.display="none";return}Kr.style.display="";const t=Math.max(0,Math.min(100,Math.round(e.done/e.total*100)));_i.style.width=`${t}%`}function Rg(e,t){const o="Sending your conversations…";return t&&t>0?`${o} ${e}/${t}`:o}async function dr(){if(!$a)return;let e;try{e=await chrome.runtime.sendMessage({type:"VAULT_UPLOAD_PROGRESS"})}catch{J("hidden","",null);return}if(!e.ok){J("hidden","",null);return}const t=e.progress;if(On&&st&&t?.phase!=="done"){J("running","Stopping after this batch…",null),Ie(t?.total?{done:t.queued,total:t.total}:null);return}if(!t){if(st){J("running","Sending your conversations…","Stop");return}if(rt===0){J("idle","Nothing here to send yet.",null),Ie(null),Qe();return}if(await as()){J("idle","Vault backup is set up. Check the latest sync time above.","Sync now"),Ie(null),Qe();return}J("idle","Not everything is backed up yet.","Sync to Vault"),Ie(null),Qe();return}if(t.phase==="done"){if(rt===null?t.total===0:rt===0){J("idle","Nothing here to send yet.",null),Ie(null),Qe();return}J("idle","Initial backup complete. Check the latest sync time above.","Sync now"),Ie(null),Qe();return}if(t.cancelled){J("idle",`Paused — ${t.queued} sent.`,"Resume"),Ie(t.total?{done:t.queued,total:t.total}:null),Qe();return}st||Date.now()-t.updatedAt<is?(J("running",Rg(t.queued,t.total),"Stop"),Ie(t.total?{done:t.queued,total:t.total}:null),vd()):(J("idle","Unfinished — continuing automatically.","Continue now"),Ie(t.total?{done:t.queued,total:t.total}:null),Qe())}function vd(){jo===null&&(jo=window.setInterval(()=>{dr()},3e3))}function Qe(){jo!==null&&(window.clearInterval(jo),jo=null)}async function Pg(){const e=D?.textContent??"";if(e==="Stop"){On=!0,J("running","Stopping after this batch…",null),await chrome.runtime.sendMessage({type:"VAULT_CANCEL_INITIAL_UPLOAD"}).catch(()=>{});return}if(e==="Sync now"){await Lg(),await dr();return}if(!st){st=!0,On=!1,J("running","Syncing your conversations to your Vault…","Stop"),vd();try{const t=await chrome.runtime.sendMessage({type:"VAULT_RUN_INITIAL_UPLOAD",resume:e==="Resume"||e==="Continue now"});t.ok||c(t.error)}catch(t){c(U(t))}finally{st=!1,On=!1,await te(),await dr()}}}let Tt=!1,Bn=!1,Ho=null;function X(e,t,o){if(dn){if(dn.style.display=e==="hidden"?"none":"flex",e==="hidden"){Ne(null);return}ig?.setAttribute("data-state",e),Ni&&(Ni.textContent=t),tt&&(tt.style.display=o?"":"none",tt.textContent=o??"",tt.removeAttribute("disabled"))}}function Ne(e){if(!Yr||!Mi)return;if(!e||e.total<=0){Yr.style.display="none";return}Yr.style.display="";const t=Math.max(0,Math.min(100,Math.round(e.done/e.total*100)));Mi.style.width=`${t}%`}const _g=5e3,ji=50;async function xd(){try{const e=await chrome.runtime.sendMessage({type:"VAULT_INCOMING_PROGRESS"});return e.ok&&e.progress!==null}catch{return!1}}function Ng(e,t,o){return`${o==="checking"?"Checking your Vault after reconnect":"Bringing your Vault here"}… ${e.toLocaleString()} of ${t.toLocaleString()}`}function Ro(e){if(Wr){if(!e||e.total<=0){Wr.style.display="none",En&&(En.style.display="none");return}if(Wr.style.display="flex",Jr){const t=Ng(e.done,e.total,e.mode),o=e.total>ji&&e.mode==="importing";Jr.textContent=o?`${t} This continues automatically in the background.`:t,Jr.title=e.total>ji?e.mode==="checking"?"Your local Vault is already current so far. This verification safely checks remote updates and deletions without importing duplicates.":"This looks like a first sync — a large Vault can take a while, sometimes an hour or more. It keeps going in the background, even if you close this page.":""}if(En&&Oi){En.style.display="";const t=Math.max(0,Math.min(100,Math.round(e.done/e.total*100)));Oi.style.width=`${t}%`}}}async function Mg(){mo();let e;try{e=await chrome.runtime.sendMessage({type:"VAULT_STATUS"})}catch{return}if(!e.ok||!e.status.unlocked)return;const t=e.status;if(t.entitled!==!0){await gd(t);return}or&&(or.textContent=t.email??"Account email unavailable"),uo(t.lastSyncedAt,t.lastSyncError)}async function wd(){if(ao||Tt){Ro(null);return}let e,t;try{[e,t]=await Promise.all([chrome.runtime.sendMessage({type:"VAULT_INCOMING_PROGRESS"}),chrome.runtime.sendMessage({type:"VAULT_RESTORE_PROGRESS"})])}catch{return}if(e.ok&&(Aa=Math.max(0,Math.floor(e.unappliable??0))),t.ok&&t.progress&&!t.progress.cancelled&&t.progress.phase!=="done"&&Date.now()-t.progress.updatedAt<is){Ro(null);return}if(!e.ok||!e.progress){Ro(null);return}const{remaining:n,total:a,mode:r}=e.progress;Ro({done:Math.max(0,a-n),total:a,mode:r}),await lr(`incoming:${n}`)}function Og(){Do===null&&(Do=window.setInterval(()=>{wd(),Mg()},_g))}function Bg(){Do!==null&&(window.clearInterval(Do),Do=null)}function Hi(e,t,o){const n=e===0?"Your Vault is already on this device.":`Restored ${e} ${e===1?"conversation":"conversations"} from your Vault.`;if(t===0)return n;const a=`${n} ${kd(t,o)}`,r=qg(o);return r?`${a} (${r})`:a}function kd(e,t){let o=null,n=0;for(const[r,s]of Object.entries(t))s>n&&(o=r,n=s);if(o===null&&e>0)return`${e} couldn't be read. Run Restore again to see why.`;const a=e!==1;switch(o){case"decrypt":return a?`${e} couldn't be unlocked. If that's most of your Vault, the passphrase on this device doesn't match the one it was saved with.`:"1 couldn't be unlocked.";case"empty":return a?`${e} had no messages saved, so there was nothing to bring back.`:"1 had no messages saved, so there was nothing to bring back.";case"write":return`${e} couldn't be saved to this device.`;case"unknown-kind":return a?`${e} were saved by a newer version and were left alone.`:"1 was saved by a newer version and was left alone.";case"parse":case"invalid":case null:return a?`${e} couldn't be read.`:"1 couldn't be read."}}function qg(e){const t=Object.entries(e).filter(([,o])=>o>0).sort((o,n)=>n[1]-o[1]).map(([o,n])=>`${o} ${n}`);return t.length>0?t.join(", "):""}async function ls(){if(!dn)return;let e;try{e=await chrome.runtime.sendMessage({type:"VAULT_RESTORE_PROGRESS"})}catch{X("hidden","",null);return}if(!e.ok){X("hidden","",null);return}const t=e.progress,o=t?.total?{done:t.restored+t.skipped+t.failed,total:t.total}:null;if(Bn&&Tt&&t?.phase!=="done"){X("running","Stopping after this batch…",null),Ne(o);return}if(!t){if(Tt){X("running","Fetching your Vault…","Stop");return}if(await xd()){X("hidden","",null),vt();return}if(await as()){X("idle",Hi(0,0,{}),"Restore again"),Ne(null),vt();return}X("idle","Nothing restored yet.","Restore"),Ne(null),vt();return}if(t.phase==="done"){X("idle",Hi(t.restored,t.failed,t.failures??{}),"Restore again"),Ne(null),vt(),await lr(`done:${t.restored}`);return}if(t.cancelled){X("idle",`Paused — ${t.restored} restored.`,"Resume"),Ne(o),vt();return}if(Tt||Date.now()-t.updatedAt<is){if(t.phase==="pull")X("running","Fetching your Vault…","Stop"),Ne(null);else{const a=t.restored+t.skipped+t.failed;X("running",t.total?`Restoring… ${a}/${t.total}`:"Restoring…","Stop"),Ne(o),await lr(`records:${Math.floor(t.restored/100)}`)}Sd()}else X("idle","Unfinished — continuing automatically.","Continue now"),Ne(o),vt()}function Sd(){Ho===null&&(Ho=window.setInterval(()=>{ls()},3e3))}function vt(){Ho!==null&&(window.clearInterval(Ho),Ho=null)}async function Vg(){const e=tt?.textContent??"";if(e==="Stop"){Bn=!0,X("running","Stopping after this batch…",null),await chrome.runtime.sendMessage({type:"VAULT_CANCEL_RESTORE"}).catch(()=>{});return}if(!Tt){Tt=!0,Bn=!1,X("running","Fetching your Vault…","Stop"),Sd();try{const t=await chrome.runtime.sendMessage({type:"VAULT_RUN_RESTORE",resume:e==="Resume"||e==="Continue now",restart:e==="Restore again"});t.ok||c(t.error)}catch(t){c(U(t))}finally{Tt=!1,Bn=!1,await te()}}}let ao=!1,qn=!1,Qt=null,Ko=null;function ye(e,t,o){if(Ea){if(Ea.style.display=e==="hidden"?"none":"flex",e==="hidden"){Yo(null);return}ag?.setAttribute("data-state",e),Ti&&(Ti.textContent=t),Jt&&(Jt.style.display=o?"":"none",Jt.textContent=o??"",Jt.removeAttribute("disabled"))}}function Yo(e){if(!Hr||!Ri)return;if(!e||e.total<=0){Hr.style.display="none";return}Hr.style.display="";const t=Math.max(0,Math.min(100,Math.round(e.done/e.total*100)));Ri.style.width=`${t}%`}async function Ug(){if(!Ea)return!1;if(ao)return!0;let e,t,o,n;try{[e,t,o,n]=await Promise.all([chrome.runtime.sendMessage({type:"VAULT_RESTORE_PROGRESS"}),chrome.runtime.sendMessage({type:"VAULT_UPLOAD_PROGRESS"}),xd(),as()])}catch{return ye("hidden","",null),!1}const a=e.ok&&e.progress===null,r=t.ok&&t.progress===null;return!a||!r||o||n?(ye("hidden","",null),!1):(ye("idle",rt===0?"Nothing on this device yet.":"This device isn't synced yet. Vault syncs on its own; this moves everything over right now.",rt===0?"Bring my Vault here":"Sync this device"),Yo(null),!0)}async function Cd(){await Ug()||(ye("hidden","",null),dr(),ls())}function zg(){Ko===null&&(Ko=window.setInterval(()=>{Fg()},3e3))}function Ed(){Ko!==null&&(window.clearInterval(Ko),Ko=null)}async function Fg(){if(!(!ao||qn)){if(Qt==="restore"){const e=await chrome.runtime.sendMessage({type:"VAULT_RESTORE_PROGRESS"}).catch(()=>null),t=e?.ok?e.progress:null;if(!t||t.phase==="pull"){ye("running","Fetching your Vault…","Stop"),Yo(null);return}const o=t.restored+t.skipped+t.failed;ye("running",t.total?`Bringing your Vault here… ${o}/${t.total}`:"Bringing your Vault here…","Stop"),Yo(t.total?{done:o,total:t.total}:null),await lr(`firstsync-restore:${Math.floor(t.restored/100)}`)}else if(Qt==="upload"){const e=await chrome.runtime.sendMessage({type:"VAULT_UPLOAD_PROGRESS"}).catch(()=>null),t=e?.ok?e.progress:null;if(!t)return;ye("running",t.total?`Sending your conversations… ${t.queued}/${t.total}`:"Sending your conversations…","Stop"),Yo(t.total?{done:t.queued,total:t.total}:null)}}}async function Dg(){for(;;){const e=await chrome.runtime.sendMessage({type:"VAULT_RUN_RESTORE"});if(!e.ok||e.result.complete||e.result.cancelled)return e}}async function Gg(){for(;;){const e=await chrome.runtime.sendMessage({type:"VAULT_RUN_INITIAL_UPLOAD"});if(!e.ok||e.result.complete||e.result.cancelled)return e}}async function jg(e){const[t,o]=await Promise.all([chrome.runtime.sendMessage({type:"VAULT_RESTORE_PROGRESS"}),e?chrome.runtime.sendMessage({type:"VAULT_UPLOAD_PROGRESS"}):Promise.resolve({ok:!0,progress:null})]),n=t.ok?t.progress?.restored??0:0,a=t.ok?t.progress?.failed??0:0,r=(t.ok?t.progress?.failures:void 0)??{},s=o.ok?o.progress?.queued??0:0;let i;return n>0&&s>0?i=`Brought ${n} down, sent ${s} up.`:n>0?i=`Brought ${n} ${n===1?"conversation":"conversations"} down.`:s>0?i=`Sent ${s} ${s===1?"conversation":"conversations"} up.`:i="Already up to date.",a===0?i:`${i} ${kd(a,r)}`}async function Hg(){if((Jt?.textContent??"")==="Stop"){qn=!0,ye("running","Stopping after this batch…",null);const t=Qt==="upload"?"VAULT_CANCEL_INITIAL_UPLOAD":"VAULT_CANCEL_RESTORE";await chrome.runtime.sendMessage({type:t}).catch(()=>{});return}if(!ao){ao=!0,qn=!1;try{Qt="restore",ye("running","Bringing your Vault here…","Stop"),zg();const t=await Dg();if(!t.ok){c(t.error);return}if(t.result.cancelled)return;const o=rt!==0;if(o){Qt="upload",ye("running","Sending your conversations…","Stop");const n=await Gg();if(!n.ok){c(n.error);return}if(n.result.cancelled)return}ye("idle",await jg(o),null)}catch(t){c(U(t))}finally{ao=!1,qn=!1,Qt=null,Ed(),await te(),await Se()}}}function ds(){if(!Nn)return;const e=Nn.style.display!=="none";Nn.style.display=e?"none":"",e&&(Uo&&(Uo.value=""),zo&&(zo.value=""),Fo&&(Fo.value=""),wr(Uo,zo,Fo))}async function Kg(){const e=M,t=G;if(!e){c(K("R06"));return}const o=Uo?.value??"",n=zo?.value??"",a=Fo?.value??"";if(!o){c("Enter your current passphrase.");return}if(n.length<8){c("New passphrase must be at least 8 characters.");return}if(n!==a){c("New passphrases don't match.");return}c("Changing passphrase…",!0),ka?.setAttribute("disabled","true");let r="C01";try{const s=await chrome.runtime.sendMessage({type:"VAULT_GET_WRAPPED_KEY"});if(!s.ok){c(lo(s.error,"C01"));return}if(!s.wrappedVaultKey){c(K("U08"));return}r="U06";const i=await pn(()=>import("./index.js"),__vite__mapDeps([0,1,2,3]));let l;try{l=await i.changePassphrase(s.wrappedVaultKey,o,n)}catch(y){c(pl(y));return}if(t!==G||e!==M){c(K("R06"));return}r="C02";const m=await chrome.runtime.sendMessage({type:"VAULT_UPDATE_WRAPPED_KEY",wrappedVaultKey:l,expectedUserId:e,expectedWrappedKeyId:JSON.stringify(s.wrappedVaultKey)});if(!m.ok){c(lo(m.error,"C02"));return}if(t!==G||e!==M){c(K("R13"));return}r="C03",ds(),c("Passphrase changed.")}catch{c(K(r))}finally{ka?.removeAttribute("disabled")}}Pn?.addEventListener("click",()=>{md()});No?.addEventListener("keydown",e=>{e.key==="Enter"&&md()});un?.addEventListener("click",()=>{yd()});He?.addEventListener("keydown",e=>{e.key==="Enter"&&yd()});fn?.addEventListener("click",()=>{vg()});cd?.addEventListener("click",xg);De?.addEventListener("input",()=>{er&&(er.textContent=cg(De?.value??""))});Ct?.addEventListener("click",()=>{wg()});Mo?.addEventListener("change",()=>{!xe||!Mo||(Mo.checked?(xe.removeAttribute("disabled"),xe.style.opacity="1"):(xe.setAttribute("disabled","true"),xe.style.opacity="0.5"))});Ut?.addEventListener("click",()=>{const e=ha?.textContent??"";navigator.clipboard.writeText(e).then(()=>{Ut&&(Ut.textContent="Copied ✓",setTimeout(()=>{Ut.textContent="Copy"},1500))}).catch(()=>{Ut&&(Ut.textContent="Press ⌘C to copy")})});xe?.addEventListener("click",()=>{kg()});va?.addEventListener("click",()=>{hd()});Wf?.addEventListener("click",()=>{Oo&&(Oo.style.display==="none"?Oo.style.display="":rr())});Bo?.addEventListener("click",()=>{if(!Lt||!Bo)return;const e=Lt.type==="text";Lt.type=e?"password":"text",Bo.textContent=e?"Show recovery key":"Hide recovery key"});xa?.addEventListener("click",()=>{Sg()});_n?.addEventListener("click",()=>{Cg()});at?.addEventListener("keydown",e=>{e.key==="Enter"&&hd()});pt(De,Hf,"passphrase");pt(St,Kf,"confirm passphrase");pt(at,Yf,"passphrase");pt(qo,Jf,"new passphrase");pt(Vo,Xf,"confirm new passphrase");pt(Uo,tg,"current passphrase");pt(zo,og,"new passphrase");pt(Fo,ng,"confirm new passphrase");Jt?.addEventListener("click",()=>{Hg()});D?.addEventListener("click",()=>{Pg()});tt?.addEventListener("click",()=>{Vg()});Qf?.addEventListener("click",()=>{$g()});ln?.addEventListener("click",()=>{Eg()});Zf?.addEventListener("click",ds);ka?.addEventListener("click",()=>{Kg()});eg?.addEventListener("click",()=>{bd()});{rg?.addEventListener("click",()=>{bd()}),Io?.addEventListener("click",()=>{yg()}),Te?.addEventListener("click",()=>{mg()}),Sa?.addEventListener("click",()=>Fi("annual")),Ca?.addEventListener("click",()=>Fi("monthly")),Mn?.addEventListener("click",()=>{zi()});const e=()=>{!Et||Et.style.display==="none"||zi()};window.addEventListener("focus",e),document.addEventListener("visibilitychange",()=>{document.visibilityState==="visible"&&e()})}te({forceEntitlement:!0});async function $d(){const e=za(Ya());if(!window.confirm(e.confirm)){kt(Fa);return}kt(lu),qe&&(qe.disabled=!0);try{let o;try{o=await chrome.runtime.sendMessage({type:"DELETE_ALL_DATA"})}catch(n){kt(`Delete failed: ${U(n)}`);return}if(!o.ok){kt(`Delete failed: ${o.error}`);return}kt(e.done),await Se(),await Sr()}finally{qe&&(qe.disabled=!1)}}async function Yg(e){const t=await chrome.runtime.sendMessage({type:"OPEN_FOUNDING_FORM",markCompleted:e});if(!t.ok)throw new Error(t.error)}async function Wg(){const e=await chrome.runtime.sendMessage({type:"DISMISS_FOUNDING_PROMPT"});if(!e.ok)throw new Error(e.error)}async function Jg(){if(no)try{const e=await chrome.storage.local.get(sa),t=Gl(e[sa]);no.value=String(t),Xn("Applies to both empty and typed searches. Lower limits usually feel faster because fewer results are rendered.")}catch(e){const t=e instanceof Error?e.message:"Unknown storage error";no.value=String(Rl),Xn(`Failed to load setting: ${t}`)}}async function Xg(e){try{await chrome.storage.local.set({[sa]:e}),Xn(`Saved: showing up to ${e} results per search.`)}catch(t){const o=t instanceof Error?t.message:"Unknown storage error";Xn(`Failed to save setting: ${o}`)}}let Z=[];const Wo=new Set,Jo=new Set;function Ad(){Z.sort((e,t)=>e.pinned!==t.pinned?e.pinned?-1:1:t.updatedAt-e.updatedAt)}function Ld(e){const t=Z.find(n=>n.docId===e),o=t?.localTitle?.trim()||t?.title?.trim();return o?`"${o}"`:"conversation"}async function Qg(e,t,o){if(e.length===0)return;let n=0;const a=Math.max(1,Math.min(e.length,t));await Promise.all(Array.from({length:a},async()=>{for(;;){const r=n;if(n+=1,r>=e.length)return;await o(e[r])}}))}async function Zg(e){const t=e.filter(o=>o.platform==="anthropic_console"&&(Pc(o.title)||ks(o.title)||ks(o.preview))||o.platform==="ai_studio"&&(Gc(o.title)||Ss(o.title)||Ss(o.preview)));await Qg(t,6,async o=>{try{const n=await Oc(o.docId);o.platform==="anthropic_console"?(o.title=Bc(n,o.title),o.preview=qc(n,o.preview)):o.platform==="ai_studio"&&(o.title=jc(n,o.title),o.preview=Hc(n,o.preview))}catch{}})}function em(e){const t=new Date(e.updatedAt).toLocaleString(),o=Wo.has(e.docId),n=Jo.has(e.docId),a=o||n,r=o?"Saving...":e.pinned?"Unstar":"Star",s=e.pinned?"#fff1d6":"#eaf3de",i=e.pinned?"#d9bb79":"#c2d0ad",l=k(e.localTitle||e.title||"Untitled"),m=k(ml(e.preview||"")),y=k(e.platform),d=k(e.docId);return`
    <div class="options-result-card">
      <div style="display: grid; grid-template-columns: minmax(0, 1fr) auto; align-items: flex-start; gap: 8px;">
        <div style="min-width: 0; overflow: hidden;">
          <div style="font-weight: 600; color: #153147; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">${l}</div>
          <div class="options-card-meta" style="margin-top: 2px; overflow-wrap: anywhere;">${y} &bull; ${e.indexLevel} &bull; ${e.messageCount} msgs &bull; ${t}</div>
          <div style="margin-top: 4px; color: #516776; font-size: 12px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">${m}</div>
        </div>
        <div style="display: grid; gap: 6px;">
          <button data-action="pin" data-doc-id="${d}" data-next-pin="${e.pinned?"false":"true"}" type="button" ${a?"disabled":""} style="padding: 6px 10px; border-radius: 8px; border: 1px solid ${i}; background: ${s}; cursor: ${a?"wait":"pointer"}; white-space: nowrap; opacity: ${a?"0.72":"1"};">${r}</button>
          <button data-action="remove" data-doc-id="${d}" type="button" ${a?"disabled":""} style="padding: 6px 10px; border-radius: 8px; border: 1px solid #d7b1b1; background: #fff4f4; color: #7a2626; cursor: ${a?"wait":"pointer"}; white-space: nowrap; opacity: ${a?"0.72":"1"};">${n?"Removing...":"Remove"}</button>
        </div>
      </div>
    </div>
  `}function tm(){const e=fr?.checked??!0,t=oo?.value?.trim().toLowerCase()??"";return!t&&!e?Z:Z.filter(o=>{if(e&&!o.pinned)return!1;if(!t)return!0;const n=`${o.localTitle??""}
${o.title||""}`.toLowerCase(),a=ml(o.preview||"").toLowerCase(),r=o.platform.toLowerCase();return n.includes(t)||a.includes(t)||r.includes(t)})}function om(){if(!nt)return;const e=Array.from(nt.querySelectorAll("button[data-action][data-doc-id]"));for(const t of e)t.addEventListener("click",()=>{const o=t.dataset.action,n=t.dataset.docId??"";if(n){if(o==="pin"){const a=t.dataset.nextPin==="true";nm(n,a);return}o==="remove"&&rm(n)}})}function je(){if(!nt)return;const e=tm();if(e.length===0){const t=fr?.checked??!0,n=!!oo?.value?.trim()?"No conversations match this filter.":t?"No starred conversations yet.":"No conversations found.";nt.innerHTML=`<div style='color:#4f6576;'>${n}</div>`;return}nt.innerHTML=e.map(em).join(""),om()}async function Sr(){if(nt){nt.textContent="Loading conversations...";try{const e=fr?.checked??!0;Z=(await Rc(250,{pinnedOnly:e})).filter(o=>!aa.has(o.platform)),await Zg(Z),Ad(),je();const t=Z.filter(o=>o.pinned).length;Ue(`Showing ${Z.length} recent docs. Starred: ${t}.`)}catch(e){const t=e instanceof Error?e.message:"Unknown error";nt.textContent=`Failed to load conversations: ${t}`}}}async function nm(e,t){if(Wo.has(e)||Jo.has(e))return;const o=Ld(e);Wo.add(e),je(),Ue(`${t?"Starring":"Unstarring"} ${o}...`);try{if(!await Nc(e,t)){Ue(`Failed to ${t?"star":"unstar"} ${o}: conversation not found.`);return}const a=Z.findIndex(s=>s.docId===e);a>=0&&(Z[a]={...Z[a],pinned:t}),Ad(),je();const r=Z.filter(s=>s.pinned).length;Ue(`${t?"Starred":"Unstarred"} ${o}. Starred: ${r}.`)}catch(n){const a=n instanceof Error?n.message:"Unknown error";Ue(`Failed to update star for ${o}: ${a}`)}finally{Wo.delete(e),je()}}async function rm(e){if(Wo.has(e)||Jo.has(e))return;const t=Ld(e);if(window.confirm(`Remove ${t} from local index?`)){Jo.add(e),je(),Ue(`Removing ${t}...`);try{if(!await Mc(e)){Ue(`${t} was already removed.`);return}Z=Z.filter(r=>r.docId!==e),je();const a=Z.filter(r=>r.pinned).length;Ue(`Removed ${t}. Starred: ${a}.`),await Se()}catch(n){const a=n instanceof Error?n.message:"Unknown error";Ue(`Failed to remove ${t}: ${a}`)}finally{Jo.delete(e),je()}}}let _=[];const Vn=new Set;let so=null;const Un=new Set;let _e=!1;function H(e){di&&(di.textContent=e)}function am(e){const t=k(e.memoryId),o="font-size: 11px; font-weight: 600; color: #5b6b54; text-transform: uppercase; letter-spacing: 0.03em;",n="width: 100%; box-sizing: border-box; padding: 8px 10px; border-radius: 8px; border: 1px solid #c6d0b0; background: #fff; font-family: inherit; font-size: 13px;";return`
    <div class="options-result-card" style="border-left-color: #9fb37e; background: #fcfdf7;">
      <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 10px;">
        <span style="font-size: 13px;">✎</span>
        <span style="font-weight: 600; color: #2f4419; font-size: 13px;">Editing memory</span>
      </div>
      <div style="display: grid; gap: 12px;">
        <label style="display: grid; gap: 4px;">
          <span style="${o}">Label</span>
          <input data-edit-field="label" data-memory-id="${t}" type="text" value="${k(e.label)}" placeholder="Short label (e.g. Code style)" style="${n}" />
        </label>
        <label style="display: grid; gap: 4px;">
          <span style="${o}">Memory</span>
          <textarea data-edit-field="text" data-memory-id="${t}" rows="5" placeholder="The memory itself, in your own words." style="${n} resize: vertical; line-height: 1.5;">${k(e.text)}</textarea>
        </label>
        <div style="display: flex; gap: 8px; align-items: center; justify-content: flex-end; border-top: 1px solid #e8eed9; padding-top: 10px;">
          <button data-action="cancel-edit-memory" data-memory-id="${t}" type="button" style="padding: 7px 14px; border-radius: 8px; border: 1px solid #c6d0b0; background: #fff; color: #4f6576; cursor: pointer; font-size: 13px;">Cancel</button>
          <button data-action="save-edit-memory" data-memory-id="${t}" type="button" style="padding: 7px 16px; border-radius: 8px; border: 1px solid #9fb37e; background: #eef4dd; color: #2f4419; cursor: pointer; font-weight: 600; font-size: 13px;">Save changes</button>
        </div>
      </div>
    </div>
  `}function Id(){return'<span class="agent-memory-badge" style="display: inline-flex; align-items: center; flex: 0 0 auto; padding: 2px 6px; border: 1px solid #b8c99a; border-radius: 999px; background: #f1f6e7; color: #486027; font-size: 10px; font-weight: 600; letter-spacing: 0.01em;">Assistant suggestion</span>'}function sm(e){if(e.memoryId===so)return am(e);const t=Un.has(e.memoryId),o=e.text.length>240,n=t||!o?k(e.text):k(e.text.slice(0,240))+"…",a=Vn.has(e.memoryId),r=a?"Removing...":"Delete",s=a?"disabled":"",i=k(e.memoryId),l=[];e.sourcePlatform&&rn[e.sourcePlatform]&&l.push(rn[e.sourcePlatform]),l.push(gp(e.text.length));const m=l.map(oe=>k(oe)).join(" &bull; "),y=e.enabled?e.pinned?"auto":"on":"off",d={off:"background: #e4e7e0 !important; color: #5a6b58 !important; font-weight: 600;",on:"background: #cfe6a3 !important; color: #33500f !important; font-weight: 600;",auto:"background: #bfe0ef !important; color: #12455f !important; font-weight: 600;"},v="border: 0 !important; padding: 4px 9px; font-size: 11px; line-height: 1.3; cursor: pointer; background: transparent !important; color: #93a07e !important;",b=(oe,ut,z)=>{const ho=y===oe,Ot=oe==="off"?"":"border-left: 1px solid #dbe2cf;";return`<button type="button" data-action="mem-state" data-memory-id="${i}" data-state="${oe}" title="${k(z)}" aria-pressed="${ho}" style="${v}${Ot}${ho?d[oe]:""}">${ut}</button>`},h='<div role="group" aria-label="Memory usage" style="display: inline-flex; border: 1px solid #c6d0b0; border-radius: 8px; overflow: hidden; background: #fff; flex: 0 0 auto;">'+b("off","Off","Off — never added to chats")+b("on","On","On — available to pick in the memory pill")+b("auto","Auto","Auto — added to every new chat automatically")+"</div>",w="width: 28px; height: 28px; display: inline-flex; align-items: center; justify-content: center; padding: 0; border-radius: 7px; border: 1px solid; cursor: pointer; font-size: 13px; line-height: 1;",A=!!e.sourceUrl&&(e.sourcePlatform?ap(e.sourcePlatform,e.sourceUrl):sp(e.sourceUrl))?`<button data-action="open-memory-source" data-memory-id="${i}" title="Open the conversation this came from" aria-label="Open source conversation" style="${w} border-color: #c6d0b0; background: #fff; color: #2f4654;">↗</button>`:"",I=t?"margin-top: 4px; color: #516776; font-size: 12px; line-height: 1.45; white-space: pre-wrap; overflow-wrap: anywhere;":"margin-top: 4px; color: #516776; font-size: 12px; overflow: hidden; text-overflow: ellipsis; max-height: 3.6em; line-height: 1.4;",S=o?`<span class="memory-view-hint" style="color: #93a07e; font-size: 11px;">${t?"Show less":"Show more"}</span>`:"",W=o?`Click to ${t?"collapse":"view"} · double-click to edit`:"Double-click to edit",Ce=o?`class="memory-card-body" data-action="view-memory" data-memory-id="${i}" title="${W}" style="min-width: 0; overflow: hidden; cursor: pointer;"`:`class="memory-card-body" data-memory-id="${i}" title="${W}" style="min-width: 0; overflow: hidden;"`;return`
    <div class="${o?"options-memory-card options-result-card":"options-result-card"}" style="opacity: ${e.enabled?"1":"0.55"};">
      <div style="display: grid; grid-template-columns: minmax(0, 1fr) auto; align-items: center; gap: 10px;">
        <div ${Ce}>
          <div style="display: flex; align-items: center; gap: 6px; min-width: 0;">
            <span style="font-weight: 600; color: #153147; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">${k(e.label)}</span>
            ${e.source==="agent"?Id():""}
          </div>
          <div class="options-card-meta" style="margin-top: 2px;">${m}${S?" &bull; "+S:""}</div>
          <div style="${I}">${n}</div>
        </div>
        <div style="display: flex; align-items: center; gap: 6px; flex: 0 0 auto;">
          ${h}
          ${A}
          <button data-action="edit-memory" data-memory-id="${i}" title="Edit memory" aria-label="Edit memory" style="${w} border-color: #c6d0b0; background: #fff; color: #2f4654;">✎</button>
          <button data-action="delete-memory" data-memory-id="${i}" title="${r} memory" aria-label="${r} memory" style="${w} border-color: #d7b1b1; background: #fff4f4; color: #7a2626;" ${s}>${a?"…":"🗑"}</button>
        </div>
      </div>
    </div>
  `}function im(e){const t=k(e.memoryId),o=e.text.length>240?`${k(e.text.slice(0,240))}…`:k(e.text);return`
    <div class="pending-memory-card options-result-card" style="border-left-color: #9fb37e; background: #fff;">
      <div style="display: grid; grid-template-columns: minmax(0, 1fr) auto; align-items: center; gap: 10px;">
        <div style="min-width: 0; overflow: hidden;">
          <div style="display: flex; align-items: center; gap: 6px; min-width: 0;">
            <span style="font-weight: 600; color: #153147; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">${k(e.label)}</span>
            ${Id()}
          </div>
          <div style="margin-top: 4px; color: #516776; font-size: 12px; line-height: 1.45; overflow-wrap: anywhere;">${o}</div>
        </div>
        <div style="display: flex; align-items: center; gap: 6px; flex-wrap: wrap; justify-content: flex-end;">
          <button data-action="reject-pending-memory" data-memory-id="${t}" type="button" ${_e?"disabled":""} style="padding: 7px 12px; border-radius: 8px; border: 1px solid #d7b1b1; background: #fff4f4; color: #7a2626; cursor: pointer; font-weight: 600; font-size: 12px;">Reject</button>
          <button data-action="enable-pending-memory" data-memory-id="${t}" type="button" ${_e?"disabled":""} style="padding: 7px 12px; border-radius: 8px; border: 1px solid #9fb37e; background: #eef4dd; color: #2f4419; cursor: pointer; font-weight: 600; font-size: 12px;">Enable</button>
        </div>
      </div>
    </div>
  `}function lm(){const e=Cl(_),t=Xl?.value?.trim().toLowerCase()??"";return t?e.filter(o=>o.label.toLowerCase().includes(t)||o.text.toLowerCase().includes(t)||o.kind.toLowerCase().includes(t)||(o.tags??[]).some(n=>n.toLowerCase().includes(t))):e}function cs(){if(!xn||!Ao)return;const e=Ga(_);if(Ao.hidden=e.length===0,Ao.disabled=_e,Ao.textContent=_e?"Enabling...":"Enable all",e.length===0){xn.innerHTML='<div style="color: #5f7066; padding: 2px 0; font-size: 12px;">No pending suggestions</div>';return}xn.innerHTML=e.map(im).join("");for(const t of Array.from(xn.querySelectorAll("button[data-action]")))t.addEventListener("click",()=>{const o=t.dataset.memoryId;o&&(t.dataset.action==="enable-pending-memory"?Ki(o,"accept"):t.dataset.action==="reject-pending-memory"&&Ki(o,"reject"))})}function dm(){const e=_.length===0;ci&&(ci.hidden=!e),Yt&&(Yt.hidden=e),pi&&(pi.hidden=e),_o&&(_o.style.display=e?"grid":"none"),Yt&&(Yt.textContent="+ Add memory")}function he(){if(dm(),cs(),!re)return;const e=lm();if(e.length===0){if(Cl(_).length>0){re.innerHTML='<div style="color: #4f6576; padding: 4px 2px;">No memories match your filter.</div>';return}if(_.length>0){re.innerHTML='<div style="color: #4f6576; padding: 4px 2px;">No other memories yet.</div>';return}re.innerHTML="";return}re.innerHTML=e.map(sm).join(""),pm()}async function cm(e){const t=_.find(o=>o.memoryId===e);if(t?.sourceUrl)try{await chrome.runtime.sendMessage({type:"OPEN_MEMORY_SOURCE",url:t.sourceUrl,selectedText:t.text,label:t.label,msgStartIndex:typeof t.sourceMsgStart=="number"?t.sourceMsgStart:-1})}catch(o){const n=o instanceof Error?o.message:"Unknown error";H(`Could not open the source conversation: ${n}`)}}function pm(){if(!re)return;const e=Array.from(re.querySelectorAll("button[data-action]"));for(const o of e)o.addEventListener("click",()=>{const n=o.dataset.memoryId;if(n)if(o.dataset.action==="delete-memory")hm(n);else if(o.dataset.action==="mem-state"){const a=o.dataset.state;a==="off"?Qr(n,{enabled:!1}):a==="on"?Qr(n,{enabled:!0,pinned:!1}):a==="auto"&&Qr(n,{enabled:!0,pinned:!0})}else o.dataset.action==="edit-memory"?(so=n,he()):o.dataset.action==="cancel-edit-memory"?(so=null,he()):o.dataset.action==="save-edit-memory"?mm(n):o.dataset.action==="open-memory-source"&&cm(n)});const t=Array.from(re.querySelectorAll(".memory-card-body"));for(const o of t){let n=null;o.addEventListener("click",()=>{const a=o.dataset.memoryId;if(a){if(n!==null){window.clearTimeout(n),n=null,so=a,he();return}n=window.setTimeout(()=>{n=null,o.dataset.action==="view-memory"&&(Un.has(a)?Un.delete(a):Un.add(a),he())},220)}})}}async function yo(){if(re){re.textContent="Loading memories...";try{_=await rl(),he();const e=_.filter(t=>t.pinned).length;H(`${_.length} memor${_.length===1?"y":"ies"}, ${e} on auto.`)}catch(e){const t=e instanceof Error?e.message:"Unknown error";re.textContent=`Failed to load memories: ${t}`}}}function Rt(e,t){chrome.runtime.sendMessage({type:e,memoryId:t}).catch(()=>{})}async function um(){const e=Ve?.value?.trim()??"";if(!e){H("Enter the memory text before adding."),Ve?.focus();return}const t=Date.now(),o=Mr?.value?.trim()??"",n={memoryId:crypto.randomUUID(),kind:"preference",label:(o||e).slice(0,48),text:e,source:"manual",pinned:Or?.checked??!1,enabled:!0,createdAt:t,updatedAt:t};try{await nl(n),Rt("QUEUE_MEMORY_PUT",n.memoryId),Ve&&(Ve.value=""),Mr&&(Mr.value=""),Or&&(Or.checked=!1),await yo(),Nt(),chrome.runtime.sendMessage({type:"TRACK_ACTIVATION_EVENT",event:"memory_created",source:"manual"}).catch(()=>{}),H("Memory added.")}catch(a){const r=a instanceof Error?a.message:"Unknown error";H(`Failed to add memory: ${r}`)}}function Xo(e){ui&&(ui.textContent=e)}async function fm(){const e=wn?.value?.trim()??"";if(!e){Xo("Paste the memory above first."),wn?.focus();return}const t=gr?.value||"generic",o=rn[t??"generic"]??"Other AI",n=Date.now();try{const a=(await rl()).filter(s=>s.source==="imported");for(const s of a)s.sourcePlatform!==t&&s.pinned&&(await zn(s.memoryId,{pinned:!1},s.updatedAt),Rt("QUEUE_MEMORY_PUT",s.memoryId));const r=a.find(s=>s.sourcePlatform===t);if(r)await zn(r.memoryId,{text:e,label:`${o} memory`,pinned:!0,enabled:!0}),Rt("QUEUE_MEMORY_PUT",r.memoryId);else{const s={memoryId:crypto.randomUUID(),kind:"profile",label:`${o} memory`,text:e,source:"imported",sourcePlatform:t,pinned:!0,enabled:!0,createdAt:n,updatedAt:n};await nl(s),Rt("QUEUE_MEMORY_PUT",s.memoryId)}wn&&(wn.value=""),await yo(),Nt(),chrome.runtime.sendMessage({type:"TRACK_ACTIVATION_EVENT",event:"memory_created",platformSource:t,source:"import"}).catch(()=>{}),Xo(`Saved your ${o} memory. It's pre-selected on new chats — switch in the picker anytime.`)}catch(a){const r=a instanceof Error?a.message:"Unknown error";Xo(`Failed to save: ${r}`)}}function Td(){const e=gr?.value||"generic",t=rn[e]??"the other AI";e==="claude"?(kn&&(kn.textContent="In Claude: Settings → Capabilities → Memory. Copy what it shows and paste it below — no prompt needed."),Lo&&(Lo.style.display="none")):(kn&&(kn.textContent=`Copy the export prompt, paste it into ${t}, then paste its full reply into the box below.`),Lo&&(Lo.style.display=""))}async function gm(){const e=gr?.value||"generic",t=rn[e]??"the other AI";try{await navigator.clipboard.writeText(fi),Xo(`Prompt copied. Paste it into ${t}, then paste its reply into the box above.`)}catch{Xo(`Couldn't copy automatically — here's the prompt:
`+fi)}}async function mm(e){if(!re)return;const t=re.querySelector(`input[data-edit-field="label"][data-memory-id="${CSS.escape(e)}"]`),o=re.querySelector(`textarea[data-edit-field="text"][data-memory-id="${CSS.escape(e)}"]`),n=o?.value?.trim()??"";if(!n){H("Memory text can't be empty."),o?.focus();return}const a=t?.value?.trim()||n.slice(0,48);try{const r=await zn(e,{label:a,text:n});r&&(Rt("QUEUE_MEMORY_PUT",e),_=_.map(s=>s.memoryId===e?r:s)),so=null,he(),Nt(),H("Memory updated.")}catch(r){const s=r instanceof Error?r.message:"Unknown error";H(`Failed to update memory: ${s}`)}}async function Rd(e,t){const o=await chrome.runtime.sendMessage({type:"TOGGLE_MEMORY",memoryId:e,enabled:t});if(!o?.ok||!o.memory)throw new Error(o?.error||"The memory could not be updated.");return o.memory}async function Ki(e,t){if(!_e){_e=!0,cs();try{const o=await chrome.runtime.sendMessage({type:"REVIEW_AGENT_MEMORY",memoryId:e,decision:t});if(!o?.ok||!o.memory)throw new Error(o?.error||"The suggestion could not be reviewed.");const n=o.memory;_=_.map(a=>a.memoryId===e?n:a),Nt(),H(t==="accept"?"Suggestion enabled.":"Suggestion rejected and removed.")}catch(o){const n=o instanceof Error?o.message:"Unknown error";H(`Could not ${t==="accept"?"enable":"reject"} the suggestion: ${n}`)}finally{_e=!1,he()}}}async function ym(){if(_e)return;const e=Ga(_).length;if(e!==0){_e=!0,cs(),H(`Enabling ${e} suggestion${e===1?"":"s"}...`);try{await uu(_,async(t,o)=>{await Rd(t,o)}),Nt(),H(`${e} suggestion${e===1?"":"s"} enabled.`)}catch(t){const o=t instanceof Error?t.message:"Unknown error";H(`Some suggestions could not be enabled: ${o}`)}finally{_e=!1,await yo()}}}async function Qr(e,t){try{const o=Object.keys(t),n=o.length===1&&typeof t.enabled=="boolean"?await Rd(e,t.enabled):await zn(e,t);if(n){o.length===1&&typeof t.enabled=="boolean"||Rt("QUEUE_MEMORY_PUT",e),_=_.map(r=>r.memoryId===e?n:r),he(),Nt();const a=_.filter(r=>r.pinned).length;H(`${_.length} memor${_.length===1?"y":"ies"}, ${a} on auto.`)}}catch(o){const n=o instanceof Error?o.message:"Unknown error";H(`Failed to update memory: ${n}`)}}async function hm(e){if(!Vn.has(e)){Vn.add(e),he(),H("Removing memory...");try{await _c(e),Rt("QUEUE_MEMORY_TOMBSTONE",e),_=_.filter(t=>t.memoryId!==e),he(),Nt(),H(`Memory removed. ${_.length} remaining.`)}catch(t){const o=t instanceof Error?t.message:"Unknown error";H(`Failed to remove memory: ${o}`)}finally{Vn.delete(e),he()}}}nf?.addEventListener("click",()=>{um()});for(const e of Array.from(document.querySelectorAll(".memory-example-chip")))e.addEventListener("click",()=>{Ve&&(Ve.value=e.dataset.example??"",Ve.focus(),Ve.select())});Yt?.addEventListener("click",()=>{if(!_o)return;const e=_o.style.display!=="none";_o.style.display=e?"none":"grid",Yt.textContent=e?"+ Add memory":"Cancel",e||Ve?.focus()});rf?.addEventListener("click",()=>{fm()});Lo?.addEventListener("click",()=>{gm()});gr?.addEventListener("change",()=>{Td()});Td();of?.addEventListener("click",()=>{yo()});Ao?.addEventListener("click",()=>{ym()});try{chrome.storage.onChanged.addListener((e,t)=>{t!=="local"||!e[np]||so===null&&yo()})}catch{}Xl?.addEventListener("input",()=>{he()});window.location.hash==="#memory-section"&&requestAnimationFrame(()=>{document.getElementById("memory-section")?.scrollIntoView({behavior:"smooth",block:"start"})});window.location.hash==="#import-chatgpt-export-section"&&requestAnimationFrame(()=>{const e=document.getElementById("import-chatgpt-export-section");if(e?.scrollIntoView({behavior:"smooth",block:"start"}),e){const t=e.style.boxShadow;e.style.transition="box-shadow 0.4s ease",e.style.boxShadow="0 0 0 3px #3d6fa8",window.setTimeout(()=>{e.style.boxShadow=t},1600)}});window.location.hash==="#corpus-native-card"&&requestAnimationFrame(()=>{const e=document.getElementById("corpus-native-card");if(e?.scrollIntoView({behavior:"smooth",block:"start"}),e){const t=e.style.boxShadow;e.style.transition="box-shadow 0.4s ease",e.style.boxShadow="0 0 0 3px #4f8a5b",window.setTimeout(()=>{e.style.boxShadow=t},1600)}});window.location.hash==="#local-sessions-card"&&requestAnimationFrame(()=>{const e=document.getElementById("local-sessions-card");if(e?.scrollIntoView({behavior:"smooth",block:"start"}),e){const t=e.style.boxShadow;e.style.transition="box-shadow 0.4s ease",e.style.boxShadow="0 0 0 3px #d97757",window.setTimeout(()=>{e.style.boxShadow=t},1600)}});let Zr=!1;ko?.addEventListener("click",()=>{Zr||!ko||(Zr=!0,ko.textContent="Refreshing…",Se().finally(()=>{Zr=!1,ko&&(ko.textContent="Refresh")}))});Eo?.addEventListener("click",()=>{Rf()});we?.addEventListener("click",()=>{wf()});chrome.permissions.onAdded.addListener(e=>{ul(e.origins)&&an()});chrome.permissions.onRemoved.addListener(e=>{ul(e.origins)&&an()});mt?.addEventListener("click",()=>{Af()});yt?.addEventListener("click",()=>{nd()});da?.addEventListener("keydown",e=>{e.key==="Enter"&&(e.preventDefault(),nd())});ht?.addEventListener("click",()=>{Lf()});bt?.addEventListener("click",()=>{If()});en?.addEventListener("click",()=>{Pf()});tn?.addEventListener("click",()=>{Tn?.click()});Tn?.addEventListener("change",()=>{const e=Tn.files?.[0];e&&(_f(e),Tn.value="")});on?.addEventListener("click",()=>{pa=!0,on.setAttribute("disabled","true"),ve("Stopping after the current conversation…")});ua?.addEventListener("click",()=>{Rn?.click()});Rn?.addEventListener("change",()=>{const e=Rn.files?.[0];e&&(Mf(e),Rn.value="")});nn?.addEventListener("click",()=>{$o=!0,nn.setAttribute("disabled","true"),ge("Stopping after the current chat…")});function Cr(e,t,o,n){e?.addEventListener("click",()=>{navigator.clipboard.writeText(t()).then(()=>{e.textContent="Copied ✓",n?.(),setTimeout(()=>{e.textContent=o},1500)}).catch(()=>{e.textContent="Press ⌘C to copy"})})}for(const e of Re){const t=ee[e];t.chooseBtn?.addEventListener("click",()=>{Uf(e)}),t.dirInput?.addEventListener("change",()=>{zf(e)}),t.rescanBtn?.addEventListener("click",()=>{Ff(e)}),t.forgetBtn?.addEventListener("click",()=>{Df(e)}),Cr(t.copyPathBtn,()=>ns(e),"Copy path")}Ze?.addEventListener("click",()=>{Gf()});Cr(Xu,()=>"brave://flags/#file-system-access-api","Copy address");Cr(Qu,()=>Wt,"Copy",()=>{ga=Date.now(),ad(!0)});jf();function bm(){!Yn||!qe||(Yn.style.display="block",qe.style.display="none",ot&&(ot.value="",ot.focus()),ps(!1))}function cr(){!Yn||!qe||(Yn.style.display="none",qe.style.display="",ot&&(ot.value=""),ps(!1))}function ps(e){Wn&&(Wn.disabled=!e)}qe?.addEventListener("click",bm);ot?.addEventListener("input",()=>{ps(pu(ot.value))});ot?.addEventListener("keydown",e=>{e.key==="Escape"?(cr(),kt(Fa)):e.key==="Enter"&&!Wn?.disabled&&(cr(),$d())});Wn?.addEventListener("click",()=>{cr(),$d()});Zu?.addEventListener("click",()=>{cr(),kt(Fa)});ef?.addEventListener("click",()=>{Sr()});oo?.addEventListener("input",()=>{je()});tf?.addEventListener("click",()=>{oo&&(oo.value="",oo.focus()),je()});fr?.addEventListener("change",()=>{Sr()});no?.addEventListener("change",()=>{const e=Gl(no.value);no.value=String(e),Xg(e)});af?.addEventListener("click",()=>{ts()});sf?.addEventListener("click",()=>{xf()});Cr(lf,()=>hp(de),"Copy logs");df?.addEventListener("click",()=>{vf()});cf?.addEventListener("click",()=>{Yg(!0).then(()=>td(!1)).catch(e=>et(`Failed to open Vault updates: ${U(e)}`))});pf?.addEventListener("click",()=>{Wg().then(()=>td(!1)).catch(e=>et(`Failed to dismiss Vault updates: ${U(e)}`))});Yu();go();Promise.all([bf(),Jg(),ts(),Se(),yr(),an(),yo()]).then(()=>Sr());{const e=document.querySelector("#organisation-section-body");if(e){const t=new URLSearchParams(window.location.search);ru(e,t.get("organise"),t.get("organiseScope"))}}const vm=document.querySelector("#corpus-sync-card"),us=document.querySelector("#corpus-connect"),fs=document.querySelector("#corpus-sync-now"),gs=document.querySelector("#corpus-full-sync"),ms=document.querySelector("#corpus-disconnect"),Yi=document.querySelector("#corpus-sync-status");function ce(e){Yi&&(Yi.textContent=e)}function Pd(){us?.style.setProperty("display","none"),fs?.style.setProperty("display","inline-block"),gs?.style.setProperty("display","inline-block"),ms?.style.setProperty("display","inline-block")}function xm(e){return e.upToDate?"MCP corpus sync is already up to date — nothing new to send.":`${e.full?"Full MCP corpus sync":"MCP corpus synced"}: wrote ${e.conversationCount} conversation(s) in ${e.chunkCount} file(s) to the corpus inbox. The companion will pick them up.`}async function _d(e,t){if(!await Au(e,{prompt:!0})){ce("Write permission denied — reconnect the folder.");return}ce(t?"Re-syncing the whole MCP corpus…":"Syncing the MCP corpus…");try{const o=await Lu(e,{full:t});ce(xm(o))}catch(o){ce(`MCP corpus sync failed: ${o instanceof Error?o.message:String(o)}`)}}async function wm(){if(!Al()){ce("This browser doesn't support the folder picker needed for corpus sync.");return}ce("Opening folder picker…");let e;try{e=await $u()}catch(t){t instanceof Il?ce("No folder chosen."):ce(`Couldn't open the folder picker: ${t instanceof Error?t.message:String(t)}`);return}Pd(),await _d(e,!0)}async function Nd(e){const t=await Ll();if(!t){ce("No folder connected — connect one first.");return}await _d(t,e)}async function km(){await Eu(),us?.style.setProperty("display","inline-block"),fs?.style.setProperty("display","none"),gs?.style.setProperty("display","none"),ms?.style.setProperty("display","none"),ce("Disconnected. The corpus files already written remain on disk; the companion keeps them.")}async function Sm(){if(!vm)return;if(!Al()){ce("This browser doesn't support the folder picker needed for corpus sync.");return}if(!await Ll()){ce("Not connected.");return}Pd(),ce("Connected. Click Sync now to push new conversations to the companion.")}us?.addEventListener("click",()=>{wm()});fs?.addEventListener("click",()=>{Nd(!1)});gs?.addEventListener("click",()=>{Nd(!0)});ms?.addEventListener("click",()=>{km()});Sm();const Cm=document.querySelector("#corpus-native-card"),Qo=document.querySelector("#corpus-native-enable"),An=document.querySelector("#corpus-native-manual"),Em=document.querySelector("#corpus-native-sync-now"),$m=document.querySelector("#corpus-native-full-sync"),Wi=document.querySelector("#corpus-native-status"),Ji=document.querySelector("#corpus-native-lastsync"),Am=document.querySelector("#corpus-native-install"),Lm=document.querySelector("#corpus-native-install-steps"),Xi=document.querySelector("#corpus-native-install-cmd"),Zo=document.querySelector("#corpus-native-copy-install"),Im=document.querySelector("#corpus-native-permission-state"),Md=document.querySelector("#corpus-native-connector-state"),Qi=document.querySelector("#corpus-native-install-copy-text"),Tm=document.querySelector("#corpus-native-node-help"),Rm=document.querySelector("#corpus-native-finish"),Pm=document.querySelector("#corpus-native-details"),ea=document.querySelector("#corpus-native-location");function Q(e){Wi&&(Wi.textContent=e)}function _m(e){if(!e)return"No history has been added yet.";const t=ur(e.at);return e.ok?`Last updated ${t}.`:`Last update (${t}) didn’t finish: ${Ua(e.error)}`}function Ra(e){Ji&&(Ji.textContent=_m(e))}function Po(e,t=!1,o=!1){Am?.style.setProperty("display","block"),Lm?.style.setProperty("display","block"),Qo?.style.setProperty("display",t?"none":"inline-block"),Im?.style.setProperty("display",t?"inline":"none"),Md?.style.setProperty("display",o?"inline":"none"),Tm?.style.setProperty("display",o?"none":"block"),Rm?.style.setProperty("display",o?"flex":"none"),Zo&&(Zo.textContent=o?"Copy repair command":"Copy install command"),Qi&&(Qi.textContent=o?"The desktop connector is installed. Run the command again only if you need to repair it or connect another supported desktop AI app.":`Next: ${Hl}`),t&&Xi&&(Xi.textContent=Wa)}function Ln(e){Pm?.style.setProperty("display",e?"":"none"),ea&&(ea.style.display=e?"":"none",ea.textContent=e?`Stored locally at ${e}`:"")}async function Od(){const e=await chrome.runtime.sendMessage({type:"GET_CORPUS_NATIVE_STATUS"});return e.ok?(Wl=e.corpus.present,Zl(),Ra(e.lastSync),e.hostSupported?e.corpus.present?(An?.style.setProperty("display","inline"),Po(!0,!0,!0),Ln(e.corpus.root??null),Q("Ready. Your LLMnesia history stays up to date automatically."),e):e.permissionGranted?(Q("The connector isn’t available yet. Run Step 1, then fully quit and reopen your browser."),An?.style.setProperty("display","none"),Ln(null),Po(!0,!0),e):(Q("Setup isn’t finished. Install the connector, restart your browser, then enable automatic sync."),An?.style.setProperty("display","none"),Ln(null),Po(!0,!1),e):(Q(e.permissionGranted?"The connector isn’t available yet. Run Step 1, then fully quit and reopen your browser.":"Setup isn’t finished. Install the connector, restart your browser, then enable automatic sync."),An?.style.setProperty("display","none"),Ln(null),Po(!0,e.permissionGranted,!1),e)):(Q(`Couldn't check status: ${Ua(e.error)}`),e)}const Nm=3e3;let io=null,Pa=!1;function Zi(){io!==null&&(window.clearTimeout(io),io=null)}function Bd(){io!==null||Pa||(io=window.setTimeout(()=>{io=null,Mm()},Nm))}async function Mm(){const e=await Od();if(!e.ok||!e.permissionGranted){Zi();return}if(!e.corpus.present){Bd();return}Pa=!0,Zi();try{Q("Desktop connector found. Adding your existing history…"),await Er(!0)}finally{Pa=!1}}async function Om(){Q("Connecting this browser…"),Qo?.setAttribute("disabled","true");let e;try{e=await chrome.permissions.request({permissions:["nativeMessaging"]})}catch(t){Q(`Permission request failed: ${t instanceof Error?t.message:String(t)}`),Qo?.removeAttribute("disabled");return}if(!e){Q("Permission wasn’t granted. Allow it when you’re ready to connect this browser."),Qo?.removeAttribute("disabled");return}Q("Finishing setup. Settings will reopen in a moment…");try{await chrome.storage.local.set({[rp]:Date.now()})}catch{}chrome.runtime.reload()}async function Er(e){Q(e?"Rebuilding your local history…":"Updating your local history…");const t=await chrome.runtime.sendMessage({type:"CORPUS_NATIVE_SYNC",full:e});if(!t.ok){const o=Ua(t.error);Q(`Couldn’t update your local history: ${o}`),Ra({at:Date.now(),ok:!1,error:o});return}Q(t.report.upToDate?"Ready. Your local history is already up to date.":"Ready. Your local history is up to date."),Ra({at:Date.now(),ok:!0,report:t.report})}Qo?.addEventListener("click",()=>{Om()});Zo?.addEventListener("click",()=>{navigator.clipboard.writeText(Wa).then(()=>{Zo.textContent="Copied",window.setTimeout(()=>{const e=Md?.style.display==="inline";Zo.textContent=e?"Copy repair command":"Copy install command"},1800)},()=>{Q("Couldn’t copy the command. Select the command shown above and copy it manually.")})});Em?.addEventListener("click",()=>{Er(!1)});$m?.addEventListener("click",()=>{Er(!0)});async function Bm(){try{await chrome.permissions.contains({permissions:["nativeMessaging"]})&&Po(!0,!0,!1)}catch{}const e=await Od();if(!(!e.ok||!e.permissionGranted)){if(!e.corpus.present){Bd();return}(!e.lastSync||!e.lastSync.ok)&&(Q("Desktop connector found. Adding your existing history…"),await Er(!0))}}Cm&&Bm();
//# sourceMappingURL=options.js.map
