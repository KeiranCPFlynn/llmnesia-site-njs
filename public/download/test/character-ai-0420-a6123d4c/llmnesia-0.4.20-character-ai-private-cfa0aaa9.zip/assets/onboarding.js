import"./modulepreload-polyfill.js";import{i as ue,T as e}from"./theme.js";import{i as xe,r as he}from"./google_ai_mode_access.js";import{n as fe,i as ge,O as be}from"./outreach.js";import{g as ye}from"./public_storage_copy.js";import"./error_logging.js";import"./backfill_tab.js";import"./backfill.js";import"./google_ai_mode_page.js";ue("onboarding_page","onboarding");const j=new URLSearchParams(window.location.search),ve=j.get("mode"),f=ve==="reprompt",z=j.get("source")??void 0,O=ye(),W=document.querySelector("#app");if(!W)throw new Error("Onboarding app root not found");W.innerHTML=`
  <style>
    :root {
      color-scheme: light;
    }
    * {
      box-sizing: border-box;
    }
    body {
      margin: 0;
      min-height: 100vh;
      background: linear-gradient(180deg, ${e.tealSoft} 0, ${e.paper} 340px);
      color: ${e.ink};
      font: 17px/1.55 "IBM Plex Sans", "Segoe UI", sans-serif;
    }
    .wrap {
      max-width: 900px;
      margin: 0 auto;
      padding: 38px 18px 64px;
    }
    .card {
      border: 1px solid ${e.rule};
      border-radius: 20px;
      background: ${e.card};
      box-shadow:
        0 20px 50px rgba(17, 34, 47, 0.10),
        inset 0 1px 0 rgba(255, 255, 255, 0.72);
      overflow: hidden;
    }
    .hero {
      padding: 38px 40px 34px;
      border-bottom: 1px solid ${e.rule};
      background:
        radial-gradient(circle at 92% 12%, rgba(47, 127, 153, 0.12), transparent 32%),
        linear-gradient(180deg, ${e.card} 0%, ${e.tealSoft} 100%);
    }
    .brand {
      display: inline-flex;
      align-items: center;
      gap: 10px;
      margin-bottom: 14px;
    }
    .brand img {
      width: 30px;
      height: 30px;
    }
    .brand-name {
      font-size: 13px;
      letter-spacing: 0;
      text-transform: uppercase;
      color: ${e.ink3};
      font-family: "IBM Plex Mono", "SF Mono", "Consolas", monospace;
      font-weight: 700;
    }
    h1 {
      margin: 0;
      max-width: 660px;
      font-size: clamp(34px, 5vw, 48px);
      line-height: 1.08;
      letter-spacing: -0.01em;
      color: #11273a;
    }
    .lead {
      margin: 14px 0 0;
      color: ${e.ink2};
      max-width: 56ch;
      font-size: 19px;
      line-height: 1.55;
    }
    .section {
      padding: 32px 40px;
      border-bottom: 1px solid ${e.ruleSoft};
    }
    .section:last-of-type {
      border-bottom: 0;
    }
    h2 {
      margin: 0;
      font-size: 26px;
      color: #11273a;
    }
    .section-kicker {
      display: block;
      margin-bottom: 5px;
      color: ${e.teal};
      font: 700 13px/1.3 "IBM Plex Mono", "SF Mono", "Consolas", monospace;
      letter-spacing: 0.06em;
      text-transform: uppercase;
    }
    .section-intro {
      margin: 9px 0 0;
      color: ${e.ink2};
      max-width: 58ch;
      font-size: 17px;
      line-height: 1.55;
    }
    .shortcut-key {
      color: ${e.ink3};
      font-size: 14px;
      font-weight: 600;
      font-family: "IBM Plex Mono", "SF Mono", "Consolas", monospace;
      background: ${e.paperSoft};
      border: 1px solid ${e.ruleSoft};
      border-bottom-width: 2px;
      border-radius: 3px;
      padding: 1px 4px;
    }
    .capture-copy {
      margin: 8px 0 0;
      color: ${e.ink2};
      max-width: 62ch;
      font-size: 16px;
    }
    .capture-section {
      background: linear-gradient(135deg, ${e.tealSoft} 0%, ${e.card} 72%);
      box-shadow: inset 4px 0 0 ${e.teal};
    }
    .capture-benefits {
      margin: 14px 0 0;
      padding: 0;
      display: flex;
      flex-wrap: wrap;
      gap: 8px;
      list-style: none;
    }
    .capture-benefits li {
      padding: 5px 9px;
      border: 1px solid ${e.ruleSoft};
      border-radius: ${e.rPill};
      background: rgba(255, 255, 255, 0.72);
      color: ${e.ink2};
      font-size: 13px;
      font-weight: 600;
    }
    .capture-consent {
      margin: 8px 0 0;
      color: ${e.ink3};
      font-size: 12px;
      line-height: 1.45;
    }
    .import-row {
      margin-top: 20px;
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr));
      gap: 12px;
    }
    .import-row button {
      min-height: 54px;
      padding: 13px 16px;
      border-color: ${e.ruleSoft};
      color: ${e.ink};
      font-size: 16px;
      font-weight: 600;
      text-align: left;
      border-radius: 10px;
      box-shadow: 0 2px 8px rgba(17, 34, 47, 0.05);
    }
    .import-row button::before {
      content: "";
      display: inline-block;
      width: 9px;
      height: 9px;
      margin-right: 10px;
      border-radius: 999px;
      background: ${e.teal};
      vertical-align: 1px;
    }
    .import-row button:hover:not(:disabled) {
      border-color: ${e.tealEdge};
      background: ${e.tealSoft};
      transform: translateY(-1px);
    }
    .import-row button:focus-visible,
    button:focus-visible,
    input:focus-visible {
      outline: 3px solid rgba(47, 127, 153, 0.22);
      outline-offset: 2px;
    }
    .checklist {
      list-style: none;
      margin: 24px 0 0;
      padding: 0;
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr));
      gap: 12px;
    }
    .step {
      display: flex;
      align-items: flex-start;
      gap: 12px;
      background: ${e.paperSoft};
      border: 1px solid ${e.ruleSoft};
      border-radius: 12px;
      padding: 18px;
    }
    .step--block {
      align-items: flex-start;
    }
    .step-body {
      flex: 1;
      display: flex;
      flex-direction: column;
      gap: 10px;
    }
    .step-body .import-row,
    .step-body .cta-row {
      margin-top: 0;
    }
    .step-num {
      flex: 0 0 28px;
      width: 28px;
      height: 28px;
      border-radius: ${e.rPill};
      border: 1px solid ${e.ruleSoft};
      background: ${e.paperSoft};
      color: ${e.ink2};
      font-family: "IBM Plex Mono", "SF Mono", "Consolas", monospace;
      font-size: 13px;
      font-weight: 700;
      display: inline-flex;
      align-items: center;
      justify-content: center;
    }
    .step-text {
      color: ${e.ink2};
      font-size: 16px;
      line-height: 1.5;
    }
    .step-text strong {
      color: ${e.ink};
    }
    .step--done {
      border-color: rgba(47, 127, 153, 0.35);
    }
    .step--done .step-num {
      border-color: ${e.teal};
      background: ${e.teal};
      color: #fff;
    }
    .index-count {
      display: none;
      font-family: "IBM Plex Mono", "SF Mono", "Consolas", monospace;
      font-size: 14px;
      color: ${e.ink3};
    }
    .index-count[data-visible="true"] {
      display: block;
    }
    .index-count strong {
      color: ${e.teal};
    }
    .cta-row {
      margin-top: 2px;
      display: flex;
      align-items: center;
      gap: 14px;
      flex-wrap: wrap;
    }
    .cta-row button.primary {
      padding: 12px 20px;
      font-weight: 700;
    }
    .cta-hint {
      color: ${e.ink3};
      font: 14px/1.5 "IBM Plex Sans", "Segoe UI", sans-serif;
      letter-spacing: 0;
    }
    .privacy-note {
      margin: 18px 0 0;
      color: ${e.ink3};
      font: 14px/1.5 "IBM Plex Sans", "Segoe UI", sans-serif;
      letter-spacing: 0;
    }
    .import-panel {
      margin-top: 24px;
      padding: 20px;
      border: 1px solid ${e.ruleSoft};
      border-radius: ${e.rMd};
      background: ${e.card};
      box-shadow: 0 8px 24px rgba(17, 34, 47, 0.05);
    }
    .import-panel.step--done {
      border-color: rgba(47, 127, 153, 0.35);
      box-shadow: 0 0 0 3px rgba(47, 127, 153, 0.06);
    }
    .import-panel .import-row {
      margin-top: 0;
    }
    .import-panel .cta-hint[role="status"] {
      margin: 16px 0 0;
      padding: 12px 14px;
      border-radius: 9px;
      background: ${e.tealSoft};
      color: ${e.ink2};
    }
    .before-start {
      display: flex;
      align-items: flex-start;
      gap: 12px;
      padding: 14px 16px;
      border: 1px solid rgba(47, 127, 153, 0.18);
      border-radius: 10px;
      background: ${e.tealSoft};
      color: ${e.ink2};
      font-size: 15px;
      line-height: 1.5;
    }
    .before-start-icon {
      display: inline-grid;
      place-items: center;
      flex: 0 0 24px;
      width: 24px;
      height: 24px;
      border-radius: 999px;
      background: ${e.teal};
      color: #fff;
      font-weight: 700;
      font-size: 14px;
    }
    .before-start strong {
      display: block;
      margin-bottom: 2px;
      color: ${e.ink};
    }
    .before-start + .import-row {
      margin-top: 18px;
    }
    .more-imports {
      margin-top: 14px;
    }
    .more-imports summary {
      display: inline-flex;
      align-items: center;
      gap: 7px;
      color: ${e.teal};
      font-size: 15px;
      font-weight: 600;
      cursor: pointer;
    }
    .more-imports summary::before {
      content: "+";
      display: inline-grid;
      place-items: center;
      width: 20px;
      height: 20px;
      border: 1px solid ${e.tealEdge};
      border-radius: 999px;
      font-size: 15px;
      line-height: 1;
    }
    .more-imports[open] summary::before {
      content: "−";
    }
    .more-imports .import-row {
      margin-top: 14px;
    }
    .row {
      margin-top: 12px;
      display: flex;
      gap: 10px;
      flex-wrap: wrap;
      align-items: center;
    }
    input[type="email"] {
      flex: 1 1 320px;
      min-width: 220px;
      border: 1px solid ${e.rule};
      border-radius: ${e.rSm};
      background: ${e.card};
      color: ${e.ink};
      padding: 10px 12px;
      font: inherit;
      outline: none;
    }
    input[type="email"]:focus {
      border-color: ${e.tealEdge};
      box-shadow: 0 0 0 2px rgba(47, 127, 153, 0.14);
    }
    button {
      appearance: none;
      border: 1px solid ${e.rule};
      background: ${e.card};
      color: ${e.ink2};
      border-radius: ${e.rSm};
      padding: 10px 14px;
      font: inherit;
      cursor: pointer;
    }
    button.primary {
      border-color: ${e.teal};
      background: ${e.teal};
      color: #fff;
      font-weight: 700;
    }
    button:disabled {
      opacity: 0.6;
      cursor: default;
    }
    .skip-link {
      margin-top: 10px;
      color: ${e.teal};
      text-decoration: underline;
      text-underline-offset: 2px;
      cursor: pointer;
      display: inline-flex;
      background: none;
      border: 0;
      padding: 0;
      font: inherit;
    }
    .error {
      min-height: 20px;
      margin-top: 8px;
      color: #8d2f2f;
      font-size: 14px;
    }
    .complete {
      display: none;
      border-top: 1px solid ${e.ruleSoft};
      padding: 18px 24px 22px;
      background: ${e.paper};
    }
    .complete[data-visible="true"] {
      display: block;
    }
    .complete p {
      margin: 0 0 12px;
      color: ${e.ink2};
    }
    .complete-note {
      margin-top: 8px;
      color: ${e.ink3};
      font: 12px/1.45 "IBM Plex Mono", "SF Mono", "Consolas", monospace;
      letter-spacing: 0;
      min-height: 18px;
    }
    /* ---- Memory demo: a looping, self-running "fake UI" of the one-tap pill ---- */
    .memory-lead {
      margin: 8px 0 0;
      color: ${e.ink2};
      max-width: 56ch;
      font-size: 16px;
    }
    .memory-note {
      margin: 12px 0 0;
      color: ${e.ink3};
      font: 15px/1.55 "IBM Plex Sans", "Segoe UI", sans-serif;
      max-width: 62ch;
    }
    .memory-cta {
      margin-top: 16px;
      display: flex;
      gap: 12px;
      flex-wrap: wrap;
      align-items: center;
    }
    .memory-cta button.primary { padding: 12px 18px; font-weight: 700; }
    .demo {
      margin: 18px 0 2px;
      display: flex;
      justify-content: center;
    }
    .demo-screen {
      width: 100%;
      max-width: 460px;
      border: 1px solid ${e.rule};
      border-radius: ${e.rMd};
      background: ${e.paperSoft};
      box-shadow: 0 12px 30px rgba(17, 34, 47, 0.10), inset 0 1px 0 rgba(255,255,255,0.7);
      overflow: hidden;
    }
    .demo-bar {
      display: flex;
      align-items: center;
      gap: 6px;
      padding: 8px 12px;
      border-bottom: 1px solid ${e.ruleSoft};
      background: ${e.card};
    }
    .demo-bar .d { width: 8px; height: 8px; border-radius: 999px; background: ${e.rule}; }
    .demo-url {
      margin-left: 8px;
      font: 600 10px/1 "IBM Plex Mono", "SF Mono", monospace;
      color: ${e.ink3};
      letter-spacing: 0.03em;
      text-transform: uppercase;
    }
    .demo-body {
      position: relative;
      height: 150px;
      padding: 14px;
      display: flex;
      flex-direction: column;
      /* Composer sits toward the top so the absolutely-positioned memory pill
         cluster below it reads as "pill under the input box" — matching the real
         app, where the pill lives beneath the composer, not above it. */
      justify-content: flex-start;
    }
    .demo-composer {
      position: relative;
      min-height: 56px;
      border: 1px solid ${e.rule};
      border-radius: ${e.rSm};
      background: ${e.card};
      padding: 10px 12px;
      overflow: hidden;
    }
    .demo-placeholder {
      color: ${e.ink3};
      font: 13px/1.4 "IBM Plex Sans", "Segoe UI", sans-serif;
      opacity: 0;
      animation: demoPlaceholder 9s ease-in-out infinite;
    }
    .demo-typed {
      position: absolute;
      inset: 10px 12px auto 12px;
      display: flex;
      flex-direction: column;
      gap: 3px;
    }
    .demo-line {
      height: 8px;
      border-radius: 4px;
      background: linear-gradient(90deg, ${e.tealEdge}, ${e.tealSoft});
      opacity: 0;
      transform: translateY(4px);
    }
    .demo-line.l0 { width: 86%; background: ${e.teal}; height: 7px; opacity: 0; animation: demoLine 9s ease-in-out infinite; animation-delay: 0s; }
    .demo-line.l1 { width: 70%; animation: demoLine 9s ease-in-out infinite; animation-delay: 0.18s; }
    .demo-line.l2 { width: 78%; animation: demoLine 9s ease-in-out infinite; animation-delay: 0.36s; }
    .demo-line.l3 { width: 54%; animation: demoLine 9s ease-in-out infinite; animation-delay: 0.54s; }
    /* Stage A — the quiet collapsed chip you first meet on a new chat: a faint
       dot + "Memory" label in mono, ~0.72 opacity, no card. Mirrors the real
       collapsed memory pill (.pill.collapsed .face). */
    .demo-chip {
      position: absolute;
      left: 50%;
      bottom: 20px;
      transform: translateX(-50%) translateY(6px);
      display: inline-flex;
      align-items: center;
      gap: 6px;
      padding: 4px 9px 4px 7px;
      border-radius: 999px;
      color: ${e.ink2};
      font: 500 11px/1 "IBM Plex Mono", "SF Mono", "Consolas", monospace;
      letter-spacing: 0.02em;
      opacity: 0;
      animation: demoChip 9s ease-in-out infinite;
    }
    .demo-chip .cdot {
      width: 6px;
      height: 6px;
      border-radius: 999px;
      background: ${e.teal};
      animation: demoDot 9s ease-in-out infinite;
    }
    /* Stage B — the chip expanded after a tap: a small card carrying the
       "Memory ▾" chooser and the teal "Add memories" button. Mirrors the
       real expanded pill (.opener + .add). */
    .demo-card {
      position: absolute;
      left: 50%;
      bottom: 16px;
      transform: translateX(-50%) translateY(4px) scale(0.98);
      display: inline-flex;
      align-items: center;
      gap: 6px;
      padding: 3px;
      border-radius: ${e.rSm};
      background: ${e.card};
      border: 1px solid ${e.ruleSoft};
      box-shadow: 0 4px 12px rgba(17, 34, 47, 0.10), inset 0 1px 0 rgba(255, 255, 255, 0.72);
      font: 600 11px/1 "IBM Plex Mono", "SF Mono", "Consolas", monospace;
      opacity: 0;
      animation: demoCard 9s ease-in-out infinite;
    }
    .demo-card .card-opener {
      display: inline-flex;
      align-items: center;
      gap: 5px;
      padding: 5px 7px 5px 9px;
      border: 1px solid ${e.ruleSoft};
      border-radius: ${e.rSm};
      background: ${e.card};
      color: ${e.ink2};
    }
    .demo-card .card-chev {
      display: grid;
      place-items: center;
      width: 14px;
      height: 14px;
      border-radius: 4px;
      background: ${e.paperSoft};
      color: ${e.ink2};
      font-size: 9px;
    }
    .demo-card .card-add {
      padding: 5px 10px;
      border-radius: ${e.rSm};
      background: ${e.teal};
      border: 1px solid ${e.teal};
      color: #fff;
      animation: demoAddPress 9s ease-in-out infinite;
    }
    .demo-cursor {
      position: absolute;
      left: 50%;
      bottom: 16px;
      width: 16px;
      height: 16px;
      margin: -2px 0 0 -2px;
      pointer-events: none;
      -webkit-mask: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24'%3E%3Cpath d='M5 3l14 8-6 1 3 6-2 1-3-6-4 4z'/%3E%3C/svg%3E") center/contain no-repeat;
      mask: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24'%3E%3Cpath d='M5 3l14 8-6 1 3 6-2 1-3-6-4 4z'/%3E%3C/svg%3E") center/contain no-repeat;
      background-color: ${e.ink};
      opacity: 0;
      animation: demoCursor 9s ease-in-out infinite;
    }
    .demo-ripple {
      position: absolute;
      width: 10px;
      height: 10px;
      border-radius: 999px;
      border: 2px solid ${e.teal};
      opacity: 0;
    }
    /* r1 lands on the chip, r2 on the "Add memories" button after the card opens. */
    .demo-ripple.r1 { left: 50%; bottom: 26px; margin-left: -5px; animation: demoRipple1 9s ease-in-out infinite; }
    .demo-ripple.r2 { left: calc(50% + 44px); bottom: 24px; margin-left: -5px; animation: demoRipple2 9s ease-in-out infinite; }
    /* One shared 9s loop, phased:
       0–13% chip rises (dot pulses) · 13–28% cursor travels in · 28–31% tap chip ·
       31–35% chip → card · 35–42% cursor to "Add" · 42–45% tap · 45–86% fill+hold ·
       86–100% reset */
    @keyframes demoChip {
      0% { opacity: 0; transform: translateX(-50%) translateY(6px); }
      13%, 28% { opacity: 0.72; transform: translateX(-50%) translateY(0); }
      30% { opacity: 0.72; transform: translateX(-50%) translateY(0) scale(0.94); }
      33%, 100% { opacity: 0; transform: translateX(-50%) translateY(0) scale(0.94); }
    }
    @keyframes demoDot {
      0%, 13% { box-shadow: 0 0 0 0 rgba(47, 127, 153, 0); }
      18% { box-shadow: 0 0 0 4px rgba(47, 127, 153, 0.16); }
      24% { box-shadow: 0 0 0 0 rgba(47, 127, 153, 0); }
      28% { box-shadow: 0 0 0 4px rgba(47, 127, 153, 0.16); }
      33%, 100% { box-shadow: 0 0 0 0 rgba(47, 127, 153, 0); }
    }
    @keyframes demoCard {
      0%, 31% { opacity: 0; transform: translateX(-50%) translateY(4px) scale(0.98); }
      35% { opacity: 1; transform: translateX(-50%) translateY(0) scale(1); }
      86% { opacity: 1; transform: translateX(-50%) translateY(0) scale(1); }
      94%, 100% { opacity: 0; transform: translateX(-50%) translateY(4px) scale(0.98); }
    }
    @keyframes demoAddPress {
      0%, 42% { transform: scale(1); }
      44% { transform: scale(0.95); }
      47%, 100% { transform: scale(1); }
    }
    @keyframes demoCursor {
      0%, 6% { opacity: 0; transform: translate(58px, 38px); }
      12% { opacity: 1; transform: translate(58px, 38px); }
      27% { opacity: 1; transform: translate(0, 6px); }
      29% { opacity: 1; transform: translate(0, 8px); }
      31% { opacity: 1; transform: translate(0, 6px); }
      40% { opacity: 1; transform: translate(44px, 12px); }
      43% { opacity: 1; transform: translate(44px, 14px); }
      46% { opacity: 1; transform: translate(44px, 12px); }
      58% { opacity: 1; transform: translate(44px, 12px); }
      66%, 100% { opacity: 0; transform: translate(44px, 12px); }
    }
    @keyframes demoRipple1 {
      0%, 28% { opacity: 0; transform: scale(0.6); }
      30% { opacity: 0.9; transform: scale(0.6); }
      37% { opacity: 0; transform: scale(3.2); }
      100% { opacity: 0; transform: scale(3.2); }
    }
    @keyframes demoRipple2 {
      0%, 42% { opacity: 0; transform: scale(0.6); }
      44% { opacity: 0.9; transform: scale(0.6); }
      51% { opacity: 0; transform: scale(3.2); }
      100% { opacity: 0; transform: scale(3.2); }
    }
    @keyframes demoLine {
      0%, 46% { opacity: 0; transform: translateY(4px); }
      56%, 86% { opacity: 1; transform: translateY(0); }
      94%, 100% { opacity: 0; transform: translateY(4px); }
    }
    @keyframes demoPlaceholder {
      0%, 44% { opacity: 1; }
      48%, 100% { opacity: 0; }
    }
    @media (prefers-reduced-motion: reduce) {
      .demo-chip, .demo-card, .demo-cursor, .demo-ripple, .demo-line, .demo-placeholder,
      .demo-chip .cdot, .demo-card .card-add { animation: none; }
      .demo-cursor, .demo-ripple, .demo-chip { display: none; }
      .demo-card { opacity: 1; transform: translateX(-50%); }
      .demo-line { opacity: 1; transform: none; }
      .demo-placeholder { opacity: 0; }
    }
    /* ---- Pin strip: shown only to users who aren't pinned yet ----
       Chrome forbids pinning programmatically, so the best we can do is show
       exactly where the control is and confirm the moment they use it. Same
       self-running fake-UI approach as the memory demo above. */
    .pin-strip {
      display: none;
      gap: 18px;
      align-items: center;
      flex-wrap: wrap;
      padding: 14px 24px;
      border-bottom: 1px solid ${e.rule};
      background: rgba(47, 127, 153, 0.06);
    }
    .pin-strip[data-visible="true"] { display: flex; }
    .pin-strip-copy { flex: 1 1 240px; min-width: 0; }
    .pin-strip h2 {
      margin: 0;
      font-size: 17px;
      line-height: 1.3;
      color: ${e.ink};
    }
    .pin-strip p {
      margin: 4px 0 0;
      font-size: 15px;
      line-height: 1.45;
      color: ${e.ink2};
      max-width: 52ch;
    }
    .pin-strip[data-state="done"] { background: rgba(73, 176, 143, 0.10); }
    .pin-strip[data-state="done"] .pin-demo-screen { display: none; }
    .pin-strip-check {
      display: none;
      width: 22px;
      height: 22px;
      flex: 0 0 auto;
      border-radius: 999px;
      background: #49b08f;
      color: #fff;
      font: 700 13px/22px "IBM Plex Sans", "Segoe UI", sans-serif;
      text-align: center;
    }
    .pin-strip[data-state="done"] .pin-strip-check { display: block; }
    /* The fake browser toolbar. Sized small — it's a diagram, not a hero. */
    .pin-demo-screen {
      position: relative;
      flex: 0 0 auto;
      width: 232px;
      height: 96px;
      border: 1px solid ${e.rule};
      border-radius: ${e.rSm};
      background: ${e.card};
      box-shadow: 0 6px 16px rgba(17, 34, 47, 0.08);
      overflow: hidden;
    }
    .pin-toolbar {
      display: flex;
      align-items: center;
      gap: 6px;
      padding: 7px 8px;
      border-bottom: 1px solid ${e.ruleSoft};
      background: ${e.paperSoft};
    }
    .pin-omni {
      flex: 1 1 auto;
      height: 12px;
      border-radius: 999px;
      background: ${e.card};
      border: 1px solid ${e.ruleSoft};
    }
    /* Where the pinned icon lands. Reserved up front so nothing shifts when the
       logo appears — the toolbar must look identical before and after. */
    .pin-slot {
      position: relative;
      width: 16px;
      height: 16px;
      flex: 0 0 auto;
    }
    .pin-slot img {
      position: absolute;
      inset: 0;
      width: 16px;
      height: 16px;
      opacity: 0;
      transform: scale(0.6);
      animation: pinLanded 7s ease-in-out infinite;
    }
    .pin-puzzle {
      width: 15px;
      height: 15px;
      flex: 0 0 auto;
      background-color: ${e.ink3};
      -webkit-mask: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24'%3E%3Cpath d='M10 3a2 2 0 0 1 4 0v1h4a1 1 0 0 1 1 1v4h1a2 2 0 0 1 0 4h-1v4a1 1 0 0 1-1 1h-4v-1a2 2 0 0 0-4 0v1H6a1 1 0 0 1-1-1v-4H4a2 2 0 0 1 0-4h1V5a1 1 0 0 1 1-1h4z'/%3E%3C/svg%3E") center/contain no-repeat;
      mask: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24'%3E%3Cpath d='M10 3a2 2 0 0 1 4 0v1h4a1 1 0 0 1 1 1v4h1a2 2 0 0 1 0 4h-1v4a1 1 0 0 1-1 1h-4v-1a2 2 0 0 0-4 0v1H6a1 1 0 0 1-1-1v-4H4a2 2 0 0 1 0-4h1V5a1 1 0 0 1 1-1h4z'/%3E%3C/svg%3E") center/contain no-repeat;
      animation: pinPuzzlePress 7s ease-in-out infinite;
    }
    /* The extensions dropdown, anchored under the puzzle piece. */
    .pin-menu {
      position: absolute;
      top: 30px;
      right: 8px;
      width: 132px;
      padding: 5px;
      border-radius: ${e.rSm};
      background: ${e.card};
      border: 1px solid ${e.ruleSoft};
      box-shadow: 0 6px 16px rgba(17, 34, 47, 0.14);
      opacity: 0;
      transform: translateY(-4px) scale(0.97);
      transform-origin: top right;
      animation: pinMenu 7s ease-in-out infinite;
    }
    .pin-menu-row {
      display: flex;
      align-items: center;
      gap: 6px;
      padding: 4px 5px;
      border-radius: 5px;
      background: ${e.paperSoft};
    }
    .pin-menu-row img { width: 13px; height: 13px; flex: 0 0 auto; }
    .pin-menu-name {
      flex: 1 1 auto;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      font: 600 9px/1.2 "IBM Plex Sans", "Segoe UI", sans-serif;
      color: ${e.ink2};
    }
    .pin-menu-pin {
      width: 12px;
      height: 12px;
      flex: 0 0 auto;
      background-color: ${e.ink3};
      -webkit-mask: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24'%3E%3Cpath d='M14 4l6 6-2.5.8-1.2 4.6L13.4 12 8 17.4V19H6.6v-1.6L12 12 8.6 8.6l4.6-1.2L14 4z'/%3E%3C/svg%3E") center/contain no-repeat;
      mask: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24'%3E%3Cpath d='M14 4l6 6-2.5.8-1.2 4.6L13.4 12 8 17.4V19H6.6v-1.6L12 12 8.6 8.6l4.6-1.2L14 4z'/%3E%3C/svg%3E") center/contain no-repeat;
      animation: pinPinToggle 7s ease-in-out infinite;
    }
    .pin-cursor {
      position: absolute;
      top: 0;
      left: 0;
      width: 14px;
      height: 14px;
      pointer-events: none;
      -webkit-mask: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24'%3E%3Cpath d='M5 3l14 8-6 1 3 6-2 1-3-6-4 4z'/%3E%3C/svg%3E") center/contain no-repeat;
      mask: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24'%3E%3Cpath d='M5 3l14 8-6 1 3 6-2 1-3-6-4 4z'/%3E%3C/svg%3E") center/contain no-repeat;
      background-color: ${e.ink};
      opacity: 0;
      animation: pinCursor 7s ease-in-out infinite;
    }
    .pin-ripple {
      position: absolute;
      width: 9px;
      height: 9px;
      border-radius: 999px;
      border: 2px solid ${e.teal};
      opacity: 0;
    }
    /* q1 lands on the puzzle piece, q2 on the pin icon inside the menu. */
    .pin-ripple.q1 { top: 11px; right: 11px; animation: pinRipple1 7s ease-in-out infinite; }
    .pin-ripple.q2 { top: 38px; right: 16px; animation: pinRipple2 7s ease-in-out infinite; }
    /* One shared 7s loop, phased:
       0–14% idle · 14–26% cursor to puzzle · 26–29% click · 29% menu opens ·
       29–43% cursor to the pin icon · 43–46% click · 46–52% pin turns teal and
       the logo lands in the toolbar · 52–88% hold · 88–100% reset */
    @keyframes pinMenu {
      0%, 29% { opacity: 0; transform: translateY(-4px) scale(0.97); }
      33%, 74% { opacity: 1; transform: translateY(0) scale(1); }
      82%, 100% { opacity: 0; transform: translateY(-4px) scale(0.97); }
    }
    @keyframes pinPuzzlePress {
      0%, 26% { transform: scale(1); }
      28% { transform: scale(0.88); }
      31%, 100% { transform: scale(1); }
    }
    @keyframes pinPinToggle {
      0%, 43% { background-color: ${e.ink3}; transform: rotate(0deg) scale(1); }
      45% { background-color: ${e.ink3}; transform: rotate(0deg) scale(0.88); }
      50%, 100% { background-color: ${e.teal}; transform: rotate(-45deg) scale(1); }
    }
    @keyframes pinLanded {
      0%, 46% { opacity: 0; transform: scale(0.6); }
      52%, 88% { opacity: 1; transform: scale(1); }
      96%, 100% { opacity: 0; transform: scale(0.6); }
    }
    @keyframes pinCursor {
      0%, 8% { opacity: 0; transform: translate(150px, 74px); }
      14% { opacity: 1; transform: translate(150px, 74px); }
      26% { opacity: 1; transform: translate(206px, 12px); }
      28% { opacity: 1; transform: translate(206px, 14px); }
      31% { opacity: 1; transform: translate(206px, 12px); }
      43% { opacity: 1; transform: translate(202px, 39px); }
      45% { opacity: 1; transform: translate(202px, 41px); }
      48% { opacity: 1; transform: translate(202px, 39px); }
      60% { opacity: 1; transform: translate(202px, 39px); }
      70%, 100% { opacity: 0; transform: translate(202px, 39px); }
    }
    @keyframes pinRipple1 {
      0%, 26% { opacity: 0; transform: scale(0.6); }
      28% { opacity: 0.9; transform: scale(0.6); }
      35% { opacity: 0; transform: scale(3); }
      100% { opacity: 0; transform: scale(3); }
    }
    @keyframes pinRipple2 {
      0%, 43% { opacity: 0; transform: scale(0.6); }
      45% { opacity: 0.9; transform: scale(0.6); }
      52% { opacity: 0; transform: scale(3); }
      100% { opacity: 0; transform: scale(3); }
    }
    @media (prefers-reduced-motion: reduce) {
      /* Land on the end state — logo in the toolbar, pin engaged — so the
         diagram still says "this is what pinning does" without motion. */
      .pin-cursor, .pin-ripple { display: none; }
      .pin-menu { animation: none; opacity: 1; transform: none; }
      .pin-menu-pin { animation: none; background-color: ${e.teal}; transform: rotate(-45deg); }
      .pin-slot img { animation: none; opacity: 1; transform: none; }
      .pin-puzzle { animation: none; }
    }
    @media (max-width: 640px) {
      .pin-strip { padding-left: 16px; padding-right: 16px; }
      .wrap {
        padding: 18px 12px 32px;
      }
      .hero, .section, .complete {
        padding-left: 16px;
        padding-right: 16px;
      }
      .import-row {
        grid-template-columns: 1fr;
      }
      .checklist {
        grid-template-columns: 1fr;
      }
      .import-panel {
        padding: 12px;
      }
    }
  </style>
  <div class="wrap">
    <article class="card">
      <section class="pin-strip" id="pin-strip" data-visible="false" data-state="todo" aria-live="polite">
        <div class="pin-demo-screen" role="img" aria-label="Animation: clicking the puzzle-piece icon in the Chrome toolbar opens the extensions menu, and clicking the pin next to LLMnesia puts its icon in the toolbar.">
          <div class="pin-toolbar" aria-hidden="true">
            <span class="pin-omni"></span>
            <span class="pin-slot"><img src="${chrome.runtime.getURL("icons/logo.svg")}" alt="" /></span>
            <span class="pin-puzzle"></span>
          </div>
          <div class="pin-menu" aria-hidden="true">
            <div class="pin-menu-row">
              <img src="${chrome.runtime.getURL("icons/logo.svg")}" alt="" />
              <span class="pin-menu-name">LLMnesia</span>
              <span class="pin-menu-pin"></span>
            </div>
          </div>
          <span class="pin-ripple q1" aria-hidden="true"></span>
          <span class="pin-ripple q2" aria-hidden="true"></span>
          <span class="pin-cursor" aria-hidden="true"></span>
        </div>
        <span class="pin-strip-check" aria-hidden="true">&#10003;</span>
        <div class="pin-strip-copy">
          <h2 id="pin-strip-title">Pin LLMnesia to your toolbar</h2>
          <p id="pin-strip-body">
            Open the puzzle-piece menu, then click the pin beside LLMnesia.
          </p>
        </div>
      </section>
      <header class="hero">
        <div class="brand">
          <img src="${chrome.runtime.getURL("icons/logo.svg")}" alt="" />
          <span class="brand-name">LLMnesia</span>
        </div>
        <h1 id="main-title">Let’s make your chats searchable.</h1>
        <p id="lead-copy" class="lead">
          Start with one AI service. We’ll guide you through the import, then keep new chats up to date automatically.
        </p>
      </header>

      <section id="checklist-section" class="section">
        <span class="section-kicker">A good place to start</span>
        <h2>Which AI do you use most?</h2>
        <p class="section-intro">Choose one service for your first import. You can add the others later from the LLMnesia menu.</p>
        <div class="import-panel" data-step="open-site">
          <div class="before-start">
            <span class="before-start-icon" aria-hidden="true">i</span>
            <div>
              <strong>Before you start</strong>
              Make sure you’re signed in. Keep the new tab open until LLMnesia says the import is complete.
            </div>
          </div>
          <div class="import-row import-row--primary">
            <button id="import-chatgpt-btn" type="button">Import from ChatGPT</button>
            <button id="import-claude-btn" type="button">Import from Claude</button>
            <button id="import-gemini-btn" type="button">Import from Gemini</button>
            <button id="import-perplexity-btn" type="button">Import from Perplexity</button>
          </div>
          <details class="more-imports">
            <summary>Use a different AI</summary>
            <div class="import-row import-row--more">
              <button id="import-grok-btn" type="button">Import from Grok</button>
              <button id="import-character_ai-btn" type="button">Import from Character.AI</button>
              <button id="import-zai-btn" type="button">Import from Z.ai</button>
              <button id="import-deepseek-btn" type="button">Import from DeepSeek</button>
              <button id="import-mistral-btn" type="button">Import from Mistral</button>
              <button id="import-qwen-btn" type="button">Import from Qwen</button>
              <button id="import-copilot-btn" type="button">Import from Copilot</button>
              <button id="import-kimi-btn" type="button">Import from Kimi</button>
              <button id="import-meta_ai-btn" type="button">Import from Meta AI</button>
              <button id="import-google_ai_mode-btn" type="button">Import from Google AI Mode</button>
            </div>
          </details>
          <p id="import-status" class="cta-hint" style="display:none" role="status" aria-live="polite"></p>
        </div>
        <ol class="checklist" id="checklist">
          <li class="step" data-step="index">
            <span class="step-num">2</span>
            <div class="step-body">
              <span class="step-text"><strong>In the new tab, click “Start now.”</strong><br />Leave that tab open. You can use other tabs while LLMnesia works.</span>
              <span id="index-count" class="index-count" data-visible="false" role="status" aria-live="polite"></span>
            </div>
          </li>
          <li class="step step--block" data-step="search">
            <span class="step-num">3</span>
            <div class="step-body">
              <span class="step-text"><strong>Try your first search.</strong><br />Come back here when the import says it’s complete.</span>
              <div class="cta-row">
                <button id="try-search-btn" class="primary" type="button" disabled>Try a search</button>
                <span class="cta-hint" id="cta-hint">Later, press <span class="shortcut-key" id="cta-shortcut">Cmd/Ctrl+Shift+9</span> or click LLMnesia.</span>
              </div>
            </div>
          </li>
        </ol>
        <p class="privacy-note"><strong>Good to know:</strong> new chats are added automatically after setup. ${O.privacy}</p>
      </section>

      <section class="section" id="memory-section">
        <span class="section-kicker">Optional</span>
        <h2>Carry context between AIs</h2>
        <p class="memory-lead">
          Save key facts, preferences, and projects once, then add them to any new chat when you need them.
        </p>
        <div class="demo">
          <div class="demo-screen" role="img" aria-label="Animation: a quiet 'Memory' chip on a new chat expands when tapped into an 'Add memories' button, and your saved memories fill the message box.">
            <div class="demo-bar">
              <span class="d"></span><span class="d"></span><span class="d"></span>
              <span class="demo-url">New chat</span>
            </div>
            <div class="demo-body" aria-hidden="true">
              <div class="demo-chip"><span class="cdot"></span>Memory</div>
              <div class="demo-card">
                <span class="card-opener">Memory <span class="card-chev">&#9662;</span></span>
                <span class="card-add">Add memories</span>
              </div>
              <span class="demo-ripple r1"></span>
              <span class="demo-ripple r2"></span>
              <span class="demo-cursor"></span>
              <div class="demo-composer">
                <div class="demo-placeholder">Message…</div>
                <div class="demo-typed">
                  <span class="demo-line l0"></span>
                  <span class="demo-line l1"></span>
                  <span class="demo-line l2"></span>
                  <span class="demo-line l3"></span>
                </div>
              </div>
            </div>
          </div>
        </div>
        <p class="memory-note">
          Only the memories you choose are added to your message. ${O.memory}
        </p>
        <div class="memory-cta">
          <button id="setup-memory-btn" type="button">Add a memory</button>
          <span class="cta-hint">Import existing memories or add one by hand.</span>
        </div>
        <p class="memory-note" id="memory-shortcut-hint" style="display:none"></p>
      </section>

      <section class="section capture-section" id="capture-section">
        <span class="section-kicker">Stay in the loop · Optional</span>
        <h2 id="capture-title">Get more value from LLMnesia</h2>
        <p id="capture-copy" class="capture-copy">
          Get practical setup tips, new platform support, and the occasional important product update.
        </p>
        <ul class="capture-benefits" aria-label="Email benefits">
          <li>Useful setup tips</li>
          <li>New platform alerts</li>
          <li>Major feature launches</li>
        </ul>
        <form id="capture-form" novalidate>
          <div class="row">
            <input id="email-input" type="email" autocomplete="email" placeholder="you@example.com" />
            <button id="submit-btn" class="primary" type="submit">Send me useful updates</button>
          </div>
          <p class="capture-consent">By subscribing, you agree to receive occasional product and marketing emails. Unsubscribe any time. We never send anything from your chats.</p>
          <div id="form-error" class="error" role="status" aria-live="polite"></div>
        </form>
        <button id="skip-btn" class="skip-link" type="button">No thanks — continue without email</button>
      </section>

      <section id="complete-section" class="complete" data-visible="false">
        <p id="complete-message">You&apos;re all set.</p>
        <button id="close-btn" class="primary" type="button">Close</button>
        <div id="complete-note" class="complete-note"></div>
      </section>
    </article>
  </div>
`;const C=document.querySelector("#capture-section"),ke=document.querySelector("#capture-form"),N=document.querySelector("#main-title"),R=document.querySelector("#lead-copy"),w=document.querySelector("#capture-title"),S=document.querySelector("#capture-copy"),T=document.querySelector("#email-input"),G=document.querySelector("#submit-btn"),v=document.querySelector("#skip-btn"),Y=document.querySelector("#form-error"),U=document.querySelector("#complete-section"),H=document.querySelector("#complete-message"),we=document.querySelector("#close-btn"),L=document.querySelector("#complete-note"),Q=document.querySelector("#import-chatgpt-btn"),Z=document.querySelector("#import-claude-btn"),J=document.querySelector("#import-gemini-btn"),ee=document.querySelector("#import-perplexity-btn"),te=document.querySelector("#import-grok-btn"),oe=document.querySelector("#import-character_ai-btn"),ne=document.querySelector("#import-zai-btn"),ie=document.querySelector("#import-deepseek-btn"),ae=document.querySelector("#import-mistral-btn"),re=document.querySelector("#import-qwen-btn"),se=document.querySelector("#import-copilot-btn"),pe=document.querySelector("#import-kimi-btn"),le=document.querySelector("#import-meta_ai-btn"),ce=document.querySelector("#import-google_ai_mode-btn"),a=document.querySelector("#import-status");let m=null;const y=document.querySelector("#checklist-section"),B=document.querySelector("#checklist"),D=document.querySelector("#cta-shortcut"),u=document.querySelector("#try-search-btn"),h=document.querySelector("#cta-hint");function g(t,o){chrome.runtime.sendMessage({type:"TRACK_ACTIVATION_EVENT",event:t,platformSource:o}).catch(()=>{})}B?.addEventListener("click",t=>{const o=t.target,n=o?.closest(".step");n&&(o?.closest("button")||g("onboarding_step_click",n.dataset.step||"unknown"))});const F="llmnesia.analytics.firstSearchCompleted",Se=y?.querySelector('[data-step="open-site"]')??null,$e=B?.querySelector('[data-step="index"]')??null,Me=B?.querySelector('[data-step="search"]')??null,$=document.querySelector("#index-count");function I(t,o,n){if(!t)return;t.classList.toggle("step--done",o);const i=t.querySelector(".step-num");i&&(i.textContent=o?"✓":n)}let M=null;async function _(){let t=0,o=!1,n=!1;try{const[d,k,p]=await Promise.all([chrome.runtime.sendMessage({type:"GET_INDEX_STATS_QUICK"}),chrome.storage.local.get(F),chrome.runtime.sendMessage({type:"GET_BACKFILL_STATUS"})]);if(t=d?.ok?d.stats.conversationCount:0,o=k[F]===!0,n=p?.ok&&p.state.active,m&&a&&p?.ok){const l=p.progress;if(p.state.active){const s=l?.indexed??0;a.style.display="",a.textContent=s>0?`Importing from ${m}… ${s} chat${s===1?"":"s"} added. Keep the ${m} tab open.`:`Importing from ${m}… Keep the ${m} tab open while LLMnesia gets started.`}else l?.phase==="done"&&(a.style.display="",a.textContent=`Import complete — ${l.indexed} chat${l.indexed===1?"":"s"} added. You can try a search now.`)}}catch{return}const i=t>0;I(Se,i,"1"),I($e,i,"2"),I(Me,o,"3"),u&&(u.disabled=!i),$&&(i?($.dataset.visible="true",$.innerHTML=`<strong>${t}</strong> conversation${t===1?"":"s"} indexed so far.`):$.dataset.visible="false"),i&&o&&!n&&M!==null&&(clearInterval(M),M=null)}f||(_(),M=setInterval(()=>{_()},3e3),document.addEventListener("visibilitychange",()=>{document.visibilityState==="visible"&&_()}));u?.addEventListener("click",()=>{g("try_first_search_click"),u&&(u.disabled=!0),chrome.runtime.sendMessage({type:"OPEN_SEARCH_FROM_ONBOARDING"}).then(t=>{t?.ok?h&&(h.textContent="Search opened in a new tab."):h&&(h.textContent="Couldn’t open search. Use the LLMnesia icon or your search shortcut.")}).catch(()=>{h&&(h.textContent="Couldn’t open search. Use the LLMnesia icon or your search shortcut.")}).finally(()=>{u&&(u.disabled=!1)})});if(f){N&&(N.textContent="You've searched 10 conversations. Want to stay in the loop?"),R&&(R.textContent="Optional: share your email for occasional product updates and feature previews."),y&&(y.style.display="none");const t=document.querySelector("#memory-section");t&&(t.style.display="none"),w&&(w.textContent="Stay in the loop"),S&&(S.textContent="Get useful setup tips, new platform support, and occasional product updates. Unsubscribe any time."),v&&(v.textContent="No thanks")}else chrome.runtime.sendMessage({type:"GET_SEARCH_SHORTCUT"}).then(t=>{const o=t?.ok&&t.shortcut?t.shortcut:"";o&&D&&(D.textContent=o)}).catch(()=>{}),C&&y&&y.insertAdjacentElement("afterend",C),w&&(w.textContent="Get more value from LLMnesia"),S&&(S.textContent="Get practical setup tips, new platform support, and the occasional important product update."),chrome.runtime.sendMessage({type:"TRACK_ACTIVATION_EVENT",event:"install_welcome_viewed",source:z}).catch(()=>{}),chrome.runtime.sendMessage({type:"TRACK_ACTIVATION_EVENT",event:"welcome_screen_viewed",source:z}).catch(()=>{}),chrome.runtime.sendMessage({type:"COMPLETE_ONBOARDING"}).catch(()=>{});const de={chatgpt:"ChatGPT",claude:"Claude",gemini:"Gemini",perplexity:"Perplexity",grok:"Grok",character_ai:"Character.AI",zai:"Z.ai",deepseek:"DeepSeek",mistral:"Mistral",qwen:"Qwen",copilot:"Copilot",kimi:"Kimi",meta_ai:"Meta AI",google_ai_mode:"Google AI Mode"},A={chatgpt:Q,claude:Z,gemini:J,perplexity:ee,grok:te,character_ai:oe,zai:ne,deepseek:ie,mistral:ae,qwen:re,copilot:se,kimi:pe,meta_ai:le,google_ai_mode:ce};let E=null;function K(){E=null,m=null;for(const[t,o]of Object.entries(A)){if(!o)continue;o.disabled=!1;const n=de[t];o.textContent=`Import from ${n}`}}function r(t){if(E)return;E=t;const o=de[t];m=o;for(const i of Object.values(A))i&&(i.disabled=!0);const n=A[t];n&&(n.textContent=`Opening ${o}…`),chrome.runtime.sendMessage({type:"OPEN_BACKFILL_ONBOARDING",platform:t}).then(i=>{if(i?.ok){n&&(n.textContent=`${o} opened ✓`);return}K(),a&&(a.textContent=`We couldn’t open ${o}. Please try again.`)}).catch(()=>{K(),a&&(a.textContent=`We couldn’t open ${o}. Please try again.`)}),a&&(a.style.display="",a.textContent=`Next: in the ${o} tab, click “Start now” and keep that tab open until the import is complete.`)}Q?.addEventListener("click",()=>r("chatgpt"));Z?.addEventListener("click",()=>r("claude"));J?.addEventListener("click",()=>r("gemini"));ee?.addEventListener("click",()=>r("perplexity"));te?.addEventListener("click",()=>r("grok"));oe?.addEventListener("click",()=>r("character_ai"));ne?.addEventListener("click",()=>r("zai"));ie?.addEventListener("click",()=>r("deepseek"));ae?.addEventListener("click",()=>r("mistral"));re?.addEventListener("click",()=>r("qwen"));se?.addEventListener("click",()=>r("copilot"));pe?.addEventListener("click",()=>r("kimi"));le?.addEventListener("click",()=>r("meta_ai"));ce?.addEventListener("click",()=>{E||(async()=>{let t=!1;try{t=await xe(),t||(a&&(a.style.display="",a.textContent="Approve Google site access in Chrome to enable the import."),t=await he())}catch{t=!1}if(!t){a&&(a.textContent="Google access was not enabled. You can turn it on later under LLMnesia Settings > Google AI Mode.");return}r("google_ai_mode")})()});const b=document.querySelector("#pin-strip"),V=document.querySelector("#pin-strip-title"),X=document.querySelector("#pin-strip-body");if(b){let n=0,i=null,d=!1;const k=()=>{i!==null&&(clearInterval(i),i=null)},p=()=>{k(),b.dataset.state="done",b.dataset.visible="true",V&&(V.textContent="Pinned. Nice one."),X&&(X.textContent="LLMnesia is now one click away.")},l=async()=>{try{const s=await chrome.runtime.sendMessage({type:"GET_PIN_STATE"});return s?.ok?s.pinned:null}catch{return null}};(async()=>await l()===!1&&(b.dataset.visible="true",d||(d=!0,g("pin_nudge_shown")),i=setInterval(()=>{if(n+=1,n>500){k();return}l().then(me=>{me===!0&&p()})},1200)))(),document.addEventListener("visibilitychange",()=>{document.visibilityState==="visible"&&b.dataset.state!=="done"&&l().then(s=>{s===!0&&p()})})}const Ce=document.querySelector("#setup-memory-btn");Ce?.addEventListener("click",()=>{g("onboarding_setup_memory_click"),chrome.runtime.sendMessage({type:"OPEN_OPTIONS",hash:"#memory-section"}).catch(()=>{})});const P=document.querySelector("#memory-shortcut-hint");if(P){const t="Alt+Shift+M";chrome.runtime.sendMessage({type:"GET_MEMORY_SHORTCUT"}).then(o=>{const n=(o?.ok&&o.shortcut?o.shortcut:"")||t;P.innerHTML=`Shortcut: <span class="shortcut-key">${n}</span>. Change it at <span class="shortcut-key">chrome://extensions/shortcuts</span>.`,P.style.display=""}).catch(()=>{})}function c(t){G&&(G.disabled=t),v&&(v.disabled=t),T&&(T.disabled=t)}function x(t){Y&&(Y.textContent=t)}function q(t,o=""){C&&(C.style.display="none"),U&&(U.dataset.visible="true"),H&&(H.textContent=t),L&&(L.textContent=o)}async function Le(){const t=fe(T?.value);if(!ge(t)){x("Please enter a valid email address.");return}x(""),c(!0);let o;try{o=await chrome.runtime.sendMessage({type:"SUBMIT_ONBOARDING_EMAIL",email:t,context:f?"search_10_reprompt":be})}catch(i){const d=i instanceof Error?i.message:"Unknown runtime error";x(`Could not submit right now: ${d}`),c(!1);return}if(!o.ok){x(o.error||"Could not submit right now."),c(!1);return}g("marketing_opt_in_submitted");const n=o.listSubmitted?"You're on the list. We'll only email occasionally with previews and important updates.":"Thanks. You're opted in here, but we couldn't sync to the list right now.";q("Thanks for opting in. You're all set.",n),c(!1)}async function Ee(){x(""),c(!0),f||chrome.runtime.sendMessage({type:"TRACK_ACTIVATION_EVENT",event:"welcome_screen_dismissed"}).catch(()=>{});let t;try{f?t=await chrome.runtime.sendMessage({type:"DISMISS_EMAIL_REPROMPT"}):t=await chrome.runtime.sendMessage({type:"COMPLETE_ONBOARDING"})}catch(o){const n=o instanceof Error?o.message:"Unknown runtime error";x(`Could not complete onboarding: ${n}`),c(!1);return}if(!t.ok){x(t.error||"Could not complete onboarding."),c(!1);return}g("marketing_opt_in_declined"),q(f?"No problem. You're all set.":"You're all set. LLMnesia will index quietly in the background."),c(!1)}function Ie(){window.close(),window.setTimeout(()=>{L&&(L.textContent="If this tab did not close automatically, you can close it now.")},350)}ke?.addEventListener("submit",t=>{t.preventDefault(),Le()});v?.addEventListener("click",()=>{Ee()});we?.addEventListener("click",()=>{Ie()});
//# sourceMappingURL=onboarding.js.map
