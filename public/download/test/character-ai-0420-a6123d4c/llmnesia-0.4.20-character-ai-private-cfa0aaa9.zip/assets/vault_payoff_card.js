import{C as M,h as U}from"./continue_targets.js";import{f as F}from"./conversation_counter.js";import{T as n}from"./theme.js";import{g as B}from"./platform_styles.js";import{r as V}from"./prompt_coordinator.js";import{n as H,V as N,b as C,v as q,d as K}from"./vault_payoff.js";const k="llmnesia.continueSummarizePref";let S;chrome.storage?.local?.get(k).then(s=>{const e=s?.[k];typeof e=="boolean"&&(S=e)}).catch(()=>{});const Y={chatgpt:{label:"ChatGPT",accent:"#10a37f"},claude:{label:"Claude",accent:"#d07a45"},gemini:{label:"Gemini",accent:"#3d63f0"},ai_studio:{label:"AI Studio",accent:"#3a67d8"},deepseek:{label:"DeepSeek",accent:"#2a7aa8"},perplexity:{label:"Perplexity",accent:"#0d9488"},grok:{label:"Grok",accent:"#7a57d1"},zai:{label:"Z.ai",accent:"#1f6feb"},mistral:{label:"Mistral",accent:"#d94848"},kimi:{label:"Kimi",accent:"#1f7ac7"},qwen:{label:"Qwen",accent:"#0f9e7b"},copilot:{label:"Copilot",accent:"#0a7c8a"},meta_ai:{label:"Meta AI",accent:"#0866ff"},character_ai:{label:"Character.AI",accent:"#d24d8f"}};class re{host=null;onDismiss=null;onDocumentClick=e=>{this.host&&!this.host.contains(e.target)&&this.hide()};onKeyDown=e=>{e.key==="Escape"&&this.hide()};show(e,t,o,r={}){this.hide();const a=[...M[t]?[t]:[],...U.filter(c=>c!==t&&M[c])];if(a.length===0)return;const i=S??!!r.suggestSummary;let p=i?"summary":"full";const l=document.createElement("div");l.style.all="initial",l.style.position="fixed",l.style.zIndex="2147483647",l.style.pointerEvents="auto";const u=l.attachShadow({mode:"open"});u.innerHTML=`
      <style>
        :host { all: initial; }
        .menu {
          background: rgba(255, 255, 255, 0.96);
          border: 1px solid rgba(0, 0, 0, 0.1);
          border-radius: 10px;
          box-shadow: 0 6px 20px rgba(0, 0, 0, 0.12);
          padding: 4px;
          min-width: 160px;
          font: 11px/1.3 "IBM Plex Sans", "SF Pro Text", "Segoe UI", sans-serif;
          color: #2f4654;
        }
        .header {
          padding: 5px 10px 4px;
          font-size: 9px;
          font-weight: 600;
          text-transform: uppercase;
          letter-spacing: 0.5px;
          color: #8a9baa;
        }
        .item {
          display: flex;
          align-items: center;
          gap: 8px;
          padding: 6px 10px;
          border: none;
          background: none;
          width: 100%;
          text-align: left;
          font: inherit;
          color: inherit;
          border-radius: 7px;
          cursor: pointer;
          transition: background 80ms ease;
        }
        .item:hover {
          background: rgba(0, 0, 0, 0.05);
        }
        .item:active {
          background: rgba(0, 0, 0, 0.08);
        }
        .dot {
          width: 7px;
          height: 7px;
          border-radius: 999px;
          flex-shrink: 0;
        }
        .name {
          flex: 1;
          white-space: nowrap;
        }
        .new-badge {
          font-size: 8px;
          font-weight: 700;
          text-transform: uppercase;
          letter-spacing: 0.4px;
          color: #8a9baa;
          background: rgba(0,0,0,0.06);
          padding: 1px 4px;
          border-radius: 3px;
        }
        .separator {
          height: 1px;
          background: rgba(0,0,0,0.07);
          margin: 3px 4px;
        }
        .summarize-row {
          display: flex;
          align-items: center;
          gap: 8px;
          padding: 6px 10px;
          border: none;
          background: rgba(47, 70, 84, 0.05);
          width: 100%;
          text-align: left;
          font: inherit;
          color: #2f4654;
          border-radius: 7px;
          cursor: pointer;
          transition: background 90ms ease;
        }
        .summarize-row:hover {
          background: rgba(47, 70, 84, 0.09);
        }
        .summarize-row.active {
          background: rgba(47, 127, 153, 0.12);
        }
        .sum-title {
          flex: 1;
          font-size: 11px;
          font-weight: 600;
          white-space: nowrap;
        }
        .check {
          width: 15px;
          height: 15px;
          border-radius: 4px;
          border: 1.5px solid #c5d0d9;
          flex-shrink: 0;
          display: flex;
          align-items: center;
          justify-content: center;
          transition: background 80ms ease, border-color 80ms ease;
        }
        .check.checked {
          background: #2f7f99;
          border-color: #2f7f99;
        }
        .check-icon {
          color: white;
          font-size: 10px;
          line-height: 1;
          display: none;
          font-style: normal;
        }
        .check.checked .check-icon {
          display: block;
        }
        .suggest-badge {
          font-size: 8px;
          font-weight: 700;
          letter-spacing: 0.3px;
          color: #fff;
          background: #2f7f99;
          padding: 1px 5px;
          border-radius: 3px;
          flex-shrink: 0;
        }
      </style>
      <div class="menu">
        <button class="summarize-row${i?" active":""}" id="toggle-summarize">
          <span class="check${i?" checked":""}" id="toggle-check"><i class="check-icon">✓</i></span>
          <span class="sum-title">Summarize first</span>
          ${r.suggestSummary?'<span class="suggest-badge">LONG CHAT</span>':""}
        </button>
        <div class="separator"></div>
        <div class="header">Continue in…</div>
        ${a.map((c,m)=>{const v=Y[c],O=v?.label??c,z=v?.accent??"#90a4ae",A=c===t,D=A&&m===0&&a.length>1?'<div class="separator"></div>':"";return`<button class="item" data-platform="${c}">
              <span class="dot" style="background:${z}"></span>
              <span class="name">${O}</span>
              ${A?'<span class="new-badge">new chat</span>':""}
            </button>${D}`}).join("")}
      </div>
    `;const f=8;let g=e.right-180,h=e.bottom+6;g<f&&(g=f),h+300>window.innerHeight&&(h=e.top-6),l.style.left=`${Math.round(g)}px`,l.style.top=`${Math.round(h)}px`;for(const c of u.querySelectorAll("[data-platform]"))c.addEventListener("click",m=>{m.stopPropagation();const v=c.dataset.platform;this.hide(),o(v,p)});const b=u.querySelector("#toggle-summarize"),x=u.querySelector("#toggle-check");b?.addEventListener("click",c=>{c.stopPropagation(),p=p==="full"?"summary":"full";const m=p==="summary";x?.classList.toggle("checked",m),b.classList.toggle("active",m),S=m,chrome.storage?.local?.set({[k]:m}).catch(()=>{})}),document.documentElement.append(l),this.host=l;const T=u.querySelector(".menu");if(T){const c=T.getBoundingClientRect();if(c.bottom>window.innerHeight-f){const m=e.top-c.height-6;l.style.top=`${Math.max(f,Math.round(m))}px`}}requestAnimationFrame(()=>{document.addEventListener("click",this.onDocumentClick,!0),document.addEventListener("contextmenu",this.onDocumentClick,!0),document.addEventListener("keydown",this.onKeyDown,!0)})}hide(){document.removeEventListener("click",this.onDocumentClick,!0),document.removeEventListener("contextmenu",this.onDocumentClick,!0),document.removeEventListener("keydown",this.onKeyDown,!0),this.host&&(this.host.remove(),this.host=null),this.onDismiss&&(this.onDismiss(),this.onDismiss=null)}isOpen(){return this.host!==null}}const P="[data-message-author-role]",R="[data-testid^='conversation-turn-']",G=["[data-testid='user-message']","[data-testid='assistant-message']","[data-testid*='-message']","[data-testid*='human-turn']","[data-testid*='ai-turn']",".prose","[class*='font-claude-response']",".standard-markdown"].join(", "),W="data-llmnesia-snippet-retrieval-active",w=2e3,j=220,L=44;function _(s){let e=s instanceof HTMLElement?s:s.parentElement;for(;e;){if(e.matches(P)||e.matches(R)||e.matches(G))return e;e=e.parentElement}return null}function $(s){const e=document.querySelectorAll(`${P}, ${R}`),t=Array.from(e);for(let o=0;o<t.length;o++)if(t[o]===s)return o;return-1}function Q(s){const e=s.commonAncestorContainer;return e===document.body||e===document.documentElement||e===document?!0:e instanceof HTMLElement&&(e.tagName==="BODY"||e.tagName==="HTML")}function X(s){let e=s instanceof HTMLElement?s:s.parentElement;for(;e;){const t=e.getAttribute?.("contenteditable");if(e.isContentEditable||t!==null&&t!=="false")return!0;const o=e.tagName;if(o==="INPUT"||o==="TEXTAREA"||o==="SELECT")return!0;e=e.parentElement}return!1}class le{host=null;shadow=null;platform;impressionReported=!1;resolveContext;resolveMessageIndexes;scopeRoot;visible=!1;currentSelection=null;hideTimer;constructor(e){this.platform=e.platform,this.resolveContext=e.resolveContext,this.scopeRoot=e.scopeRoot??null,this.resolveMessageIndexes=e.resolveMessageIndexes??(t=>{const o=_(t.startContainer),r=_(t.endContainer);return{start:o?$(o):-1,end:r?$(r):-1}})}attach(){if(this.host)return;const e=document.createElement("div");e.setAttribute("data-llmnesia-selection-capture","true"),e.style.all="initial",e.style.position="fixed",e.style.zIndex="2147483645",e.style.display="none";const t=e.attachShadow({mode:"open"});t.innerHTML=`
      <style>
        :host { all: initial; }
        * { box-sizing: border-box; }
        .container {
          font-family: "IBM Plex Sans", "Segoe UI", system-ui, sans-serif;
          font-size: 13px;
          display: flex;
          align-items: center;
          gap: 6px;
          background: linear-gradient(180deg, ${n.card} 0%, ${n.tealSoft} 100%);
          color: ${n.ink};
          border: 1px solid rgba(47, 127, 153, 0.18);
          border-radius: ${n.rSm};
          padding: 6px 10px;
          box-shadow:
            0 14px 32px rgba(17, 34, 47, 0.16),
            inset 0 1px 0 rgba(255, 255, 255, 0.72);
          white-space: nowrap;
          max-width: 400px;
        }
        .save-btn {
          background: ${n.teal};
          color: #fff;
          border: 1px solid ${n.teal};
          border-radius: ${n.rSm};
          padding: 4px 10px;
          font-size: 12px;
          font-family: inherit;
          cursor: pointer;
          font-weight: 600;
          white-space: nowrap;
        }
        .save-btn:hover { opacity: 0.9; }
        .cancel-btn {
          background: transparent;
          color: ${n.ink3};
          border: none;
          font-size: 16px;
          cursor: pointer;
          padding: 2px 4px;
          line-height: 1;
        }
        .cancel-btn:hover { color: ${n.ink}; }
        .label-input {
          background: ${n.card};
          color: ${n.ink};
          border: 1px solid ${n.rule};
          border-radius: ${n.rSm};
          padding: 4px 8px;
          font-size: 12px;
          font-family: inherit;
          width: 200px;
          outline: none;
        }
        .label-input::placeholder { color: ${n.ink3}; }
        .note {
          color: ${n.ink3};
          font: 500 10.5px/1.2 "IBM Plex Sans", system-ui, sans-serif;
          white-space: nowrap;
        }
        .toast {
          background: ${n.paperSoft};
          color: ${n.ink2};
          border: 1px solid ${n.ruleSoft};
          border-radius: ${n.rSm};
          padding: 4px 10px;
          font: 600 10.5px/1.2 "IBM Plex Mono", "SF Mono", "Consolas", monospace;
          letter-spacing: 0;
        }
      </style>
      <div class="container" id="root"></div>
    `,this.host=e,this.shadow=t,document.documentElement.appendChild(e),document.addEventListener("mouseup",this.handleMouseUp),document.addEventListener("mousedown",this.handleMouseDown)}detach(){document.removeEventListener("mouseup",this.handleMouseUp),document.removeEventListener("mousedown",this.handleMouseDown),this.host?.remove(),this.host=null,this.shadow=null,this.visible=!1,this.currentSelection=null}handleMouseDown=e=>{!this.host||!this.visible||e.composedPath().includes(this.host)||this.hide()};handleMouseUp=e=>{const t=e.composedPath();this.host&&t.includes(this.host)||window.setTimeout(()=>this.checkSelection(),10)};checkSelection(){if(document.documentElement.hasAttribute(W)){this.hide();return}const e=window.getSelection();if(!e||e.isCollapsed||!e.toString().trim())return;const t=e.getRangeAt(0);X(t.startContainer)||this.scopeRoot&&!this.scopeRoot.contains(t.startContainer)||Q(t)||(this.currentSelection={text:e.toString().trim(),range:t},this.showAtSelection(t))}showAtSelection(e){if(!this.host||!this.shadow)return;this.hideTimer&&(window.clearTimeout(this.hideTimer),this.hideTimer=void 0);const t=e.getClientRects(),o=t.length>0?t[t.length-1]:e.getBoundingClientRect(),r=Math.min(o.left+o.width/2,window.innerWidth-j);let a=o.bottom+8;a+L>window.innerHeight&&(a=Math.max(8,o.top-L)),this.host.style.left=`${Math.max(8,r)}px`,this.host.style.top=`${Math.max(8,a)}px`,this.host.style.display="block",this.visible=!0,this.renderButton(),this.reportFirstImpression()}reportFirstImpression(){this.impressionReported||(this.impressionReported=!0,chrome.runtime.sendMessage({type:"TRACK_ACTIVATION_EVENT",event:"selection_capture_shown",platformSource:this.platform}).catch(()=>{}))}renderButton(){const e=this.shadow?.getElementById("root");e&&(e.innerHTML=`
      <span style="font-size: 14px;">&#129504;</span>
      <button class="save-btn" id="save-btn">Save to Memory</button>
      <button class="cancel-btn" id="cancel-btn">&times;</button>
    `,e.querySelector("#save-btn")?.addEventListener("click",t=>{t.stopPropagation(),this.showLabelInput()}),e.querySelector("#cancel-btn")?.addEventListener("click",t=>{t.stopPropagation(),this.hide()}))}showLabelInput(){const e=this.shadow?.getElementById("root");if(!e||!this.currentSelection)return;const t=this.currentSelection.text,o=t.slice(0,60)+(t.length>60?"...":""),r=t.length>w;e.innerHTML=`
      <input class="label-input" id="label-input" type="text" placeholder="Memory label..." value="${this.escapeAttr(o)}" />
      <button class="save-btn" id="confirm-btn">Save</button>
      ${r?`<span class="note">Trimmed to ${w} characters</span>`:""}
      <button class="cancel-btn" id="cancel-btn">&times;</button>
    `;const a=e.querySelector("#label-input");a?.focus(),a?.select(),a?.addEventListener("keydown",i=>{i.key==="Enter"&&(i.preventDefault(),this.saveMemory(a.value.trim()||o)),i.key==="Escape"&&(i.preventDefault(),this.hide())}),e.querySelector("#confirm-btn")?.addEventListener("click",i=>{i.stopPropagation(),this.saveMemory(a?.value.trim()||o)}),e.querySelector("#cancel-btn")?.addEventListener("click",i=>{i.stopPropagation(),this.hide()})}async saveMemory(e){if(!this.currentSelection){this.hide();return}const t=this.currentSelection.text;if(!t){this.hide();return}const o=this.currentSelection.range,{start:r,end:a}=this.resolveMessageIndexes(o),i=this.resolveContext()??{platform:this.platform,docId:null,conversationTitle:document.title||"Untitled",conversationUrl:window.location.href},p=Date.now(),l={memoryId:crypto.randomUUID(),kind:"fact",label:e,text:t.slice(0,w),source:"snippet",...i.docId?{sourceDocId:i.docId}:{},sourcePlatform:i.platform,...i.conversationUrl?{sourceUrl:i.conversationUrl}:{},...i.conversationTitle?{sourceTitle:i.conversationTitle}:{},...r>=0?{sourceMsgStart:r}:{},...a>=0?{sourceMsgEnd:a}:{},pinned:!1,enabled:!0,createdAt:p,updatedAt:p};try{const u=await chrome.runtime.sendMessage({type:"SAVE_MEMORY",memory:l});if(u&&u.ok===!1){this.showToast("Failed to save");return}await F(),chrome.runtime.sendMessage({type:"TRACK_ACTIVATION_EVENT",event:"memory_created",source:"selection"}).catch(()=>{}),this.showToast("Saved to memory")}catch{this.showToast("Failed to save")}}showToast(e){const t=this.shadow?.getElementById("root");if(!t){this.hide();return}t.innerHTML=`<span class="toast">${this.escapeHtml(e)}</span>`,this.hideTimer=window.setTimeout(()=>this.hide(),1500)}hide(){this.hideTimer&&(window.clearTimeout(this.hideTimer),this.hideTimer=void 0),this.host&&(this.host.style.display="none"),this.visible=!1,this.currentSelection=null}escapeHtml(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}escapeAttr(e){return e.replace(/&/g,"&amp;").replace(/"/g,"&quot;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}}function Z(s){let e=!1,t=!1;const o=s.now??(()=>Date.now());return{isRetired:()=>e,maybeClaim:()=>e||t||!s.isPageHostable()?Promise.resolve(!1):(t=!0,(async()=>{try{const r=H(await s.readArmedState());if(!r||r.status!=="armed"||s.pageLoadedAt<r.armedAt||o()-r.armedAt>N)return e=!0,!1;let a;try{a=await s.claim()}catch{return!1}if(!a||a.ok!==!0||a.outcome==="busy")return!1;if(a.outcome!=="claimed")return e=!0,!1;if(!s.isPageHostable()){try{await s.release?.()}catch{}return!1}return await s.onClaimed(a.counts??{}),e=!0,!0}catch{return!1}finally{t=!1}})())}}const I="llmnesia-vault-payoff-host",J=`
  .card {
    position: fixed;
    bottom: 20px;
    right: 20px;
    z-index: 2147483647;
    box-sizing: border-box;
    width: 340px;
    max-width: calc(100vw - 32px);
    background: linear-gradient(180deg, ${n.card} 0%, ${n.tealSoft} 100%);
    border: 1px solid ${n.tealEdge};
    border-radius: ${n.rMd};
    padding: 14px 16px 14px 16px;
    color: ${n.ink};
    font: 14px/1.45 "IBM Plex Sans", "Segoe UI", sans-serif;
    box-shadow: 0 18px 42px rgba(17, 34, 47, 0.16), inset 0 1px 0 rgba(255, 255, 255, 0.72);
  }
  .close {
    position: absolute;
    top: 8px;
    right: 8px;
    appearance: none;
    background: none;
    border: none;
    color: ${n.ink3};
    font-size: 14px;
    line-height: 1;
    padding: 4px;
    border-radius: ${n.rSm};
    cursor: pointer;
  }
  .close:hover { color: ${n.ink}; background: rgba(20, 36, 48, 0.06); }
  .title { margin: 0 22px 2px 0; font-weight: 600; font-size: 14.5px; color: #11273a; }
  .count {
    margin: 0 0 8px;
    color: ${n.ink3};
    font: 11px/1.4 "IBM Plex Mono", "SF Mono", "Consolas", monospace;
  }
  .chips { display: flex; flex-wrap: wrap; gap: 5px; margin: 0 0 10px; padding: 0; list-style: none; }
  .chip {
    display: inline-flex;
    align-items: baseline;
    gap: 5px;
    border: 1px solid ${n.ruleSoft};
    border-radius: ${n.rPill};
    padding: 2px 8px;
    font-size: 12px;
    background: ${n.card};
    color: ${n.ink2};
  }
  .chip b { font-weight: 600; color: ${n.ink}; }
  .vault { margin: 0 0 4px; color: ${n.ink2}; font-size: 13px; }
  .price { margin: 0 0 12px; color: ${n.ink3}; font-size: 12px; }
  .actions { display: flex; gap: 8px; }
  .cta {
    appearance: none;
    background: ${n.teal};
    border: 1px solid ${n.teal};
    border-radius: ${n.rSm};
    color: #fff;
    font: 600 13px "IBM Plex Sans", "Segoe UI", sans-serif;
    padding: 6px 12px;
    cursor: pointer;
  }
  .cta:hover { background: ${n.tealDark}; border-color: ${n.tealDark}; }
  .dismiss {
    appearance: none;
    background: transparent;
    border: 1px solid ${n.ruleSoft};
    border-radius: ${n.rSm};
    color: ${n.ink2};
    font: 13px "IBM Plex Sans", "Segoe UI", sans-serif;
    padding: 6px 10px;
    cursor: pointer;
  }
  .dismiss:hover { background: ${n.paperSoft}; }
`;function d(s,e,t){const o=document.createElement(s);return o.className=e,t!==void 0&&(o.textContent=t),o}function ee(s,e){document.getElementById(I)?.remove();const t=q(s,h=>B(h).label),o=document.createElement("div");o.id=I;const r=o.attachShadow({mode:"closed"}),a=document.createElement("style");a.textContent=J;const i=d("section","card");i.setAttribute("role","dialog"),i.setAttribute("aria-label","LLMnesia Vault");const p=d("button","close","✕");if(p.type="button",p.setAttribute("aria-label","Close"),i.append(p,d("p","title",t.title),d("p","count",t.countLine)),t.platforms.length>0){const h=d("ul","chips");for(const b of t.platforms){const x=d("li","chip");x.append(d("span","",b.label),d("b","",b.count.toLocaleString("en-GB"))),h.append(x)}t.morePlatforms>0&&h.append(d("li","chip",`+${t.morePlatforms} more`)),i.append(h)}i.append(d("p","vault",t.vaultLine),d("p","price",t.priceLine));const l=d("div","actions"),u=d("button","cta",t.ctaLabel);u.type="button";const f=d("button","dismiss",t.dismissLabel);f.type="button",l.append(u,f),i.append(l),r.append(a,i),document.body.appendChild(o);let y=!1;const g=h=>{y||(y=!0,o.remove(),e(h))};u.addEventListener("click",()=>g("cta")),f.addEventListener("click",()=>g("dismissed")),p.addEventListener("click",()=>g("dismissed"))}function E(s){chrome.runtime.sendMessage(s).catch(()=>{})}function ce(s,e){const t=Math.floor(performance.timeOrigin);return Z({readArmedState:async()=>(await chrome.storage.local.get(C))[C],claim:async()=>await chrome.runtime.sendMessage({type:"VAULT_PAYOFF_CLAIM",pageLoadedAt:t}),release:async()=>{await chrome.runtime.sendMessage({type:"VAULT_PAYOFF_RELEASE"})},isPageHostable:e,pageLoadedAt:t,onClaimed:async o=>{ee(o,a=>{a==="cta"&&window.open(K,"_blank","noopener"),E({type:"VAULT_PAYOFF_RESOLVE",reason:a}),E({type:"TRACK_ACTIVATION_EVENT",event:a==="cta"?"vault_payoff_cta_clicked":"vault_payoff_dismissed",props:{surface:s}})});const r=Object.values(o).reduce((a,i)=>a+(Number.isFinite(i)?i:0),0);E({type:"TRACK_ACTIVATION_EVENT",event:"vault_payoff_shown",props:{surface:s,indexed_conversation_count:r,platform_count:Object.keys(o).length}}),await V("vault_payoff")}})}export{re as C,le as S,ce as c};
//# sourceMappingURL=vault_payoff_card.js.map
