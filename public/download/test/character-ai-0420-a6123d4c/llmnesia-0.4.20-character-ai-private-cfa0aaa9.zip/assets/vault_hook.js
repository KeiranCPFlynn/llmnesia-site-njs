import{T as o}from"./theme.js";const a=`
  .vault-wl { display: flex; flex-direction: column; gap: 12px; font: inherit; }
  .vault-wl form { display: flex; flex-direction: column; gap: 12px; }
  .vault-wl-row { display: flex; gap: 8px; align-items: stretch; flex-wrap: wrap; }
  /* One question label + its pill row, grouped tighter than the gap between
     separate questions so the two read as distinct groups, not one wall. */
  .vault-wl-question { display: flex; flex-direction: column; gap: 6px; }
  .vault-wl-input,
  .vault-wl-textarea {
    flex: 1 1 160px;
    min-width: 0;
    border: 1px solid ${o.rule};
    border-radius: ${o.rSm};
    background: ${o.card};
    color: ${o.ink};
    padding: 8px 10px;
    font: inherit;
    font-size: 13px;
    box-shadow: inset 0 1px 2px rgba(20, 36, 48, 0.05);
    transition: border-color 0.12s ease, box-shadow 0.12s ease;
  }
  .vault-wl-textarea { width: 100%; resize: vertical; min-height: 52px; }
  .vault-wl-input:focus,
  .vault-wl-textarea:focus {
    outline: none;
    border-color: ${o.teal};
    box-shadow: 0 0 0 3px ${o.tealSoft};
  }
  .vault-wl-btn {
    appearance: none;
    border: 1px solid ${o.tealDark};
    background: ${o.teal};
    color: #fff;
    font: inherit;
    font-size: 13px;
    font-weight: 700;
    border-radius: ${o.rSm};
    padding: 8px 14px;
    cursor: pointer;
    white-space: nowrap;
    box-shadow: ${o.shadowSm};
    transition: background 0.12s ease, box-shadow 0.12s ease, transform 0.05s ease;
  }
  .vault-wl-btn:hover { background: ${o.tealDark}; }
  .vault-wl-btn:active { background: ${o.tealDark}; box-shadow: none; transform: translateY(1px); }
  .vault-wl-btn[disabled] { opacity: 0.6; cursor: default; box-shadow: none; transform: none; }
  /* Pending state: the join round-trip goes out to the leads API and on to a
     Sheets webhook, which can take several seconds. Without a visible signal the
     greyed-out button reads as stuck, so say what's happening and spin. */
  .vault-wl-btn.pending { opacity: 1; }
  .vault-wl-spinner {
    display: inline-block;
    width: 11px;
    height: 11px;
    margin-right: 6px;
    vertical-align: -1px;
    border: 2px solid rgba(255, 255, 255, 0.4);
    border-top-color: #fff;
    border-radius: 50%;
    animation: vault-wl-spin 0.7s linear infinite;
  }
  @keyframes vault-wl-spin { to { transform: rotate(360deg); } }
  @media (prefers-reduced-motion: reduce) {
    .vault-wl-spinner { animation-duration: 2.4s; }
  }
  .vault-wl-btn.ghost {
    border-color: ${o.rule};
    background: ${o.card};
    color: ${o.ink2};
    font-weight: 600;
    box-shadow: ${o.shadowSm};
  }
  .vault-wl-btn.ghost:hover { background: ${o.paperSoft}; border-color: ${o.ink3}; }
  .vault-wl-btn.ghost:active { background: ${o.paperSoft}; box-shadow: none; transform: translateY(1px); }
  .vault-wl-confirm-title { font-weight: 700; font-size: 14px; color: ${o.ink}; }
  .vault-wl-confirm-q { color: ${o.ink2}; font-weight: 600; font-size: 12.5px; }
  .vault-wl-pills { display: flex; gap: 8px; flex-wrap: wrap; }
  .vault-wl-pill {
    border-color: ${o.rule};
    background: ${o.card};
    color: ${o.ink2};
    font-weight: 600;
    padding: 5px 12px;
    box-shadow: ${o.shadowSm};
  }
  .vault-wl-pill:hover { background: ${o.tealSoft}; border-color: ${o.teal}; color: ${o.ink}; }
  .vault-wl-pill.selected {
    border-color: ${o.tealDark};
    background: ${o.teal};
    color: #fff;
  }
  .vault-wl-pill.selected:hover { background: ${o.tealDark}; }
  .vault-wl-error { color: #b23b3b; font-size: 12px; min-height: 0; }
  .vault-wl-error:empty { display: none; }
`;function l(e,t){chrome.runtime.sendMessage({type:"TRACK_HOOK_EVENT",event:e,surface:t.surface,variant:t.variant,milestone:t.milestone}).catch(()=>{})}const r=`${a}
  .vault-headline { font-weight: 700; font-size: 15px; line-height: 1.3; color: ${o.ink}; }
  .vault-body { color: ${o.ink2}; font-size: 12.5px; line-height: 1.45; }
  .vault-dismiss {
    position: absolute;
    top: 10px;
    right: 10px;
    appearance: none;
    border: none;
    background: transparent;
    color: ${o.ink3};
    cursor: pointer;
    font-size: 13px;
    line-height: 1;
    padding: 4px;
    border-radius: ${o.rSm};
  }
  .vault-dismiss:hover { background: rgba(20, 36, 48, 0.08); color: ${o.ink}; }
  .vault-hook {
    position: relative;
    display: flex;
    flex-direction: column;
    gap: 10px;
    border: 1px solid ${o.tealEdge};
    border-radius: ${o.rMd};
    background: ${o.tealSoft};
    box-shadow: ${o.shadowSm};
    padding: 14px 30px 14px 16px;
  }
  .vault-counter {
    position: relative;
    display: none;
    flex-direction: column;
    gap: 8px;
    border: 1px solid ${o.ruleSoft};
    border-radius: ${o.rMd};
    background: ${o.card};
    box-shadow: ${o.shadowSm};
    padding: 12px 30px 12px 15px;
  }
  .vault-counter[data-visible="true"] { display: flex; }
  .vault-counter .vault-headline { font-size: 14px; }
  .vault-milestone {
    position: relative;
    display: none;
    flex-direction: column;
    gap: 10px;
    border: 1px solid ${o.onEdge};
    border-radius: ${o.rMd};
    background: ${o.onBg};
    box-shadow: ${o.shadowSm};
    padding: 14px 30px 14px 16px;
  }
  .vault-milestone[data-visible="true"] { display: flex; }
  .vault-milestone .vault-headline { color: ${o.onInk}; }
  .vault-milestone .vault-body { color: ${o.onInk}; }
  .vault-footer {
    position: relative;
    display: none;
    flex-direction: column;
    gap: 6px;
    border-top: 1px solid ${o.ruleSoft};
    padding: 10px 24px 4px 0;
    margin-top: 12px;
    color: ${o.ink3};
    font-size: 12px;
    line-height: 1.4;
  }
  .vault-footer[data-visible="true"] { display: flex; }
  .vault-footer .vault-link,
  .vault-settings .vault-link {
    align-self: flex-start;
    appearance: none;
    border: none;
    background: transparent;
    color: ${o.teal};
    font: inherit;
    font-weight: 600;
    padding: 0;
    cursor: pointer;
  }
  .vault-settings {
    position: relative;
    display: none;
    flex-direction: column;
    gap: 6px;
  }
  .vault-settings[data-visible="true"] { display: flex; }
`;async function i(e,t){return e.textContent="",!1}async function s(e,t){return e.textContent="",e.dataset.visible="false",!1}export{r as V,s as a,i as m,l as t};
//# sourceMappingURL=vault_hook.js.map
