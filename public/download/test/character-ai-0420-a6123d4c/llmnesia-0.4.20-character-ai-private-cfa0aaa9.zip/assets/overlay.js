import{g as de}from"./google_ai_mode_page.js";import{n as he,i as pe,b as ue}from"./outreach.js";import{T as i}from"./theme.js";import{a as me}from"./search_import_notice.js";import{g as L,P as fe}from"./platform_styles.js";import{c as ge}from"./capture_provenance.js";import{c as W,r as G}from"./prompt_coordinator.js";import{O as be,c as ye}from"./backfill.js";import{O as R,o as xe,h as we,g as Se}from"./organisation_scope.js";import{s as ve}from"./claude_scheduled_task.js";import{a as O,b as N,d as Ee}from"./pin_state.js";import{C as ke,r as Ce,l as $e,i as Pe,b as Te,c as Ie}from"./claude_code_promo.js";const Me=[{title:"Search from any tab (default shortcuts)",items:[{label:"Open the search palette",keys:{mac:[["⌘","⇧","9"]],other:[["Ctrl","⇧","9"]]},note:"Opens a separate search tab when the current page cannot host search."},{label:"Open the palette (alternate binding)",keys:{mac:[["⌥","⇧","K"]],other:[["Alt","⇧","K"]]}}]},{title:"Memories on supported AI chat pages (default shortcuts)",items:[{label:"Add your memory context to the chat",keys:{mac:[["⌥","⇧","M"]],other:[["Alt","⇧","M"]]},note:"Requires memories enabled and an open chat composer."},{label:"Add a single memory by number",keys:{mac:[["⌥","⇧","N"],["1-9"]],other:[["Alt","⇧","N"],["1-9"]]},sequence:!0,note:"Shows your memories numbered, then press one. Press it again to hide."}]},{title:"Inside the palette",items:[{label:"Move through results",keys:{mac:[["↑"],["↓"]],other:[["↑"],["↓"]]}},{label:"Open the selected conversation",keys:{mac:[["↵"]],other:[["↵"]]}},{label:"Open your saved copy (works offline)",keys:{mac:[["⌥","↵"]],other:[["Alt","↵"]]}},{label:"Close the palette",keys:{mac:[["Esc"]],other:[["Esc"]]},note:"Closes an open menu first."},{label:"Show search help",keys:{mac:[["?"]],other:[["?"]]},note:"When the search box is empty"},{label:"Close search help",keys:{mac:[["Esc"],["?"]],other:[["Esc"],["?"]]}}]},{title:"With the mouse",items:[{label:"Open a result in a background tab (palette stays open)",keys:{mac:[["⌘","click"]],other:[["Ctrl","click"]]}},{label:"Open a result's saved copy",keys:{mac:[["⌥","click"]],other:[["Alt","click"]]},note:"You can also use the Open copy button on a result."}]}];function Le(){if(typeof navigator>"u")return!0;const l=navigator.platform||"",e=navigator.userAgent||"";return/Mac|iPhone|iPad|iPod/i.test(l)||/Mac OS X/i.test(e)}function k(l,e,t){chrome.runtime.sendMessage({type:"TRACK_ACTIVATION_EVENT",event:l,platformSource:e,props:t}).catch(()=>{})}function Ae(){try{return typeof chrome<"u"&&!!chrome.runtime?.id}catch{return!1}}const U=100;function Re(){try{return window.location?.protocol==="chrome-extension:"}catch{return!1}}function V(l,e){if(l.enabled!==e.enabled)return!1;if(!l.enabled)return!0;const t={kind:"unclassified"};return l.enabled===e.enabled&&we(l.scope??t,e.scope??t)&&l.revisionToken===e.revisionToken}const B="llmnesia.search.uiPrefs.v1",T="llmnesia.search.history.v1",Q=50,D="llmnesia.search.recentLimit",Fe=[30,50,100,250,500],ee=30;function j(l){const e=Number(l);return Fe.includes(e)?e:ee}function He(l,e){const t=Math.min(l.length,e.length);for(let s=0;s<t;s+=1)if(l[s]!==e[s])return!1;return!0}const _e=45,Oe=500,Ne=0,Be={day:1440*60*1e3,week:10080*60*1e3,month:720*60*60*1e3};function De(l){return l==="day"?"Last 24h":l==="week"?"Last 7d":l==="month"?"Last 30d":"Any time"}function qe(l){return l==="best_match"||l==="updated_desc"||l==="updated_asc"}function K(l){return l==="opened_desc"||l==="modified_desc"||l==="modified_asc"}function ze(l){return l==="any"||l==="day"||l==="week"||l==="month"}function _(l){return Object.prototype.hasOwnProperty.call(fe,l)}function We(l){return l==="all"||_(l)}function Y(l){return l==="all"||l==="with_images"}function Ge(l){return l==="with_images"?"AI images":"All"}function X(l){return l==="all"||l==="keyword"||l==="meaning"}function Ue(l){return l==="keyword"?"Keyword":l==="meaning"?"Meaning":"All"}const Ve=.2;function Z(l){return JSON.stringify(l.map(e=>[e.docId,e.title,e.snippet,e.platform,e.starred,e.hasImages,e.updatedAt,e.createdAt,e.lastOpenedAt??0,e.matchedByMeaning===!0,e.models??[],e.scheduledTaskRun===!0,e.localTitle??""]))}function F(l){return l.matchedByMeaning===!0?!0:typeof l.semanticScore=="number"&&l.semanticScore>=Ve}function Qe(l){return l==="opened_desc"?"Last opened":l==="modified_asc"?"Oldest":"Last modified"}function g(l){return l.replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;").replaceAll('"',"&quot;").replaceAll("'","&#39;")}function je(l){return l.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")}function Ke(){const l=Le();return`
    <div class="shortcuts-sheet-header">
      <span class="shortcuts-sheet-title">Search help and shortcuts</span>
      <button class="shortcuts-close" type="button" aria-label="Close search help">Done</button>
    </div>
    <div class="shortcuts-sheet-body">
      <div class="shortcuts-group search-guide">
        <div class="shortcuts-group-title">How search works</div>
        <table class="search-guide-table">
          <thead><tr><th scope="col">Search choice</th><th scope="col">What it does</th></tr></thead>
          <tbody>
            <tr><th scope="row">Normal search</th><td>Prefers all words, but may show word beginnings or fewer words.</td></tr>
            <tr><th scope="row">All words</th><td>Requires every searchable word as a whole word in the same conversation.</td></tr>
            <tr><th scope="row"><code>AND</code>, <code>OR</code>, <code>NOT</code>, <code>+</code>, <code>*</code>, quotes</th><td>These are not search operators. Quotes do not force an exact phrase.</td></tr>
          </tbody>
        </table>
        <p>For example, open <strong>Filters</strong>, choose <strong>Words: All words</strong> and search <strong>solar battery</strong> to require both words, in any order. They can appear in the title or different messages of one conversation.</p>
        <p>Search ignores case. Common English words (for example, <strong>the</strong>, <strong>and</strong>, <strong>of</strong>) and single characters are ignored. Punctuation separates words. Whole-word matching means <strong>battery</strong> does not match <strong>batteries</strong>.</p>
        <p>Meaning-based suggestions can appear in normal search when enabled in Settings. All words keeps the list empty if nothing qualifies. Remove the <strong>All words</strong> chip to broaden your search. The option resets when you close search.</p>
        <p>Filters narrow results by platform, last updated date, starred chats or AI images. Sort changes the order. Clear the query to browse recent chats. Only indexed content is searchable.</p>
        <p>The popup's quick search uses normal search. Open full search for All words and filters.</p>
      </div>
      <p class="shortcuts-note">Global shortcuts below are defaults. Check or change your bindings at <strong>chrome://extensions/shortcuts</strong>.</p>
      ${Me.map(t=>{const s=t.items.map(a=>{const r=l?a.keys.mac:a.keys.other,o=a.sequence?'<span class="shortcuts-sep word">then</span>':'<span class="shortcuts-sep">/</span>',n=r.map(d=>d.map(h=>`<kbd>${g(h)}</kbd>`).join("")).join(o),c=a.note?`<span class="shortcuts-note">${g(a.note)}</span>`:"";return`
          <li class="shortcuts-row">
            <span class="shortcuts-label">${g(a.label)}${c}</span>
            <span class="shortcuts-keys">${n}</span>
          </li>`}).join("");return`
      <div class="shortcuts-group">
        <div class="shortcuts-group-title">${g(t.title)}</div>
        <ul class="shortcuts-list">${s}</ul>
      </div>`}).join("")}
    </div>`}function q(l,e){const t=g(l);if(!e)return t;const s=e.toLowerCase().split(/[^a-z0-9]+/g).filter(r=>r.length>=2);if(!s.length)return t;const a=new RegExp(`(${s.map(je).join("|")})`,"gi");return t.replace(a,"<mark>$1</mark>")}function Ye(l){return new Date(l).toLocaleString(void 0,{year:"numeric",month:"short",day:"numeric",hour:"numeric",minute:"2-digit"})}function J(l){const e=l.platform==="zai"&&!l.localTitle?Se(l.title,l.snippet):l.title;return l.platform==="claude_code"&&l.scheduledTaskRun&&!l.localTitle?ve(e,l.createdAt):e}const Xe=["chatgpt","claude","claude_code","codex","zcode","gemini","google_ai_mode","ai_studio","deepseek","perplexity","grok","zai","mistral","kimi","qwen","copilot","meta_ai","character_ai"],H=new Set(["anthropic_console","generic"]);function Ze(l){try{return new URL(l).hostname.toLowerCase()}catch{return null}}function Je(l){if(l.platform!=="grok")return L(l.platform).label;const e=Ze(l.url);return e==="x.com"||e==="www.x.com"||e==="mobile.x.com"||e==="twitter.com"||e==="www.twitter.com"||e==="mobile.twitter.com"?"Grok/X":e==="grok.com"||e==="www.grok.com"?"Grok.com":L(l.platform).label}function et(l){const e=l.models?.filter(Boolean)??[];return e.length===0?"":e.length===1?e[0]:`${e[0]} +${e.length-1}`}function tt(l){const e=ge(l.captureProvenance);return e?`<span class="platform-pill provenance-pill">${g(e)}</span>`:""}function M(l){return Number.isFinite(l.lastOpenedAt)?l.lastOpenedAt:Number.isFinite(l.lastSeenAt)?l.lastSeenAt:l.indexedAt}class mt{host=null;openState=!1;inputEl=null;clearEl=null;filtersToggleEl=null;allWordsChipEl=null;quickClearFiltersEl=null;starredToggleEl=null;controlsEl=null;recentsRowEl=null;sortRowEl=null;matchRowEl=null;filterMenuMatchRowVisible=null;platformChipsEl=null;platformScrollViewportEl=null;platformScrollBackEl=null;platformScrollForwardEl=null;activeFiltersEl=null;resultsEl=null;firstSearchSuggestionsEl=null;firstSearchTerms=[];firstSearchSuggestionRequest=0;resultQuery="";resultSearchId;statusEl=null;paginationEl=null;newerPageEl=null;olderPageEl=null;countMenuEl=null;showCountMenu=!1;preserveResultsView=!1;renderedDocIds=[];searchHintEl=null;emailPromptEl=null;emailPromptTitleEl=null;emailPromptCopyEl=null;emailPromptBenefitsEl=null;emailPromptTrustEl=null;emailPromptInputEl=null;emailPromptSubmitEl=null;emailPromptDismissEl=null;emailPromptStatusEl=null;emailPromptErrorEl=null;emailPromptSuccessEl=null;emailPromptBusy=!1;emailPromptMode="none";emailPromptSuccessTimer;searchTimer;searchHistorySaveTimer;pendingHistoryQuery="";focusTimer;searchRequestId=0;rawResults=[];matchedBeforeUserFilters=0;results=[];currentQuery="";recentsSortMode="modified_desc";recentLimit=ee;recentOffset=0;hasMoreRecentResults=!1;sortMode="best_match";updatedWindow="any";platformFilters=new Set;mediaFilter="all";matchFilter="all";matchAllWords=!1;starredOnly=!1;showFilters=!1;preferencesLoaded=!1;preferencesLoadPromise=null;selectedIndex=0;resultsCollapsed=!1;attachRetryTimer;deletingDocIds=new Set;helpToggleEl=null;shortcutsSheetEl=null;shortcutsSheetOpen=!1;backfillBarEl=null;backfillBarFillEl=null;backfillBarFadeTimer;backfillHintEl=null;backfillLiveRefreshTimer;indexNudgeConvCount=-1;indexNudgeHasRun=!1;searchGateActive=!1;searchGateProgress=null;searchGateDismissedForQuery=null;indexedConversationCount=-1;claudeCodeNudgeArmedQuery=null;claudeCodeNudgeCheckedQuery=null;backfillActive=!1;get currentBackfillPlatform(){return be(window.location.href,de())}importCtaPending=!1;importCtaImpressionFired=!1;importCtaError="";importCtaNotice="";pinHintVisible=!1;pinHintChecked=!1;pinHintEl=null;degradedIndexWarningEl=null;degradedIndexWarningFired=!1;indexHealthRequest=0;searchHistory=[];historyNavIndex=-1;historyToggleEl=null;historyDropdownEl=null;showHistoryDropdown=!1;orgState=null;orgSelection=new Set;orgLabels=new Map;orgScopeEmpty=!1;orgScopeRowEl=null;orgScopeChipsEl=null;orgScopeMixEl=null;orgScopeHintEl=null;organiserBarEl=null;organiserCountEl=null;organiserGoEl=null;orgScopeMixVisible=!1;viewGeneration=0;stateRequestId=0;onOrganisationBroadcast=e=>{typeof e=="object"&&e!==null&&e.type==="ORGANISATION_CHANGED"&&(this.invalidateOrganisationView(),this.refreshOrganisationState().then(()=>{this.openState&&this.scheduleSearch(0)}))};replaceSelection(e){if(!this.inputEl)return;const t=this.inputEl.value,s=this.inputEl.selectionStart??t.length,a=this.inputEl.selectionEnd??t.length;this.inputEl.value=`${t.slice(0,s)}${e}${t.slice(a)}`;const r=s+e.length;this.inputEl.setSelectionRange(r,r)}applyBackspace(e){if(!this.inputEl)return;const t=this.inputEl.value,s=this.inputEl.selectionStart??t.length,a=this.inputEl.selectionEnd??t.length;if(s!==a){this.replaceSelection(""),this.scheduleSearch();return}if(s===0)return;let r=s-1;if(e){for(;r>0&&/\s/.test(t[r-1]);)r-=1;for(;r>0&&!/\s/.test(t[r-1]);)r-=1}this.inputEl.value=`${t.slice(0,r)}${t.slice(a)}`,this.inputEl.setSelectionRange(r,r),this.scheduleSearch()}applyDelete(){if(!this.inputEl)return;const e=this.inputEl.value,t=this.inputEl.selectionStart??e.length,s=this.inputEl.selectionEnd??e.length;if(t!==s){this.replaceSelection(""),this.scheduleSearch();return}t>=e.length||(this.inputEl.value=`${e.slice(0,t)}${e.slice(t+1)}`,this.inputEl.setSelectionRange(t,t),this.scheduleSearch())}onWindowKeydownCapture=e=>{if(!this.openState)return;const t=e.composedPath(),s=this.inputEl?t.includes(this.inputEl):!1,a=this.emailPromptInputEl?t.includes(this.emailPromptInputEl):!1,r=t.some(f=>f instanceof HTMLElement&&f.classList.contains("rename-editor")),o=t.some(f=>f instanceof HTMLElement&&f.classList.contains("rename-editor-action")),n=t.some(f=>f instanceof HTMLElement?f.classList.contains("email-prompt-submit")||f.classList.contains("email-prompt-dismiss"):!1),c=t.some(f=>f instanceof HTMLElement?f.classList.contains("control-chip")||f.classList.contains("filters-toggle")||f.classList.contains("all-words-chip")||f.classList.contains("reset-filters")||f.classList.contains("panel-help")||f.classList.contains("shortcuts-close")||f.classList.contains("clear"):!1),d=e.key,h=d.toLowerCase(),m=d.length===1&&!e.metaKey&&!e.ctrlKey&&!e.altKey,u=d==="Backspace",w=d==="Delete",b=d==="ArrowDown",p=d==="ArrowUp",x=d==="Enter",S=d==="Escape",E=d==="Tab",C=(e.metaKey||e.ctrlKey)&&h==="a";if(!(m||u||w||b||p||x||S||E||C))return;const $=d==="?"&&!e.metaKey&&!e.ctrlKey&&!e.altKey;if(this.shortcutsSheetOpen){if(e.stopImmediatePropagation(),e.stopPropagation(),S||$){e.preventDefault(),this.toggleShortcutsSheet(!1);return}c||e.preventDefault();return}if($&&!a&&!n&&!r&&(this.inputEl?.value??"")===""){e.stopImmediatePropagation(),e.stopPropagation(),e.preventDefault(),this.toggleShortcutsSheet(!0);return}if(n){e.stopImmediatePropagation(),e.stopPropagation(),S&&(e.preventDefault(),this.close());return}if(a){e.stopImmediatePropagation(),e.stopPropagation(),S&&(e.preventDefault(),this.close());return}if(r){e.stopImmediatePropagation(),e.stopPropagation(),S?(e.preventDefault(),this.resultsEl?.querySelector(".rename-cancel")?.click()):x&&!o&&(e.preventDefault(),this.resultsEl?.querySelector(".rename-editor")?.requestSubmit());return}if(c){e.stopImmediatePropagation(),e.stopPropagation(),S&&(e.preventDefault(),this.close());return}if(s){if(e.stopImmediatePropagation(),e.stopPropagation(),(b||p||x||S)&&e.preventDefault(),S){if(this.showCountMenu){this.closeCountMenu();return}if(this.showHistoryDropdown){this.closeHistoryDropdown();return}this.close();return}if(b){this.moveSelection(1);return}if(p){this.moveSelection(-1);return}x&&this.openSelected(!0,!1,e.altKey);return}if(e.stopImmediatePropagation(),e.stopPropagation(),e.preventDefault(),S){if(this.showCountMenu){this.closeCountMenu();return}if(this.showHistoryDropdown){this.closeHistoryDropdown();return}this.close();return}if(b){this.moveSelection(1);return}if(p){this.moveSelection(-1);return}if(x){this.openSelected(!0,!1,e.altKey);return}if(E){this.focusInput();return}if(this.inputEl){if(C){this.focusInput(),this.inputEl.select();return}if(this.focusInput(),u){this.applyBackspace(e.altKey);return}if(w){this.applyDelete();return}m&&(this.historyNavIndex=-1,this.replaceSelection(d),this.scheduleSearch())}};scheduleAttachRetry(){typeof this.attachRetryTimer!="number"&&(this.attachRetryTimer=window.setTimeout(()=>{this.attachRetryTimer=void 0,this.attach()},40))}attach(){chrome.runtime.onMessage.addListener(this.onOrganisationBroadcast);const e=document.documentElement??document.body;if(!e){this.scheduleAttachRetry();return}for(const o of Array.from(document.querySelectorAll("[data-llmnesia-overlay]")))o!==this.host&&o.remove();if(this.host)return;typeof this.attachRetryTimer=="number"&&(window.clearTimeout(this.attachRetryTimer),this.attachRetryTimer=void 0);const t=document.createElement("div");t.setAttribute("data-llmnesia-overlay","true"),t.style.all="initial",t.style.position="fixed",t.style.inset="0",t.style.zIndex="2147483647",t.style.display="none",t.style.pointerEvents="auto";const s=t.attachShadow({mode:"open"});s.innerHTML=`
      <style>
        :host { all: initial; }
        .backdrop {
          position: fixed;
          inset: 0;
          display: grid;
          place-items: start center;
          padding-top: min(11vh, 88px);
          background: rgba(8, 10, 12, 0.24);
          font-family: "IBM Plex Sans", "SF Pro Text", "Segoe UI", sans-serif;
        }
        .panel {
          position: relative;
          width: min(600px, calc(100vw - 24px));
          background: ${i.card};
          color: ${i.ink};
          border: 1px solid ${i.rule};
          border-radius: ${i.rMd};
          box-shadow:
            0 22px 50px -28px rgba(20, 36, 48, 0.2),
            0 18px 42px rgba(0, 0, 0, 0.2),
            inset 0 1px 0 rgba(255, 255, 255, 0.5);
          overflow: hidden;
        }
        .panel.help-open { height: min(620px, calc(100vh - 120px)); }
        .panel-header {
          display: flex;
          align-items: center;
          gap: 8px;
          padding: 7px 12px;
          border-bottom: 1px solid ${i.rule};
          background: ${i.paper};
        }
        .panel-dot {
          width: 7px;
          height: 7px;
          border-radius: 50%;
          background: ${i.onEdge};
          box-shadow: 0 0 0 3px rgba(154, 180, 88, 0.18);
        }
        .panel-brand {
          color: ${i.ink};
          font-size: 12px;
          font-weight: 600;
          line-height: 1;
        }
        .panel-help {
          margin-left: auto;
          width: 18px;
          height: 18px;
          padding: 0;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          border: 1px solid ${i.rule};
          border-radius: 50%;
          background: ${i.paperSoft};
          color: ${i.ink3};
          font-family: "IBM Plex Mono", "SF Mono", "Consolas", monospace;
          font-size: 11px;
          font-weight: 600;
          line-height: 1;
          cursor: pointer;
          transition: color 0.12s ease, border-color 0.12s ease, background 0.12s ease;
        }
        .panel-help:hover {
          color: ${i.teal};
          border-color: ${i.tealEdge};
          background: ${i.tealSoft};
        }
        .panel-kbd {
          margin-left: 6px;
          border: 1px solid ${i.rule};
          border-bottom-width: 2px;
          border-radius: 4px;
          padding: 3px 6px;
          color: ${i.ink3};
          background: ${i.paperSoft};
          font-family: "IBM Plex Mono", "SF Mono", "Consolas", monospace;
          font-size: 10.5px;
          line-height: 1;
          letter-spacing: 0;
        }
        .input-wrap {
          padding: 11px 12px 9px;
          border-bottom: 1px solid ${i.ruleSoft};
          background: ${i.card};
          position: relative;
        }
        .search {
          width: 100%;
          min-width: 0;
          border: 0;
          box-sizing: border-box;
          padding: 0;
          font-size: 15px;
          font-weight: 500;
          line-height: 1.3;
          outline: none;
          background: transparent;
          color: #11222f;
        }
        .search::placeholder {
          color: ${i.ink3};
          font-weight: 400;
        }
        .search-row {
          display: flex;
          align-items: center;
          gap: 8px;
          position: relative;
        }
        .search-hint {
          display: flex;
          align-items: center;
          gap: 6px;
          margin-top: 7px;
          color: ${i.ink3};
          font-family: "IBM Plex Mono", "SF Mono", "Consolas", monospace;
          font-size: 10.5px;
          line-height: 1.3;
          letter-spacing: 0;
        }
        .search-hint .dot-sep {
          opacity: 0.5;
        }
        kbd {
          border: 1px solid ${i.ruleSoft};
          border-bottom-width: 2px;
          border-radius: 3px;
          padding: 1px 4px;
          background: ${i.paperSoft};
          color: ${i.ink3};
          font-family: "IBM Plex Mono", "SF Mono", "Consolas", monospace;
          font-size: 10px;
          line-height: 1;
        }
        .backfill-bar {
          position: absolute;
          bottom: -1px;
          left: 0;
          right: 0;
          height: 2px;
          overflow: hidden;
          opacity: 0;
          transition: opacity 0.3s ease;
          pointer-events: none;
          z-index: 1;
        }
        .backfill-bar.visible {
          opacity: 1;
        }
        .backfill-bar-fill {
          height: 100%;
          width: 0%;
          background: linear-gradient(90deg, #2f7f99, #49b08f);
          transition: width 0.6s ease;
        }
        .backfill-bar.indeterminate .backfill-bar-fill {
          width: 100% !important;
          background: linear-gradient(90deg, transparent 0%, #2f7f99 30%, #49b08f 60%, transparent 100%);
          background-size: 200% 100%;
          animation: backfill-shimmer 1.6s linear infinite;
          transition: none;
        }
        @keyframes backfill-shimmer {
          0%   { background-position: 200% 0; }
          100% { background-position: -200% 0; }
        }
        .backfill-hint {
          font-size: 11px;
          color: #3fa882;
          padding: 3px 14px 0;
          height: 0;
          overflow: hidden;
          opacity: 0;
          transition: height 0.2s ease, opacity 0.2s ease;
          white-space: nowrap;
          letter-spacing: 0.01em;
        }
        .backfill-hint.visible {
          height: 18px;
          opacity: 1;
        }
        .search-actions {
          display: inline-flex;
          align-items: center;
          flex-shrink: 0;
          gap: 3px;
        }
        .filters-toggle,
        .clear,
        .history-toggle {
          width: 24px;
          height: 24px;
          border: 1px solid transparent;
          background: transparent;
          color: ${i.ink3};
          border-radius: 6px;
          font-size: 0;
          line-height: 1;
          padding: 0;
          cursor: pointer;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          transition: background-color 120ms ease, border-color 120ms ease, color 120ms ease, box-shadow 120ms ease;
        }
        .filters-toggle::before,
        .clear::before {
          content: "";
          width: 14px;
          height: 14px;
          display: block;
          background: currentColor;
        }
        .filters-toggle::before {
          -webkit-mask: url("data:image/svg+xml,%3Csvg width='14' height='14' viewBox='0 0 14 14' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M2 4h10M4.2 7h5.6M5.6 10h2.8' stroke='black' stroke-width='1.5' stroke-linecap='round'/%3E%3C/svg%3E") center / 14px 14px no-repeat;
          mask: url("data:image/svg+xml,%3Csvg width='14' height='14' viewBox='0 0 14 14' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M2 4h10M4.2 7h5.6M5.6 10h2.8' stroke='black' stroke-width='1.5' stroke-linecap='round'/%3E%3C/svg%3E") center / 14px 14px no-repeat;
        }
        .clear::before {
          width: 13px;
          height: 13px;
          background:
            linear-gradient(45deg, transparent 43%, currentColor 43%, currentColor 57%, transparent 57%),
            linear-gradient(-45deg, transparent 43%, currentColor 43%, currentColor 57%, transparent 57%);
        }
        .filters-toggle:hover,
        .clear:not(:disabled):hover,
        .history-toggle:hover {
          background: ${i.paperSoft};
          border-color: ${i.ruleSoft};
          color: ${i.ink};
          box-shadow: none;
        }
        .filters-toggle.active {
          border-color: ${i.tealEdge};
          background: ${i.tealSoft};
          color: ${i.teal};
        }
        .search-meta { display: flex; align-items: center; flex-wrap: wrap; gap: 6px; margin-top: 7px; min-height: 18px; }
        .search-meta .search-hint { margin-top: 0; }
        .all-words-chip { margin-left: auto; align-items: center; gap: 6px; cursor: pointer; }
        .all-words-chip[hidden] { display: none; }
        .all-words-chip:hover { border-color: ${i.teal}; }
        .search-guide { font-size: 12.5px; }
        .search-guide p { margin: 8px 0; line-height: 1.5; }
        .search-guide-table { width: 100%; border-collapse: collapse; line-height: 1.4; }
        .search-guide-table th, .search-guide-table td {
          padding: 7px 8px;
          border: 1px solid ${i.ruleSoft};
          text-align: left;
          vertical-align: top;
        }
        .search-guide-table th { font-weight: 600; background: ${i.paperSoft}; }
        .search-guide-table code { font-size: 11px; white-space: nowrap; }
        /* Auto-hint: pulse the collapsed Filters badge when active filters are
           the reason the result list is empty, so the cause is obvious even
           without reading the empty-state copy. */
        .filters-toggle.attention {
          border-color: ${i.tealEdge};
          color: ${i.teal};
          animation: filters-attention 1.1s ease-in-out 3;
        }
        @keyframes filters-attention {
          0%, 100% { background: ${i.tealSoft}; box-shadow: none; }
          50% { background: ${i.tealSoft}; box-shadow: 0 0 0 3px rgba(47, 127, 153, 0.22); }
        }
        @media (prefers-reduced-motion: reduce) {
          .filters-toggle.attention { animation: none; }
        }
        /* Always-visible one-click star filter, so "Starred only" isn't buried in
           the Filters panel. Muted by default, solid gold when active — mirrors
           the per-row star buttons. */
        .starred-toggle {
          width: 24px;
          height: 24px;
          border: 1px solid transparent;
          background: transparent;
          color: #97a3ab;
          border-radius: 6px;
          font-size: 14px;
          line-height: 1;
          padding: 0;
          cursor: pointer;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          transition: background-color 120ms ease, border-color 120ms ease, color 120ms ease, box-shadow 120ms ease;
        }
        .starred-toggle:hover {
          background: ${i.paperSoft};
          border-color: ${i.ruleSoft};
          color: #e0a500;
        }
        .starred-toggle.active {
          color: #f2b705;
          border-color: rgba(242, 183, 5, 0.5);
          background: rgba(242, 183, 5, 0.14);
        }
        .clear:disabled {
          opacity: 0.4;
          cursor: default;
          pointer-events: none;
        }
        .history-wrapper {
          position: relative;
        }
        .history-toggle {
          opacity: 0.72;
        }
        /* The base rule above gives this button an author-level display
           value, which beats the UA's [hidden] { display: none }. Without
           this, the toggle stays visible with an empty history and clicking
           it opens a collapsed, thin-line dropdown box (issue #8). */
        .history-toggle[hidden] {
          display: none;
        }
        .history-toggle.open {
          opacity: 1;
          background: ${i.paperSoft};
          border-color: ${i.ruleSoft};
          color: ${i.ink};
        }
        .history-dropdown {
          position: absolute;
          top: calc(100% + 6px);
          right: 0;
          background: #fff;
          border: 1px solid #dce5dd;
          border-radius: 12px;
          min-width: 200px;
          max-width: 320px;
          max-height: 260px;
          overflow-y: auto;
          z-index: 20;
          box-shadow: 0 12px 28px rgba(17, 24, 39, 0.14);
        }
        .history-item {
          display: flex;
          align-items: center;
          gap: 6px;
          padding: 7px 10px;
          cursor: pointer;
          font-size: 12.5px;
          color: #2f4654;
        }
        .history-item:hover {
          background: #f8faf7;
        }
        .history-item:first-child {
          border-radius: 10px 10px 0 0;
        }
        .history-item:last-child {
          border-radius: 0 0 10px 10px;
        }
        .history-item:only-child {
          border-radius: 10px;
        }
        .history-item-text {
          flex: 1;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }
        .history-item-remove {
          flex-shrink: 0;
          background: none;
          border: none;
          cursor: pointer;
          color: #aab8a0;
          padding: 1px 3px;
          font-size: 14px;
          line-height: 1;
          border-radius: 4px;
        }
        .history-item-remove:hover {
          color: #2f4654;
          background: #eef3ed;
        }
        .email-prompt {
          display: none;
          border-bottom: 1px solid #dbe7ff;
          border-top: 1px solid #c8dbff;
          background:
            radial-gradient(120% 120% at 0% 0%, #edf5ff 0%, rgba(237, 245, 255, 0.6) 48%, transparent 100%),
            linear-gradient(125deg, #f9fbff 0%, #eef4ff 100%);
          padding: 12px 13px 11px;
          gap: 9px;
          position: relative;
        }
        .email-prompt::before {
          content: "";
          position: absolute;
          left: 0;
          top: 0;
          bottom: 0;
          width: 4px;
          background: linear-gradient(180deg, #3b82f6, #06b6d4);
        }
        .email-prompt[data-visible="true"] {
          display: grid;
        }
        .email-prompt-title {
          font-size: 13px;
          font-weight: 700;
          color: #17365c;
          letter-spacing: 0.01em;
        }
        .email-prompt-copy {
          font-size: 12px;
          color: #3f5775;
          line-height: 1.35;
        }
        .email-prompt-benefits {
          display: flex;
          flex-wrap: wrap;
          gap: 5px;
        }
        .email-prompt-benefit {
          display: inline-flex;
          align-items: center;
          border: 1px solid #cdd9f5;
          background: rgba(255, 255, 255, 0.86);
          color: #34557b;
          border-radius: 999px;
          font-size: 10px;
          line-height: 1;
          padding: 4px 8px;
          font-weight: 600;
          white-space: nowrap;
        }
        .email-prompt-form {
          display: flex;
          gap: 6px;
          flex-wrap: wrap;
          align-items: center;
        }
        .email-prompt-input {
          flex: 1 1 220px;
          min-width: 160px;
          border: 1px solid #b7c8ea;
          border-radius: 8px;
          padding: 6px 8px;
          font-size: 12px;
          color: #17365c;
          background: #fff;
          outline: none;
        }
        .email-prompt-input:focus {
          border-color: #3b82f6;
          box-shadow: 0 0 0 2px rgba(59, 130, 246, 0.17);
        }
        .email-prompt-submit,
        .email-prompt-dismiss {
          border-radius: 8px;
          font-size: 11px;
          line-height: 1.2;
          padding: 6px 10px;
          cursor: pointer;
        }
        .email-prompt-submit {
          border: 1px solid #2f6cc6;
          background: linear-gradient(135deg, #4f8cf8, #2f6cd6);
          color: #eef5ff;
          font-weight: 700;
          transition: transform 120ms ease, box-shadow 120ms ease;
        }
        .email-prompt-submit:not(:disabled):hover {
          transform: translateY(-1px);
          box-shadow: 0 4px 12px rgba(47, 108, 214, 0.24);
        }
        .email-prompt-dismiss {
          border: 1px solid #cfd8e8;
          background: rgba(255, 255, 255, 0.86);
          color: #3f5572;
        }
        .email-prompt-submit:disabled,
        .email-prompt-dismiss:disabled {
          opacity: 0.72;
          cursor: default;
        }
        .email-prompt-status {
          display: none;
          align-items: center;
          gap: 7px;
          min-height: 14px;
          color: #3f5f87;
          font-size: 11px;
        }
        .email-prompt-status[data-visible="true"] {
          display: inline-flex;
        }
        .email-prompt-status[data-busy="true"]::before {
          content: "";
          width: 11px;
          height: 11px;
          border-radius: 50%;
          border: 2px solid rgba(47, 108, 214, 0.22);
          border-top-color: #2f6cd6;
          animation: email-prompt-spin 0.8s linear infinite;
        }
        .email-prompt-error {
          min-height: 13px;
          color: #b42318;
          font-size: 11px;
        }
        .email-prompt-success {
          display: none;
          border: 1px solid #bfd5ff;
          background: linear-gradient(130deg, #f4f8ff, #edf4ff);
          color: #294e7b;
          border-radius: 8px;
          padding: 9px 10px;
          font-size: 11px;
          line-height: 1.35;
          box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.65);
        }
        .email-prompt-success[data-visible="true"] {
          display: flex;
          align-items: flex-start;
          gap: 7px;
        }
        .email-prompt-success[data-visible="true"]::before {
          content: "✓";
          font-size: 12px;
          line-height: 1.2;
          font-weight: 700;
          color: #2f6cd6;
        }
        .email-prompt-trust {
          font-size: 10px;
          color: #627595;
          line-height: 1.35;
        }
        @keyframes email-prompt-spin {
          from {
            transform: rotate(0deg);
          }
          to {
            transform: rotate(360deg);
          }
        }
        .reset-filters {
          flex: 0 0 auto;
          border: 1px solid ${i.ruleSoft};
          background: transparent;
          color: ${i.ink2};
          border-radius: 6px;
          font-size: 10px;
          line-height: 1.2;
          font-weight: 600;
          padding: 3px 9px;
          cursor: pointer;
          white-space: nowrap;
          transition: background-color 120ms ease, border-color 120ms ease, color 120ms ease;
        }
        .reset-filters:hover:not(:disabled) {
          border-color: rgba(47, 127, 153, 0.3);
          background: rgba(230, 240, 243, 0.6);
          color: ${i.ink};
        }
        .reset-filters[hidden] {
          display: none;
        }
        .reset-filters:disabled { opacity: 0.4; cursor: default; }
        .status {
          min-width: 0;
          overflow: hidden;
          color: ${i.ink2};
          text-overflow: ellipsis;
          white-space: nowrap;
        }
        .count-pick {
          font: inherit;
          color: ${i.teal};
          background: none;
          border: none;
          padding: 0;
          margin: 0;
          cursor: pointer;
          border-radius: 0;
        }
        .count-pick:hover {
          color: ${i.ink};
        }
        /* Persistent, high-contrast marker in the footer count so a narrowed
           result set never reads as "everything" — the plain " · filtered"
           text was too easy to miss. Clicking it opens the filters panel. */
        .filtered-badge {
          display: inline-flex;
          align-items: center;
          gap: 5px;
          font: inherit;
          font-size: 9.5px;
          font-weight: 700;
          line-height: 1;
          text-transform: uppercase;
          letter-spacing: 0.4px;
          color: ${i.paper};
          background: ${i.teal};
          border: none;
          border-radius: 999px;
          padding: 3px 8px;
          margin-left: 8px;
          cursor: pointer;
          vertical-align: middle;
          transition: filter 120ms ease;
        }
        .filtered-badge:hover {
          filter: brightness(1.08);
        }
        .filtered-badge::before {
          content: "";
          width: 6px;
          height: 6px;
          border-radius: 50%;
          background: currentColor;
        }
        .count-menu {
          position: absolute;
          left: 10px;
          bottom: calc(100% + 4px);
          display: flex;
          flex-direction: column;
          background: #fff;
          border: 1px solid #dce5dd;
          border-radius: 10px;
          overflow: hidden;
          z-index: 20;
          box-shadow: 0 12px 28px rgba(17, 24, 39, 0.16);
        }
        .count-menu[hidden] {
          display: none;
        }
        .count-option {
          font-family: "IBM Plex Mono", "SF Mono", "Consolas", monospace;
          font-size: 11px;
          text-align: left;
          min-width: 88px;
          padding: 7px 12px;
          background: none;
          border: none;
          cursor: pointer;
          color: ${i.ink2};
        }
        .count-option:hover {
          background: #f8faf7;
        }
        .count-option.selected {
          color: ${i.teal};
          font-weight: 600;
        }
        .controls {
          display: none;
          flex-wrap: wrap;
          column-gap: 10px;
          row-gap: 6px;
          align-items: center;
          min-width: 0;
          max-height: 140px;
          overflow-x: hidden;
          overflow-y: auto;
          scrollbar-gutter: stable;
          overflow-anchor: none;
          padding: 6px 10px;
          border-bottom: 1px solid ${i.ruleSoft};
          background: linear-gradient(180deg, ${i.card}, ${i.paper});
        }
        /* Groups flow and wrap to fill the row; the platform list (many chips)
           and the footer each take their own full line. */
        .controls .platform-row,
        .controls .filters-footer {
          flex-basis: 100%;
        }
        .control-row {
          display: flex;
          flex: 0 1 auto;
          flex-wrap: nowrap;
          gap: 4px;
          align-items: center;
          min-width: 0;
          max-width: 100%;
          overflow-x: auto;
          padding: 2px 4px;
          border: 1px solid ${i.ruleSoft};
          border-radius: 7px;
          background: ${i.card};
          scrollbar-width: none;
        }
        .control-row.has-active-choice { border-color: ${i.tealEdge}; }
        .control-row.has-active-choice .control-label { color: ${i.tealDark}; }
        .control-row::-webkit-scrollbar {
          display: none;
        }
        .platform-chips {
          display: inline-flex;
          flex-wrap: nowrap;
          gap: 4px;
          min-width: max-content;
        }
        .scope-chips,
        .scope-mix {
          display: inline-flex;
          flex-wrap: wrap;
          gap: 4px;
        }
        /* display:flex above would beat the UA's [hidden] rule; without these
         * the empty organiser bar and scope rows would always paint. */
        .organise-bar[hidden],
        .scope-row[hidden],
        .scope-mix-row[hidden] {
          display: none;
        }
        .scope-chip,
        .scope-mix-chip {
          flex: 0 1 auto;
          white-space: nowrap;
        }
        .scope-chip[data-active="true"] {
          border-color: ${i.teal};
          background: ${i.tealSoft};
          color: ${i.tealDark};
          font-weight: 600;
        }
        .scope-mix-chip[data-checked="true"] {
          border-color: ${i.teal};
          background: ${i.tealSoft};
        }
        .organise-bar {
          display: flex;
          align-items: center;
          gap: 8px;
          padding: 8px 16px;
          border-top: 1px solid ${i.ruleSoft};
          font-size: 12.5px;
        }
        .organise-count {
          color: ${i.teal};
          font-weight: 600;
        }
        .organise-go {
          padding: 5px 10px;
          border: 1px solid ${i.teal};
          border-radius: 999px;
          background: ${i.teal};
          color: #fff;
          font-weight: 600;
          cursor: pointer;
        }
        .organise-go:disabled {
          opacity: 0.6;
          cursor: default;
        }
        .organise-clear {
          padding: 5px 10px;
          border: 1px solid ${i.ruleSoft};
          border-radius: 999px;
          background: ${i.card};
          color: ${i.ink};
          cursor: pointer;
        }
        .space-pill {
          font-size: 10px;
          padding: 1px 6px;
          border: 1px solid ${i.ruleSoft};
          border-radius: 999px;
          background: ${i.tealSoft};
          color: ${i.teal};
          white-space: nowrap;
        }
        .select-btn {
          flex: 0 0 auto;
          width: 18px;
          height: 18px;
          margin: 10px 0 0 10px;
          border: 1.5px solid ${i.ruleSoft};
          border-radius: 5px;
          background: ${i.card};
          cursor: pointer;
          padding: 0;
        }
        .select-btn[data-checked="true"] {
          border-color: ${i.teal};
          background: ${i.teal};
        }
        .select-btn[data-checked="true"]::after {
          content: "\\2713";
          display: block;
          color: #fff;
          font-size: 12px;
          line-height: 15px;
        }
        .scope-empty-note {
          padding: 14px 16px;
          font-size: 13px;
        }
        .scope-empty-note button {
          margin-left: 8px;
          padding: 4px 10px;
          border: 1px solid ${i.teal};
          border-radius: 999px;
          background: ${i.card};
          color: ${i.teal};
          cursor: pointer;
        }
        .platform-row {
          overflow: hidden;
        }
        .platform-scroll-viewport {
          flex: 1 1 auto;
          min-width: 0;
          overflow-x: auto;
          overscroll-behavior-inline: contain;
          scroll-behavior: smooth;
          scrollbar-width: none;
        }
        .platform-scroll-viewport::-webkit-scrollbar {
          display: none;
        }
        .platform-scroll-button {
          display: inline-flex;
          flex: 0 0 auto;
          align-items: center;
          justify-content: center;
          width: 22px;
          height: 22px;
          padding: 0;
          border: 1px solid ${i.ruleSoft};
          border-radius: 999px;
          background: ${i.card};
          color: ${i.teal};
          font: 700 15px/1 "IBM Plex Sans", sans-serif;
          cursor: pointer;
        }
        .platform-scroll-button:hover:not(:disabled) {
          border-color: ${i.tealEdge};
          background: ${i.tealSoft};
        }
        .platform-scroll-button:disabled {
          opacity: 0.28;
          cursor: default;
        }
        .control-label {
          color: ${i.ink3};
          flex: 0 0 auto;
          font-family: "IBM Plex Mono", "SF Mono", "Consolas", monospace;
          font-size: 9px;
          font-weight: 700;
          text-transform: uppercase;
          letter-spacing: 0.5px;
          border-right: 1px solid ${i.rule};
          padding: 0 6px 0 2px;
          margin-right: 2px;
        }
        .control-chip {
          flex: 0 0 auto;
          border: 1px solid transparent;
          background: transparent;
          color: ${i.ink2};
          border-radius: 6px;
          font-size: 10.5px;
          font-weight: 500;
          line-height: 1.2;
          padding: 2px 6px;
          cursor: pointer;
          transition: background-color 120ms ease, border-color 120ms ease, color 120ms ease;
        }
        .control-chip:hover {
          border-color: ${i.ruleSoft};
          background: rgba(250, 246, 228, 0.72);
        }
        .control-chip.selected {
          border-color: ${i.rule};
          background: #eef1ec;
          color: ${i.ink};
        }
        .control-chip.filter-active { border-color: ${i.tealDark}; background: ${i.tealDark}; color: #fff; }
        .control-chip:focus-visible { outline: 2px solid ${i.teal}; outline-offset: 1px; }
        .filters-footer {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 8px;
          min-width: 0;
          padding-top: 2px;
          height: 22px;
          flex-shrink: 0;
        }
        .active-filters {
          display: flex;
          flex: 1 1 auto;
          flex-wrap: wrap;
          gap: 6px;
          min-height: 0;
          min-width: 0;
          overflow: hidden;
          color: ${i.ink3};
          font-size: 10px;
          line-height: 1.3;
        }
        .active-chip {
          display: inline-flex;
          max-width: 100%;
          min-width: 0;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
          border-radius: 6px;
          border: 1px solid rgba(47, 127, 153, 0.18);
          background: rgba(230, 240, 243, 0.82);
          color: ${i.teal};
          font-size: 9.5px;
          padding: 2px 6px;
        }
        .results {
          display: grid;
          gap: 5px;
          min-width: 0;
          margin: 0;
          padding: 7px 8px 5px;
          list-style: none;
          max-height: min(48vh, 342px);
          overflow-x: hidden;
          overflow-y: auto;
          background: ${i.card};
          opacity: 1;
          transition: max-height 140ms ease, padding 140ms ease, opacity 120ms ease;
        }
        .results.collapsed {
          max-height: 0;
          padding-top: 0;
          padding-bottom: 0;
          overflow: hidden;
          opacity: 0;
          pointer-events: none;
        }
        .item {
          margin: 0;
          min-width: 0;
        }
        @media (prefers-reduced-motion: no-preference) {
          .results.cascade .item {
            animation: result-cascade 55ms ease-out both;
          }
          .results.cascade .item:nth-child(2) { animation-delay: 4ms; }
          .results.cascade .item:nth-child(3) { animation-delay: 8ms; }
          .results.cascade .item:nth-child(4) { animation-delay: 12ms; }
          .results.cascade .item:nth-child(5) { animation-delay: 16ms; }
          .results.cascade .item:nth-child(n+6) { animation-delay: 20ms; }
        }
        @keyframes result-cascade {
          from {
            opacity: 0;
            transform: translateY(-5px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        .item-row {
          position: relative;
          min-width: 0;
        }
        .result-btn {
          position: relative;
          width: 100%;
          min-width: 0;
          box-sizing: border-box;
          text-align: left;
          display: grid;
          grid-template-columns: minmax(0, 1fr);
          gap: 3px;
          padding: 10px 12px 9px;
          border-radius: 6px;
          border: 1px solid ${i.ruleSoft};
          border-left: 3px solid var(--item-accent, #8ea0ac);
          background: var(--item-bg, ${i.card});
          line-height: 1.4;
          color: inherit;
          cursor: pointer;
          box-shadow: none;
          transition: background 150ms ease, border-color 150ms ease;
        }
        .result-open-btn {
          position: absolute;
          inset: 0;
          z-index: 0;
          width: 100%;
          border: 0;
          border-radius: inherit;
          background: transparent;
          padding: 0;
          cursor: pointer;
        }
        .result-btn:has(.result-open-btn:focus-visible) {
          outline: 2px solid ${i.teal};
          outline-offset: 2px;
        }
        .result-btn:hover {
          background: var(--item-selected, ${i.paperSoft});
        }
        .result-btn.selected {
          border-color: var(--item-border, ${i.ruleSoft});
          border-left-color: var(--item-accent, #2f7f99);
          border-left-width: 5px;
          background: var(--item-selected, #eef3f7);
          box-shadow:
            inset 0 0 0 1px var(--item-accent, #2f7f99),
            0 4px 12px rgba(17, 34, 47, 0.08);
        }
        .result-btn.selected strong {
          color: #0f2534;
        }
        .remove-btn {
          position: absolute;
          right: 40px;
          bottom: 7px;
          border: 1px solid #e7dcda;
          background: #fffdfb;
          color: #9a6f6f;
          border-radius: 6px;
          font-size: 10px;
          font-weight: 500;
          line-height: 1.2;
          padding: 2px 6px;
          cursor: pointer;
          white-space: nowrap;
          opacity: 0;
          transform: translateY(2px);
          pointer-events: none;
          transition: opacity 120ms ease, transform 120ms ease;
        }
        .remove-btn:disabled {
          cursor: default;
          opacity: 0.6;
        }
        .item-row:hover .remove-btn,
        .item-row:focus-within .remove-btn,
        .remove-btn.visible {
          opacity: 0.68;
          transform: translateY(0);
          pointer-events: auto;
        }
        .remove-btn:hover,
        .remove-btn:focus-visible,
        .remove-btn.visible {
          opacity: 1;
          border-color: #d8bebe;
          background: #fff8f7;
          color: #7f4a4a;
        }
        .viewer-btn {
          position: absolute;
          right: 78px;
          bottom: 7px;
          border: 1px solid ${i.tealEdge};
          background: ${i.card};
          color: ${i.teal};
          border-radius: 6px;
          font-size: 10px;
          font-weight: 600;
          line-height: 1.2;
          padding: 2px 6px;
          cursor: pointer;
          white-space: nowrap;
          opacity: 0;
          transform: translateY(2px);
          pointer-events: none;
          transition: opacity 120ms ease, transform 120ms ease, background 120ms ease, border-color 120ms ease;
        }
        .item-row:hover .viewer-btn,
        .item-row:focus-within .viewer-btn {
          opacity: 0.68;
          transform: translateY(0);
          pointer-events: auto;
        }
        .viewer-btn:hover,
        .viewer-btn:focus-visible {
          opacity: 1;
          border-color: ${i.teal};
          background: ${i.tealSoft};
        }
        .rename-btn {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          flex: 0 0 auto;
          width: 20px;
          height: 20px;
          border: 0;
          background: transparent;
          color: ${i.ink3};
          border-radius: 5px;
          padding: 3px;
          cursor: pointer;
          opacity: 0.46;
          pointer-events: auto;
          position: relative;
          z-index: 2;
          transition: opacity 120ms ease, background 120ms ease, color 120ms ease;
        }
        .rename-btn svg {
          display: block;
          width: 13px;
          height: 13px;
        }
        .rename-btn:hover,
        .rename-btn:focus-visible {
          opacity: 1;
          background: ${i.tealSoft};
          color: ${i.teal};
        }
        .result-title[hidden],
        .rename-btn[hidden] {
          display: none;
        }
        .rename-editor {
          display: flex;
          align-items: center;
          flex: 1 1 auto;
          gap: 3px;
          min-width: 0;
          pointer-events: auto;
          position: relative;
          z-index: 2;
        }
        .rename-input {
          flex: 1 1 auto;
          min-width: 70px;
          height: 24px;
          box-sizing: border-box;
          border: 1px solid ${i.teal};
          border-radius: 5px;
          background: ${i.card};
          color: ${i.ink};
          font: 500 12.5px/1.2 "IBM Plex Sans", "Segoe UI", sans-serif;
          padding: 3px 6px;
          outline: none;
          box-shadow: 0 0 0 2px rgba(47, 127, 153, 0.13);
        }
        .rename-input:disabled {
          opacity: 0.65;
        }
        .rename-editor-action {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          flex: 0 0 auto;
          width: 22px;
          height: 22px;
          border: 0;
          border-radius: 5px;
          background: transparent;
          color: ${i.ink3};
          font: 600 14px/1 "IBM Plex Sans", "Segoe UI", sans-serif;
          padding: 0;
          cursor: pointer;
        }
        .rename-save {
          color: ${i.teal};
        }
        .rename-editor-action:hover,
        .rename-editor-action:focus-visible {
          background: ${i.tealSoft};
          outline: none;
        }
        .star-btn {
          position: absolute;
          right: 6px;
          bottom: 4px;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          width: 26px;
          height: 26px;
          border: none;
          border-radius: 50%;
          background: transparent;
          /* Persistently visible but muted so every row reads as starrable at a
             glance, without competing with the title. Brightens on hover, goes
             solid gold when starred. */
          color: #97a3ab;
          font-size: 17px;
          line-height: 1;
          padding: 0;
          cursor: pointer;
          opacity: 0.5;
          transition: opacity 120ms ease, color 120ms ease, background 120ms ease, transform 120ms ease;
        }
        .item-row:hover .star-btn,
        .item-row:focus-within .star-btn {
          opacity: 0.8;
        }
        .star-btn:hover,
        .star-btn:focus-visible {
          opacity: 1;
          color: #e0a500;
          background: rgba(242, 183, 5, 0.16);
          transform: scale(1.08);
        }
        .star-btn.starred {
          opacity: 1;
          color: #f2b705;
        }
        .star-btn.starred:hover,
        .star-btn.starred:focus-visible {
          color: #e0a500;
        }
        .title-row {
          position: relative;
          z-index: 1;
          display: flex;
          justify-content: space-between;
          align-items: center;
          gap: 8px;
          min-width: 0;
          pointer-events: none;
        }
        .title-main {
          display: flex;
          align-items: center;
          flex: 1 1 auto;
          gap: 3px;
          min-width: 0;
        }
        .title-row strong {
          display: block;
          flex: 0 1 auto;
          min-width: 0;
          color: ${i.ink};
          font-size: 13px;
          font-weight: 500;
          line-height: 1.35;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }
        .title-row mark {
          background: #ffe0a3;
          color: ${i.ink};
          border-radius: 3px;
          box-shadow: inset 0 -1px 0 rgba(198, 87, 47, 0.24);
          padding: 0 3px;
        }
        .title-meta {
          display: inline-flex;
          align-items: center;
          flex: 0 0 auto;
          gap: 6px;
          max-width: 48%;
          min-width: 0;
          overflow: hidden;
        }
        .model-pill::before {
          content: "·";
          flex: 0 0 auto;
          margin: 0 6px;
          color: color-mix(in srgb, ${i.ink3} 55%, transparent);
        }
        .snippet {
          position: relative;
          z-index: 1;
          display: -webkit-box;
          overflow: hidden;
          color: ${i.ink3};
          font-size: 12px;
          line-height: 1.45;
          -webkit-box-orient: vertical;
          -webkit-line-clamp: 2;
          word-break: break-word;
          pointer-events: none;
        }
        .snippet mark {
          background: #ffe6b8;
          color: ${i.ink};
          border-radius: 3px;
          box-shadow: inset 0 -1px 0 rgba(198, 87, 47, 0.18);
          padding: 0 2px;
        }
        .platform-pill {
          display: inline-flex;
          align-items: center;
          flex-shrink: 0;
          max-width: 112px;
          min-width: 0;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
          border-radius: 999px;
          border: 1px solid var(--pill-border, #d4dec7);
          background: var(--pill-bg, #eff5e1);
          color: var(--pill-text, #2f4654);
          font-size: 9.5px;
          font-weight: 500;
          line-height: 1;
          padding: 3px 7px;
          letter-spacing: 0;
        }
        .provenance-pill {
          font-style: italic;
          max-width: 150px;
          opacity: 0.85;
        }
        .model-pill {
          display: inline-flex;
          align-items: center;
          flex: 0 1 auto;
          min-width: 0;
          max-width: 180px;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
          color: color-mix(in srgb, ${i.ink3} 76%, transparent);
          font-size: 9px;
          font-weight: 400;
          line-height: 1.2;
        }
        .media-pill {
          display: inline-flex;
          align-items: center;
          flex: 0 0 auto;
          border-radius: 999px;
          border: 1px solid #b9ccd9;
          background: #eaf3f9;
          color: #1e4d66;
          font-size: 9px;
          line-height: 1;
          font-weight: 700;
          letter-spacing: 0;
          padding: 4px 7px;
        }
        .meaning-pill {
          display: inline-flex;
          align-items: center;
          flex: 0 0 auto;
          border-radius: 999px;
          border: 1px solid #c9bce0;
          background: #f1ecf9;
          color: #5a3f86;
          font-size: 9px;
          line-height: 1;
          font-weight: 700;
          letter-spacing: 0;
          padding: 4px 7px;
        }
        .meta {
          position: relative;
          z-index: 1;
          display: flex;
          align-items: center;
          min-width: 0;
          min-height: 18px;
          margin-top: 3px;
          padding-right: 28px;
          color: ${i.ink3};
          font-family: "IBM Plex Mono", "SF Mono", "Consolas", monospace;
          font-size: 10px;
          line-height: 1;
          letter-spacing: 0;
          pointer-events: none;
        }
        .empty {
          color: ${i.ink3};
          font-size: 12.5px;
          font-style: italic;
          line-height: 1.5;
          padding: 18px 8px 22px;
          text-align: center;
        }
        .search-gate-dismiss {
          display: inline-block;
          margin-top: 10px;
          padding: 0;
          border: none;
          background: none;
          color: #3fa882;
          font-size: 11.5px;
          font-style: normal;
          font-family: inherit;
          cursor: pointer;
          text-decoration: underline;
          letter-spacing: 0.01em;
        }
        .search-gate-dismiss:hover {
          color: #2f7f99;
        }
        .empty-tips {
          list-style: none;
          margin: 8px 0 0;
          padding: 0;
          font-style: normal;
          font-size: 11.5px;
          line-height: 1.7;
          color: ${i.ink3};
        }
        .empty-tips li::before {
          content: "•";
          margin-right: 6px;
          opacity: 0.6;
        }
        .empty-status {
          margin-top: 8px;
          font-style: normal;
          font-size: 11.5px;
          line-height: 1.6;
          color: ${i.ink2};
        }
        .cc-nudge {
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 8px;
          margin: 14px auto 2px;
          max-width: 320px;
          padding: 10px 12px;
          border: 1px solid ${i.tealEdge};
          border-radius: 10px;
          background: ${i.tealSoft};
          font-style: normal;
        }
        .cc-nudge-text {
          font-size: 11.5px;
          line-height: 1.5;
          color: ${i.ink2};
        }
        .cc-nudge-actions {
          display: flex;
          align-items: center;
          gap: 8px;
        }
        .cc-nudge-connect {
          padding: 5px 12px;
          border-radius: 7px;
          border: 1px solid ${i.teal};
          background: ${i.teal};
          color: #fff;
          font-size: 11.5px;
          font-family: inherit;
          font-weight: 600;
          cursor: pointer;
        }
        .cc-nudge-connect:hover {
          filter: brightness(1.05);
        }
        .cc-nudge-dismiss {
          padding: 5px 10px;
          border: none;
          background: none;
          color: ${i.ink3};
          font-size: 11.5px;
          font-family: inherit;
          cursor: pointer;
          text-decoration: underline;
        }
        .cc-nudge-dismiss:hover {
          color: ${i.ink2};
        }
        /* Empty-index import CTA. Not italic like the rest of .empty — this is
           an action, not a passive status line, and it should read like one. */
        .import-cta {
          font-style: normal;
          font-size: 12.5px;
          color: ${i.ink2};
        }
        .import-cta strong {
          color: ${i.ink};
          font-weight: 600;
        }
        .import-cta-actions {
          display: flex;
          flex-wrap: wrap;
          justify-content: center;
          gap: 8px;
          margin-top: 12px;
        }
        .import-cta-btn {
          padding: 7px 14px;
          border-radius: 8px;
          border: 1px solid ${i.teal};
          background: ${i.teal};
          color: #fff;
          font-size: 12px;
          font-family: inherit;
          font-weight: 600;
          cursor: pointer;
        }
        .import-cta-btn:hover {
          filter: brightness(1.05);
        }
        .import-cta-note {
          margin-top: 8px;
          font-size: 11px;
          line-height: 1.5;
          color: ${i.ink3};
        }
        .import-cta-status {
          margin-top: 10px;
          font-size: 11.5px;
          line-height: 1.6;
          color: ${i.ink2};
        }
        .import-cta-error {
          color: #b4573f;
        }
        /* Degraded-index warning: soft amber bar above results when the index
           has unresolved extract errors or an active backfill. */
        .degraded-index-warning {
          display: flex;
          align-items: center;
          gap: 6px;
          padding: 6px 12px;
          border-bottom: 1px solid #cbdce7;
          background: #f1f7fb;
          color: #3f5568;
          font-size: 11px;
          line-height: 1.35;
        }
        .degraded-index-warning[hidden] { display: none; }
        .degraded-index-warning-icon { flex: none; font-size: 12px; }
        /* Toolbar pin hint: a single quiet line under the results, never a card.
           It competes with nothing — if the index is empty, the import CTA above
           is the priority and this stays hidden. */
        .pin-hint {
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
          padding: 7px 10px;
          border-top: 1px solid ${i.ruleSoft};
          font-size: 11px;
          line-height: 1.5;
          color: ${i.ink3};
        }
        .pin-hint[hidden] { display: none; }
        .pin-hint-dismiss {
          padding: 0 2px;
          border: none;
          background: none;
          color: ${i.ink3};
          font-size: 13px;
          font-family: inherit;
          line-height: 1;
          cursor: pointer;
          opacity: 0.7;
        }
        .pin-hint-dismiss:hover {
          opacity: 1;
        }
        .empty-filters {
          display: flex;
          flex-wrap: wrap;
          justify-content: center;
          gap: 6px;
          margin-top: 10px;
        }
        .empty-clear-filters {
          display: inline-block;
          margin-top: 12px;
          padding: 4px 12px;
          border: 1px solid ${i.tealEdge};
          border-radius: 6px;
          background: ${i.tealSoft};
          color: ${i.teal};
          font-size: 11.5px;
          font-style: normal;
          font-weight: 600;
          font-family: inherit;
          cursor: pointer;
          letter-spacing: 0.01em;
        }
        .empty-clear-filters:hover {
          background: ${i.paperSoft};
          border-color: ${i.teal};
        }
        .panel-footer {
          position: relative;
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 12px;
          padding: 6px 12px;
          border-top: 1px solid ${i.ruleSoft};
          background: ${i.paper};
          color: ${i.ink3};
          font-family: "IBM Plex Mono", "SF Mono", "Consolas", monospace;
          font-size: 10.5px;
          line-height: 1;
          letter-spacing: 0;
        }
        .panel-footer-shortcut {
          flex-shrink: 0;
        }
        .pagination {
          display: none;
          align-items: center;
          justify-content: center;
          gap: 5px;
          margin-left: auto;
        }
        .pagination[data-visible="true"] {
          display: flex;
        }
        .page-button {
          border: 1px solid ${i.ruleSoft};
          border-radius: 6px;
          background: ${i.card};
          color: ${i.ink2};
          font: inherit;
          line-height: 1;
          padding: 4px 8px;
          cursor: pointer;
        }
        .page-button:hover:not(:disabled) {
          border-color: ${i.tealEdge};
          color: ${i.teal};
        }
        .page-button:disabled {
          opacity: 0.35;
          cursor: default;
        }
        .panel-footer kbd {
          margin-right: 3px;
          border-color: ${i.rule};
          background: ${i.card};
          color: ${i.ink2};
          font-size: 9.5px;
        }
        .snippet-item-text {
          font-size: 12px;
          color: #47606f;
          margin-top: 4px;
          max-height: 3.6em;
          overflow: hidden;
          line-height: 1.4;
          word-break: break-word;
        }
        .snippet-label {
          font-weight: 600;
          color: #153147;
          font-size: 13px;
        }
        .snippet-conv {
          font-size: 11px;
          color: #6b8a9e;
          margin-top: 2px;
        }
        .shortcuts-sheet {
          position: absolute;
          inset: 0;
          z-index: 6;
          display: flex;
          flex-direction: column;
          background: ${i.card};
          border-radius: ${i.rMd};
          overflow: hidden;
        }
        .shortcuts-sheet[hidden] {
          display: none;
        }
        .shortcuts-sheet-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 11px 14px;
          border-bottom: 1px solid ${i.rule};
          background: ${i.paper};
        }
        .shortcuts-sheet-title {
          color: ${i.ink};
          font-size: 13px;
          font-weight: 600;
        }
        .shortcuts-close {
          border: 1px solid ${i.rule};
          border-radius: ${i.rSm};
          padding: 4px 10px;
          background: ${i.card};
          color: ${i.ink2};
          font-size: 11px;
          font-weight: 600;
          cursor: pointer;
        }
        .shortcuts-close:hover {
          border-color: ${i.tealEdge};
          color: ${i.teal};
        }
        .shortcuts-sheet-body {
          flex: 1;
          overflow-y: auto;
          padding: 6px 14px 14px;
        }
        .shortcuts-group {
          margin-top: 12px;
        }
        .shortcuts-group-title {
          color: ${i.ink3};
          font-family: "IBM Plex Mono", "SF Mono", "Consolas", monospace;
          font-size: 10px;
          text-transform: uppercase;
          letter-spacing: 0.06em;
          margin-bottom: 6px;
        }
        .shortcuts-list {
          list-style: none;
          margin: 0;
          padding: 0;
        }
        .shortcuts-row {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 16px;
          padding: 7px 0;
          border-top: 1px solid ${i.ruleSoft};
        }
        .shortcuts-row:first-child {
          border-top: 0;
        }
        .shortcuts-label {
          display: flex;
          flex-direction: column;
          gap: 2px;
          color: ${i.ink2};
          font-size: 12.5px;
          line-height: 1.3;
        }
        .shortcuts-note {
          color: ${i.ink3};
          font-size: 10.5px;
        }
        .shortcuts-keys {
          flex-shrink: 0;
          display: flex;
          align-items: center;
          gap: 2px;
          white-space: nowrap;
        }
        .shortcuts-keys kbd {
          font-size: 11px;
          padding: 2px 5px;
        }
        .shortcuts-sep {
          color: ${i.ink3};
          font-size: 10px;
          margin: 0 2px;
        }
        /* A word needs more room than "/" to stay legible between two key caps. */
        .shortcuts-sep.word { margin: 0 5px; }
      </style>
      <div class="backdrop">
        <div class="panel" role="dialog" aria-label="LLMnesia Search">
          <div class="panel-header">
            <span class="panel-dot"></span>
            <span class="panel-brand">LLMnesia</span>
            <button class="panel-help" type="button" aria-label="Search help and shortcuts" title="Search help and shortcuts (?)">?</button>
            <span class="panel-kbd">⌘ ⇧ 9</span>
          </div>
          <div class="input-wrap">
            <div class="search-row">
              <input class="search" type="text" placeholder="Search your AI history..." />
              <div class="search-actions">
                <div class="history-wrapper">
                  <button class="history-toggle" type="button" aria-label="Search history" aria-expanded="false" hidden>
                    <svg width="13" height="13" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><circle cx="8" cy="8" r="6.5"/><polyline points="8,4.5 8,8 10.5,10"/></svg>
                  </button>
                  <div class="history-dropdown" hidden></div>
                </div>
                <button class="starred-toggle" type="button" aria-label="Starred only" aria-pressed="false" title="Show starred chats only">★</button>
                <button class="filters-toggle" type="button" aria-label="Filters" aria-expanded="false">Filters</button>
                <button class="clear" type="button" aria-label="Clear search" disabled>Clear</button>
              </div>
            </div>
            <div class="search-meta">
              <div class="search-hint">Indexed chats <span class="dot-sep">·</span> <kbd>↑</kbd>/<kbd>↓</kbd> to browse</div>
              <button class="active-chip all-words-chip" type="button" aria-label="Remove All words filter" hidden>All words <span aria-hidden="true">×</span></button>
            </div>
            <div class="backfill-bar" aria-hidden="true"><div class="backfill-bar-fill"></div></div>
          </div>
          <div class="backfill-hint" aria-live="polite"></div>
          <div class="email-prompt" data-visible="false">
            <div class="email-prompt-title">Help shape LLMnesia</div>
            <div class="email-prompt-copy">Want occasional product updates and early feature previews? Leave your email.</div>
            <div class="email-prompt-benefits">
              <span class="email-prompt-benefit">Early feature previews</span>
              <span class="email-prompt-benefit">Direct feedback loop</span>
              <span class="email-prompt-benefit">Important release updates</span>
            </div>
            <form class="email-prompt-form" novalidate>
              <input class="email-prompt-input" type="email" autocomplete="email" placeholder="you@example.com" />
              <button class="email-prompt-submit" type="submit">Send me updates</button>
              <button class="email-prompt-dismiss" type="button">Skip for now</button>
            </form>
            <div class="email-prompt-status" data-visible="false" data-busy="false" aria-live="polite"></div>
            <div class="email-prompt-error"></div>
            <div class="email-prompt-success" data-visible="false"></div>
            <div class="email-prompt-trust">A short email now and then. No spam, unsubscribe any time.</div>
          </div>
          <div class="controls">
            <div class="control-row scope-row" hidden>
              <span class="control-label">Space</span>
              <div class="scope-chips" role="group" aria-label="Search scope"></div>
            </div>
            <div class="control-row scope-mix-row" hidden>
              <span class="control-label">Include</span>
              <div class="scope-mix" role="group" aria-label="Spaces to include"></div>
            </div>
            <div class="control-row recents-row">
              <span class="control-label">Recents</span>
              <button class="control-chip recents-chip" type="button" data-recents-sort="opened_desc">Last opened</button>
              <button class="control-chip recents-chip" type="button" data-recents-sort="modified_desc">Last modified</button>
              <button class="control-chip recents-chip" type="button" data-recents-sort="modified_asc">Oldest</button>
            </div>
            <div class="control-row sort-row">
              <span class="control-label">Sort</span>
              <button class="control-chip sort-chip" type="button" data-sort="best_match">Best match</button>
              <button class="control-chip sort-chip" type="button" data-sort="updated_desc">Newest</button>
              <button class="control-chip sort-chip" type="button" data-sort="updated_asc">Oldest</button>
            </div>
            <div class="control-row">
              <span class="control-label">Updated</span>
              <button class="control-chip updated-chip" type="button" data-updated="any">Any time</button>
              <button class="control-chip updated-chip" type="button" data-updated="day">Last 24h</button>
              <button class="control-chip updated-chip" type="button" data-updated="week">Last 7d</button>
              <button class="control-chip updated-chip" type="button" data-updated="month">Last 30d</button>
            </div>
            <div class="control-row">
              <span class="control-label">Media</span>
              <button class="control-chip media-chip" type="button" data-media="all">All</button>
              <button class="control-chip media-chip" type="button" data-media="with_images">AI images</button>
            </div>
            <div class="control-row">
              <span class="control-label">Starred</span>
              <button class="control-chip starred-chip" type="button" data-starred="all">All</button>
              <button class="control-chip starred-chip" type="button" data-starred="only">Starred only</button>
            </div>
            <div class="control-row match-row">
              <span class="control-label">Match</span>
              <button class="control-chip match-chip" type="button" data-match="all">All</button>
              <button class="control-chip match-chip" type="button" data-match="keyword">Keyword</button>
              <button class="control-chip match-chip" type="button" data-match="meaning">Meaning</button>
            </div>
            <div class="control-row words-row">
              <span class="control-label">Words</span>
              <button class="control-chip" type="button" data-word-match="normal">Normal</button>
              <button class="control-chip" type="button" data-word-match="all" title="Require every searchable word in the same conversation">All words</button>
            </div>
            <div class="control-row platform-row">
              <span class="control-label">Platform</span>
              <button class="platform-scroll-button platform-scroll-back" type="button" aria-label="Show previous platforms" title="Previous platforms">‹</button>
              <div class="platform-scroll-viewport" tabindex="0" aria-label="Platform filters">
                <div class="platform-chips"></div>
              </div>
              <button class="platform-scroll-button platform-scroll-forward" type="button" aria-label="Show more platforms" title="More platforms">›</button>
            </div>
            <div class="filters-footer">
              <div class="active-filters"></div>
              <button class="reset-filters" type="button" aria-label="Reset all filters" hidden>Reset all filters</button>
            </div>
          </div>
          <div class="degraded-index-warning" hidden>
            <span class="degraded-index-warning-icon" aria-hidden="true">↻</span>
            <span class="degraded-index-warning-text"></span>
          </div>
          <div class="first-search-suggestions" hidden style="padding: 10px 16px; font-size: 13px">
            <p style="margin: 0 0 8px">Try a search from your saved chats:</p>
            <div class="first-search-terms" style="display: flex; gap: 8px; flex-wrap: wrap"></div>
          </div>
          <div class="organise-bar" hidden>
            <span class="organise-count" aria-live="polite"></span>
            <button class="organise-go" type="button">Organise selected chats</button>
            <button class="organise-clear" type="button">Clear</button>
          </div>
          <ul class="results"></ul>
          <div class="pin-hint" hidden></div>
          <div class="panel-footer">
            <span class="status"></span>
            <div class="count-menu" role="menu" aria-label="How many to show" hidden>
              <button class="count-option" type="button" role="menuitemradio" data-recent-count="30">30</button>
              <button class="count-option" type="button" role="menuitemradio" data-recent-count="50">50</button>
              <button class="count-option" type="button" role="menuitemradio" data-recent-count="100">100</button>
              <button class="count-option" type="button" role="menuitemradio" data-recent-count="250">250</button>
              <button class="count-option" type="button" role="menuitemradio" data-recent-count="500">500</button>
            </div>
            <div class="pagination" data-visible="false" aria-label="Browse indexed chats">
              <button class="page-button newer-page" type="button" aria-label="Show previous page">‹ Previous</button>
              <button class="page-button older-page" type="button" aria-label="Show next page">Next ›</button>
            </div>
            <span class="panel-footer-shortcut"><kbd>↵</kbd> open <span class="dot-sep">·</span> <kbd>?</kbd> help</span>
          </div>
          <div class="shortcuts-sheet" hidden></div>
        </div>
      </div>
    `,this.inputEl=s.querySelector(".search"),this.clearEl=s.querySelector(".clear"),this.historyToggleEl=s.querySelector(".history-toggle"),this.historyDropdownEl=s.querySelector(".history-dropdown"),this.starredToggleEl=s.querySelector(".starred-toggle"),this.filtersToggleEl=s.querySelector(".filters-toggle"),this.allWordsChipEl=s.querySelector(".all-words-chip"),this.quickClearFiltersEl=s.querySelector(".reset-filters"),this.controlsEl=s.querySelector(".controls"),this.recentsRowEl=s.querySelector(".recents-row"),this.sortRowEl=s.querySelector(".sort-row"),this.matchRowEl=s.querySelector(".match-row"),this.platformChipsEl=s.querySelector(".platform-chips"),this.orgScopeRowEl=s.querySelector(".scope-row"),this.orgScopeChipsEl=s.querySelector(".scope-chips"),this.orgScopeMixEl=s.querySelector(".scope-mix"),this.organiserBarEl=s.querySelector(".organise-bar"),this.organiserCountEl=s.querySelector(".organise-count"),this.organiserGoEl=s.querySelector(".organise-go"),this.orgScopeChipsEl?.addEventListener("click",o=>{const n=o.target;if(n.closest("button[data-org-open-settings]")){chrome.runtime.sendMessage({type:"OPEN_OPTIONS",hash:"#organisation"}),this.close();return}const d=n.closest("button[data-scope-option]");if(!d)return;const h=d.dataset.scopeOption;if(h==="unclassified"){this.setOrganisationScope({kind:"unclassified"});return}if(h==="mix"){this.orgScopeMixVisible=!this.orgScopeMixVisible,this.renderScopeMix();return}h?.startsWith("space:")&&this.setOrganisationScope({kind:"space",spaceId:h.slice(6)})}),this.orgScopeMixEl?.addEventListener("click",o=>{const c=o.target.closest("button[data-scope-mix]");if(!c||!this.orgState)return;const d=this.orgState.scope,h=d&&d.kind==="spaces"?d:{spaceIds:[],includeUnclassified:!1},m=c.dataset.scopeMix;let u=h.spaceIds,w=h.includeUnclassified;if(m==="unclassified")w=!w;else if(m?.startsWith("space:")){const b=m.slice(6);u=u.includes(b)?u.filter(p=>p!==b):[...u,b]}else return;this.setOrganisationScope({kind:"spaces",spaceIds:u,includeUnclassified:w})}),this.organiserGoEl?.addEventListener("click",()=>{this.openOrganiserWithSelection()}),s.querySelector(".organise-clear")?.addEventListener("click",()=>{this.orgSelection.clear(),this.updateOrganiseBar(),this.render()}),this.platformScrollViewportEl=s.querySelector(".platform-scroll-viewport"),this.platformScrollBackEl=s.querySelector(".platform-scroll-back"),this.platformScrollForwardEl=s.querySelector(".platform-scroll-forward"),this.activeFiltersEl=s.querySelector(".active-filters"),this.resultsEl=s.querySelector(".results"),this.firstSearchSuggestionsEl=s.querySelector(".first-search-suggestions"),this.firstSearchSuggestionsEl?.addEventListener("click",o=>{const c=o.target.closest("button[data-first-search-index]"),d=Number(c?.dataset.firstSearchIndex),h=this.firstSearchTerms[d];!c||!h||!this.inputEl||(this.inputEl.value=h,this.currentQuery=h,this.resetBrowsePage(),this.focusInput(),k("search_suggestion_clicked",void 0,{surface:"first_search_overlay",suggestion_index:d}),this.renderFirstSearchSuggestions(),this.scheduleSearch(0))}),this.pinHintEl=s.querySelector(".pin-hint"),this.renderPinHint(),this.pinHintEl?.addEventListener("click",o=>{o.target.closest("button[data-pin-hint-dismiss]")&&this.dismissPinHint()}),this.degradedIndexWarningEl=s.querySelector(".degraded-index-warning"),this.statusEl=s.querySelector(".status"),this.paginationEl=s.querySelector(".pagination"),this.newerPageEl=s.querySelector(".newer-page"),this.olderPageEl=s.querySelector(".older-page"),this.countMenuEl=s.querySelector(".count-menu"),this.searchHintEl=s.querySelector(".search-hint"),this.emailPromptEl=s.querySelector(".email-prompt"),this.emailPromptTitleEl=s.querySelector(".email-prompt-title"),this.emailPromptCopyEl=s.querySelector(".email-prompt-copy"),this.emailPromptBenefitsEl=s.querySelector(".email-prompt-benefits"),this.emailPromptTrustEl=s.querySelector(".email-prompt-trust"),this.emailPromptInputEl=s.querySelector(".email-prompt-input"),this.emailPromptSubmitEl=s.querySelector(".email-prompt-submit"),this.emailPromptDismissEl=s.querySelector(".email-prompt-dismiss"),this.emailPromptStatusEl=s.querySelector(".email-prompt-status"),this.emailPromptErrorEl=s.querySelector(".email-prompt-error"),this.emailPromptSuccessEl=s.querySelector(".email-prompt-success"),this.helpToggleEl=s.querySelector(".panel-help"),this.shortcutsSheetEl=s.querySelector(".shortcuts-sheet"),this.backfillBarEl=s.querySelector(".backfill-bar"),this.backfillBarFillEl=s.querySelector(".backfill-bar-fill"),this.backfillHintEl=s.querySelector(".backfill-hint");const a=s.querySelector(".backdrop"),r=s.querySelector(".panel");this.inputEl?.addEventListener("input",()=>{this.updateClearButtonState(),this.historyNavIndex=-1,this.resetBrowsePage(),this.scheduleSearch()}),this.inputEl?.addEventListener("blur",()=>{this.openState&&window.setTimeout(()=>{if(!this.openState||this.hasOpenTitleEditor())return;const o=this.host?.shadowRoot?.activeElement,n=o instanceof HTMLElement&&this.emailPromptEl instanceof HTMLElement&&this.emailPromptEl.contains(o),c=o instanceof HTMLElement&&!!o.closest(".rename-editor");n||c||this.isFilterControlFocused(o)||this.focusInput()},0)}),this.resultsEl?.addEventListener("click",o=>{const n=o.target;if(n.closest("button[data-org-open-settings]")){chrome.runtime.sendMessage({type:"OPEN_OPTIONS",hash:"#organisation"}),this.close();return}const d=n.closest("button[data-select-index]");if(d){const y=Number(d.dataset.selectIndex),P=this.results[y];P&&Number.isInteger(y)&&this.toggleOrgSelection(P.docId);return}if(n.closest("button[data-search-gate-dismiss]")){this.searchGateDismissedForQuery=this.currentQuery,this.render();return}if(n.closest("button[data-clear-filters-inline]")){this.resetFilters();return}if(n.closest("button[data-import-here]")){this.startImportFromOverlay();return}const w=n.closest("button[data-import-open]");if(w){const y=w.dataset.importOpen;(y==="chatgpt"||y==="claude")&&this.openImportTab(y);return}if(n.closest("button[data-cc-nudge-connect]")){k("claude_code_promo_clicked",void 0,{surface:"search_nudge"}),chrome.runtime.sendMessage({type:"OPEN_OPTIONS",hash:ke});return}if(n.closest("button[data-cc-nudge-dismiss]")){k("claude_code_promo_dismissed",void 0,{surface:"search_nudge"}),this.claudeCodeNudgeArmedQuery=null,Ce(),this.render();return}const x=n.closest("button[data-viewer-index]");if(x){const y=Number(x.dataset.viewerIndex);if(!Number.isFinite(y)||!this.results[y])return;const P=o.metaKey||o.ctrlKey;this.selectedIndex=y,this.openSelected(!0,P,!0);return}const S=n.closest("button[data-rename-index]");if(S){const y=Number(S.dataset.renameIndex);if(!Number.isFinite(y)||!this.results[y])return;this.renameResult(y);return}const E=n.closest("button[data-star-index]");if(E){const y=Number(E.dataset.starIndex);if(!Number.isFinite(y)||!this.results[y])return;this.toggleStar(y);return}const C=n.closest("button[data-remove-index]");if(C){const y=Number(C.dataset.removeIndex);if(!Number.isFinite(y)||!this.results[y])return;this.removeResult(y);return}const v=n.closest("button.result-open-btn[data-index]");if(!v)return;const $=Number(v.dataset.index);if(!Number.isFinite($)||!this.results[$])return;const f=o.metaKey||o.ctrlKey,I=o.altKey;this.selectedIndex=$,this.openSelected(!0,f,I)}),this.clearEl?.addEventListener("click",()=>{this.clearSearch()}),this.historyToggleEl?.addEventListener("click",()=>{if(this.searchHistory.length===0){this.showHistoryDropdown=!1,this.updateHistoryToggleState(),this.updateHistoryToggleVisibility();return}this.showHistoryDropdown=!this.showHistoryDropdown,this.showHistoryDropdown&&this.renderHistoryDropdown(),this.updateHistoryToggleState()}),this.filtersToggleEl?.addEventListener("click",()=>{this.showFilters=!this.showFilters,this.persistPreferences(),this.updateControlState(),this.showFilters||this.focusInput()}),s.querySelectorAll("button[data-word-match]").forEach(o=>{o.addEventListener("click",()=>this.setMatchAllWords(o.dataset.wordMatch==="all"))}),this.allWordsChipEl?.addEventListener("click",()=>{this.setMatchAllWords(!1),this.focusInput()}),this.platformScrollBackEl?.addEventListener("click",()=>{this.scrollPlatformFilters(-1)}),this.platformScrollForwardEl?.addEventListener("click",()=>{this.scrollPlatformFilters(1)}),this.platformScrollViewportEl?.addEventListener("scroll",()=>{this.updatePlatformScrollButtons()}),this.newerPageEl?.addEventListener("click",()=>{this.recentOffset!==0&&(this.recentOffset=Math.max(0,this.recentOffset-this.recentLimit),this.scheduleSearch(0),this.focusInput())}),this.olderPageEl?.addEventListener("click",()=>{this.hasMoreRecentResults&&(this.recentOffset+=this.recentLimit,this.scheduleSearch(0),this.focusInput())}),this.statusEl?.addEventListener("click",o=>{const n=o.target;if(n.closest(".count-pick")){o.stopPropagation(),this.toggleCountMenu();return}n.closest(".filtered-badge")&&(o.stopPropagation(),this.showFilters||(this.showFilters=!0,this.persistPreferences(),this.updateControlState()),this.focusInput())}),this.countMenuEl?.addEventListener("click",o=>{const n=o.target.closest(".count-option");n&&(o.stopPropagation(),this.applyRecentLimit(Number(n.dataset.recentCount)))}),this.starredToggleEl?.addEventListener("click",()=>{this.starredOnly=!this.starredOnly,this.resetBrowsePage(),this.persistPreferences(),this.updateControlState(),this.scheduleSearch(),this.focusInput()}),this.helpToggleEl?.addEventListener("click",()=>{this.toggleShortcutsSheet(!this.shortcutsSheetOpen)}),this.shortcutsSheetEl?.addEventListener("click",o=>{o.target.closest(".shortcuts-close")&&this.toggleShortcutsSheet(!1)}),this.quickClearFiltersEl?.addEventListener("click",()=>{this.resetFilters(),this.filtersToggleEl?.focus({preventScroll:!0})}),this.emailPromptEl?.querySelector(".email-prompt-form")?.addEventListener("submit",o=>{o.preventDefault(),this.submitEmailPrompt()}),this.emailPromptDismissEl?.addEventListener("click",()=>{this.dismissEmailPrompt()}),this.controlsEl?.addEventListener("click",o=>{const n=o.target,c=n.closest("button[data-recents-sort]");if(c){const p=c.dataset.recentsSort;typeof p=="string"&&K(p)&&(this.recentsSortMode=p,this.resetBrowsePage(),this.persistPreferences(),this.currentQuery.length===0?this.scheduleSearch(0):this.applyResultPresentation());return}const d=n.closest("button[data-sort]");if(d){const p=d.dataset.sort;(p==="best_match"||p==="updated_desc"||p==="updated_asc")&&(this.sortMode=p,this.persistPreferences(),this.applyResultPresentation());return}const h=n.closest("button[data-updated]");if(h){const p=h.dataset.updated;(p==="any"||p==="day"||p==="week"||p==="month")&&(this.updatedWindow=p,this.resetBrowsePage(),this.persistPreferences(),this.updateControlState(),this.scheduleSearch());return}const m=n.closest("button[data-media]");if(m){const p=m.dataset.media;typeof p=="string"&&Y(p)&&(this.mediaFilter=p,this.resetBrowsePage(),this.persistPreferences(),this.updateControlState(),this.scheduleSearch());return}const u=n.closest("button[data-starred]");if(u){const p=u.dataset.starred;(p==="all"||p==="only")&&(this.starredOnly=p==="only",this.resetBrowsePage(),this.persistPreferences(),this.updateControlState(),this.scheduleSearch());return}const w=n.closest("button[data-match]");if(w){const p=w.dataset.match;typeof p=="string"&&X(p)&&(this.matchFilter=p,this.persistPreferences(),this.updateControlState(),this.scheduleSearch());return}const b=n.closest("button[data-platform]");if(b){const p=b.dataset.platform;typeof p=="string"&&We(p)&&(p==="all"?this.platformFilters.clear():H.has(p)||(this.platformFilters.has(p)?this.platformFilters.delete(p):this.platformFilters.add(p)),this.resetBrowsePage(),this.persistPreferences(),this.updateControlState(),this.scheduleSearch());return}}),a?.addEventListener("mousedown",o=>{o.target===a&&this.close()}),r?.addEventListener("mousedown",o=>{o.stopPropagation();const n=o.target;this.showHistoryDropdown&&!n.closest(".history-wrapper")&&this.closeHistoryDropdown(),this.showCountMenu&&!n.closest(".count-menu")&&!n.closest(".count-pick")&&this.closeCountMenu()}),e.append(t),this.host=t,window.addEventListener("keydown",this.onWindowKeydownCapture,!0),this.updateClearButtonState(),this.renderPlatformChips(),this.updateControlState(),this.ensurePreferencesLoaded().then(()=>{this.updateControlState()}),this.setStatus("Type to search your indexed chats."),this.render()}open(e){if(!this.host)return!1;if(this.openState)return e!==void 0&&this.inputEl&&(this.inputEl.value=e,this.currentQuery=e.trim(),this.focusInput(),this.scheduleSearch(0)),!1;if(!Ae())return!1;this.host.style.display="block",this.openState=!0,this.matchAllWords=!1;try{chrome.runtime.sendMessage({type:"WARM_SEMANTIC_SEARCH"}).catch(()=>{})}catch{}this.firstSearchTerms=[],this.resultQuery="",this.resultSearchId=void 0,this.firstSearchSuggestionRequest+=1,this.inputEl&&(this.inputEl.value=e??"",this.currentQuery=e?.trim()??""),typeof this.searchTimer=="number"&&(window.clearTimeout(this.searchTimer),this.searchTimer=void 0),this.searchRequestId+=1,this.rawResults=[],this.matchedBeforeUserFilters=0,this.results=[],this.selectedIndex=0,this.resultsCollapsed=!0,this.pendingHistoryQuery="",this.historyNavIndex=-1,this.importCtaImpressionFired=!1,this.degradedIndexWarningFired=!1,this.claudeCodeNudgeArmedQuery=null,this.claudeCodeNudgeCheckedQuery=null,this.loadSearchHistory();const t=this.refreshOrganisationState();return this.refreshIndexStats().then(()=>this.evaluatePinHint()),this.syncClaudeCodeThenRefresh(),this.checkDegradedIndex(),this.focusInput(),this.startFocusLoop(),this.updateClearButtonState(),this.setEmailPromptVisible(!1),this.setStatus(e?"Searching...":"Loading recent chats..."),this.render(),Promise.all([this.ensurePreferencesLoaded(),t]).then(()=>{this.openState&&(this.scheduleSearch(e?0:Ne),e||this.loadFirstSearchSuggestions(),this.refreshEmailPromptState())}),!0}async syncClaudeCodeThenRefresh(){let e=0;try{const t=await chrome.runtime.sendMessage({type:"SYNC_CLAUDE_CODE"});e=t&&t.ok===!0&&typeof t.indexed=="number"?t.indexed:0}catch{return}e>0&&this.openState&&this.runSearch({quiet:!0})}close(){if(!this.host)return;const e=this.pendingHistoryQuery||(this.historyNavIndex<0?this.inputEl?.value?.trim()??"":"");typeof this.searchHistorySaveTimer=="number"&&(window.clearTimeout(this.searchHistorySaveTimer),this.searchHistorySaveTimer=void 0),this.saveToSearchHistory(e),this.pendingHistoryQuery="",this.closeHistoryDropdown(),this.host.style.display="none",this.openState=!1,this.matchAllWords=!1,this.searchRequestId+=1,typeof this.searchTimer=="number"&&(window.clearTimeout(this.searchTimer),this.searchTimer=void 0),this.updateControlState(),this.firstSearchSuggestionRequest+=1,this.firstSearchTerms=[],this.toggleShortcutsSheet(!1),this.stopFocusLoop()}toggleShortcutsSheet(e){this.shortcutsSheetEl&&(e&&this.shortcutsSheetEl.childElementCount===0&&(this.shortcutsSheetEl.innerHTML=Ke()),this.shortcutsSheetOpen=e,this.host?.shadowRoot?.querySelector(".panel")?.classList.toggle("help-open",e),this.shortcutsSheetEl.hidden=!e,this.helpToggleEl?.setAttribute("aria-expanded",e?"true":"false"),e||this.focusInput())}teardown(){this.indexHealthRequest+=1,typeof this.searchTimer=="number"&&(window.clearTimeout(this.searchTimer),this.searchTimer=void 0),typeof this.searchHistorySaveTimer=="number"&&(window.clearTimeout(this.searchHistorySaveTimer),this.searchHistorySaveTimer=void 0),this.searchRequestId+=1,typeof this.backfillLiveRefreshTimer=="number"&&(window.clearInterval(this.backfillLiveRefreshTimer),this.backfillLiveRefreshTimer=void 0),typeof this.attachRetryTimer=="number"&&(window.clearTimeout(this.attachRetryTimer),this.attachRetryTimer=void 0),this.stopFocusLoop(),window.removeEventListener("keydown",this.onWindowKeydownCapture,!0),chrome.runtime.onMessage.removeListener(this.onOrganisationBroadcast),this.host?.remove(),this.host=null,this.openState=!1}toggle(){return this.openState?(this.close(),!1):this.open()}startBackfillLiveRefresh(){typeof this.backfillLiveRefreshTimer!="number"&&(this.backfillLiveRefreshTimer=window.setInterval(()=>{this.openState&&this.scheduleSearch()},3e3))}stopBackfillLiveRefresh(){typeof this.backfillLiveRefreshTimer=="number"&&(window.clearInterval(this.backfillLiveRefreshTimer),this.backfillLiveRefreshTimer=void 0)}setBackfillProgress(e){const t=this.backfillActive;if(this.backfillActive=e!=null&&e.phase!=="cancelled"&&e.phase!=="done",this.backfillActive?!t&&this.openState&&this.checkDegradedIndex():(this.indexHealthRequest+=1,this.degradedIndexWarningEl&&(this.degradedIndexWarningEl.hidden=!0)),!this.backfillBarEl||!this.backfillBarFillEl)return;if(typeof this.backfillBarFadeTimer=="number"&&(window.clearTimeout(this.backfillBarFadeTimer),this.backfillBarFadeTimer=void 0),!e||e.phase==="cancelled"){this.stopBackfillLiveRefresh(),this.backfillBarEl.classList.remove("visible","indeterminate"),this.backfillHintEl&&(this.backfillHintEl.classList.remove("visible"),this.backfillHintEl.textContent="");return}if(e.phase==="done"){this.stopBackfillLiveRefresh(),this.backfillBarFillEl.style.width="100%",this.backfillBarEl.classList.remove("indeterminate"),this.backfillBarEl.classList.add("visible");const o=e.indexed??0;this.backfillHintEl&&(this.backfillHintEl.textContent=o>0?`Backfill done — ${o} chat${o===1?"":"s"} indexed`:"Backfill done",this.backfillHintEl.classList.add("visible")),this.openState&&this.scheduleSearch(),this.backfillBarFadeTimer=window.setTimeout(()=>{this.backfillBarEl?.classList.remove("visible"),this.backfillHintEl&&(this.backfillHintEl.classList.remove("visible"),this.backfillHintEl.textContent=""),this.backfillBarFadeTimer=void 0},3e3);return}if(e.phase==="collecting"){if(this.backfillBarEl.classList.add("visible","indeterminate"),this.backfillHintEl){const o=(e.total??0)>0?` (${e.total} found so far)`:"";this.backfillHintEl.textContent=`Indexing older chats: fetching list${o}…`,this.backfillHintEl.classList.add("visible")}return}if(e.phase==="pruning"){this.backfillBarEl.classList.add("visible","indeterminate"),this.backfillHintEl&&(this.backfillHintEl.textContent="Indexing older chats: checking what's new…",this.backfillHintEl.classList.add("visible"));return}this.startBackfillLiveRefresh(),this.backfillBarEl.classList.remove("indeterminate"),this.backfillBarEl.classList.add("visible");const s=e.processed??0,a=e.total??0,r=a>0?Math.max(2,Math.min(99,Math.round(s/a*100))):5;if(this.backfillBarFillEl.style.width=`${r}%`,this.backfillHintEl){const o=a>0?` (${s}/${a})`:"";this.backfillHintEl.textContent=`Indexing older chats in background${o}`,this.backfillHintEl.classList.add("visible")}}setIndexNudge(e,t){this.indexNudgeConvCount=e,this.indexedConversationCount=e,this.indexNudgeHasRun=t,this.openState&&this.updateStatusFromPresentation()}async refreshIndexStats(){try{const e=await chrome.runtime.sendMessage({type:"GET_INDEX_STATS"});if(!e.ok)return;this.indexedConversationCount=e.stats.conversationCount,this.indexNudgeConvCount<0&&(this.indexNudgeConvCount=e.stats.conversationCount),this.openState&&this.updateStatusFromPresentation()}catch{}}focusInput(){this.hasOpenTitleEditor()||(this.inputEl?.focus({preventScroll:!0}),window.requestAnimationFrame(()=>{this.hasOpenTitleEditor()||this.inputEl?.focus({preventScroll:!0})}),window.setTimeout(()=>{this.hasOpenTitleEditor()||this.inputEl?.focus({preventScroll:!0})},20))}hasOpenTitleEditor(){return!!this.resultsEl?.querySelector(".rename-editor")}updateClearButtonState(){!this.clearEl||!this.inputEl||(this.clearEl.disabled=this.inputEl.value.length===0)}clearSearch(){this.inputEl&&(this.inputEl.value="",this.resetBrowsePage(),this.updateClearButtonState(),this.focusInput(),this.scheduleSearch())}setEmailPromptVisible(e){this.emailPromptEl&&(this.emailPromptEl.dataset.visible=e?"true":"false",e||(this.setEmailPromptBusy(!1),this.emailPromptMode="none",this.setEmailPromptStatus(""),this.setEmailPromptError(""),this.setEmailPromptSuccess("")))}setEmailPromptError(e){this.emailPromptErrorEl&&(this.emailPromptErrorEl.textContent=e)}setEmailPromptSuccess(e){this.emailPromptSuccessEl&&(typeof this.emailPromptSuccessTimer=="number"&&(window.clearTimeout(this.emailPromptSuccessTimer),this.emailPromptSuccessTimer=void 0),this.emailPromptSuccessEl.textContent=e,this.emailPromptSuccessEl.dataset.visible=e?"true":"false")}setEmailPromptStatus(e,t=!1){this.emailPromptStatusEl&&(this.emailPromptStatusEl.textContent=e,this.emailPromptStatusEl.dataset.visible=e?"true":"false",this.emailPromptStatusEl.dataset.busy=t?"true":"false")}getEmailPromptSubmitLabel(){return this.emailPromptMode==="reprompt"?"Get updates":"Send me updates"}getEmailPromptDismissLabel(){return this.emailPromptMode==="reprompt"?"Maybe later":"Skip for now"}updateEmailPromptActions(){this.emailPromptSubmitEl&&(this.emailPromptSubmitEl.textContent=this.emailPromptBusy?"Sending...":this.getEmailPromptSubmitLabel()),this.emailPromptDismissEl&&(this.emailPromptDismissEl.textContent=this.getEmailPromptDismissLabel())}setEmailPromptBusy(e){this.emailPromptBusy=e,this.emailPromptEl&&(this.emailPromptEl.dataset.busy=e?"true":"false"),this.emailPromptInputEl&&(this.emailPromptInputEl.disabled=e),this.emailPromptSubmitEl&&(this.emailPromptSubmitEl.disabled=e),this.emailPromptDismissEl&&(this.emailPromptDismissEl.disabled=e),this.updateEmailPromptActions()}renderEmailPromptContent(e,t){const s=Number.isFinite(t)?Math.max(0,Math.floor(t)):0,a=new Intl.NumberFormat().format(s),r=e==="initial"?"Help shape LLMnesia":"Enjoying LLMnesia so far?",o=e==="initial"?"Want occasional product updates and early feature previews? Leave your email.":`You've searched ${a} conversations. Want early previews and important updates?`,n=e==="initial"?["Early feature previews","Direct feedback loop","Important release updates"]:["Get beta drops first","Share feedback directly","Roadmap and release updates"],c=e==="initial"?"A short email now and then. No spam, unsubscribe any time.":"Only occasional emails when there is something genuinely useful to share.";if(this.emailPromptTitleEl&&(this.emailPromptTitleEl.textContent=r),this.emailPromptCopyEl&&(this.emailPromptCopyEl.textContent=o),this.emailPromptBenefitsEl){this.emailPromptBenefitsEl.replaceChildren();for(const d of n){const h=document.createElement("span");h.className="email-prompt-benefit",h.textContent=d,this.emailPromptBenefitsEl.appendChild(h)}}this.emailPromptTrustEl&&(this.emailPromptTrustEl.textContent=c),this.updateEmailPromptActions()}async refreshEmailPromptState(){let e;try{e=await chrome.runtime.sendMessage({type:"GET_EMAIL_REPROMPT_STATE",surface:"overlay"})}catch{this.setEmailPromptVisible(!1);return}if(!e.ok||!e.showPrompt){this.setEmailPromptVisible(!1);return}if(!await W("email")){this.setEmailPromptVisible(!1);return}this.emailPromptMode=e.mode,(e.mode==="initial"||e.mode==="reprompt")&&this.renderEmailPromptContent(e.mode,e.searchCount),this.setEmailPromptVisible(!0),G("email"),e.mode==="initial"&&chrome.runtime.sendMessage({type:"COMPLETE_ONBOARDING"})}async checkSearchGate(){const e=this.currentQuery;let t;try{t=await chrome.runtime.sendMessage({type:"GET_SEARCH_GATE_STATE"})}catch{this.searchGateActive=!1,this.searchGateProgress=null;return}e===this.currentQuery&&(t.ok?(this.searchGateActive=t.gated,this.searchGateProgress=t.progress):(this.searchGateActive=!1,this.searchGateProgress=null),this.render())}async submitEmailPrompt(){const e=he(this.emailPromptInputEl?.value);if(!pe(e)){this.setEmailPromptError("Enter a valid email first.");return}this.setEmailPromptError(""),this.setEmailPromptSuccess(""),this.setEmailPromptStatus("Saving your email...",!0),this.setEmailPromptBusy(!0);let t;try{const s=this.emailPromptMode==="reprompt"?ue:"onboarding_install";t=await chrome.runtime.sendMessage({type:"SUBMIT_ONBOARDING_EMAIL",email:e,context:s})}catch(s){const a=s instanceof Error?s.message:"Unknown runtime error";this.setEmailPromptStatus(""),this.setEmailPromptError(`Couldn't submit right now: ${a}`),this.setEmailPromptBusy(!1);return}if(!t.ok){this.setEmailPromptStatus(""),this.setEmailPromptError(t.error||"Couldn't submit right now."),this.setEmailPromptBusy(!1);return}this.setEmailPromptStatus(""),this.setEmailPromptBusy(!1),this.emailPromptInputEl&&(this.emailPromptInputEl.value=""),this.setEmailPromptSuccess("You're all set. Thanks for joining us. We'll send occasional updates and early previews."),this.emailPromptSuccessTimer=window.setTimeout(()=>{this.setEmailPromptVisible(!1)},5400),this.focusInput()}async dismissEmailPrompt(){this.setEmailPromptStatus(""),this.setEmailPromptError(""),this.setEmailPromptBusy(!0);let e;try{this.emailPromptMode==="initial"?e=await chrome.runtime.sendMessage({type:"COMPLETE_ONBOARDING"}):e=await chrome.runtime.sendMessage({type:"DISMISS_EMAIL_REPROMPT"})}catch(t){const s=t instanceof Error?t.message:"Unknown runtime error";this.setEmailPromptError(`Dismiss failed: ${s}`),this.setEmailPromptBusy(!1);return}if(!e.ok){this.setEmailPromptError(e.error||"Dismiss failed."),this.setEmailPromptBusy(!1);return}this.setEmailPromptVisible(!1),this.setEmailPromptBusy(!1),this.focusInput()}async ensurePreferencesLoaded(){if(!this.preferencesLoaded){if(this.preferencesLoadPromise){await this.preferencesLoadPromise;return}this.preferencesLoadPromise=(async()=>{try{const e=await chrome.storage.local.get([B,D]);this.recentLimit=j(e[D]);const t=e[B];t&&typeof t=="object"&&(typeof t.sortMode=="string"&&qe(t.sortMode)&&(this.sortMode=t.sortMode),typeof t.recentsSortMode=="string"&&K(t.recentsSortMode)&&(this.recentsSortMode=t.recentsSortMode),typeof t.updatedWindow=="string"&&ze(t.updatedWindow)&&(this.updatedWindow=t.updatedWindow),Array.isArray(t.platformFilters)?this.platformFilters=new Set(t.platformFilters.filter(s=>_(s)&&!H.has(s))):typeof t.platformFilter=="string"&&t.platformFilter!=="playgrounds"&&_(t.platformFilter)&&!H.has(t.platformFilter)&&(this.platformFilters=new Set([t.platformFilter])),typeof t.mediaFilter=="string"&&Y(t.mediaFilter)&&(this.mediaFilter=t.mediaFilter),typeof t.matchFilter=="string"&&X(t.matchFilter)&&(this.matchFilter=t.matchFilter),typeof t.starredOnly=="boolean"&&(this.starredOnly=t.starredOnly),typeof t.showFilters=="boolean"&&(this.showFilters=t.showFilters))}catch{}finally{this.preferencesLoaded=!0,this.preferencesLoadPromise=null}})(),await this.preferencesLoadPromise}}persistPreferences(){const e={sortMode:this.sortMode,recentsSortMode:this.recentsSortMode,updatedWindow:this.updatedWindow,platformFilter:this.platformFilters.size===1?Array.from(this.platformFilters)[0]:"all",platformFilters:Array.from(this.platformFilters),mediaFilter:this.mediaFilter,matchFilter:this.matchFilter,starredOnly:this.starredOnly,showFilters:this.showFilters};chrome.storage.local.set({[B]:e}).catch(()=>{})}setMatchAllWords(e){this.matchAllWords=e,this.searchRequestId+=1,this.resetBrowsePage(),this.updateControlState(),this.scheduleSearch(0)}resetFilters(){this.searchRequestId+=1,this.recentsSortMode="modified_desc",this.sortMode="best_match",this.updatedWindow="any",this.platformFilters.clear(),this.mediaFilter="all",this.matchFilter="all",this.matchAllWords=!1,this.starredOnly=!1,this.resetBrowsePage(),this.persistPreferences(),this.updateControlState(),this.scheduleSearch()}resetBrowsePage(){this.recentOffset=0,this.hasMoreRecentResults=!1,this.updatePagination()}updatePagination(){if(!this.paginationEl||!this.newerPageEl||!this.olderPageEl)return;const t=this.currentQuery.length===0&&(this.recentOffset>0||this.hasMoreRecentResults);this.paginationEl.dataset.visible=t?"true":"false",this.newerPageEl.disabled=this.recentOffset===0,this.olderPageEl.disabled=!this.hasMoreRecentResults}scrollPlatformFilters(e){if(!this.platformScrollViewportEl)return;const t=Math.max(120,Math.round(this.platformScrollViewportEl.clientWidth*.72));this.platformScrollViewportEl.scrollLeft+=e*t,window.setTimeout(()=>this.updatePlatformScrollButtons(),0)}updatePlatformScrollButtons(){if(!this.platformScrollViewportEl||!this.platformScrollBackEl||!this.platformScrollForwardEl)return;const{scrollLeft:e,scrollWidth:t,clientWidth:s}=this.platformScrollViewportEl,a=t>s+1;this.platformScrollBackEl.hidden=!a,this.platformScrollForwardEl.hidden=!a,this.platformScrollBackEl.disabled=!a||e<=1,this.platformScrollForwardEl.disabled=!a||e+s>=t-1}updatedAfterCutoffMs(){if(this.updatedWindow==="any")return null;const e=Be[this.updatedWindow];return Date.now()-e}renderPlatformChips(){this.platformChipsEl&&(this.platformChipsEl.childElementCount>0||(this.platformChipsEl.innerHTML=['<button class="control-chip platform-chip" type="button" data-platform="all">All</button>',...Xe.map(e=>{const t=g(L(e).label);return`<button class="control-chip platform-chip" type="button" data-platform="${g(e)}">${t}</button>`})].join(""),window.setTimeout(()=>this.updatePlatformScrollButtons(),0)))}updateControlState(){const e=this.host?.shadowRoot;if(!e)return;const t=this.currentQuery.length>0;e.querySelectorAll("button[data-recents-sort]").forEach(r=>{const o=r.dataset.recentsSort===this.recentsSortMode;r.classList.toggle("selected",o),r.setAttribute("aria-pressed",String(o))}),e.querySelectorAll("button[data-sort]").forEach(r=>{const o=r.dataset.sort===this.sortMode;r.classList.toggle("selected",o),r.setAttribute("aria-pressed",String(o))}),e.querySelectorAll("button[data-recent-count]").forEach(r=>{const o=Number(r.dataset.recentCount)===this.recentLimit;r.classList.toggle("selected",o),r.setAttribute("aria-pressed",String(o))}),e.querySelectorAll("button[data-updated]").forEach(r=>{const o=r.dataset.updated===this.updatedWindow;r.classList.toggle("selected",o),r.setAttribute("aria-pressed",String(o))}),e.querySelectorAll("button[data-media]").forEach(r=>{const o=r.dataset.media===this.mediaFilter;r.classList.toggle("selected",o),r.setAttribute("aria-pressed",String(o))}),e.querySelectorAll("button[data-match]").forEach(r=>{const o=r.dataset.match===this.matchFilter;r.classList.toggle("selected",o),r.setAttribute("aria-pressed",String(o))}),e.querySelectorAll("button[data-starred]").forEach(r=>{const o=r.dataset.starred===(this.starredOnly?"only":"all");r.classList.toggle("selected",o),r.setAttribute("aria-pressed",String(o))}),this.starredToggleEl&&(this.starredToggleEl.classList.toggle("active",this.starredOnly),this.starredToggleEl.setAttribute("aria-pressed",String(this.starredOnly))),e.querySelectorAll("button[data-word-match]").forEach(r=>{const o=r.dataset.wordMatch==="all"===this.matchAllWords;r.classList.toggle("selected",o),r.setAttribute("aria-pressed",String(o))}),this.allWordsChipEl&&(this.allWordsChipEl.hidden=!(t&&this.matchAllWords)),e.querySelectorAll("button[data-platform]").forEach(r=>{const o=r.dataset.platform,n=o==="all"?this.platformFilters.size===0:typeof o=="string"&&_(o)&&this.platformFilters.has(o);r.classList.toggle("selected",n),r.setAttribute("aria-pressed",String(n))}),e.querySelectorAll(".controls .control-chip").forEach(r=>{const o=r.dataset.sort==="best_match"||r.dataset.recentsSort==="modified_desc"||r.dataset.updated==="any"||r.dataset.media==="all"||r.dataset.match==="all"||r.dataset.starred==="all"||r.dataset.wordMatch==="normal"||r.dataset.platform==="all";r.classList.toggle("filter-active",r.classList.contains("selected")&&!o)}),e.querySelectorAll(".control-row").forEach(r=>{r.classList.toggle("has-active-choice",r.querySelector(".filter-active")!==null)});let s=0;t&&this.matchAllWords&&(s+=1),t&&this.sortMode!=="best_match"&&(s+=1),!t&&this.recentsSortMode!=="modified_desc"&&(s+=1),this.updatedWindow!=="any"&&(s+=1),this.platformFilters.size>0&&(s+=this.platformFilters.size),this.mediaFilter!=="all"&&(s+=1),this.starredOnly&&(s+=1),this.matchFilter!=="all"&&(s+=1);const a=s>0;if(this.controlsEl&&(this.controlsEl.style.display=this.showFilters?"flex":"none"),this.recentsRowEl&&(this.recentsRowEl.style.display=t?"none":"flex"),this.sortRowEl&&(this.sortRowEl.style.display=t?"flex":"none"),this.matchRowEl){const r=this.rawResults.some(F);this.showFilters?this.filterMenuMatchRowVisible??=r:this.filterMenuMatchRowVisible=null,this.matchRowEl.style.display=(this.showFilters?this.filterMenuMatchRowVisible:r)?"flex":"none"}this.filtersToggleEl&&(this.filtersToggleEl.classList.toggle("active",this.showFilters||a),this.filtersToggleEl.textContent=this.showFilters?"Hide filters":a?`Filters (${s})`:"Filters",this.filtersToggleEl.setAttribute("aria-expanded",String(this.showFilters))),this.quickClearFiltersEl&&(this.quickClearFiltersEl.hidden=!1,this.quickClearFiltersEl.disabled=!a),this.updatePagination(),window.setTimeout(()=>this.updatePlatformScrollButtons(),0),this.activeFiltersEl&&(this.activeFiltersEl.textContent=a?`${s} active`:"Default view")}activeFilterLabels(){const e=this.currentQuery.length>0,t=[];if(e&&this.matchAllWords&&t.push("All words"),!e&&this.recentsSortMode!=="modified_desc"&&t.push(`Recents: ${Qe(this.recentsSortMode)}`),e&&(this.sortMode==="updated_desc"?t.push("Sort: Newest"):this.sortMode==="updated_asc"&&t.push("Sort: Oldest")),this.updatedWindow!=="any"&&t.push(`Updated: ${De(this.updatedWindow)}`),this.mediaFilter!=="all"&&t.push(`Media: ${Ge(this.mediaFilter)}`),this.starredOnly&&t.push("Starred only"),this.matchFilter!=="all"&&t.push(`Match: ${Ue(this.matchFilter)}`),this.platformFilters.size>0){const s=Array.from(this.platformFilters).map(a=>L(a).label);t.push(`Platforms: ${s.join(", ")}`)}return t}applyResultPresentation(e){const t=this.resultsEl?.scrollTop??0;this.renderPlatformChips();const s=this.updatedAfterCutoffMs(),a=this.currentQuery.length>0,r=a?this.sortMode:"updated_desc",o=this.matchFilter!=="all"&&this.rawResults.some(F),n=this.rawResults.filter(d=>!(this.platformFilters.size>0&&!this.platformFilters.has(d.platform)||s!==null&&d.updatedAt<s||this.mediaFilter==="with_images"&&!((d.platform==="chatgpt"||d.platform==="gemini")&&d.hasImages)||this.starredOnly&&!d.starred||o&&this.matchFilter==="meaning"&&!F(d)||o&&this.matchFilter==="keyword"&&d.matchedByMeaning===!0));a?r==="updated_desc"?this.results=[...n].sort((d,h)=>h.updatedAt-d.updatedAt):r==="updated_asc"?this.results=[...n].sort((d,h)=>d.updatedAt-h.updatedAt):this.results=n:this.recentsSortMode==="opened_desc"?this.results=[...n].sort((d,h)=>{const m=M(h)-M(d);return m!==0?m:h.updatedAt-d.updatedAt}):this.results=[...n].sort((d,h)=>{const m=this.recentsSortMode==="modified_asc"?1:-1,u=m*(d.updatedAt-h.updatedAt);return u!==0?u:m*(M(d)-M(h))});const c=e?this.results.findIndex(d=>d.docId===e):-1;c>=0&&(this.selectedIndex=c),this.selectedIndex=Math.min(this.selectedIndex,Math.max(0,this.results.length-1)),this.updateControlState(),this.updateStatusFromPresentation(),this.render(),this.showFilters&&this.resultsEl&&(this.resultsEl.scrollTop=t)}updateStatusFromPresentation(){const e=this.results.length,t=this.rawResults.length,s=e===1?"":"s";this.updateSearchHint();const a=this.currentQuery.length>0&&this.matchAllWords||this.updatedWindow!=="any"||this.platformFilters.size>0||this.mediaFilter!=="all"||this.matchFilter!=="all"||this.currentQuery.length===0&&this.recentsSortMode!=="modified_desc";if(this.currentQuery.length>0){this.setCountStatus(e,e===t?`result${s}`:"displayed",a);return}if(this.recentOffset>0||this.hasMoreRecentResults){const r=e>0?this.recentOffset+1:this.recentOffset,o=this.recentOffset+e;this.setCountStatus(e,`chats · ${r}–${o}`,a)}else this.setCountStatus(e,"recent",a)}setCountStatus(e,t,s=!1){if(!this.statusEl)return;this.statusEl.textContent="";const a=document.createElement("button");if(a.type="button",a.className="count-pick",a.textContent=String(e),a.title="Change how many to show",a.setAttribute("aria-haspopup","menu"),a.setAttribute("aria-expanded",String(this.showCountMenu)),this.statusEl.append(a,document.createTextNode(` ${t}`)),s){const r=document.createElement("button");r.type="button",r.className="filtered-badge",r.textContent="Filtered",r.title=this.showFilters?"Filters are active":"Filters are active — click to review or clear them",this.statusEl.append(r)}this.updateCountMenu()}toggleCountMenu(e){this.showCountMenu=e??!this.showCountMenu,this.updateCountMenu()}closeCountMenu(){this.showCountMenu&&(this.showCountMenu=!1,this.updateCountMenu())}updateCountMenu(){this.countMenuEl&&(this.countMenuEl.hidden=!this.showCountMenu),this.statusEl?.querySelector(".count-pick")?.setAttribute("aria-expanded",String(this.showCountMenu))}applyRecentLimit(e){const t=j(e);this.closeCountMenu(),t!==this.recentLimit&&(this.recentLimit=t,this.resetBrowsePage(),chrome.storage.local.set({[D]:t}).catch(()=>{}),this.updateControlState(),this.preserveResultsView=!0,this.scheduleSearch()),this.focusInput()}startFocusLoop(){this.stopFocusLoop(),this.focusTimer=window.setInterval(()=>{if(!this.openState||!this.inputEl)return;const e=this.host?.shadowRoot?.activeElement,t=e!=null&&this.firstSearchSuggestionsEl?.contains(e)||e===this.emailPromptInputEl||e===this.emailPromptSubmitEl||e===this.emailPromptDismissEl;e!==this.inputEl&&!t&&!this.isFilterControlFocused(e)&&this.focusInput()},220)}stopFocusLoop(){typeof this.focusTimer=="number"&&(window.clearInterval(this.focusTimer),this.focusTimer=void 0)}isFilterControlFocused(e){return e!=null&&(this.controlsEl?.contains(e)===!0||e===this.filtersToggleEl||e===this.allWordsChipEl)}orgEnabled(){return this.orgState?.enabled===!0}orgSpaceName(e){const t=this.orgState?.spaces?.find(a=>a.id===e);return t?(this.orgState?.spaces??[]).filter(a=>a.name===t.name).length>1?`${t.name} (${t.id.slice(-4)})`:t.name:"Removed space"}async refreshOrganisationState(){const e=++this.stateRequestId;let t=null;try{const a=await chrome.runtime.sendMessage({type:"ORGANISATION_GET_STATE"});if(e!==this.stateRequestId)return;t=a?.ok?{enabled:a.enabled===!0,scope:a.scope??(a.enabled?R:{kind:"unclassified"}),missingSpaceIds:a.missingSpaceIds??[],spaces:a.spaces??[],revisionToken:a.revisionToken??""}:null}catch{t=this.orgState}if(e!==this.stateRequestId)return;const s=this.orgState;this.orgState=t,s!==t&&(s===null||t===null||!V({enabled:s.enabled===!0,scope:s.scope??null,revisionToken:s.revisionToken??null},{enabled:t.enabled===!0,scope:t.scope??null,revisionToken:t.revisionToken??null}))&&this.invalidateOrganisationView(),this.renderScopeChips(),this.updateOrganiseBar()}invalidateOrganisationView(){this.viewGeneration+=1,this.invalidateFirstSearchSuggestions(),this.rawResults=[],this.results=[],this.orgLabels.clear(),this.orgScopeEmpty=!1,this.matchedBeforeUserFilters=0,this.hasMoreRecentResults=!1,this.recentOffset=0,this.resultSearchId=void 0,this.selectedIndex=0,this.renderPlatformChips(),this.updateControlState(),this.render()}async setOrganisationScope(e){if(this.invalidateOrganisationView(),!Re()){try{const t=await chrome.runtime.sendMessage({type:"ORGANISATION_REQUEST_SCOPE_CHANGE",scope:e});t&&t.ok===!1?this.setStatus(`Scope change failed: ${t.error??"refused"}`):this.setStatus("Finish choosing this scope in LLMnesia Settings.")}catch(t){this.setStatus(`Scope change failed: ${t instanceof Error?t.message:"no response"}`)}return}try{const t=await chrome.runtime.sendMessage({type:"ORGANISATION_SET_SCOPE",scope:e});t&&t.ok===!1&&this.setStatus(`Scope change failed: ${t.error??"refused"}`)}catch(t){this.setStatus(`Scope change failed: ${t instanceof Error?t.message:"no response"}`)}await this.refreshOrganisationState(),this.openState&&this.scheduleSearch(0)}renderScopeChips(){if(!this.orgScopeRowEl||!this.orgScopeChipsEl)return;if(!this.orgEnabled()||!this.orgState){if(this.orgScopeRowEl.hidden=!0,this.orgScopeMixEl){this.orgScopeMixEl.textContent="";const o=this.orgScopeMixEl.closest(".scope-mix-row");o&&(o.hidden=!0)}this.orgScopeHintEl&&(this.orgScopeHintEl.remove(),this.orgScopeHintEl=null);return}this.orgScopeRowEl.hidden=!1;const e=this.orgState,t=e.scope??R,s=[],a=t.kind==="space"?t.spaceId:t.kind==="spaces"&&t.spaceIds.length===1&&!t.includeUnclassified?t.spaceIds[0]:null;s.push(`<button class="control-chip scope-chip" type="button" data-scope-option="unclassified" aria-pressed="${t.kind==="unclassified"}"${t.kind==="unclassified"?' data-active="true"':""}>Unclassified</button>`);for(const o of e.spaces??[]){const n=a===o.id;s.push(`<button class="control-chip scope-chip" type="button" data-scope-option="space:${g(o.id)}" aria-pressed="${n}"${n?' data-active="true"':""}>${g(this.orgSpaceName(o.id))}</button>`)}const r=t.kind==="spaces"&&(t.spaceIds.length>1||t.includeUnclassified);s.push(`<button class="control-chip scope-chip" type="button" data-scope-option="mix" aria-pressed="${r||this.orgScopeMixVisible}">Selected spaces…</button>`),(e.missingSpaceIds??[]).length>0&&s.push('<button class="control-chip scope-chip" type="button" data-org-open-settings title="A selected space was removed. Choose a replacement.">Space removed, choose again</button>'),this.orgScopeChipsEl.innerHTML=s.join(""),this.updateControlState(),this.renderScopeMix(),this.renderScopeHint()}renderScopeMix(){if(!this.orgScopeMixEl)return;const e=this.orgScopeMixEl.closest(".scope-mix-row");if(!this.orgEnabled()||!this.orgState){e&&(e.hidden=!0);return}const t=this.orgState.scope??R,s=this.orgScopeMixVisible||t.kind==="spaces"&&t.spaceIds.length>0;if(e&&(e.hidden=!s),!s){this.orgScopeMixEl.textContent="";return}const a=t.kind==="spaces"?t.spaceIds:[],r=t.kind==="spaces"?t.includeUnclassified:!1,o=[];o.push(`<button class="control-chip scope-mix-chip" type="button" data-scope-mix="unclassified" aria-pressed="${r}" data-checked="${r}">Unclassified</button>`);for(const n of this.orgState?.spaces??[]){const c=a.includes(n.id);o.push(`<button class="control-chip scope-mix-chip" type="button" data-scope-mix="space:${g(n.id)}" aria-pressed="${c}" data-checked="${c}">${g(this.orgSpaceName(n.id))}</button>`)}this.orgScopeMixEl.innerHTML=o.join("")}renderScopeHint(){if(!this.searchHintEl)return;if(!this.orgEnabled()||!this.orgState){this.orgScopeHintEl&&(this.orgScopeHintEl.remove(),this.orgScopeHintEl=null);return}const e=this.orgState.scope??R,t=xe(e,s=>this.orgSpaceName(s));(!this.orgScopeHintEl||!this.searchHintEl.contains(this.orgScopeHintEl))&&(this.orgScopeHintEl=document.createElement("span"),this.orgScopeHintEl.className="scope-name",this.searchHintEl.prepend(this.orgScopeHintEl)),this.orgScopeHintEl.textContent=`Searching: ${t} · `}toggleOrgSelection(e){if(this.orgSelection.has(e))this.orgSelection.delete(e);else{if(this.orgSelection.size>=U){this.setStatus(`You can organise up to ${U} chats at once.`);return}this.orgSelection.add(e)}this.updateOrganiseBar(),this.render()}updateOrganiseBar(){if(!this.organiserBarEl||!this.organiserCountEl||!this.organiserGoEl)return;const e=this.orgEnabled()&&this.orgSelection.size>0;this.organiserBarEl.hidden=!e,e&&(this.organiserCountEl.textContent=`${this.orgSelection.size} selected`,this.organiserGoEl.disabled=!1)}async openOrganiserWithSelection(){const e=Array.from(this.orgSelection);if(e.length!==0)try{const t=await chrome.runtime.sendMessage({type:"ORGANISATION_OPEN_ORGANISER",documentIds:e});if(t?.ok){this.orgSelection.clear(),this.updateOrganiseBar(),this.close();return}this.setStatus(`Could not open the organiser: ${t?.error??"no response"}`)}catch(t){this.setStatus(`Could not open the organiser: ${t instanceof Error?t.message:"no response"}`)}}scheduleSearch(e=_e){this.updateClearButtonState(),this.renderFirstSearchSuggestions(),typeof this.searchTimer=="number"&&window.clearTimeout(this.searchTimer),this.searchTimer=window.setTimeout(()=>{this.runSearch()},e)}scheduleSearchHistorySave(e){typeof this.searchHistorySaveTimer=="number"&&window.clearTimeout(this.searchHistorySaveTimer),this.searchHistorySaveTimer=window.setTimeout(()=>{this.searchHistorySaveTimer=void 0,e===(this.inputEl?.value??"").trim()&&this.saveToSearchHistory(e)},Oe)}async runSearch(e={}){this.degradedIndexWarningEl&&!this.degradedIndexWarningEl.hidden&&this.checkDegradedIndex();const t=++this.searchRequestId,s=this.viewGeneration,r=(this.inputEl?.value??"").trim();this.currentQuery=r;const o=this.showFilters&&r===this.resultQuery;!e.quiet&&!o&&this.setStatus(r?"Searching...":"Loading recent chats...");let n;try{n=await chrome.runtime.sendMessage({type:"SEARCH_QUERY",query:r,sentAtMs:Date.now(),...r.length===0?{recentOffset:this.recentOffset,recentOrder:this.recentsSortMode==="opened_desc"?"opened":this.recentsSortMode==="modified_asc"?"modified_asc":"seen"}:{},platformFilters:Array.from(this.platformFilters),mediaFilter:this.mediaFilter,updatedAfterMs:this.updatedAfterCutoffMs(),excludePlatforms:Array.from(H),starredOnly:this.starredOnly,matchAllWords:this.matchAllWords,matchFilter:this.matchFilter,surface:"overlay"})}catch(m){if(t!==this.searchRequestId||s!==this.viewGeneration||r!==(this.inputEl?.value??"").trim())return;const u=m instanceof Error?m.message:"Unknown runtime error";this.rawResults=[],this.matchedBeforeUserFilters=0,this.hasMoreRecentResults=!1,this.results=[],this.selectedIndex=0,this.resultsCollapsed=!1,this.renderPlatformChips(),this.updateControlState(),this.setStatus(`Search failed: ${u}`),this.render();return}if(t!==this.searchRequestId||s!==this.viewGeneration||r!==(this.inputEl?.value??"").trim())return;if(!n?.ok){this.rawResults=[],this.matchedBeforeUserFilters=0,this.hasMoreRecentResults=!1,this.results=[],this.selectedIndex=0,this.resultsCollapsed=!1,this.renderPlatformChips(),this.updateControlState(),this.setStatus(`Search failed: ${n?.error??"No response from background"}`),this.render();return}if(s!==this.viewGeneration)return;const c=n.organisation;if(c?.superseded&&!this.orgState){this.invalidateOrganisationView(),await this.refreshOrganisationState(),t===this.searchRequestId&&this.openState&&this.scheduleSearch(0);return}if(c&&this.orgState){if(c.superseded===!0||!V({enabled:c.enabled,scope:c.scope??null,revisionToken:c.revisionToken??null},{enabled:this.orgState.enabled===!0,scope:this.orgState.scope??null,revisionToken:this.orgState.revisionToken??null})){if(await this.refreshOrganisationState(),t!==this.searchRequestId)return;this.openState&&this.scheduleSearch(0);return}this.orgLabels=new Map(Object.entries(c.labels??{})),this.orgScopeEmpty=c.scopeEmpty===!0}else c?(this.orgLabels=new Map(Object.entries(c.labels??{})),this.orgScopeEmpty=c.scopeEmpty===!0,this.refreshOrganisationState().then(()=>{t===this.searchRequestId&&s!==this.viewGeneration&&this.openState&&this.scheduleSearch(0)})):(this.orgLabels=new Map,this.orgScopeEmpty=!1);const d=r.length===0&&n.hasMore===!0;if(e.quiet&&r===this.resultQuery&&d===this.hasMoreRecentResults&&Z(n.results)===Z(this.rawResults))return;const h=e.quiet||o?this.results[this.selectedIndex]?.docId:void 0;r!==this.resultQuery&&(this.filterMenuMatchRowVisible=null),this.rawResults=n.results,this.resultQuery=r,this.resultSearchId=r?n.searchId:void 0,r&&(this.firstSearchTerms=[],this.firstSearchSuggestionRequest+=1),this.matchedBeforeUserFilters=n.matchedBeforeUserFilters??0,this.hasMoreRecentResults=d,this.selectedIndex=0,e.quiet||(this.resultsCollapsed=!1),this.historyNavIndex<0&&r&&(this.pendingHistoryQuery=r,this.scheduleSearchHistorySave(r)),this.applyResultPresentation(h),await this.refreshEmailPromptState(),await this.checkSearchGate()}async openSelected(e,t=!1,s=!1){const a=this.results[this.selectedIndex];if(!a)return;const r=this.inputEl?.value?.trim()??"";let o;try{o=await chrome.runtime.sendMessage({type:"OPEN_RESULT",result:a,inNewTab:e,background:t,query:r,fromSearch:r.length>0&&r===this.resultQuery,searchId:r.length>0&&r===this.resultQuery?this.resultSearchId:void 0,rank:this.selectedIndex,forceViewer:s,surface:"overlay"})}catch(n){const c=n instanceof Error?n.message:"Unknown runtime error";this.setStatus(`Open failed: ${c}`);return}if(o.ok){t||this.close();return}this.setStatus(`Open failed: ${o.error}`)}async removeResult(e){const t=this.results[e];if(!t||this.deletingDocIds.has(t.docId))return;const s=t.title.trim(),a=s.length>0?s:"this chat";if(!window.confirm(`Remove "${a}" from local index?`))return;this.deletingDocIds.add(t.docId),this.render();let o;try{o=await chrome.runtime.sendMessage({type:"DELETE_CONVERSATION",docId:t.docId})}catch(n){const c=n instanceof Error?n.message:"Unknown runtime error";this.setStatus(`Delete failed: ${c}`),this.deletingDocIds.delete(t.docId),this.render();return}if(this.deletingDocIds.delete(t.docId),this.render(),!o.ok){this.setStatus(`Delete failed: ${o.error}`);return}await this.runSearch()}renameResult(e){const t=this.results[e];if(!t)return;const s=this.resultsEl?.querySelector(`.result-btn[data-index="${e}"]`)?.closest(".item-row"),a=s?.querySelector(".title-main"),r=s?.querySelector(".result-title"),o=s?.querySelector("button[data-rename-index]");if(!s||!a||!r||!o)return;const n=a.querySelector(".rename-editor");if(n){n.querySelector(".rename-input")?.focus();return}this.resultsEl?.querySelector(".rename-cancel")?.click();const c=t.providerTitle?.trim()||t.title.trim()||"Untitled conversation",d=document.createElement("form");d.className="rename-editor";const h=document.createElement("input");h.className="rename-input",h.type="text",h.maxLength=160,h.value=t.localTitle??t.title,h.autocomplete="off",h.spellcheck=!1,h.title=`Leave blank to restore the original title: ${c}`,h.setAttribute("aria-label",`Title in LLMnesia. Leave blank to restore the original title: ${c}`);const m=document.createElement("button");m.className="rename-editor-action rename-save",m.type="submit",m.textContent="✓",m.title="Save title",m.setAttribute("aria-label","Save title");const u=document.createElement("button");u.className="rename-editor-action rename-cancel",u.type="button",u.textContent="×",u.title="Cancel",u.setAttribute("aria-label","Cancel title edit"),d.append(h,m,u);const w=()=>{d.remove(),r.hidden=!1,o.hidden=!1};u.addEventListener("click",p=>{p.stopPropagation(),w(),this.inputEl?.focus()});let b=!1;d.addEventListener("submit",p=>{p.preventDefault(),p.stopPropagation(),!b&&(b=!0,h.disabled=!0,m.disabled=!0,u.disabled=!0,(async()=>{let x;try{x=await chrome.runtime.sendMessage({type:"SET_CONVERSATION_LOCAL_TITLE",docId:t.docId,localTitle:h.value})}catch(f){const I=f instanceof Error?f.message:"Unknown runtime error";this.setStatus(`Title update failed: ${I}`),b=!1,h.disabled=!1,m.disabled=!1,u.disabled=!1,h.focus();return}if(!x.ok){this.setStatus(`Title update failed: ${x.error}`),b=!1,h.disabled=!1,m.disabled=!1,u.disabled=!1,h.focus();return}const S=f=>{f.title=x.title,f.providerTitle=x.providerTitle,x.localTitle?f.localTitle=x.localTitle:delete f.localTitle};S(t);const E=this.rawResults.find(f=>f.docId===t.docId);E&&E!==t&&S(E);const C=J(t);r.innerHTML=q(C,this.currentQuery);const v=C||"conversation";o.setAttribute("aria-label",`Edit title for ${v}`),s.querySelector("button[data-viewer-index]")?.setAttribute("aria-label",`Open saved copy of ${v}`),s.querySelector("button.result-open-btn")?.setAttribute("aria-label",`Open ${v}`);const $=s.querySelector("button[data-star-index]");$?.setAttribute("aria-label",t.starred?`Unstar ${v}`:`Star ${v}`),$?.setAttribute("title",t.starred?`Unstar ${v}`:`Star ${v}`),s.querySelector("button[data-remove-index]")?.setAttribute("aria-label",`Delete ${v}`),w(),this.inputEl?.focus()})())}),r.hidden=!0,o.hidden=!0,a.append(d),h.focus(),h.select()}async toggleStar(e){const t=this.results[e];if(!t)return;const s=!t.starred,a=s?"Star":"Unstar",r=n=>{t.starred=n;const c=this.rawResults.find(d=>d.docId===t.docId);c&&(c.starred=n)};r(s),this.render();let o;try{o=await chrome.runtime.sendMessage({type:"SET_CONVERSATION_STARRED",docId:t.docId,starred:s})}catch(n){const c=n instanceof Error?n.message:"Unknown runtime error";r(!s),this.render(),this.setStatus(`${a} failed: ${c}`);return}if(!o.ok){r(!s),this.render(),this.setStatus(`${a} failed: ${o.error}`);return}this.starredOnly&&this.applyResultPresentation()}setStatus(e){this.closeCountMenu(),this.statusEl&&(this.statusEl.textContent=e)}updateSearchHint(){if(!this.searchHintEl)return;const e=this.indexedConversationCount>=0?`${this.indexedConversationCount} indexed`:"Indexed chats";this.searchHintEl.innerHTML=`${g(e)} <span class="dot-sep">·</span> <kbd>↑</kbd>/<kbd>↓</kbd> to browse`,this.renderScopeHint()}moveSelection(e){if(this.results.length===0)return;const{start:t,end:s}=this.meaningView();this.historyNavIndex=-1;const a=this.selectedIndex;this.selectedIndex<t||this.selectedIndex>s?this.selectedIndex=e>0?t:s:this.selectedIndex=Math.min(s,Math.max(t,this.selectedIndex+e)),this.selectedIndex!==a&&this.updateSelectedResultState(a,this.selectedIndex),this.scrollSelectedResultIntoView()}updateSelectedResultState(e,t){this.resultsEl&&(e>=0&&this.resultsEl.querySelector(`.result-btn[data-index="${e}"]`)?.classList.remove("selected"),t>=0&&this.resultsEl.querySelector(`.result-btn[data-index="${t}"]`)?.classList.add("selected"))}scrollSelectedResultIntoView(){if(!this.resultsEl||this.selectedIndex<0)return;const e=this.resultsEl.querySelector(`.result-btn[data-index="${this.selectedIndex}"]`),t=e?.closest(".item")??e;if(!t)return;const s=this.resultsEl.getBoundingClientRect(),a=t.getBoundingClientRect(),r=6;if(a.top<s.top+r){this.resultsEl.scrollTop=Math.max(0,this.resultsEl.scrollTop-(s.top+r-a.top));return}a.bottom>s.bottom-r&&(this.resultsEl.scrollTop+=a.bottom-(s.bottom-r))}updateHistoryToggleVisibility(){this.historyToggleEl&&(this.historyToggleEl.hidden=this.searchHistory.length===0,this.searchHistory.length===0&&this.closeHistoryDropdown())}updateHistoryToggleState(){!this.historyToggleEl||!this.historyDropdownEl||(this.historyToggleEl.classList.toggle("open",this.showHistoryDropdown),this.historyToggleEl.setAttribute("aria-expanded",String(this.showHistoryDropdown)),this.historyDropdownEl.hidden=!this.showHistoryDropdown)}closeHistoryDropdown(){this.showHistoryDropdown&&(this.showHistoryDropdown=!1,this.updateHistoryToggleState())}renderHistoryDropdown(){if(this.historyDropdownEl){this.historyDropdownEl.innerHTML="";for(let e=0;e<this.searchHistory.length;e++){const t=this.searchHistory[e],s=document.createElement("div");s.className="history-item";const a=document.createElement("span");a.className="history-item-text",a.textContent=t;const r=document.createElement("button");r.className="history-item-remove",r.type="button",r.setAttribute("aria-label","Remove"),r.textContent="×",r.addEventListener("click",o=>{o.stopPropagation(),this.removeFromSearchHistory(e).then(()=>{this.showHistoryDropdown&&this.renderHistoryDropdown()})}),s.addEventListener("click",()=>{this.inputEl&&(this.inputEl.value=t,this.updateClearButtonState()),this.historyNavIndex=-1,this.scheduleSearch(),this.closeHistoryDropdown(),this.focusInput()}),s.append(a,r),this.historyDropdownEl.append(s)}}}async loadSearchHistory(){try{const t=(await chrome.storage.local.get(T))[T];if(Array.isArray(t)){const s=t.filter(r=>typeof r=="string"),a=this.searchHistory.filter(r=>!s.includes(r));this.searchHistory=[...a,...s].slice(0,Q)}}catch{}this.updateHistoryToggleVisibility()}async saveToSearchHistory(e){const t=e.trim();if(t.length<2)return;let s=[];try{const r=(await chrome.storage.local.get(T))[T];Array.isArray(r)&&(s=r.filter(o=>typeof o=="string"))}catch{}this.searchHistory=Array.from(new Set([t,...s,...this.searchHistory])).slice(0,Q),this.updateHistoryToggleVisibility();try{await chrome.storage.local.set({[T]:this.searchHistory})}catch{}}async removeFromSearchHistory(e){this.searchHistory.splice(e,1);try{await chrome.storage.local.set({[T]:this.searchHistory})}catch{}this.updateHistoryToggleVisibility()}hasSuggestionFilters(){return this.updatedWindow!=="any"||this.mediaFilter!=="all"||this.starredOnly||this.matchFilter!=="all"||this.platformFilters.size>0}invalidateFirstSearchSuggestions(){this.firstSearchTerms=[],this.firstSearchSuggestionRequest+=1,this.renderFirstSearchSuggestions()}async loadFirstSearchSuggestions(){const e=this.firstSearchSuggestionRequest;if(!this.hasSuggestionFilters())try{const t=await chrome.runtime.sendMessage({type:"GET_SEARCH_SUGGESTIONS",mode:"first_search"});if(!this.openState||e!==this.firstSearchSuggestionRequest||!t?.ok)return;this.firstSearchTerms=(t.terms??[]).filter(s=>typeof s=="string"&&s.length>0&&s.length<=80).slice(0,3),this.renderFirstSearchSuggestions()}catch{}}renderFirstSearchSuggestions(){const e=this.firstSearchSuggestionsEl;if(!e)return;const t=this.openState&&!this.inputEl?.value.trim()&&!this.hasSuggestionFilters()&&this.firstSearchTerms.length>0,s=e.hidden;e.hidden=!t;const a=e.querySelector(".first-search-terms");!t||!a||(a.replaceChildren(...this.firstSearchTerms.map((r,o)=>{const n=document.createElement("button");return n.type="button",n.className="control-chip",n.dataset.firstSearchIndex=String(o),n.textContent=r,n})),s&&k("search_suggestion_shown",void 0,{surface:"first_search_overlay",suggestion_count:this.firstSearchTerms.length}))}render(){if(this.renderFirstSearchSuggestions(),!this.resultsEl)return;const e=this.preserveResultsView;if(this.preserveResultsView=!1,this.filtersToggleEl?.classList.remove("attention"),this.resultsCollapsed&&this.results.length===0){this.resultsEl.classList.remove("cascade"),this.resultsEl.classList.add("collapsed"),this.resultsEl.innerHTML="",this.renderedDocIds=[];return}if(this.resultsEl.classList.remove("collapsed"),this.searchGateActive&&this.currentQuery.length>0&&this.searchGateDismissedForQuery!==this.currentQuery){this.resultsEl.classList.remove("cascade"),this.resultsEl.innerHTML=this.renderSearchGateHtml(),this.renderedDocIds=[];return}if(this.results.length===0){if(this.resultsEl.classList.remove("cascade"),this.orgScopeEmpty&&this.orgEnabled()){this.resultsEl.innerHTML='<li class="empty scope-empty-note">Your search scope has no spaces selected, so there is nothing to search.<button type="button" data-org-open-settings>Choose spaces</button></li>',this.renderedDocIds=[];return}const d=this.rawResults.length>0||this.matchedBeforeUserFilters>0,h=this.updatedWindow!=="any"||this.mediaFilter!=="all"||this.starredOnly||this.matchFilter!=="all"||this.platformFilters.size>0;if(!d&&!(this.matchAllWords&&this.currentQuery.length>0)&&!this.indexNudgeHasRun&&this.indexNudgeConvCount>=0&&this.indexNudgeConvCount<30)this.resultsEl.innerHTML=this.renderImportCtaHtml(),this.reportImportCtaImpression();else if(d&&h){const u=this.activeFilterLabels().map(E=>`<span class="active-chip">${g(E)}</span>`).join(""),w=u?`<div class="empty-filters">${u}</div>`:"",b=Math.max(this.rawResults.length,this.matchedBeforeUserFilters),S=`<strong>${b} ${b===1?"chat matches":"chats match"}</strong> your search, but your filters are ${b===1?"hiding it":"hiding them"}.`;this.resultsEl.innerHTML=`<li class="empty filtered-empty">${S}${w}<button type="button" class="empty-clear-filters" data-clear-filters-inline>Clear filters to see ${b===1?"it":"them"}</button></li>`,this.filtersToggleEl?.classList.toggle("attention",!this.showFilters)}else this.claudeCodeNudgeCheckedQuery!==this.currentQuery&&(this.claudeCodeNudgeCheckedQuery=this.currentQuery,this.evaluateClaudeCodeNudge(this.currentQuery)),this.resultsEl.innerHTML=this.renderNoMatchEmptyHtml();this.renderedDocIds=[];return}this.resultsEl.classList.toggle("cascade",!e&&!this.showFilters&&!this.resultsCollapsed&&this.results.length>0);const t=this.meaningView();this.selectedIndex=Math.min(Math.max(this.selectedIndex,t.start),t.end);const s=(c,d)=>{const h=J(c),m=d===this.selectedIndex?"selected":"",u=L(c.platform),w=Je(c),b=et(c),p=(c.platform==="chatgpt"||c.platform==="gemini")&&c.hasImages?'<span class="media-pill">IMG</span>':"",x=typeof c.semanticScore=="number"?c.semanticScore:null,S=F(c),E=x===null?"Meaning match":x>=.4?"Strong meaning match":x>=.3?"Good meaning match":"Related in meaning",C=c.matchedByMeaning?"Found by meaning, not keywords":"Also a close match by meaning",v=x!==null?`${C} (similarity ${x.toFixed(2)})`:C,$=S?`<span class="meaning-pill" title="${v}">${E}</span>`:"",f=this.orgEnabled()?this.orgLabels.get(c.docId):void 0,I=f?`<span class="space-pill">${g(f)}</span>`:"",y=this.orgEnabled()?`<button class="select-btn" type="button" data-select-index="${d}" data-checked="${this.orgSelection.has(c.docId)}" aria-pressed="${this.orgSelection.has(c.docId)}" aria-label="${g(`Select ${h||"conversation"} for organising`)}" title="Select for organising"></button>`:"",P=c.starred,te=P?"star-btn starred":"star-btn",z=P?`Unstar ${h||"conversation"}`:`Star ${h||"conversation"}`,se=P?"★":"☆",A=this.deletingDocIds.has(c.docId),ie=A?"Removing...":"Del",re=A?"disabled":"",oe=A?"remove-btn visible":"remove-btn",ae=A?`Removing ${h||"conversation"}`:`Delete ${h||"conversation"}`,ne=this.currentQuery.length===0&&this.recentsSortMode==="opened_desc"?M(c):c.platform==="claude_code"?c.createdAt:c.updatedAt,le=this.currentQuery.length===0&&this.recentsSortMode==="opened_desc"?"Opened":c.platform==="claude_code"?"Session started":"Updated",ce=`--item-accent:${u.accent};--item-bg:${u.card};--item-selected:${u.cardSelected};--item-border:${u.pillBorder};--pill-bg:${u.pillBg};--pill-border:${u.pillBorder};--pill-text:${u.pillText};`;return`
          <li class="item">
            <div class="item-row">
              ${y}
              <div class="result-btn ${m}" data-index="${d}" style="${ce}">
                <button class="result-open-btn" type="button" data-index="${d}" aria-label="${g(`Open ${h||"conversation"}`)}"></button>
                <div class="title-row">
                  <span class="title-main">
                    <strong class="result-title">${q(h,this.currentQuery)}</strong>
                    <button class="rename-btn" type="button" data-rename-index="${d}" aria-label="${g(`Edit title for ${h||"conversation"}`)}" title="Edit title in LLMnesia">
                      <svg viewBox="0 0 16 16" aria-hidden="true" focusable="false">
                        <path d="M3 11.9 3.7 9l6.9-6.9a1.45 1.45 0 0 1 2.05 0l1.25 1.25a1.45 1.45 0 0 1 0 2.05L7 12.3 4.1 13Z" fill="none" stroke="currentColor" stroke-width="1.35" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="m9.6 3.1 3.3 3.3" fill="none" stroke="currentColor" stroke-width="1.35" stroke-linecap="round"/>
                      </svg>
                    </button>
                  </span>
                  <span class="title-meta">
                    ${$}
                    ${p}
                    <span class="platform-pill">${g(w)}</span>
                    ${I}
                    ${tt(c)}
                  </span>
                </div>
                <span class="snippet">${q(c.snippet||"No snippet available.",this.currentQuery)}</span>
                <div class="meta">
                  <span>${g(`${le} ${Ye(ne)}`)}</span>
                  ${b?`<span class="model-pill" title="${g(c.models?.join(", ")??b)}">${g(b)}</span>`:""}
                </div>
              </div>
              <button class="viewer-btn" type="button" data-viewer-index="${d}" aria-label="${g(`Open saved copy of ${h||"conversation"}`)}" title="Open your saved copy — instant, works offline">Open copy</button>
              <button class="${te}" type="button" data-star-index="${d}" aria-label="${g(z)}" aria-pressed="${P}" title="${g(z)}">${se}</button>
              <button class="${oe}" type="button" data-remove-index="${d}" aria-label="${g(ae)}" ${re}>${ie}</button>
            </div>
          </li>
        `},a=this.results.map(c=>c.docId),r=this.resultsEl.querySelectorAll(":scope > li.item");if(e&&r.length===this.renderedDocIds.length&&this.renderedDocIds.length>0&&He(this.renderedDocIds,a)){const c=this.renderedDocIds.length,d=a.length;if(d>c){const h=this.results.slice(c).map((m,u)=>s(m,c+u)).join("");this.resultsEl.insertAdjacentHTML("beforeend",h)}else if(d<c)for(let h=c-1;h>=d;h-=1)r[h]?.remove();this.renderedDocIds=a;return}const o=this.results.map((c,d)=>s(c,d)),n=this.resultsEl.scrollTop;this.resultsEl.innerHTML=o.join(""),e&&(this.resultsEl.scrollTop=n),this.renderedDocIds=a}renderNoMatchEmptyHtml(){const e=this.indexedConversationCount,t=this.matchAllWords&&this.currentQuery.length>0;let s="";if(this.backfillActive)s="Still importing your chats. More become searchable as they finish.";else if(e>=1){const o=e===1?"chat":"chats";s=`Searched all ${e.toLocaleString()} indexed ${o}. Nothing matched.`}const a=s?`<div class="empty-status">${g(s)}</div>`:"",r=this.claudeCodeNudgeArmedQuery===this.currentQuery?this.renderClaudeCodeNudgeHtml():"";return`<li class="empty no-match">${t?"No conversations contain all your search words.":"No matches for that search."}`+a+`<ul class="empty-tips"><li>${t?"Try fewer words or remove the All words chip to broaden your search.":"Try fewer or simpler words"}</li></ul>`+r+"</li>"}async evaluatePinHint(){if(this.pinHintChecked)return;if(this.pinHintChecked=!0,this.indexedConversationCount<1){this.pinHintChecked=!1;return}let e=null,t=!1,s=null;try{const[a,r]=await Promise.all([chrome.runtime.sendMessage({type:"GET_PIN_STATE"}),chrome.storage.local.get([O,N])]);e=a?.ok?a.pinned:null,t=r[O]===!0;const o=r[N];s=typeof o=="number"?o:null}catch{return}Ee({pinned:e,dismissed:t,lastShownAt:s,nowMs:Date.now()})&&(this.pinHintVisible=!0,chrome.storage.local.set({[N]:Date.now()}).catch(()=>{}),k("pin_nudge_shown",void 0,{surface:"search_overlay"}),this.renderPinHint())}renderPinHint(){if(this.pinHintEl){if(!this.pinHintVisible){this.pinHintEl.hidden=!0,this.pinHintEl.innerHTML="";return}this.pinHintEl.hidden=!1,this.pinHintEl.innerHTML=`<span>Pin LLMnesia from Chrome's puzzle-piece menu to reach import and status in one click.</span><button type="button" class="pin-hint-dismiss" data-pin-hint-dismiss aria-label="Dismiss">&times;</button>`}}dismissPinHint(){this.pinHintVisible=!1,chrome.storage.local.set({[O]:!0}).catch(()=>{}),k("pin_nudge_dismissed",void 0,{surface:"search_overlay"}),this.renderPinHint()}async checkDegradedIndex(){if(!this.degradedIndexWarningEl)return;const e=++this.indexHealthRequest;try{const t=await chrome.runtime.sendMessage({type:"GET_INDEX_HEALTH"});if(e!==this.indexHealthRequest)return;if(!t.ok||!("degraded"in t)){this.degradedIndexWarningEl.hidden=!0;return}const s=me(t.backfillActive===!0,t.backfillPlatform);if(s){const a=this.degradedIndexWarningEl.querySelector(".degraded-index-warning-text");if(a&&(a.textContent=s),this.degradedIndexWarningEl.hidden=!1,!this.degradedIndexWarningFired){this.degradedIndexWarningFired=!0;const r={extract_error_count:t.extractErrorCount,backfill_complete:t.backfillComplete};typeof t.daysSinceActivation=="number"&&(r.days_since_activation=t.daysSinceActivation),k("search_with_degraded_index",void 0,r)}}else this.degradedIndexWarningEl.hidden=!0}catch{e===this.indexHealthRequest&&(this.degradedIndexWarningEl.hidden=!0)}}reportImportCtaImpression(){if(this.importCtaImpressionFired||this.importCtaPending)return;this.importCtaImpressionFired=!0;const e=this.currentBackfillPlatform;e?k("backfill_prompt_shown",e,{surface:"search_empty"}):k("backfill_prompt_shown",void 0,{surface:"search_empty_offsite"})}renderImportCtaHtml(){const e=this.indexNudgeConvCount,t=this.currentQuery.length>0?e===0?"<strong>Nothing is indexed yet</strong>, so there's nothing to search.":`<strong>Only ${e} chat${e===1?"":"s"} indexed</strong> — your match may just not be in there yet.`:e===0?"<strong>Bring in your chat history</strong> and it all becomes searchable from here.":`<strong>Only ${e} chat${e===1?"":"s"} indexed.</strong> Import the rest of your history to search all of it.`;if(this.importCtaPending)return`<li class="empty import-cta">${t}<div class="import-cta-status">Starting import…</div></li>`;if(this.backfillActive)return`<li class="empty import-cta">${t}<div class="import-cta-status">Importing now — chats become searchable as they finish.</div></li>`;const s=this.importCtaError?`<div class="import-cta-status import-cta-error">${g(this.importCtaError)}</div>`:this.importCtaNotice?`<div class="import-cta-status">${g(this.importCtaNotice)}</div>`:"";if(this.currentBackfillPlatform){const a=ye(this.currentBackfillPlatform);return`<li class="empty import-cta">${t}<div class="import-cta-actions"><button type="button" class="import-cta-btn" data-import-here>Import my ${g(a)} history</button></div><div class="import-cta-note">Runs in this tab, on this device. Nothing is uploaded.</div>`+s+"</li>"}return`<li class="empty import-cta">${t}<div class="import-cta-actions"><button type="button" class="import-cta-btn" data-import-open="chatgpt">Import from ChatGPT</button><button type="button" class="import-cta-btn" data-import-open="claude">Import from Claude</button></div><div class="import-cta-note">Opens the site in a new tab and starts importing there.</div>`+s+"</li>"}async startImportFromOverlay(){const e=this.currentBackfillPlatform;if(!(!e||this.importCtaPending)){this.importCtaPending=!0,this.importCtaError="",this.importCtaNotice="",this.render(),k("backfill_prompt_accepted",e,{surface:"search_empty"});try{const t=await chrome.runtime.sendMessage({type:"START_BACKFILL",platform:e,seedTabId:0,source:"prompt"});t?.ok?t.deferredBy&&(this.importCtaNotice="Restoring your Vault first. Your import starts straight after."):this.importCtaError=t?.error?`Couldn't start the import: ${t.error}`:"Couldn't start the import. Try again from the extension popup."}catch{this.importCtaError="Couldn't start the import. Try again from the extension popup."}finally{this.importCtaPending=!1,this.render()}}}openImportTab(e){k("backfill_prompt_accepted",e,{surface:"search_empty_offsite"}),chrome.runtime.sendMessage({type:"OPEN_BACKFILL_ONBOARDING",platform:e}).catch(()=>{})}renderClaudeCodeNudgeHtml(){return'<div class="cc-nudge"><span class="cc-nudge-text">Use Claude Code or Codex? Index your terminal &amp; IDE sessions to search them here too.</span><span class="cc-nudge-actions"><button type="button" class="cc-nudge-connect" data-cc-nudge-connect>Connect →</button><button type="button" class="cc-nudge-dismiss" data-cc-nudge-dismiss>Not now</button></span></div>'}async evaluateClaudeCodeNudge(e){if(!$e(e))return;const[t,s]=await Promise.all([Pe(),Te()]);t||s.declines>=Ie||await W("claude_code")&&(!this.openState||this.currentQuery!==e||this.results.length!==0||(this.claudeCodeNudgeArmedQuery=e,G("claude_code"),k("claude_code_promo_shown",void 0,{surface:"search_nudge"}),this.render()))}renderSearchGateHtml(){const e=this.searchGateProgress,t=e&&e.phase==="running"&&e.total>0?Math.max(2,Math.min(99,Math.round(e.processed/e.total*100))):null,s=t!==null?`Your chats are still importing — ${t}% complete. Search will work once it's done.`:"Your chats are still importing. Search will work once it's done.";return`<li class="empty search-gate">${g(s)}<br><button type="button" class="search-gate-dismiss" data-search-gate-dismiss>Show results anyway →</button></li>`}meaningView(){return{start:0,end:Math.max(0,this.results.length-1)}}}export{mt as S,Le as i};
//# sourceMappingURL=overlay.js.map
