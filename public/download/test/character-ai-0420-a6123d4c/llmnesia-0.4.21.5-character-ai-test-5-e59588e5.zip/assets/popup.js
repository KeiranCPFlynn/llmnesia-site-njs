import"./modulepreload-polyfill.js";import{C as ya}from"./character_ai_private_test_build.js";import{b as va,p as xa,a as ka,c as wa}from"./report_capture.js";import{A as Gt,n as pe,p as Sa,i as Ca,G as _a,d as Ge,c as y,g as Ht,e as lt,f as Ea,h as $a,b as qa,a as ct,j as _,m as Ia,k as Na,l as La,o as Ma}from"./backfill.js";import{C as Ta}from"./character_ai_archive_recovery.js";import{b as Kt}from"./backfill_tab.js";import{v as Aa,Q as Pa,c as Ra,d as me,s as Ba,e as Oa,f as Da,V as Ua,w as Fa,b as za,r as Va,i as Ga,a as Ha}from"./vault_status_summary.js";import{i as Ka,T as o}from"./theme.js";import{c as dt,r as ut}from"./prompt_coordinator.js";import{C as Ya,d as Qa,i as Wa,a as ja}from"./claude_code_promo.js";import{c as Xa,s as Za}from"./site_health.js";import{m as B,n as Ja,o as R,p as de,V as eo,c as to,d as ao,q as He,r as oo,s as no,t as ot,u as Yt,v as io,f as so,I as pt,S as ft,e as mt,i as ro,h as lo}from"./conversation_counter.js";import{i as co,c as m}from"./analytics.js";import{i as uo,d as po}from"./vault_state.js";import{V as fo,t as mo}from"./vault_hook.js";import{s as ho,a as go}from"./search_import_notice.js";import{g as Qt}from"./platform_styles.js";import{c as bo}from"./capture_provenance.js";import"./google_ai_mode_page.js";import"./error_logging.js";function yo(){const e={info:null,ask:null};return{claim(a,t){return e[a]===null||e[a]===t?(e[a]=t,!0):!1},release(a,t){e[a]===t&&(e[a]=null)},holder(a){return e[a]}}}const vo=10,Ke="llmnesia.mcpPromoDismissed",ht="llmnesia.analytics.mcpCorpusConnected";function xo(e){return Number.isFinite(e)&&e>=vo}async function ko(){try{return(await chrome.storage.local.get(ht))[ht]===!0}catch{return!0}}async function wo(){try{return(await chrome.storage.local.get(Ke))[Ke]===!0}catch{return!1}}async function So(){try{await chrome.storage.local.set({[Ke]:!0})}catch{}}const Co=10;function Wt(e){if(!e||typeof e!="object")return{};const a=e,t={};for(const i of Gt){const n=a[i];typeof n=="number"&&Number.isFinite(n)&&n>0&&(t[i]=Math.floor(n))}return t}function _o(e){const a=pe(e.promptStateRaw),t=e.snoozed??{},i=e.now??Date.now();for(const n of Gt){const s=e.counts[n]??0;if(!(s<=0||Sa(a[n],s).hasBackfillRun||(t[n]??0)>i))return{platform:n,count:s}}return null}function Eo(e){return e>=Co}const jt="Restoring your Vault first. Your import starts straight after.",Le={headline:"{count} conversations. Keep them with you.",body:"Vault is live: encrypt your history, keep it backed up, and restore it on any device.",cta:"Set up Vault"},$o=30;function Ye(e){return e?new Date(e).toLocaleString():"Never"}Ka("popup_page","popup");co();chrome.runtime.sendMessage({type:"WARM_SEMANTIC_SEARCH"}).catch(()=>{});const qo=chrome.runtime.sendMessage({type:"POPUP_OPENED"}).catch(()=>({ok:!1})),Xt=document.querySelector("#app");if(!Xt)throw new Error("Popup app root not found");Xt.innerHTML=`
  <style>
    :root {
      color-scheme: light;
      --popup-height: 580px;
    }
    * {
      box-sizing: border-box;
      animation: none !important;
      transition: none !important;
    }
    html, body, #app {
      width: 380px;
      height: var(--popup-height);
      overflow: hidden;
    }
    body {
      margin: 0;
      position: relative;
      background: ${o.paper};
      color: ${o.ink};
      font: 13px/1.4 "IBM Plex Sans", "Segoe UI", sans-serif;
      width: 380px;
      max-width: 380px;
    }
    .popup {
      width: 380px;
      height: 100%;
      max-width: 100%;
      margin: 0;
      padding: 12px;
      overflow-x: hidden;
      overflow-y: auto;
      overscroll-behavior: contain;
      scrollbar-gutter: stable;
    }
    .secondary-surfaces {
      opacity: 0;
      visibility: hidden;
    }
    html[data-secondary-ready="true"] .secondary-surfaces {
      opacity: 1;
      visibility: visible;
      transition: opacity 140ms ease-out !important;
    }
    @media (prefers-reduced-motion: reduce) {
      html[data-secondary-ready="true"] .secondary-surfaces {
        transition: none !important;
      }
      .inline-loader::before,
      .state-pill[data-loading="true"]::after,
      .helper-note[data-loading="true"]::before,
      .quick-search-status[data-loading="true"]::before {
        animation: none !important;
      }
    }
    .head {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      gap: 12px;
      margin-bottom: 6px;
    }
    .head-brand {
      display: flex;
      align-items: center;
      gap: 8px;
      min-width: 0;
    }
    /* Settings owns the controls people actually need (imports, Vault, pills),
       so it gets a permanent seat in the header; the quiet footer line stays
       for anyone who learned it there. */
    .head-settings-btn {
      flex: none;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 30px;
      height: 30px;
      padding: 0;
      border: 1px solid ${o.rule};
      border-radius: ${o.rSm};
      background: ${o.card};
      color: ${o.ink2};
      box-shadow: ${o.shadowSm};
      cursor: pointer;
    }
    .head-settings-btn svg {
      width: 16px;
      height: 16px;
    }
    .head-settings-btn:hover {
      border-color: ${o.teal};
      color: ${o.teal};
    }
    .head-settings-btn:active {
      box-shadow: none;
      transform: translateY(1px);
    }
    .head-logo {
      width: 28px;
      height: 28px;
      flex-shrink: 0;
    }
    .title {
      margin: 0;
      font-size: 19px;
      line-height: 1.2;
      letter-spacing: 0.01em;
      color: #11273a;
    }
    .subtitle {
      margin: 3px 0 0;
      color: #496073;
      font-size: 12px;
    }
    .pill {
      display: inline-flex;
      align-items: center;
      border-radius: ${o.rPill};
      border: 1px solid ${o.tealEdge};
      background: ${o.tealSoft};
      color: ${o.ink2};
      font-size: 11px;
      font-weight: 600;
      padding: 3px 8px;
      white-space: nowrap;
    }
    .panel {
      border: 1px solid ${o.rule};
      border-radius: ${o.rMd};
      background: ${o.card}dd;
      box-shadow: 0 8px 18px rgba(20, 45, 64, 0.06);
      padding: 7px 11px;
      margin-top: 5px;
    }
    .panel-head {
      display: flex;
      justify-content: space-between;
      align-items: center;
      gap: 8px;
      margin-bottom: 5px;
    }
    .panel-title {
      margin: 0;
      font-size: 13px;
      font-weight: 600;
      color: #183046;
    }
    /* Second-level heading inside a panel. Indexer stats and backfill used to be
       two sibling panels with equal weight; they are both "how is indexing
       going", so they now share one panel with a rule between them. */
    .panel-block {
      margin-top: 9px;
      padding-top: 8px;
      border-top: 1px solid ${o.ruleSoft};
    }
    .panel-subhead {
      display: flex;
      justify-content: space-between;
      align-items: center;
      gap: 8px;
      margin-bottom: 5px;
    }
    .panel-subtitle {
      margin: 0;
      font-size: 12px;
      font-weight: 600;
      color: #2c465c;
    }
    .panel-subhead-actions {
      display: flex;
      gap: 6px;
      flex: 0 0 auto;
    }
    /* The max-items cap is a power-user escape hatch, not a per-run decision —
       folded away so the default view is just "Start". */
    .backfill-options {
      margin-top: 6px;
      color: ${o.ink3};
      font-family: "IBM Plex Mono", "SF Mono", "Consolas", monospace;
      font-size: 10.5px;
      line-height: 1.35;
    }
    .backfill-options-summary {
      cursor: pointer;
      list-style: none;
      user-select: none;
      color: ${o.ink3};
    }
    .backfill-options-summary::-webkit-details-marker { display: none; }
    .backfill-options-summary::before {
      content: "▸ ";
      font-size: 9px;
    }
    .backfill-options[open] .backfill-options-summary::before {
      content: "▾ ";
    }
    .quick-memory-summary {
      display: flex;
      align-items: center;
      gap: 8px;
      cursor: pointer;
      list-style: none;
      user-select: none;
    }
    .quick-memory-summary::-webkit-details-marker { display: none; }
    /* Draw the +/- as centered CSS bars rather than text glyphs: "+" and "−"
       both sit on the font's math axis (above the line-box center), so a text
       glyph always floats high in the circle. Background gradients centre
       geometrically and stay crisp regardless of font. */
    .quick-memory-summary::before {
      content: "";
      flex: none;
      width: 16px;
      height: 16px;
      border-radius: 999px;
      border: 1px solid ${o.tealEdge};
      color: ${o.teal};
      background:
        linear-gradient(currentColor, currentColor) center / 8px 2px no-repeat,
        linear-gradient(currentColor, currentColor) center / 2px 8px no-repeat;
    }
    details[open] .quick-memory-summary::before {
      background: linear-gradient(currentColor, currentColor) center / 8px 2px no-repeat;
    }
    .quick-memory-hint {
      margin-left: auto;
      font-size: 11px;
      color: ${o.ink3};
    }
    .btn {
      appearance: none;
      border: 1px solid ${o.rule};
      background: ${o.card};
      color: #1d3a52;
      border-radius: ${o.rSm};
      padding: 5px 10px;
      font: inherit;
      font-weight: 600;
      cursor: pointer;
      box-shadow: ${o.shadowSm};
      transition: background 0.12s ease, box-shadow 0.12s ease, transform 0.05s ease;
    }
    .btn:hover { border-color: ${o.teal}; }
    .btn:active { box-shadow: none; transform: translateY(1px); }
    .btn[disabled] { opacity: 0.55; cursor: default; box-shadow: none; transform: none; }
    .btn.primary {
      border-color: ${o.tealDark};
      background: ${o.teal};
      color: #fff;
    }
    .btn.primary:hover { background: ${o.tealDark}; border-color: ${o.tealDark}; }
    .btn.ghost {
      border-color: ${o.ruleSoft};
      color: #3f576a;
      background: transparent;
      font-weight: 600;
      box-shadow: none;
    }
    .btn.ghost:hover { background: ${o.paperSoft}; border-color: ${o.teal}; }
    .stats-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 6px;
    }
    .stat {
      border: 1px solid ${o.ruleSoft};
      border-radius: ${o.rSm};
      border-left: 3px solid ${o.tealEdge};
      background: ${o.card};
      padding: 6px 8px;
    }
    .stat-label {
      color: ${o.ink3};
      font-family: "IBM Plex Mono", "SF Mono", "Consolas", monospace;
      font-size: 9.5px;
      font-weight: 600;
      letter-spacing: 0;
      line-height: 1;
      margin-bottom: 4px;
      text-transform: uppercase;
    }
    .stat-value {
      color: #163046;
      font-family: "IBM Plex Mono", "SF Mono", "Consolas", monospace;
      font-size: 16px;
      font-weight: 700;
      line-height: 1.2;
      letter-spacing: -0.01em;
    }
    .inline-loader {
      display: inline-flex;
      align-items: center;
      gap: 5px;
      color: ${o.ink3};
      font: 600 10.5px/1 "IBM Plex Mono", "SF Mono", "Consolas", monospace;
      letter-spacing: 0;
    }
    .inline-loader::before,
    .state-pill[data-loading="true"]::after,
    .helper-note[data-loading="true"]::before,
    .quick-search-status[data-loading="true"]::before {
      content: "";
      width: 8px;
      height: 8px;
      flex: none;
      border: 1.5px solid currentColor;
      border-right-color: transparent;
      border-radius: 999px;
      animation: inline-loader-spin 0.8s linear infinite !important;
    }
    @keyframes inline-loader-spin {
      to { transform: rotate(360deg); }
    }
    .meta-line {
      margin-top: 5px;
      color: ${o.ink3};
      font-family: "IBM Plex Mono", "SF Mono", "Consolas", monospace;
      font-size: 10.5px;
      line-height: 1.3;
      letter-spacing: 0;
    }
    .indicator-row {
      margin-top: 6px;
      display: grid;
      gap: 5px;
    }
    .pill-toggle-row {
      margin-top: 6px;
      display: flex;
      flex-wrap: wrap;
      gap: 6px;
    }
    .pill-toggle {
      appearance: none;
      cursor: pointer;
      font-family: "IBM Plex Mono", "SF Mono", "Consolas", monospace;
    }
    /* Filled = on, outlined + dimmed = off — a clear toggle at a glance.
       Chained with .state-pill to out-specificity that class's own
       [data-state] rules regardless of stylesheet order. */
    .state-pill.pill-toggle[data-state="on"] {
      border-color: ${o.teal};
      background: ${o.teal};
      color: #ffffff;
      opacity: 1;
    }
    .state-pill.pill-toggle[data-state="off"] {
      border-color: #cbd3d9;
      background: ${o.card};
      color: ${o.ink3};
      opacity: 0.72;
    }
    .pill-toggle:hover {
      border-color: ${o.teal};
      opacity: 1;
    }
    .control-row {
      display: flex;
      justify-content: space-between;
      align-items: center;
      gap: 8px;
      min-width: 0;
    }
    .control-row > .btn {
      flex: 0 0 auto;
      padding: 5px 8px;
      white-space: nowrap;
    }
    .state-pill {
      display: inline-flex;
      align-items: center;
      border-radius: ${o.rPill};
      border: 1px solid ${o.ruleSoft};
      background: ${o.paperSoft};
      color: ${o.ink2};
      font-family: "IBM Plex Mono", "SF Mono", "Consolas", monospace;
      font-size: 10.5px;
      font-weight: 600;
      line-height: 1;
      padding: 3px 8px;
      min-height: 24px;
      min-width: 0;
      max-width: 100%;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    .state-pill[data-loading="true"] {
      color: ${o.ink3};
      cursor: wait;
      opacity: 0.78;
    }
    .state-pill[data-loading="true"]::after {
      margin-left: 2px;
    }
    .state-pill[data-state="on"] {
      border-color: ${o.tealEdge};
      background: ${o.tealSoft};
      color: ${o.ink2};
    }
    .state-pill[data-state="off"] {
      border-color: #d2d9e0;
      background: #f3f6f8;
      color: #4e6578;
    }
    .state-pill[data-state="error"] {
      border-color: #efc0c0;
      background: #fff0f0;
      color: #8d2f2f;
    }
    .helper-note {
      margin-top: 4px;
      color: ${o.ink3};
      font-family: "IBM Plex Mono", "SF Mono", "Consolas", monospace;
      font-size: 10.5px;
      line-height: 1.35;
      letter-spacing: 0;
    }
    .helper-note[data-loading="true"] {
      display: flex;
      align-items: center;
      gap: 5px;
    }
    .backfill-status-line {
      display: none;
      align-items: center;
      gap: 6px;
      margin-top: 4px;
      font-size: 11px;
      font-weight: 600;
      color: ${o.ink2};
    }
    .backfill-status-line[data-visible="true"] {
      display: flex;
    }
    .backfill-status-dot {
      width: 6px;
      height: 6px;
      border-radius: 999px;
      background: ${o.teal};
      flex-shrink: 0;
    }
    .backfill-status-dot[data-state="paused"] {
      background: #9aa8b4;
    }
    /* A stalled import is not the same as a healthy one; the teal dot next to
       "Indexing…" was the last thing still insisting it was fine. */
    .backfill-status-dot[data-state="stuck"] {
      background: #c9752f;
    }
    .backfill-progress {
      margin-top: 7px;
      height: 8px;
      border-radius: 999px;
      border: 1px solid ${o.ruleSoft};
      background: ${o.paperSoft};
      overflow: hidden;
    }
    .backfill-progress-fill {
      display: block;
      height: 100%;
      width: 0%;
      background: linear-gradient(90deg, ${o.teal} 0%, #5f9cac 100%);
      transition: width 0.4s ease;
    }
    /* Every low-frequency escape hatch lives here, as one quiet line. These used
       to be split between the header (Report a problem, Visit site) and the
       footer, which spent the popup's most valuable row on links most people
       never click. */
    .settings-row {
      display: flex;
      justify-content: center;
      align-items: center;
      gap: 7px;
      padding: 6px 0 2px;
    }
    .settings-sep {
      color: #b9c7d1;
      font-size: 10.5px;
      line-height: 1;
    }
    .settings-btn {
      background: none;
      border: none;
      color: #8faabb;
      font: 10.5px/1 "IBM Plex Mono", "SF Mono", "Consolas", monospace;
      cursor: pointer;
      padding: 2px 0;
      letter-spacing: 0;
    }
    .settings-btn:hover {
      color: #2f7f99;
    }
    .founding-strip {
      display: none;
      margin-top: 5px;
      border: 1px solid ${o.rule};
      border-radius: ${o.rMd};
      background: ${o.paperSoft};
      padding: 6px 9px;
      align-items: center;
      gap: 5px;
      flex-wrap: wrap;
      font-size: 11px;
      color: #355068;
    }
    .founding-strip[data-visible="true"] {
      display: flex;
    }
    .whats-new-strip {
      display: none;
      flex-direction: column;
      margin-top: 5px;
      margin-bottom: 5px;
      border: 1px solid rgba(47, 127, 153, 0.18);
      border-radius: ${o.rMd};
      background: linear-gradient(180deg, ${o.card} 0%, ${o.tealSoft} 100%);
      padding: 8px 9px;
      gap: 5px;
      font-size: 11px;
      color: ${o.ink2};
    }
    .whats-new-strip[data-visible="true"] {
      display: flex;
    }
    .whats-new-head {
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .whats-new-label {
      flex: 1 1 auto;
      min-width: 0;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      font-weight: 600;
    }
    .whats-new-body {
      /* Full text, wraps as needed — this is a shown-once card, so a little extra
         height is fine and truncating the spotlight copy is not. */
      color: ${o.ink3};
      line-height: 1.35;
    }
    .whats-new-actions {
      display: flex;
      align-items: center;
      gap: 5px;
      margin-top: 1px;
    }
    .whats-new-strip .btn.primary {
      border-color: ${o.tealEdge};
      background: ${o.card};
      color: ${o.teal};
    }
    .whats-new-strip .btn.ghost {
      border-color: rgba(47, 127, 153, 0.16);
      background: transparent;
      color: ${o.ink3};
    }
    /* Permanent, every-open search box — the popup's primary action. It is the
       only search UI reachable when the tab behind the popup isn't one of the
       supported chat sites (the palette only runs there), so it's the popup's
       sole path to search on the rest of the user's browsing. */
    .quick-search {
      display: flex;
      flex-direction: column;
      gap: 5px;
      margin-top: 6px;
      margin-bottom: 6px;
    }
    .quick-search-row {
      display: flex;
      align-items: center;
      gap: 6px;
      border: 1.5px solid ${o.tealEdge};
      border-radius: ${o.rMd};
      background: ${o.tealSoft};
      box-shadow: 0 1px 3px rgba(47, 127, 153, 0.10);
      padding: 3px 4px 3px 10px;
      transition: border-color 0.15s, box-shadow 0.15s;
    }
    .quick-search-row:focus-within {
      border-color: ${o.teal};
      box-shadow: 0 0 0 3px rgba(47, 127, 153, 0.18);
    }
    .quick-search-icon {
      flex: none;
      width: 15px;
      height: 15px;
      color: ${o.teal};
      opacity: 0.7;
    }
    .quick-search-input {
      flex: 1 1 auto;
      min-width: 0;
      border: none;
      border-radius: 0;
      background: transparent;
      color: ${o.ink};
      font: 13px/1.3 "IBM Plex Sans", "Segoe UI", sans-serif;
      padding: 6px 0;
    }
    .quick-search-input:focus {
      outline: none;
    }
    .quick-search-full-btn {
      flex: none;
      appearance: none;
      border: none;
      border-radius: ${o.rSm};
      background: ${o.teal};
      color: #fff;
      font: 11px/1.3 "IBM Plex Sans", "Segoe UI", sans-serif;
      font-weight: 600;
      white-space: nowrap;
      padding: 5px 10px;
      cursor: pointer;
    }
    .quick-search-full-btn:hover {
      background: #266e84;
    }
    .quick-search-status {
      color: ${o.ink3};
      line-height: 1.35;
      font-size: 11px;
    }
    .quick-search-status[data-loading="true"] {
      display: flex;
      align-items: center;
      gap: 5px;
    }
    /* Collapse entirely when there's nothing to say. It used to reserve a line
       height unconditionally, which read as dead space under the input on every
       open. Recents now occupy that area instead. */
    .quick-search-status:empty {
      display: none;
    }
    .quick-search-label {
      display: none;
      margin-top: 5px;
      color: ${o.ink3};
      font-family: "IBM Plex Mono", "SF Mono", "Consolas", monospace;
      font-size: 9.5px;
      font-weight: 600;
      letter-spacing: 0;
      line-height: 1;
      text-transform: uppercase;
    }
    .quick-search-label[data-visible="true"] {
      display: block;
    }
    .quick-search-results {
      display: flex;
      flex-direction: column;
      gap: 2px;
      margin: 0;
      padding: 4px;
      list-style: none;
      border: 1px solid ${o.ruleSoft};
      border-radius: ${o.rSm};
      background: ${o.paperSoft};
    }
    .quick-search-results:empty {
      display: none;
    }
    .quick-search-result {
      display: block;
      width: 100%;
      text-align: left;
      border: 1px solid transparent;
      border-radius: 6px;
      background: ${o.card};
      color: ${o.ink2};
      cursor: pointer;
      padding: 5px 7px;
      font: 11px/1.35 "IBM Plex Sans", "Segoe UI", sans-serif;
    }
    .quick-search-result:hover,
    .quick-search-result:focus-visible {
      border-color: ${o.teal};
      background: ${o.tealSoft};
      outline: none;
    }
    .quick-search-result-head {
      display: flex;
      align-items: center;
      gap: 5px;
      min-width: 0;
    }
    .quick-search-result-platform {
      flex: none;
      display: inline-flex;
      align-items: center;
      border-radius: ${o.rPill};
      border: 1px solid var(--pill-border);
      background: var(--pill-bg);
      color: var(--pill-text);
      font-size: 9px;
      font-weight: 700;
      letter-spacing: 0.02em;
      text-transform: uppercase;
      padding: 1px 6px;
      white-space: nowrap;
    }
    .quick-search-result-title {
      flex: 1 1 auto;
      min-width: 0;
      font-weight: 600;
      color: #183046;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    .quick-search-result-meta {
      display: block;
      color: ${o.ink3};
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    /* One-time intro, shown only the moment the toolbar activation badge (the
       "N chats indexed" count) is retired by opening the popup. Sits above the
       permanent box above rather than owning its own copy of it, so there is
       only ever one search implementation to keep in sync. */
    .quick-search-intro {
      display: none;
      flex-direction: column;
      gap: 3px;
      border: 1px solid rgba(58, 125, 44, 0.2);
      border-radius: ${o.rMd};
      background: rgba(58, 125, 44, 0.07);
      padding: 7px 9px;
      font-size: 11px;
      color: ${o.ink2};
    }
    .quick-search-intro[data-visible="true"] {
      display: flex;
    }
    .quick-search-intro-head {
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .quick-search-intro-label {
      flex: 1 1 auto;
      font-weight: 600;
      color: #2c5a20;
    }
    .quick-search-intro-body {
      line-height: 1.35;
    }
    .quick-search-intro-body strong {
      color: #2c5a20;
    }
    .quick-search-intro-dismiss {
      flex: none;
      border: none;
      background: transparent;
      color: ${o.ink3};
      cursor: pointer;
      font-size: 12px;
      line-height: 1;
      padding: 2px;
    }
    @keyframes panel-flash {
      0%, 100% { box-shadow: 0 0 0 0 rgba(47, 127, 153, 0); background-color: transparent; }
      12% { box-shadow: 0 0 0 4px rgba(47, 127, 153, 0.55); background-color: ${o.tealSoft}; }
      33% { box-shadow: 0 0 0 0 rgba(47, 127, 153, 0); background-color: transparent; }
      55% { box-shadow: 0 0 0 4px rgba(47, 127, 153, 0.55); background-color: ${o.tealSoft}; }
      78% { box-shadow: 0 0 0 0 rgba(47, 127, 153, 0); background-color: transparent; }
    }
    .panel-flash {
      /* The global \`* { animation: none !important }\` reset above kills every
         animation in the popup, so this one deliberate cue needs !important to
         win on specificity — otherwise the flash never plays. */
      animation: panel-flash 1.7s ease-out !important;
      border-radius: ${o.rMd};
    }
    .setup-checklist {
      display: none;
      flex-direction: column;
      gap: 6px;
      margin-top: 5px;
      margin-bottom: 5px;
      border: 1px solid ${o.ruleSoft};
      border-radius: ${o.rMd};
      background: ${o.card};
      padding: 9px 11px;
    }
    .setup-checklist[data-visible="true"] { display: flex; }
    .setup-checklist-head {
      display: flex;
      align-items: baseline;
      justify-content: space-between;
      gap: 8px;
    }
    .setup-checklist-title { font-weight: 700; color: ${o.ink}; font-size: 13px; }
    .setup-checklist-progress { font-size: 11px; color: ${o.ink3}; }
    .setup-checklist-list { list-style: none; margin: 0; padding: 0; display: flex; flex-direction: column; gap: 5px; }
    .setup-step {
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 12px;
      color: ${o.ink2};
    }
    .setup-step-mark {
      flex: 0 0 auto;
      width: 16px;
      height: 16px;
      border-radius: 999px;
      border: 1px solid ${o.tealEdge};
      display: inline-flex;
      align-items: center;
      justify-content: center;
      font-size: 10px;
      line-height: 1;
      color: ${o.ink3};
    }
    .setup-step[data-done="true"] .setup-step-mark {
      border-color: ${o.onEdge};
      background: ${o.onBg};
      color: ${o.onInk};
    }
    .setup-step-label { flex: 1 1 auto; min-width: 0; }
    .setup-step[data-done="true"] .setup-step-label { color: ${o.ink3}; text-decoration: line-through; }
    .setup-step .btn.slim { flex: 0 0 auto; }
    .setup-step-hint {
      font-size: 11px;
      color: ${o.ink3};
      margin: 2px 0 0 24px;
      line-height: 1.35;
    }
    .setup-checklist-done { font-size: 12px; color: ${o.onInk}; font-weight: 600; }
    /* Coverage gap strip — surfaces when the user has captured on at least one
       platform but has never imported history on another. Takes the info seat,
       sits below the setup checklist (which owns brand-new users); modelled on
       the whats-new strip's visual weight so it reads as information, not an ask. */
    .coverage-gap-strip {
      display: none;
      flex-direction: column;
      margin-top: 5px;
      margin-bottom: 5px;
      border: 1px solid rgba(47, 127, 153, 0.18);
      border-radius: ${o.rMd};
      background: linear-gradient(180deg, ${o.card} 0%, ${o.tealSoft} 100%);
      padding: 8px 9px;
      gap: 6px;
      font-size: 11px;
      color: ${o.ink2};
    }
    .coverage-gap-strip[data-visible="true"] {
      display: flex;
    }
    .coverage-gap-copy {
      color: ${o.ink2};
      line-height: 1.35;
    }
    .coverage-gap-copy strong {
      color: ${o.ink};
      font-weight: 600;
    }
    .coverage-gap-actions {
      display: flex;
      align-items: center;
      gap: 5px;
    }
    .coverage-gap-strip .btn.primary {
      border-color: ${o.tealEdge};
      background: ${o.card};
      color: ${o.teal};
    }
    .coverage-gap-strip .btn.ghost {
      border-color: rgba(47, 127, 153, 0.16);
      background: transparent;
      color: ${o.ink3};
    }
    .founding-title {
      font-weight: 700;
      color: #19364f;
    }
    .founding-copy {
      flex: 1 1 180px;
      min-width: 120px;
    }
    .btn.slim {
      padding: 5px 8px;
      font-size: 11px;
      border-radius: ${o.rSm};
    }
    .site-status {
      border-radius: 8px;
      padding: 5px 9px;
      margin-bottom: 5px;
      font-family: "IBM Plex Mono", "SF Mono", "Consolas", monospace;
      font-size: 10.5px;
      line-height: 1.35;
      letter-spacing: 0;
    }
    .site-status[data-status="ok"] {
      border: 1px solid rgba(47, 127, 153, 0.18);
      background: ${o.tealSoft};
      color: ${o.ink2};
    }
    .site-status[data-status="failed"] {
      border: 1px solid #efc0c0;
      background: #fff0f0;
      color: #8d2f2f;
    }
    .site-status[data-status="unsupported"] {
      border: 1px solid #d2d9e0;
      background: #f3f6f8;
      color: #4e6578;
    }
    .site-status[data-status="unknown"] {
      border: 1px solid #d2d9e0;
      background: #f3f6f8;
      color: #4e6578;
    }
    .site-status[data-status="hidden"] {
      display: none;
    }
    .report-row {
      margin-top: 5px;
      display: flex;
      align-items: center;
      gap: 6px;
      flex-wrap: wrap;
    }
    .snapshot-toggle {
      display: inline-flex;
      align-items: center;
      gap: 4px;
      font-size: 10px;
      color: #4e6578;
      cursor: pointer;
    }
    .snapshot-toggle input {
      margin: 0;
    }
    .report-warning {
      margin-top: 3px;
      font-size: 10px;
      font-family: "IBM Plex Mono", "SF Mono", "Consolas", monospace;
      color: #6a7f90;
    }
    .search-hint {
      display: flex;
      align-items: center;
      gap: 6px;
      flex-wrap: wrap;
      color: ${o.ink3};
      font-family: "IBM Plex Mono", "SF Mono", "Consolas", monospace;
      font-size: 10.5px;
      line-height: 1.3;
      letter-spacing: 0;
      padding: 2px 0 7px;
    }
    .search-hint-sep {
      color: ${o.ink3};
      opacity: 0.5;
      flex-shrink: 0;
    }
    .change-shortcut {
      color: #2f7f99;
      font-size: 10.5px;
      cursor: pointer;
      background: none;
      border: none;
      padding: 0;
      font: inherit;
      text-decoration: underline;
      text-underline-offset: 2px;
    }
    .backfill-nudge-strip {
      display: none;
      margin-bottom: 5px;
      border: 1px solid rgba(47, 127, 153, 0.18);
      border-radius: ${o.rMd};
      background: linear-gradient(180deg, ${o.card} 0%, ${o.tealSoft} 100%);
      padding: 6px 8px;
      gap: 5px;
      align-items: center;
      justify-content: space-between;
      flex-wrap: wrap;
      font-size: 12px;
      color: ${o.ink2};
    }
    .backfill-nudge-strip[data-visible="true"] {
      display: flex;
    }
    .backfill-nudge-copy {
      display: grid;
      grid-template-columns: auto minmax(0, 1fr);
      align-items: center;
      gap: 6px;
      flex: 1 1 190px;
      min-width: 0;
      line-height: 1.35;
    }
    .backfill-nudge-count {
      display: inline-flex;
      align-items: center;
      max-width: 100%;
      border: 1px solid ${o.ruleSoft};
      border-radius: ${o.rPill};
      background: ${o.paperSoft};
      color: ${o.ink2};
      font-family: "IBM Plex Mono", "SF Mono", "Consolas", monospace;
      font-size: 10.5px;
      font-weight: 700;
      line-height: 1;
      padding: 4px 7px;
      white-space: nowrap;
    }
    .backfill-nudge-text {
      min-width: 0;
      color: ${o.ink2};
    }
    .backfill-nudge-actions {
      display: flex;
      gap: 6px;
      flex: 0 0 auto;
      flex-wrap: wrap;
      justify-content: flex-end;
    }
    .cc-promo-card {
      display: none;
      margin-top: 5px;
      margin-bottom: 5px;
      border: 1px solid rgba(47, 127, 153, 0.18);
      border-radius: ${o.rMd};
      background: linear-gradient(180deg, ${o.card} 0%, ${o.tealSoft} 100%);
      padding: 8px 9px;
      gap: 6px;
      align-items: center;
      justify-content: space-between;
      flex-wrap: wrap;
      font-size: 11px;
      color: ${o.ink2};
    }
    .cc-promo-card[data-visible="true"] {
      display: flex;
    }
    .cc-promo-copy {
      flex: 1 1 190px;
      min-width: 0;
      line-height: 1.35;
    }
    .cc-promo-title {
      font-weight: 600;
      color: ${o.ink};
    }
    .cc-promo-sub {
      color: ${o.ink3};
      margin-top: 1px;
    }
    .cc-promo-actions {
      display: flex;
      align-items: center;
      gap: 5px;
      flex: 0 0 auto;
    }
    kbd {
      display: inline-block;
      border: 1px solid ${o.ruleSoft};
      border-bottom-width: 2px;
      border-radius: 3px;
      background: ${o.paperSoft};
      color: ${o.ink3};
      padding: 1px 4px;
      font: 10px/1 "IBM Plex Mono", "SF Mono", "Consolas", "DejaVu Sans Mono", monospace;
    }
    /* Search suggestions: contextual chips below the search input on D2+. */
    .search-suggestions {
      display: none;
      flex-wrap: wrap;
      gap: 5px;
      margin-top: 4px;
    }
    .search-suggestions[data-visible="true"] { display: flex; }
    .search-suggestion-chip {
      appearance: none;
      border: 1px solid ${o.ruleSoft};
      border-radius: ${o.rPill};
      background: ${o.paperSoft};
      color: ${o.ink2};
      font: 11px/1.3 "IBM Plex Sans", "Segoe UI", sans-serif;
      padding: 4px 10px;
      cursor: pointer;
      white-space: nowrap;
      max-width: 100%;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    .search-suggestion-chip:hover {
      border-color: ${o.teal};
      background: ${o.tealSoft};
      color: ${o.ink};
    }
    /* Degraded-index warning: soft notice above results when index is incomplete. */
    .degraded-index-warning {
      display: none;
      align-items: center;
      gap: 6px;
      margin-top: 4px;
      border: 1px solid #cbdce7;
      border-radius: ${o.rSm};
      background: #f1f7fb;
      color: #3f5568;
      font-size: 11px;
      line-height: 1.35;
      padding: 5px 8px;
    }
    .degraded-index-warning[data-visible="true"] { display: flex; }
    .degraded-index-warning-icon { flex: none; font-size: 12px; }
    /* Save-failure warning: persistent banner while chats cannot be saved. */
    .storage-warning {
      display: none;
      flex-direction: column;
      gap: 4px;
      margin: 0 12px 8px;
      border: 1px solid #e8b7b0;
      border-radius: ${o.rSm};
      background: #fdecea;
      color: #7a2e22;
      font-size: 11.5px;
      line-height: 1.4;
      padding: 7px 10px;
    }
    .storage-warning[data-visible="true"] { display: flex; }
    .storage-warning-head { display: flex; align-items: center; gap: 6px; font-weight: 600; }
    .storage-warning-detail { overflow-wrap: anywhere; }
    .storage-warning-meta { color: #95584d; font-size: 10.5px; }
    .storage-warning[data-recovered="true"] { background: #f1f6fa; border-color: #cbdce8; color: #405e72; }
    .storage-warning[data-recovered="true"] .storage-warning-meta { color: #526d80; }
    ${fo}
    /* Only one Vault surface renders at a time; give whichever shows breathing room. */
    #vault-milestone[data-visible="true"],
    #vault-counter[data-visible="true"],
    #vault-backfill-hook > .vault-hook {
      margin-top: 6px;
      margin-bottom: 10px;
    }
    #vault-sync-status {
      display: none;
      position: relative;
      margin-top: 6px;
    }
    #vault-sync-status[data-visible="true"] { display: block; }
    #vault-sync-pill {
      display: flex;
      align-items: center;
      gap: 6px;
      width: 100%;
      padding: 5px 10px;
      border: none;
      border-radius: ${o.rSm};
      background: #f0f7f5;
      color: #2f5e53;
      font-size: 11.5px;
      font-weight: 600;
      line-height: 1.35;
      text-align: left;
      cursor: pointer;
    }
    #vault-sync-pill:hover { opacity: 0.85; }
    #vault-sync-pill:focus-visible { outline: 2px solid #2f5e53; outline-offset: 1px; }
    #vault-sync-status[data-tone="attention"] #vault-sync-pill {
      background: #fdf3f3;
      color: #7a2626;
    }
    #vault-sync-status[data-tone="attention"] #vault-sync-pill:focus-visible {
      outline-color: #7a2626;
    }
    #vault-sync-status[data-tone="ok"] #vault-sync-pill {
      background: #eef6f0;
      color: #2b5a3c;
    }
    .vault-sync-dot {
      flex: none;
      width: 7px;
      height: 7px;
      border-radius: 50%;
      background: currentColor;
      opacity: 0.55;
    }
    #vault-sync-status[data-tone="ok"] .vault-sync-dot { opacity: 0.8; }
    #vault-sync-status[data-busy="true"] .vault-sync-dot {
      animation: vault-sync-pulse 1.1s ease-in-out infinite;
    }
    @keyframes vault-sync-pulse {
      0%, 100% { opacity: 0.3; }
      50% { opacity: 0.95; }
    }
    @media (prefers-reduced-motion: reduce) {
      #vault-sync-status[data-busy="true"] .vault-sync-dot { animation: none; }
    }
    #vault-sync-panel {
      position: absolute;
      top: calc(100% + 4px);
      left: 0;
      right: 0;
      z-index: 60;
      padding: 16px;
      border-radius: 14px;
      background: #ffffff;
      border: 1px solid #d8e4e0;
      box-shadow: 0 6px 18px rgba(15, 40, 34, 0.14);
      color: #24413a;
      font-size: 11.5px;
      line-height: 1.45;
    }
    #vault-sync-pill::after { content: ""; width: 5px; height: 5px; border-right: 1.5px solid currentColor; border-bottom: 1.5px solid currentColor; transform: rotate(45deg); margin-left: auto; flex: none; }
    #vault-sync-pill[aria-expanded="true"]::after { transform: rotate(225deg); }
    .vault-sync-panel-actions {
      display: flex;
      flex-wrap: wrap;
      gap: 6px;
      margin-top: 14px;
      padding-top: 14px;
      border-top: 1px solid #e2ebe7;
    }
    .vault-sync-panel-actions button {
      padding: 4px 10px;
      border: 1px solid #c4d6d0;
      border-radius: ${o.rSm};
      background: #f6faf8;
      color: #24413a;
      font-size: 11px;
      font-weight: 600;
      cursor: pointer;
    }
    .vault-sync-panel-actions button:hover { background: #e9f2ef; }
    #vault-sync-now-btn, #vault-sync-recovery-btn { background: #2f5e53; border-color: #2f5e53; color: #fff; }
    #vault-sync-now-btn:hover, #vault-sync-recovery-btn:hover { background: #244a41; }
    .vault-sync-panel-actions button:focus-visible {
      outline: 2px solid #2f5e53;
      outline-offset: 1px;
    }
    .vault-sync-panel-actions button:disabled { opacity: 0.6; cursor: default; }
    ${Aa}
  </style>
  <div class="popup">
    <header class="head">
      <div class="head-brand">
        <img class="head-logo" src="${chrome.runtime.getURL("icons/logo.svg")}" alt="">
        <div>
          <h1 class="title">LLMnesia</h1>
          <p class="subtitle">Search your AI chats. Instantly.</p>
        </div>
      </div>
      <div class="head-controls">
        <div id="vault-sync-status" data-visible="true" data-condition="checking" data-tone="quiet" data-busy="true">
          <button id="vault-sync-pill" type="button" aria-label="Checking Vault…" title="Checking Vault…" aria-expanded="false" aria-controls="vault-sync-panel">
            ${Pa}
            <span id="vault-sync-pill-label" aria-live="polite">Checking Vault…</span>
          </button>
          <div id="vault-sync-panel" hidden>
            <div class="vault-status-panel-head">
              <span class="vault-status-heading">Vault sync</span>
              <button id="vault-sync-now-btn" type="button" aria-label="Sync now" title="Sync now" hidden>Sync now</button>
            </div>
            <div class="vault-status-panel-body"><div id="vault-sync-panel-facts"></div></div>
            <div class="vault-sync-panel-actions">
              <button id="vault-sync-recovery-btn" type="button" hidden></button>
            </div>
          </div>
        </div>

      <button id="head-settings-btn" class="head-settings-btn" type="button" title="Full settings" aria-label="Full settings">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>
      </button>
      </div>
    </header>
    <button id="vault-sync-attention" class="vault-status-attention" type="button" hidden></button>

    <section id="quick-search" class="quick-search">
      <div id="quick-search-intro" class="quick-search-intro" data-visible="false">
        <div class="quick-search-intro-head">
          <span id="quick-search-intro-label" class="quick-search-intro-label"></span>
          <button id="quick-search-intro-dismiss" class="quick-search-intro-dismiss" type="button" aria-label="Dismiss">✕</button>
        </div>
        <div id="quick-search-intro-body" class="quick-search-intro-body"></div>
      </div>
      <div class="quick-search-row">
        <svg class="quick-search-icon" viewBox="0 0 16 16" fill="none" aria-hidden="true"><circle cx="6.5" cy="6.5" r="5" stroke="currentColor" stroke-width="1.5"/><line x1="10.2" y1="10.2" x2="14.5" y2="14.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>
        <input id="quick-search-input" class="quick-search-input" type="search" autocomplete="off" placeholder="Search your chats…" aria-label="Search your chats">
        <button id="quick-search-full-btn" class="quick-search-full-btn" type="button">Full search ⤢</button>
      </div>
      <div id="storage-warning" class="storage-warning" data-visible="false">
        <span id="storage-warning-head" class="storage-warning-head">⚠️ A chat couldn't be saved</span>
        <span id="storage-warning-detail" class="storage-warning-detail"></span>
        <span id="storage-warning-meta" class="storage-warning-meta"></span>
      </div>
      <div id="degraded-index-warning" class="degraded-index-warning" data-visible="false">
        <span class="degraded-index-warning-icon" aria-hidden="true">↻</span>
        <span id="degraded-index-warning-text"></span>
      </div>
      <div id="search-suggestions" class="search-suggestions" data-visible="false"></div>
      <div id="quick-search-label" class="quick-search-label" data-visible="false">Recent</div>
      <div id="quick-search-scope" class="quick-search-label" data-visible="false"></div>
      <div id="quick-search-status" class="quick-search-status" aria-live="polite"><span class="inline-loader">Loading recent chats</span></div>
      <ul id="quick-search-results" class="quick-search-results"></ul>
    </section>

    <section id="whats-new-strip" class="whats-new-strip" data-visible="false">
      <div class="whats-new-head">
        <span class="whats-new-label">✨ <span id="whats-new-title"></span></span>
        <button id="whats-new-dismiss" class="btn ghost slim" type="button" aria-label="Dismiss">✕</button>
      </div>
      <span class="whats-new-body" id="whats-new-body"></span>
      <div class="whats-new-actions">
        <a id="whats-new-link" href="#" class="btn primary slim"></a>
      </div>
    </section>

    <section id="setup-checklist" class="setup-checklist" data-visible="false"></section>

    <section id="coverage-gap-strip" class="coverage-gap-strip" data-visible="false">
      <span id="coverage-gap-copy" class="coverage-gap-copy"></span>
      <div class="coverage-gap-actions">
        <button id="coverage-gap-import" class="btn primary slim" type="button">Import history</button>
        <button id="coverage-gap-dismiss" class="btn ghost slim" type="button">Not now</button>
      </div>
    </section>

    <section id="vault-milestone" class="vault-milestone" data-visible="false"></section>
    <div id="vault-backfill-hook"></div>
    <section id="vault-counter" class="vault-counter" data-visible="false"></section>

    <div id="site-status" class="site-status" data-status="hidden">
      <div id="site-status-text"></div>
      <div id="report-section" style="display: none;">
        <div class="report-row">
          <button id="report-btn" class="btn primary slim" type="button">Report site not indexing</button>
          <label class="snapshot-toggle">
            <input id="snapshot-toggle" type="checkbox" checked />
            Include diagnostic snapshot (no message text)
          </label>
        </div>
        <div class="report-warning">The contact form will open with a prefilled report. You can edit before submitting.</div>
      </div>
    </div>

    <div class="search-hint">
      <span>Open search <kbd id="qs-primary">…</kbd></span>
      <span class="search-hint-sep">·</span>
      <span>Add memories <kbd id="qs-memory">…</kbd></span>
      <span class="search-hint-sep">·</span>
      <button id="change-shortcut" class="change-shortcut" type="button">Change shortcut</button>
    </div>

    <section id="backfill-nudge-strip" class="backfill-nudge-strip" data-visible="false">
      <span id="backfill-nudge-copy" class="backfill-nudge-copy"></span>
      <div class="backfill-nudge-actions">
        <button id="backfill-nudge-start" class="btn primary slim" type="button">Index older chats</button>
        <button id="backfill-nudge-dismiss" class="btn ghost slim" type="button">Not now</button>
      </div>
    </section>

    <section class="panel" id="status-panel">
      <div class="panel-head">
        <h2 class="panel-title">Status</h2>
      </div>

      <div id="status-stats-block">
        <div id="stats-content" data-loading="true" aria-live="polite">
          <div class="stats-grid">
            <div class="stat">
              <div class="stat-label">Conversations</div>
              <div class="stat-value"><span class="inline-loader">Loading</span></div>
            </div>
            <div class="stat">
              <div class="stat-label">Messages</div>
              <div class="stat-value"><span class="inline-loader">Loading</span></div>
            </div>
          </div>
          <div class="meta-line">Last indexed: <span class="inline-loader">Loading</span></div>
        </div>
        <div class="pill-toggle-row">
          <button id="indexing-status" class="state-pill pill-toggle" data-state="off" data-loading="true" type="button" title="Loading indexing status">Indexing</button>
          <button id="indicator-status" class="state-pill pill-toggle" data-state="off" data-loading="true" type="button" title="Loading search pill status">Search pill</button>
          <button id="memory-pill-status" class="state-pill pill-toggle" data-state="off" data-loading="true" type="button" title="Loading memory pill status">Memory pill</button>
        </div>
        <div class="helper-note">Hiding a pill won't stop indexing or keyboard search.</div>
      </div>

      <div id="status-backfill-block" class="panel-block">
        <div class="panel-subhead">
          <h3 id="backfill-panel-title" class="panel-subtitle">Index older chats</h3>
          <div class="panel-subhead-actions">
            <button id="backfill-action-btn" class="btn primary slim" type="button">Start</button>
            <button id="backfill-cancel-btn" class="btn ghost slim" type="button" style="display:none;color:#c0392b;border-color:#e8c4c0;">Cancel</button>
          </div>
        </div>
        <div id="backfill-status-line" class="backfill-status-line" data-visible="false">
          <span id="backfill-status-dot" class="backfill-status-dot"></span>
          <span id="backfill-status-label"></span>
        </div>
        <div id="backfill-progress-track" class="backfill-progress">
          <span id="backfill-progress-fill" class="backfill-progress-fill"></span>
        </div>
        <div id="backfill-status-text" class="helper-note" data-loading="true" aria-live="polite">Checking import status</div>
        <div id="backfill-open-row" class="helper-note" style="margin-top:8px;display:none;align-items:center;gap:6px;flex-wrap:wrap;font-size:11px;">
          <span>Not on a supported tab?</span>
          <select id="backfill-open-select" style="padding:3px 6px;border-radius:6px;border:1px solid #c6d4e0;font-size:11px;color:#1d3a52;">
            <option value="chatgpt">ChatGPT</option>
            <option value="claude">Claude</option>
            <option value="gemini">Gemini</option>
            <option value="perplexity">Perplexity</option>
            <option value="grok">Grok</option>
            <option value="character_ai">Character.AI</option>
            <option value="zai">Z.ai</option>
            <option value="deepseek">DeepSeek</option>
            <option value="mistral">Mistral</option>
            <option value="qwen">Qwen</option>
            <option value="copilot">Copilot</option>
            <option value="kimi">Kimi</option>
            <option value="meta_ai">Meta AI</option>
            <option value="google_ai_mode">Google AI Mode</option>
          </select>
          <button id="backfill-open-btn" class="btn ghost slim" type="button">Open</button>
        </div>
        ${`<p class="helper-note"><strong>${ya}</strong>: recover all available chats in one run. Unreadable archives may be unarchived in Character.AI and will stay unarchived. Keep the tab open.</p><button id="character-ai-archive-recovery" class="btn ghost slim" type="button">Recover available chats</button>`}
        <details id="backfill-limit-row" class="backfill-options">
          <summary class="backfill-options-summary">Import options</summary>
          <label style="display:inline-flex;align-items:center;gap:6px;margin-top:6px;">
            Limit this import to:
            <input id="backfill-max-items" type="number" min="1" step="1" placeholder="All" style="width:60px;padding:2px 6px;border-radius:6px;border:1px solid #c6d4e0;font-size:12px;" /> chats
          </label>
        </details>
      </div>
    </section>

    <details class="panel" id="quick-memory-panel">
      <summary class="quick-memory-summary">
        <span class="panel-title">Save a reusable memory</span>
        <span class="quick-memory-hint">for every AI</span>
      </summary>
      <div style="display:flex;flex-direction:column;gap:6px;margin-top:8px;">
        <input id="quick-memory-label" type="text" placeholder="Short label (optional)" style="padding:6px 8px;border-radius:6px;border:1px solid #c6d4e0;font-size:12px;" />
        <textarea id="quick-memory-text" rows="2" placeholder="Something every AI should know about you…" style="padding:6px 8px;border-radius:6px;border:1px solid #c6d4e0;font-size:12px;resize:vertical;font-family:inherit;"></textarea>
        <div class="control-row">
          <label style="display:inline-flex;align-items:center;gap:6px;font-size:12px;color:#3f5568;cursor:pointer;">
            <input id="quick-memory-star" type="checkbox" />
            Add this memory to new chats automatically
          </label>
          <button id="quick-memory-save" class="btn primary" type="button">Save</button>
        </div>
        <div class="control-row" style="justify-content:flex-end;">
          <button id="quick-memory-manage" class="btn ghost slim" type="button">Manage memories →</button>
        </div>
        <div id="quick-memory-status" class="helper-note"></div>
      </div>
    </details>

    <section id="cc-promo-card" class="cc-promo-card" data-visible="false" data-kind="none">
      <div class="cc-promo-copy">
        <div id="desktop-promo-title" class="cc-promo-title"></div>
        <div id="desktop-promo-sub" class="cc-promo-sub"></div>
      </div>
      <div class="cc-promo-actions">
        <button id="cc-promo-connect" class="btn primary slim" type="button"></button>
        <button id="cc-promo-dismiss" class="btn ghost slim" type="button" aria-label="Dismiss">✕</button>
      </div>
    </section>

    <div id="secondary-surfaces" class="secondary-surfaces"></div>

    <div class="settings-row">
      <button id="quick-report-btn" class="settings-btn" type="button">Report a problem</button>
      <span class="settings-sep">·</span>
      <button id="open-landing" class="settings-btn" type="button">Visit site</button>
      <span class="settings-sep">·</span>
      <button id="open-whats-new" class="settings-btn" type="button">✨ What's new</button>
    </div>
    
  </div>
`;const gt=document.querySelector("#secondary-surfaces");for(const e of["whats-new-strip","setup-checklist","coverage-gap-strip","backfill-nudge-strip","vault-milestone","vault-backfill-hook","vault-counter","cc-promo-card","founding-strip"]){const a=document.getElementById(e);a&&gt&&gt.append(a)}const he=document.querySelector("#qs-primary"),ge=document.querySelector("#qs-memory"),Io=chrome.commands.getAll().then(e=>{const a=e.find(i=>i.name==="open-search-palette"),t=e.find(i=>i.name==="inject-memory-context");he&&(he.textContent=a?.shortcut||"Not set"),ge&&(ge.textContent=t?.shortcut||"Not set")}).catch(()=>{he&&(he.textContent="Not set"),ge&&(ge.textContent="Not set")}),No=document.querySelector("#change-shortcut");No?.addEventListener("click",()=>{chrome.tabs.create({url:"chrome://extensions/shortcuts"})});const Zt=document.querySelector("#backfill-max-items"),Me=document.querySelector("#backfill-status-line"),Lo=document.querySelector("#backfill-status-dot"),bt=document.querySelector("#backfill-status-label"),yt=document.querySelector("#backfill-panel-title"),Te=document.querySelector("#backfill-progress-fill"),vt=document.querySelector("#backfill-progress-track"),v=document.querySelector("#backfill-action-btn"),E=document.querySelector("#backfill-cancel-btn"),K=document.querySelector("#backfill-limit-row"),d=document.querySelector("#backfill-status-text"),xt=document.querySelector("#backfill-open-row"),Se=document.querySelector("#backfill-open-select"),xe=document.querySelector("#backfill-open-btn"),N=document.querySelector("#backfill-nudge-strip"),Q=document.querySelector("#backfill-nudge-copy"),D=document.querySelector("#backfill-nudge-start"),Mo=document.querySelector("#backfill-nudge-dismiss"),To=30,nt=["chatgpt","claude","gemini","perplexity","grok","character_ai","zai","deepseek","mistral","qwen","copilot","kimi","meta_ai","google_ai_mode","ai_studio"],Ao={ai_studio:"https://aistudio.google.com/library",chatgpt:"https://chatgpt.com/",claude:"https://claude.ai/",gemini:"https://gemini.google.com/app",perplexity:"https://www.perplexity.ai/",grok:"https://grok.com/",character_ai:"https://character.ai/",zai:"https://chat.z.ai/",deepseek:"https://chat.deepseek.com/",mistral:"https://chat.mistral.ai/",qwen:"https://chat.qwen.ai/",copilot:"https://copilot.com/",kimi:"https://www.kimi.ai/",meta_ai:"https://www.meta.ai/",google_ai_mode:_a};Se?.addEventListener("change",()=>{P()});xe?.addEventListener("click",()=>{const e=Se?.value;Ca(e)&&chrome.tabs.create({url:Ao[e]}).catch(()=>{})});let kt=null,Ae=null,I=null,Jt=null,S=null,wt=!1;function Po(e,a){if(!Te)return;let t=0,i="linear-gradient(90deg, #2f7f99 0%, #49b08f 100%)";e?.active?(a?.phase==="running"&&a.total>0?t=Math.max(2,Math.min(100,Math.round(a.processed/a.total*100))):a?.phase==="done"?t=100:t=18,e.paused&&(i="#9aa8b4")):a?.phase==="done"&&(t=100),Te.style.width=`${t}%`,Te.style.background=i,vt&&(vt.style.display=t>0?"":"none")}function Ro(e){const{state:a,progress:t,runProgress:i,activeTabPlatform:n,queue:s,authMissingPlatform:r}=e;if(!a.active&&n==="google_ai_mode"){const l=Ht(t);if(l)return l.message}if(!a.active&&r)return`Sign in to ${y(r)} in this tab and try again — we couldn't authenticate the last import.`;if(a.active){const l=y(a.platform);if(a.yieldReason==="tab_frozen")return`${l} import paused while its tab is sleeping. It continues when Chrome wakes the tab.`;if(!a.paused&&Ge(i)){const c=i&&i.total>0?` on ${i.activeItemIndex??i.processed} of ${i.total}`:"";return a.platform==="google_ai_mode"&&i?.googleTargetedRetry?"Selected Google chat stalled. Click Stop, then retry that chat in Settings.":a.platform==="google_ai_mode"?`${l} import stalled${c}. Click Stop, then Start to resume unfinished chats.`:`${l} import stalled${c}. Restarting it from where it left off.`}if(n&&a.platform&&n!==a.platform)return s.find(u=>u.platform===n)?`${l} is indexing. ${y(n)} is queued.`:`${l} is indexing. Queue ${y(n)} from this tab if needed.`;if(a.paused)return"Paused.";const p=t?.throttledUntil?t.throttledUntil-Date.now():0;if(p>0){const c=Math.max(1,Math.ceil(p/1e3)),u=t&&t.total>0?` (${t.processed}/${t.total})`:"";return`${l} hit a rate limit — resuming in ${c}s${u}`}if(t?.phase==="running"){const c=typeof t.activeItemIndex=="number"&&t.activeItemIndex>0?t.activeItemIndex:t.processed,u=t.total>0?` (${c}/${t.total})`:"",g=Ea(t)??0;if(g>=$a){const C=Math.round(g/1e3),q=t.activeItemAttempt??1,w=q>1?`, retry ${q-1}`:"";return`Still fetching one chat on ${l} (${C}s${w})${u}`}if(t.lastIndexedTitle){const C=qa(!!t.lastIndexedChanged,!!t.lastIndexedIsNew),q=t.lastIndexedPartialDepth?a.platform==="google_ai_mode"?" (captured in part, click Start after this run to retry)":" (partial depth, will retry)":"";return`${C}: ${t.lastIndexedTitle}${q}${u}`}return t.lastSkippedTitle?`Skipped: ${t.lastSkippedTitle} (${t.lastSkippedReason??"not indexable"})${u}`:`Indexing older chats on ${l}…${u}`}if(t?.phase==="collecting"){const c=t.total>0?` (${t.total} found so far)`:"";return`Fetching your ${l} chat list…${c}`}return t?.phase==="pruning"?"Checking what's already indexed…":`Indexing older chats on ${l}…`}if(n&&s.find(p=>p.platform===n))return`${y(n)} is queued.`;if(n==="google_ai_mode"){if(t?.lastError==="unsupported_account")return"Choose Google's default signed-in account to import. Other account slots are not supported yet.";if(t?.lastError==="account_changed")return"Google account changed. Import stopped. Return to the original account and press Start to resume.";if(t?.lastError==="account_unavailable"||t?.lastError==="permission_or_session")return"Open a signed-in Google AI Mode page, reload it, then press Start to import."}if(n==="ai_studio"){const l=ka(t?.lastError);if(l)return l}if(t?.lastError==="history_list_unavailable")return`Couldn’t reach your ${y(n)} chat history. Try the import again later.`;if(n==="character_ai"&&(t?.lastError==="character_ai_access_denied"||t?.characterAiArchiveRecovery&&["done","cancelled"].includes(t.phase)))return ct(t,n);if(t?.phase==="cancelled"){const l=y(n),p=`Saved ${t.indexed} ${t.indexed===1?"chat":"chats"}.`,c=t.failed?` ${t.failed} could not be saved.`:"";return n==="google_ai_mode"?`Google import stopped. ${p}${c} Choose Resume import to continue.`:`${n?`${l} import`:"Last import"} stopped. ${p}${c} Press Start to import any remaining chats.`}return t?.phase==="done"?ct(t,n??a.platform):n?n==="google_ai_mode"?"Save your Google AI Mode chats without switching conversations. Keep the Google tab open while importing.":`Ready to index older chats on ${y(n)} — press Start.`:"No supported AI tab open. Pick one below to start."}async function fe(){let e;try{e=await chrome.tabs.query({active:!0,currentWindow:!0})}catch{return null}const a=e[0],t=typeof a?.id=="number"?a.id:null,i=a?await Kt(a):null;return!i||typeof t!="number"||t<=0?null:{platform:i,seedTabId:t}}async function ea(e){try{const a=await chrome.storage.local.get(_),t=pe(a[_]);return(e?[e]:nt).some(n=>t[n]?.hasBackfillRun===!0)}catch{return!1}}async function P(){let e;try{e=await chrome.runtime.sendMessage({type:"GET_BACKFILL_STATUS"})}catch{d&&(d.dataset.loading="false",d.textContent="Couldn’t check import status.");return}if(!e.ok){d&&(d.dataset.loading="false",d.textContent="Couldn’t check import status.");return}d?.setAttribute("data-loading","false");const a=await fe(),t=a?.platform??null,{state:i,progress:n,queue:s,progressByPlatform:r}=e;ma(ho(i,n),i.platform),(i.active||S?.seedTabId!==a?.seedTabId)&&(S=null);const l=i.yieldReason==="tab_frozen",p=I?.active===!0;I=i,Jt=t,p&&!i.active&&st();const c=t&&r[t]?r[t]??null:n,u=`${t??i.platform}:${c?.phase}:${c?.indexed}:${c?.processed}`;c&&u!==kt&&(kt=u,await da());const g=t&&i.active&&i.platform!==t?null:i;Po(g,c);const C="Import chats";if(yt&&(yt.textContent=C),Me&&bt)if(i.active){const w=!i.paused&&Ge(n);bt.textContent=i.paused?"Paused":w?`${y(i.platform)} import stalled`:`Indexing ${y(i.platform)}…`;const h=va({paused:i.paused,stalled:w,since:n?.activeItemStartedAt??Date.now(),platformLabel:i.platform?y(i.platform):null,pauseCause:i.yieldReason==="vault_catch_up"?"vault":"user"}),Ne=h?xa(h).tone==="attention":!1;Lo?.setAttribute("data-state",i.paused?"paused":Ne?"stuck":"active"),Me.dataset.visible="true"}else Me.dataset.visible="false";if(v){const w=t?s.some(ba=>ba.platform===t):!1,h=!!t&&i.active&&i.platform===t,Ne=i.active&&!i.paused&&Ge(n);h?(v.disabled=l,v.textContent=l?"Paused":i.paused?"Resume":"Pause",E&&(E.style.display="",E.textContent=Ne?"Stop":"Cancel"),K&&(K.style.display="none")):i.active?(v.disabled=w,v.textContent=w?"Queued":"Queue",E&&(E.style.display="",E.textContent="Stop"),K&&(K.style.display="none")):(v.disabled=!1,v.textContent=w?"Queued":t==="google_ai_mode"?Ht(c)?.action??"Start":"Start",E&&(E.style.display="none"),K&&(K.style.display=""))}const q=await Oo(t);d&&(d.textContent=S?.message??Ro({state:i,progress:c,runProgress:n,activeTabPlatform:t,queue:s,authMissingPlatform:q})),xt&&(xt.style.display=!i.active&&!t?"flex":"none",xe&&(xe.textContent=Se?.value==="google_ai_mode"?"Open Google":"Open",xe.title=Se?.value==="google_ai_mode"?"Open Google AI Mode, then click Start in LLMnesia to import your history.":"Open the selected AI site, then click Start to import your history."))}const Bo=1440*60*1e3;async function Oo(e){try{const t=(await chrome.storage.local.get(lt))[lt];return!t||typeof t.at!="number"||Date.now()-t.at>Bo||e&&t.platform!==e?null:t.platform}catch{return null}}async function Do(){return fe()}async function it(e=!1,a=!1){if(!v)return;v.disabled=!0,(!I||Jt===null)&&await P();const t=await Do();if(!t){d&&(d.textContent="No supported AI tab open. Pick one below to start."),v&&(v.disabled=!1);return}if(a&&(t.platform!=="character_ai"||I?.active)){d&&(d.textContent="Open Character.AI and wait for any current import to finish before recovering archives."),v.disabled=!1;return}if(a&&!window.confirm(Ta)){v.disabled=!1;return}if(!!I?.active&&I?.platform===t.platform&&I){if(e){if(I.paused)try{await chrome.runtime.sendMessage({type:"RESUME_BACKFILL"})}catch{}await P();return}const r=I.paused?"RESUME_BACKFILL":"PAUSE_BACKFILL";try{await chrome.runtime.sendMessage({type:r})}catch{}await P();return}const n=parseInt(Zt?.value??"",10),s=Number.isFinite(n)&&n>0?n:void 0;try{const r=await chrome.runtime.sendMessage({type:"START_BACKFILL",platform:t.platform,seedTabId:t.seedTabId,source:"manual",...a?{characterAiArchiveRecovery:!0}:s!==void 0?{maxItems:s}:{}});if(r.ok)if(r.ok&&r.deferredBy&&d)S=null,d.textContent=jt;else if(r.ok&&r.queued&&d){S=null;const l=typeof r.queuePosition=="number"?` (#${r.queuePosition})`:"";d.textContent=`${y(t.platform)} queued${l}.`}else S=null;else{const l=r.error??"Could not start indexing.";S={seedTabId:t.seedTabId,message:l},d&&(d.textContent=l)}}catch{}await P()}async function Uo(e){if(e>0)return!1;try{if((await chrome.storage.local.get(de))[de]===!0)return!1}catch{return!1}return!0}async function Fo(e){if(!N)return;if(await Uo(e)){N.dataset.visible="false",f.release("ask","backfill_nudge");return}if(e>=To||I?.active){N.dataset.visible="false",f.release("ask","backfill_nudge");return}const a=await fe(),t=a?.platform??null,i=t?[t]:nt;if(e>0){const n=await chrome.storage.local.get(_),s=pe(n[_]),r=Date.now();if(!i.some(p=>{const c=s[p];return c?!(c.hasBackfillRun||c.snoozeUntil>r):!0})){N.dataset.visible="false",f.release("ask","backfill_nudge");return}}if(!f.claim("ask","backfill_nudge")){N.dataset.visible="false";return}if(Q){const n=S&&S.seedTabId===a?.seedTabId?S.message:null,s=n?"Not started":e===0?"No older chats yet":`Only ${e} indexed`,r=document.createElement("span");r.className="backfill-nudge-count",r.textContent=s;const l=document.createElement("span");l.className="backfill-nudge-text",l.textContent=n??"Add them for better search.",Q.replaceChildren(r,l)}N.dataset.visible="true",wt||(wt=!0,m("backfill_prompt_shown",t??void 0,{conversation_count:e}))}async function zo(){N&&(N.dataset.visible="false");const e=await chrome.storage.local.get(_),a=pe(e[_]),i=(await fe())?.platform??null,n=i?[i]:nt;let s=a;const r=Date.now();for(const l of n)s=Na(s,l,r);await chrome.storage.local.set({[_]:s}),m("backfill_prompt_dismissed",i??void 0)}async function Vo(){D&&(D.disabled=!0);const e=await fe(),a=e?.platform??null;if(!e){const t="Open ChatGPT, Claude, Gemini, or Perplexity, then click this again.";if(d&&(d.textContent=t),Q){const i=document.createElement("span");i.className="backfill-nudge-count",i.textContent="Needs a tab";const n=document.createElement("span");n.className="backfill-nudge-text",n.textContent=t,Q.replaceChildren(i,n)}D&&(D.disabled=!1);return}try{const t=await chrome.storage.local.get(_),i=pe(t[_]),n=[e.platform];let s=i;const r=Date.now();for(const u of n)s=Ia(s,u,"onboarding",r);await chrome.storage.local.set({[_]:s}),m("backfill_prompt_accepted",a??void 0);const l=parseInt(Zt?.value??"",10),p=Number.isFinite(l)&&l>0?l:void 0,c=await chrome.runtime.sendMessage({type:"START_BACKFILL",platform:e.platform,seedTabId:e.seedTabId,source:"prompt",...p!==void 0?{maxItems:p}:{}});if(!c.ok){const u=c.error??"Could not start indexing older chats.";if(S={seedTabId:e.seedTabId,message:u},d&&(d.textContent=u),Q){const g=document.createElement("span");g.className="backfill-nudge-count",g.textContent="Not started";const C=document.createElement("span");C.className="backfill-nudge-text",C.textContent=u,Q.replaceChildren(g,C)}return}if(S=null,N&&(N.dataset.visible="false"),c.deferredBy&&d)d.textContent=jt;else if(c.queued&&d){const u=typeof c.queuePosition=="number"?` (#${c.queuePosition})`:"";d.textContent=`${y(e.platform)} queued${u}.`}await P()}catch{const t="Could not start indexing older chats.";S={seedTabId:e.seedTabId,message:t},d&&(d.textContent=t)}finally{D&&(D.disabled=!1)}}D?.addEventListener("click",()=>{Vo()});Mo?.addEventListener("click",()=>{zo()});const le="llmnesia.coverageGap.snoozed",M=document.querySelector("#coverage-gap-strip"),St=document.querySelector("#coverage-gap-copy"),F=document.querySelector("#coverage-gap-import"),Go=document.querySelector("#coverage-gap-dismiss");let Ct=!1,ue=null;async function Ho(){try{const e=await chrome.runtime.sendMessage({type:"GET_PLATFORM_CONVERSATION_COUNTS"});if(e.ok)return e.counts}catch{}return{}}async function Ko(e){if(!M||!St)return;if(!Eo(e)){M.dataset.visible="false",f.release("info","coverage_gap");return}const[a,t,i]=await Promise.all([Ho(),chrome.storage.local.get(_),chrome.storage.local.get(le)]),n=_o({counts:a,promptStateRaw:t[_],snoozed:Wt(i[le])});if(!n){M.dataset.visible="false",f.release("info","coverage_gap");return}if(!f.claim("info","coverage_gap")){M.dataset.visible="false";return}ue=n.platform;const s=y(n.platform),r=n.count.toLocaleString();St.innerHTML=`<strong>${r} ${s} chats indexed</strong>, but your older ${s} history isn't here yet. Import it for complete search.`,F&&(F.textContent=`Import ${s} history`),M.dataset.visible="true",Ct||(Ct=!0,m("coverage_gap_shown",n.platform,{conversation_count:n.count}))}async function Yo(){M&&(M.dataset.visible="false"),f.release("info","coverage_gap");const e=ue;if(ue=null,!e)return;const a=await chrome.storage.local.get(le),t=Wt(a[le]),i=Date.now(),s=(t[e]??0)>i?La:Ma;t[e]=i+s,await chrome.storage.local.set({[le]:t}),m("coverage_gap_dismissed",e)}async function Qo(){const e=ue;if(e){F&&(F.disabled=!0),m("coverage_gap_accepted",e);try{await chrome.runtime.sendMessage({type:"OPEN_BACKFILL_ONBOARDING",platform:e,surface:"coverage_gap"}),M&&(M.dataset.visible="false"),f.release("info","coverage_gap"),ue=null}catch{F&&(F.disabled=!1)}}}F?.addEventListener("click",()=>{Qo()});Go?.addEventListener("click",()=>{Yo()});function Wo(){const e=P();return Ae!==null&&clearInterval(Ae),Ae=setInterval(()=>{P()},1200),e}v?.addEventListener("click",()=>{it()});document.querySelector("#character-ai-archive-recovery")?.addEventListener("click",()=>{it(!1,!0)});E?.addEventListener("click",()=>{E.disabled=!0,chrome.runtime.sendMessage({type:"STOP_BACKFILL"}).catch(()=>{}).finally(async()=>{E.disabled=!1,await P()})});const O=document.querySelector("#stats-content"),z=document.querySelector("#indicator-status"),ne=document.querySelector("#indexing-status"),ie=document.querySelector("#memory-pill-status"),jo=document.querySelector("#open-whats-new"),Xo=document.querySelector("#open-landing"),Zo=document.querySelector("#quick-report-btn"),_t=document.querySelector("#founding-strip"),Jo=document.querySelector("#founding-join"),en=document.querySelector("#founding-not-now"),Ce=document.querySelector("#quick-search-intro"),Et=document.querySelector("#quick-search-intro-label"),$t=document.querySelector("#quick-search-intro-body"),tn=document.querySelector("#quick-search-intro-dismiss"),$=document.querySelector("#quick-search-input"),an=document.querySelector("#quick-search-full-btn"),Pe=document.querySelector("#quick-search-status"),ce=document.querySelector("#quick-search-results"),qt=document.querySelector("#quick-search-label"),ae=document.querySelector("#quick-search-scope"),U=document.querySelector("#whats-new-strip"),It=document.querySelector("#whats-new-title"),Nt=document.querySelector("#whats-new-body"),Re=document.querySelector("#whats-new-link"),on=document.querySelector("#whats-new-dismiss"),Qe="llmnesia.whatsNew",nn="llmnesia.whatsNewSeenId";let ta=null;const Lt=document.querySelector("#site-status"),_e=document.querySelector("#site-status-text"),Mt=document.querySelector("#report-section"),sn=document.querySelector("#report-btn"),rn=document.querySelector("#snapshot-toggle");let We="",je="",Xe=null,Ze=null;const f=yo();function aa(e){_t&&(_t.dataset.visible="false")}function Tt(){if(U){const a=document.documentElement,t=a.scrollHeight>a.clientHeight+1,i=document.querySelector(".popup");if(i&&!t&&U.dataset.visible==="true"){const n=getComputedStyle(U),s=U.offsetHeight+parseFloat(n.marginTop||"0")+parseFloat(n.marginBottom||"0"),r=parseFloat(getComputedStyle(i).paddingBottom||"0");i.style.paddingBottom=`${Math.round(r+s)}px`}U.dataset.visible="false"}const e=ta?.id;chrome.storage.local.remove(Qe),e&&chrome.storage.local.set({[nn]:e})}function ln(e){if(e.actionKind==="viewer-recent"){chrome.runtime.sendMessage({type:"OPEN_RECENT_SAVED_VIEWER"}).catch(()=>{});return}if(e.actionKind==="url"&&e.url){chrome.tabs.create({url:e.url});return}if(e.actionKind==="options-mcp"){chrome.tabs.create({url:chrome.runtime.getURL("options.html#corpus-native-card")});return}if(e.actionKind==="options-vault"){chrome.tabs.create({url:chrome.runtime.getURL("options.html#vault-card")});return}chrome.tabs.create({url:"https://llmnesia.com/changelog"})}function cn(){Ce&&(Ce.dataset.visible="false")}const oa=6,At=4,dn=180;let Be=null,j=0;function x(e,a=!1){Pe&&(Pe.textContent=e,Pe.dataset.loading=a?"true":"false")}function T(){ce&&(ce.textContent="")}function V(e){qt&&(qt.dataset.visible=e?"true":"false")}function X(e){ae&&(e?.enabled===!0&&e.scopeLabel?(ae.textContent=e.scopeEmpty?"No spaces selected: pick a scope in Settings":`Searching: ${e.scopeLabel}`,ae.dataset.visible="true"):(ae.textContent="",ae.dataset.visible="false"))}async function Ee(e=0){const a=++j;x("Loading recent chats",!0);let t;try{t=await chrome.runtime.sendMessage({type:"SEARCH_QUERY",query:"",surface:"popup"})}catch{a===j&&(T(),V(!1),x(""));return}if(a!==j)return;if(t.ok&&t.organisation?.superseded){if(te+=1,Ie(),T(),X(void 0),V(!1),e<1)return Ee(e+1);x("Search scope is changing. Try searching again.");return}if(!t.ok||t.results.length===0){T(),V(!1),X(t.ok?t.organisation:void 0),x("");return}x(""),X(t.organisation),V(!0),na(t.results,At,"popup_recents");const i=Math.min(t.results.length,At);m("popup_recents_shown",void 0,{result_count:i})}function na(e,a=oa,t="popup",i="",n){ce&&(ce.textContent="",e.slice(0,a).forEach((s,r)=>{const l=document.createElement("li"),p=document.createElement("button");p.type="button",p.className="quick-search-result";const c=Qt(s.platform),u=document.createElement("div");u.className="quick-search-result-head";const g=document.createElement("span");g.className="quick-search-result-platform",g.style.setProperty("--pill-bg",c.pillBg),g.style.setProperty("--pill-border",c.pillBorder),g.style.setProperty("--pill-text",c.pillText),g.textContent=c.label,u.append(g);const C=bo(s.captureProvenance);if(C){const h=document.createElement("span");h.className="quick-search-result-platform",h.style.setProperty("--pill-bg","transparent"),h.style.setProperty("--pill-border",c.pillBorder),h.style.setProperty("--pill-text",c.pillText),h.style.fontStyle="italic",h.textContent=C,u.append(h)}const q=document.createElement("span");q.className="quick-search-result-title",q.textContent=s.title||"Untitled conversation",u.append(q),p.append(u);const w=document.createElement("span");w.className="quick-search-result-meta",w.textContent=s.snippet?s.snippet.replace(/\s+/g," ").trim().slice(0,90):"",w.textContent&&p.append(w),p.addEventListener("click",()=>{const h=$?.value.trim()??"";chrome.runtime.sendMessage({type:"OPEN_RESULT",result:s,inNewTab:!0,query:h,fromSearch:t==="popup"&&h.length>0&&h===i,searchId:t==="popup"&&h.length>0&&h===i?n:void 0,rank:r,surface:t}).then(()=>window.close()).catch(()=>x("Could not open that conversation."))}),l.append(p),ce.append(l)}))}async function Je(e,a=0){const t=e.trim(),i=++j;if(!t){T(),x(""),V(!1),Ee();return}V(!1),x("Searching…");let n;try{n=await chrome.runtime.sendMessage({type:"SEARCH_QUERY",query:t,surface:"popup"})}catch(s){if(i!==j)return;T(),x(s instanceof Error?`Search failed: ${s.message}`:"Search failed.");return}if(i===j){if(!n.ok){T(),X(void 0),x(`Search failed: ${n.error}`);return}if(n.organisation?.superseded){if(te+=1,Ie(),T(),X(void 0),a<1)return Je(t,a+1);x("Search scope is changing. Try searching again.");return}if(X(n.organisation),n.results.length===0){T(),x(n.organisation?.scopeEmpty?"No spaces selected: pick a scope in Settings.":"No matches. Try a word you'd have typed in the chat.");return}x(""),na(n.results,oa,"popup",t,n.searchId)}}function Pt(){const e=$?.value.trim()??"";chrome.runtime.sendMessage({type:"OPEN_SEARCH_ANYWHERE",query:e||void 0}).then(()=>window.close()).catch(()=>x("Could not open full search."))}function un(){return $?.addEventListener("input",()=>{Be!==null&&window.clearTimeout(Be),Be=window.setTimeout(()=>{Je($?.value??"")},dn)}),$?.addEventListener("keydown",e=>{e.key==="Enter"&&Pt()}),an?.addEventListener("click",Pt),$?.focus(),chrome.runtime.onMessage.addListener(e=>{if(e?.type==="ORGANISATION_CHANGED"){te+=1,Ie(),T(),V(!1);const a=$?.value.trim()??"";a?Je(a):Ee(),at&&ha(at)}}),Ee()}function pn(e){if(!Ce||!$t||!Et||!f.claim("info","quick_search_intro"))return;const a=e.toLocaleString();Et.textContent=`✓ ${a} chats indexed`,$t.textContent="That's the number that was on the icon. They're all searchable — try the box below.",Ce.dataset.visible="true",tn?.addEventListener("click",cn,{once:!0})}async function fn(){chrome.storage.local.remove("llmnesia.whatsNewVersion");const a=(await chrome.storage.local.get(Qe))[Qe];!a||!U||!It||!Nt||!Re||f.claim("info","whats_new")&&(ta=a,It.textContent=a.title,Nt.textContent=a.body,Re.textContent=a.cta,U.dataset.visible="true",Re.addEventListener("click",t=>{t.preventDefault(),ln(a),Tt()}),on?.addEventListener("click",Tt))}const k=document.querySelector("#setup-checklist"),mn={import:{label:"Import your history",cta:"Import"},memory:{label:"Add your first memory",cta:"Add"},handoff:{label:"Try a handoff",cta:"How?"}};async function hn(){return await ea(null)||await ot()>0}async function ia(){if(await no())return!0;try{const e=await chrome.runtime.sendMessage({type:"LIST_MEMORIES"});return e?.ok===!0&&Array.isArray(e.memories)&&e.memories.length>0}catch{return!1}}async function sa(){return oo()}const gn={import:hn,memory:ia,handoff:sa};async function ra(){const e=[He,de,...B.map(t=>R[t])],a=await chrome.storage.local.get(e);return{initialized:a[He]===!0,completedShown:a[de]===!0,done:{import:a[R.import]===!0,memory:a[R.memory]===!0,handoff:a[R.handoff]===!0}}}async function bn(){if(!k)return;if(!(await ra()).initialized){const[a,t,i]=await Promise.all([(async()=>await ea(null)||await ot()>0)(),ia(),sa()]),n={[He]:!0};a&&(n[R.import]=!0),t&&(n[R.memory]=!0),i&&(n[R.handoff]=!0),await chrome.storage.local.set(n)}await st()}async function st(){if(!k)return;const e=await ra();if(e.completedShown){k.dataset.visible="false",f.release("info","setup_checklist");return}const a={import:!1,memory:!1,handoff:!1};await Promise.all(B.filter(n=>!e.done[n]).map(async n=>{a[n]=await gn[n]()}));const t=Ja(e.done,a);for(const n of t.newlyCompleted)await chrome.storage.local.set({[R[n]]:!0}),m("checklist_step_completed",void 0,{step:n});if(!f.claim("info","setup_checklist")){k.dataset.visible="false";return}if(t.allComplete){vn(),k.dataset.visible="true",await chrome.storage.local.set({[de]:!0}),m("checklist_completed");return}const i=B.filter(n=>t.done[n]).length;yn(t.done,i),k.dataset.visible="true"}function yn(e,a){if(!k)return;const t=B.map((i,n)=>{const s=mn[i],r=e[i],l=r?"✓":String(n+1),p=r?"":`<button class="btn ghost slim" type="button" data-step-action="${i}">${s.cta}</button>`;return`<li class="setup-step" data-done="${r}" data-step="${i}">
        <span class="setup-step-mark">${l}</span>
        <span class="setup-step-label">${s.label}</span>
        ${p}
      </li>`}).join("");k.innerHTML=`
    <div class="setup-checklist-head">
      <span class="setup-checklist-title">Get set up</span>
      <span class="setup-checklist-progress">${a} of ${B.length} complete</span>
    </div>
    <ol class="setup-checklist-list">${t}</ol>
  `;for(const i of B){if(e[i])continue;k.querySelector(`[data-step-action="${i}"]`)?.addEventListener("click",()=>{xn(i)})}}function vn(){k&&(k.innerHTML=`
    <div class="setup-checklist-head">
      <span class="setup-checklist-title">You're all set</span>
      <span class="setup-checklist-progress">${B.length} of ${B.length} complete</span>
    </div>
    <div class="setup-checklist-done">Import, memory, and handoff — all done.</div>
  `)}function Rt(e){if(!e)return;const a=e.getBoundingClientRect();a.top>=0&&a.bottom<=window.innerHeight||e.scrollIntoView({behavior:"smooth",block:"center"}),e.classList.remove("panel-flash"),e.offsetWidth,e.classList.add("panel-flash"),window.setTimeout(()=>e.classList.remove("panel-flash"),1800)}async function xn(e){if(e==="import"){Rt(document.querySelector("#status-backfill-block")),await it(!0);return}if(e==="memory"){const a=document.querySelector("#quick-memory-panel");a&&(a.open=!0,Rt(a),window.setTimeout(()=>se?.focus(),320));return}kn()}function kn(){if(!k||k.querySelector(".setup-step-hint"))return;const e=document.createElement("div");e.className="setup-step-hint",e.style.marginLeft="0",e.textContent="Open a saved chat from LLMnesia search. On that page, right-click the search pill and choose “Continue in…” to move it into another AI.",k.append(e)}const A=document.querySelector("#vault-sync-status"),G=document.querySelector("#vault-sync-pill"),wn=document.querySelector("#vault-sync-panel"),et=document.querySelector("#vault-sync-panel-facts"),W=document.querySelector("#vault-sync-now-btn"),Z=document.querySelector("#vault-sync-recovery-btn"),rt=Ra({root:A,button:G,panel:wn,syncNow:W,render:Cn,refresh:qe,async runSync(){return(await chrome.runtime.sendMessage({type:"VAULT_SYNC_NOW"}))?.ok===!0}});let Bt=0,la=!1;function $e(e){rt.clear(),Va({root:A,button:G,facts:et,syncNow:W,recovery:Z,label:document.querySelector("#vault-sync-pill-label"),attention:document.querySelector("#vault-sync-attention")},e)}$e("checking");function Sn(e){if(!A)return;if(!e){$e("unavailable");return}if(la=!0,!Ga(e)){$e(e.status.available?"setup":"unavailable");return}const a=Ha(e,Date.now());rt.update(a)}function Cn(e){if(!A)return;A.dataset.visible="true",A.dataset.tone=e.tone,A.dataset.condition=e.condition;const a=document.querySelector("#vault-sync-attention");a&&(a.hidden=e.tone!=="attention",a.textContent=me(e)),A.dataset.busy=e.busy?"true":"false",G&&(G.setAttribute("aria-label",`Vault status: ${e.copy}`),G.title=me(e));const t=G?.querySelector("#vault-sync-pill-label");if(t&&t.textContent!==me(e)&&(t.textContent=me(e)),W&&(W.hidden=!1,W.disabled=e.busy||!e.canSyncNow,Ba(W,e.busy)),Z){const i={signin:"Sign in",unlock:"Unlock Vault",subscription:"Review subscription",update:"How to update"},n=e.recovery;Z.hidden=n===null,Z.textContent=n===null?"":i[n]}et&&Oa(et,e,()=>{rt.close(),chrome.runtime.openOptionsPage()})}async function qe(){la||$e("checking");const e=++Bt,a=await Da();e===Bt&&Sn(a)}async function _n(){try{const e=await chrome.runtime.sendMessage({type:"VAULT_STATUS"});return e.ok?e.status:null}catch{return null}}async function En(){const e=await _n();return e!==null&&e.available&&e.signedIn&&e.unlocked}A&&G&&(Z&&Z.addEventListener("click",()=>{chrome.runtime.openOptionsPage()}),document.querySelector("#vault-sync-attention")?.addEventListener("click",()=>{chrome.runtime.openOptionsPage()}),chrome.storage.onChanged.addListener((e,a)=>{a==="local"&&(eo in e||to in e||ao in e||Ua.some(t=>t in e))&&$n()}),Fa(()=>{qe()}));let be=null;function $n(){be&&clearTimeout(be),be=setTimeout(()=>{be=null,qe()},200)}const Ot=document.querySelector("#vault-milestone"),Dt=document.querySelector("#vault-backfill-hook"),L=document.querySelector("#vault-counter");let Ut=!1;function oe(){L&&(L.dataset.visible="false")}function qn(){Ot&&(Ot.dataset.visible="false")}function In(){Dt&&(Dt.textContent="")}async function ca(){try{const e=await chrome.runtime.sendMessage({type:"GET_INDEX_STATS_QUICK"});if(e.ok)return e.stats.conversationCount}catch{}return ot()}async function Nn(){{qn(),In(),await Ln();return}}async function Ln(){if(!L){oe(),f.release("ask","vault");return}if(await En()){oe(),f.release("ask","vault");return}const e=await ca();if(e<$o||await uo("popup")){oe(),f.release("ask","vault");return}if(!f.claim("ask","vault")){oe();return}Ut||(Ut=!0,mo("hook_impression",{surface:"popup"})),L.textContent="";const a=document.createElement("div");a.className="vault-headline",a.textContent=Le.headline.replace("{count}",e.toLocaleString("en-US")),L.append(a);const t=document.createElement("div");t.className="vault-body",t.textContent=Le.body,L.append(t);const i=document.createElement("button");i.className="btn primary slim",i.type="button",i.textContent=Le.cta,i.addEventListener("click",()=>{chrome.tabs.create({url:chrome.runtime.getURL("options.html#vault-card")})}),L.append(i);const n=document.createElement("button");n.className="vault-dismiss",n.type="button",n.setAttribute("aria-label","Dismiss"),n.textContent="✕",n.addEventListener("click",()=>{po("popup"),oe(),f.release("ask","vault")}),L.append(n),L.dataset.visible="true"}async function Mn(e){try{await chrome.runtime.sendMessage({type:"UPDATE_FOUNDING_STATS_SNAPSHOT",conv_count:e.conversationCount,msg_count:e.messageCount})}catch{}}async function Tn(){}async function da(){if(!O)return null;let e;try{e=await chrome.runtime.sendMessage({type:"GET_INDEX_STATS_QUICK"})}catch(n){const s=n instanceof Error?n.message:"Unknown runtime error";return O.dataset.loading="false",O.textContent=`Failed to load stats: ${s}`,null}if(!e.ok)return O.dataset.loading="false",O.textContent=`Failed to load stats: ${e.error}`,null;const{conversationCount:a,messageCount:t,lastIndexedAt:i}=e.stats;return O.dataset.loading="false",O.innerHTML=`
    <div class="stats-grid">
      <div class="stat">
        <div class="stat-label">Conversations</div>
        <div class="stat-value">${a}</div>
      </div>
      <div class="stat">
        <div class="stat-label">Messages</div>
        <div class="stat-value">${t}</div>
      </div>
    </div>
    <div class="meta-line">Last indexed: <strong>${Ye(i)}</strong></div>
  `,await Mn(e.stats),a}function J(e,a){z&&(z.textContent=e,z.dataset.state=a,z.dataset.loading="false")}async function ua(){let e;try{e=await chrome.runtime.sendMessage({type:"GET_INDICATOR_VISIBLE"})}catch(a){const t=a instanceof Error?a.message:"Unknown runtime error";J(`Search pill: error (${t})`,"error");return}if(!e.ok){J(`Search pill: error (${e.error})`,"error");return}J(`Search pill ${e.visible?"✓":"✕"}`,e.visible?"on":"off")}async function An(){const e=z?.dataset.state==="on"||z?.textContent?.toLowerCase().includes("shown")===!0;let a;try{a=await chrome.runtime.sendMessage({type:"SET_INDICATOR_VISIBLE",visible:!e})}catch(t){const i=t instanceof Error?t.message:"Unknown runtime error";J(`Search pill: error (${i})`,"error");return}if(!a.ok){J(`Search pill: error (${a.error})`,"error");return}J(`Search pill ${a.visible?"✓":"✕"}`,a.visible?"on":"off"),await ua()}async function pa(){if(!ie)return;const e=await Yt();ie.textContent=`Memory pill ${e?"✓":"✕"}`,ie.dataset.state=e?"on":"off",ie.dataset.loading="false"}async function Pn(){const e=await Yt();await io(!e),m("memory_layer_toggled",void 0,{enabled:!e}),await pa()}function ee(e,a){ne&&(ne.textContent=e,ne.dataset.state=a,ne.dataset.loading="false")}async function Rn(){let e;try{e=await chrome.runtime.sendMessage({type:"GET_INDEXING_ENABLED"})}catch(a){const t=a instanceof Error?a.message:"Unknown runtime error";ee(`Indexing: error (${t})`,"error");return}if(!e.ok){ee(`Indexing: error (${e.error})`,"error");return}ee(`Indexing ${e.enabled?"✓":"⏸"}`,e.enabled?"on":"off")}async function Bn(){let e;try{e=await chrome.runtime.sendMessage({type:"TOGGLE_INDEXING_ENABLED"})}catch(a){const t=a instanceof Error?a.message:"Unknown runtime error";ee(`Indexing: error (${t})`,"error");return}if(!e.ok){ee(`Indexing: error (${e.error})`,"error");return}ee(`Indexing ${e.enabled?"✓":"⏸"}`,e.enabled?"on":"off")}z?.addEventListener("click",()=>{An()});ne?.addEventListener("click",()=>{Bn()});ie?.addEventListener("click",()=>{Pn()});jo?.addEventListener("click",()=>{chrome.tabs.create({url:"https://llmnesia.com/changelog"})});const On=document.querySelector("#head-settings-btn");On?.addEventListener("click",()=>{chrome.runtime.openOptionsPage()});const b=document.querySelector("#cc-promo-card"),ke=document.querySelector("#cc-promo-connect"),Dn=document.querySelector("#cc-promo-dismiss"),Oe=document.querySelector("#desktop-promo-title"),De=document.querySelector("#desktop-promo-sub");function Ft(e){if(!(!b||!Oe||!De||!ke)){if(b.dataset.kind=e,e==="mcp"){Oe.textContent="Use your chats in Claude, Cursor & Codex",De.textContent="Let your desktop AI search LLMnesia—with links back to the originals.",ke.textContent="Set up →";return}Oe.textContent="🖥️ Index your Claude Code & Codex sessions",De.textContent="Search your terminal & IDE chats alongside the rest.",ke.textContent="Connect →"}}async function Un(e){if(b){if(xo(e)&&!await ko()&&!await wo()){if(!await dt("mcp")||!f.claim("ask","desktop_connection")){b.dataset.visible="false";return}Ft("mcp"),b.dataset.visible="true",ut("mcp"),m("mcp_promo_shown",void 0,{surface:"popup"});return}if(await Wa()||await ja()){b.dataset.visible="false",f.release("ask","desktop_connection");return}if(!await dt("claude_code")){b.dataset.visible="false",f.release("ask","desktop_connection");return}if(!f.claim("ask","desktop_connection")){b.dataset.visible="false";return}Ft("claude_code"),b.dataset.visible="true",ut("claude_code"),m("claude_code_promo_shown",void 0,{surface:"popup"})}}ke?.addEventListener("click",()=>{if(b?.dataset.kind==="mcp"){m("mcp_promo_clicked",void 0,{surface:"popup"}),chrome.tabs.create({url:chrome.runtime.getURL("options.html#corpus-native-card")});return}m("claude_code_promo_clicked",void 0,{surface:"popup"}),chrome.tabs.create({url:chrome.runtime.getURL(`options.html${Ya}`)})});Dn?.addEventListener("click",()=>{if(b?.dataset.kind==="mcp"){m("mcp_promo_dismissed",void 0,{surface:"popup"}),b&&(b.dataset.visible="false"),So();return}m("claude_code_promo_dismissed",void 0,{surface:"popup"}),b&&(b.dataset.visible="false"),Qa()});const Ue=document.querySelector("#quick-memory-label"),se=document.querySelector("#quick-memory-text"),Fe=document.querySelector("#quick-memory-star"),re=document.querySelector("#quick-memory-save"),zt=document.querySelector("#quick-memory-status"),Fn=document.querySelector("#quick-memory-manage");function ye(e){zt&&(zt.textContent=e)}async function zn(){const e=se?.value?.trim()??"";if(!e){ye("Type the memory first."),se?.focus();return}const a=Ue?.value?.trim()||e.slice(0,48),t=Date.now(),i={memoryId:crypto.randomUUID(),kind:"preference",label:a,text:e,source:"manual",pinned:Fe?.checked??!1,enabled:!0,createdAt:t,updatedAt:t};re&&(re.disabled=!0),ye("Saving…");try{const n=await chrome.runtime.sendMessage({type:"SAVE_MEMORY",memory:i});if(!n?.ok)throw new Error(n?.error||"Save failed");Ue&&(Ue.value=""),se&&(se.value=""),Fe&&(Fe.checked=!1),so(),m("memory_created",void 0,{source:"popup"}),ye("Saved. Offered on your next new chat."),st()}catch(n){const s=n instanceof Error?n.message:"Unknown error";ye(`Couldn't save: ${s}`)}finally{re&&(re.disabled=!1)}}re?.addEventListener("click",()=>{zn()});Fn?.addEventListener("click",()=>{chrome.tabs.create({url:chrome.runtime.getURL("options.html#memory-section")})});Xo?.addEventListener("click",()=>{chrome.tabs.create({url:"https://llmnesia.com/"})});Zo?.addEventListener("click",()=>{fa(!0)});Jo?.addEventListener("click",()=>{chrome.runtime.sendMessage({type:"OPEN_FOUNDING_FORM",markCompleted:!0}).then(e=>{e.ok&&aa()}).catch(()=>{})});en?.addEventListener("click",()=>{chrome.runtime.sendMessage({type:"DISMISS_FOUNDING_PROMPT"}).then(e=>{e.ok&&aa()}).catch(()=>{})});const Vn={ok:"Indexed OK",failed:"Indexing failed on this site",unsupported:"This page isn't an AI chat. Your saved chats are still searchable.",unknown:"Site status not checked yet"};function Gn(e){!Lt||!_e||(Lt.dataset.status=e,_e.textContent=Vn[e],Mt&&(Mt.style.display=e==="failed"?"":"none"))}async function Hn(){try{const e=await chrome.storage.local.get([pt,ft,mt]);return{indexingEnabled:e[pt]!==!1,semanticSearchEnabled:e[ft]===!0,memoryLayerEnabled:e[mt]!==!1}}catch{return{}}}async function fa(e){const a=We||"general";let t=Ze??Xa(a);const i=je||window.location.href;let n=null,s=null,r=null;if(e){r=Xe===null?{capture:null,source:"unavailable",contentScriptError:"no_active_tab"}:await wa(Xe);const c=r.capture;c?(s=c,n=c.snapshot??"(No chat container or message nodes found on the page; the conversation may not have rendered.)"):n="(Page capture failed. See the capture error codes above; check site access or reload the page.)"}const l=await Hn(),p=za({hostname:a,fullUrl:i,healthRecord:t,snapshot:n,environment:l,liveDiagnostic:s,captureResult:r});chrome.tabs.create({url:p})}async function Kn(){let e;try{e=await chrome.tabs.query({active:!0,currentWindow:!0})}catch{return}const a=e[0];if(!a?.url)return;let t;try{t=new URL(a.url)}catch{return}if(!t.hostname||t.protocol==="chrome:"||t.protocol==="chrome-extension:")return;We=t.hostname,je=a.url,Xe=a.id??null;let i;try{i=await chrome.runtime.sendMessage({type:"GET_SITE_HEALTH",hostname:We})}catch{return}if(!i.ok)return;Ze=i.record;const n=ro(t)??await Kt(a),s=Za(Ze,n?Qt(n).label:null,lo(je));Gn(s.status),_e&&(_e.textContent=s.message)}sn?.addEventListener("click",()=>{fa(rn?.checked??!0)});let we={daysSinceActivation:void 0,backfillComplete:!1};function tt(){const e={backfill_complete:we.backfillComplete};return typeof we.daysSinceActivation=="number"&&(e.days_since_activation=we.daysSinceActivation),e}const Vt=document.querySelector("#degraded-index-warning"),Y=document.querySelector("#storage-warning"),ze=document.querySelector("#storage-warning-detail"),Ve=document.querySelector("#storage-warning-meta"),ve=document.querySelector("#storage-warning-head");function Yn(e){if(!Y||!ze||!Ve)return;const a=e.storageHealth;if(a&&!a.failing&&a.recoveryCheckedAt){Y.dataset.recovered="true",Y.dataset.visible="true",ve&&(ve.textContent="Storage check passed"),ze.textContent="Storage is responding again. Earlier chat updates may not have been saved.",Ve.textContent=a.lastSuccessfulSaveAt?`Last confirmed chat save: ${Ye(a.lastSuccessfulSaveAt)}.`:"The next chat save will confirm capture has resumed.";return}if(!a?.failing||!a.userMessage){Y.dataset.visible="false";return}ze.textContent=a.userMessage,Y.dataset.recovered="false",ve&&(ve.textContent="⚠️ A chat couldn't be saved");const t=a.lastSuccessfulSaveAt;Ve.textContent=t?`Last confirmed save: ${Ye(t)}. Later chat updates may not have been saved.`:"No successful save has been recorded yet on this install.",Y.dataset.visible="true"}function Qn(e){ma(e.backfillActive===!0,e.backfillPlatform),e.backfillActive&&m("search_with_degraded_index",void 0,{extract_error_count:e.extractErrorCount,backfill_complete:e.backfillComplete,...tt()})}function ma(e,a){if(!Vt)return;const t=go(e,a),i=document.querySelector("#degraded-index-warning-text");i&&(i.textContent=t??""),Vt.dataset.visible=t?"true":"false"}const H=document.querySelector("#search-suggestions");let te=0,at=null;function Wn(e){return e.replace(/\b\w/g,a=>a.toUpperCase())}function Ie(){H&&(H.textContent="",H.dataset.visible="false")}async function ha(e){if(!H)return;at=e;const a=++te;if(Ie(),!e.activated)return;const t=e.daysSinceActivation;if(typeof t!="number"||t<1||e.justActivated)return;let i=[];try{const n=await chrome.runtime.sendMessage({type:"GET_SEARCH_SUGGESTIONS"});if(a!==te)return;if(n.ok)i=n.terms;else return}catch{return}a===te&&(i.length<2||(H.innerHTML="",i.forEach((n,s)=>{const r=document.createElement("button");r.type="button",r.className="search-suggestion-chip",r.textContent=Wn(n),r.addEventListener("click",()=>{$&&($.value=n,$.focus(),$.dispatchEvent(new Event("input",{bubbles:!0}))),m("search_suggestion_clicked",void 0,{suggestion_index:s,...tt()})}),H.appendChild(r)}),H.dataset.visible="true",m("search_suggestion_shown",void 0,{suggestion_count:i.length,...tt()})))}const ga=da();Promise.allSettled([ga,ua(),Rn(),pa(),Kn(),qe(),Io,un(),Wo()]);async function jn(){const e=await qo;return e.ok&&(we={daysSinceActivation:e.daysSinceActivation,backfillComplete:e.backfillComplete}),e.ok&&(Yn(e),Qn(e),e.justActivated&&pn(e.count),ha(e)),e}const Xn=jn();async function Zn(){await Xn;const e=await ga??await ca();return await fn(),await bn(),await Ko(e),e}const Jn=Zn();async function ei(){const e=await Jn;await Fo(e),await Nn(),await Un(e),await Tn()}const ti=ei();ti.finally(()=>{document.documentElement.dataset.secondaryReady="true"});
//# sourceMappingURL=popup.js.map
