const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/index.js","assets/packed-index.js","assets/vault_support_errors.js","assets/preload-helper.js"])))=>i.map(i=>d[i]);
import"./modulepreload-polyfill.js";import{_ as un}from"./preload-helper.js";import{c as od,v as nd,p as rd,a as ad}from"./report_capture.js";import{b as sd}from"./backfill_tab.js";import{v as id,Q as ld,b as cd,c as dd,V as pd,w as ud,r as fd,f as gd,i as md,a as yd,d as hn,s as hd,e as bd}from"./vault_status_summary.js";import{c as vd,L as ae,p as cl,l as xd,a as wd,b as kd,s as Sd,i as Cd,r as Ed,d as $d,e as Ad,f as Id,g as Ld,u as Td,h as _d,j as dl,k as pl,S as Rd,m as Pd,n as Nd,q as Md,t as _e,v as ul,w as fl,x as Dn,y as Od,z as Bd,A as gl,H as Ba,B as ml,C as qd,D as Ud,E as Vd,F as yl,G as hl,I as bl,J as zd,K as As,M as Fd,N as Dd,O as Gd,P as jd,Q as Hd,R as Kd}from"./db.js";import{u as fr,s as qa,n as Yd,v as Wd,a as Ua,b as Jd,c as K,d as po,e as vl}from"./vault_support_errors.js";import{s as Zd,M as Xd,l as Qd,a as Is,p as ep,b as tp}from"./search_invite.js";import{c as Mt,i as op}from"./analytics.js";import{c as np,G as Ls,b as rp}from"./corpus_native_failure.js";import{a as ap}from"./rolling_backup.js";import{g as xl,i as sp,r as ip,a as lp}from"./google_ai_mode_access.js";import{C as ra,i as wl,a as cp,b as kl,V as dp,c as pp,d as up,M as fp,I as Ts,S as _s,e as Rs,f as Ot,g as gp,l as mp,h as yp,j as Ps,k as Ns}from"./conversation_counter.js";import{O as hp,o as bp,c as Sl}from"./organisation_scope.js";import{V as vp}from"./vault_hook.js";import{V as mt,v as xp,a as Cl,b as wo,c as ko,d as wp}from"./continue_targets.js";import{e as kp,f as Sp}from"./chatgpt.js";import{i as Cp,T as u}from"./theme.js";import{E as Ep,f as $p}from"./error_logging.js";import{c as Ap}from"./site_health.js";import{b as Ip,a as Lp,B as Tp,c as _p}from"./backfill.js";import{g as Rp}from"./platform_styles.js";import"./google_ai_mode_page.js";import"./capture_provenance.js";function Pp(e){let t=67108864;const o=fr(e,{filter:a=>!/\.(png|jpe?g|webp|gif)$/i.test(a.name)||a.originalSize>Xd||a.originalSize<=0||a.originalSize>t||a.name.split("/").includes("..")?!1:(t-=a.originalSize,!0)}),n=new Map;for(const[a,r]of Object.entries(o)){const s=a.split(".").at(-1).toLowerCase(),i=s==="jpg"?"jpeg":s;let l="";for(let p=0;p<r.length;p+=8192)l+=String.fromCharCode(...r.subarray(p,p+8192));const f=Zd(`data:image/${i};base64,${btoa(l)}`);f&&n.set(a,f)}return n}function El(e,t){if(typeof e!="string"||!/^(?:sediment|file-service):\/\//.test(e))return;const o=e.replace(/^(?:sediment|file-service):\/\//,"").split("/").at(-1);if(!o||o==="..")return;const n=[...t].filter(([a])=>{const r=a.split("/").at(-1);return r===o||r.startsWith(`${o}-`)||r.startsWith(`${o}_`)||r.startsWith(`${o}.`)});return n.length===1?n[0][1]:void 0}function Np(e,t){if(!e||typeof e!="object"||!t.size)return!1;const o=e.mapping;return!o||typeof o!="object"?!1:Object.values(o).some(n=>Array.isArray(n?.message?.content?.parts)&&n.message.content.parts.some(a=>a?.content_type==="image_asset_pointer"&&El(a.asset_pointer,t)))}const Ms=e=>e instanceof Error?e.message:String(e),Os=64,Mp=6;function Bs(e){return e?e.reason==="restore_timeout"?"Google timed out":e.reason==="completion_unconfirmed"?"completion unconfirmed":e.reason==="unbalanced_transcript"?"reply missing":e.status==="complete"?"older messages unconfirmed":e.status:"no import record"}function Op(e){const t=e.diagnostic,o=t?t.reason==="restore_timeout"?"Google restore timed out":t.reason==="completion_unconfirmed"?"Google completion unconfirmed":t.reason==="unbalanced_transcript"?"reply missing":t.status==="complete"?"saved rendered messages; coverage unknown":`${t.status}; coverage ${t.coverage??"unknown"}`:"saved chat; no retained import diagnostic; coverage unknown",n=t?.capturedMessageCount===void 0?"capture count unavailable":`${t?.capturedMessageCount} captured messages`,a=e.storedMessageCount??t?.savedMessageCount,r=a===void 0?"stored count unavailable":`${a} stored messages`,s=t?.sourceRetrieval==="used"?"; source response used, coverage unknown":t?.sourceRetrieval==="failed"?"; source response unavailable, using rendered snapshot, coverage unknown":"";return`${e.title||"Untitled chat"} (${o}${s}, ${n}, ${r}, ID ${e.sourceId})`}function Bp(){const e=()=>document.querySelector("#google-import-retry-filter"),t=()=>document.querySelector("#google-import-retry-detail");function o(){const r=document.querySelector("#google-import-retry-chat"),s=t();if(!r||!s)return;const i=r.selectedOptions[0];s.textContent=i&&!i.hidden?i.title:""}function n(){const r=document.querySelector("#google-import-retry-chat"),s=document.querySelector("#retry-google-import-chat");if(!r||!s)return;const i=(e()?.value??"").trim().toLowerCase(),l=[...r.options].filter(c=>!c.dataset.placeholder);for(const c of l)c.hidden=i!==""&&!(c.dataset.search??"").includes(i);const f=l.filter(c=>!c.hidden);l.length>0&&!f.some(c=>c.value===r.value)&&(r.value=f[0]?.value??""),s.disabled=r.disabled||r.value==="";const p=t();i!==""&&l.length>0&&f.length===0?p&&(p.textContent="No saved Google chats match that search."):o()}async function a(){const r=document.querySelector("#google-import-retry-chat"),s=document.querySelector("#retry-google-import-chat");if(!r||!s)return;const i=r.value;try{const l=await chrome.runtime.sendMessage({type:"LIST_GOOGLE_IMPORT_RETRY_CHATS"});if(!l?.ok||!Array.isArray(l.chats))throw new Error(l?.error??"Could not read saved chats");const f=l.chats.sort((c,v)=>+(c.diagnostic?.status==="complete")-+(v.diagnostic?.status==="complete")),p=new Map;for(const c of f){const v=c.title||"Untitled chat";p.set(v,(p.get(v)??0)+1)}r.replaceChildren();for(const c of f){const v=document.createElement("option");v.value=c.sourceId;const y=c.title||"Untitled chat",b=y.length>Os?`${y.slice(0,Os-1)}…`:y,w=c.storedMessageCount??c.diagnostic?.savedMessageCount,C=[b];w!==void 0&&C.push(`${w} messages`),C.push(Bs(c.diagnostic)),(p.get(y)??0)>1&&C.push(`#${c.sourceId.slice(-Mp)}`),v.textContent=C.join(" · "),v.title=Op(c),v.dataset.search=`${y} ${c.sourceId} ${Bs(c.diagnostic)}`.toLowerCase(),r.append(v)}if(f.some(c=>c.sourceId===i)&&(r.value=i),r.disabled=s.disabled=f.length===0,!f.length){const c=document.createElement("option");c.textContent="No saved Google chats with a retryable ID or retained import diagnostics",c.dataset.placeholder="1",r.append(c)}n()}catch(l){r.disabled=s.disabled=!0;const f=document.querySelector("#google-import-retry-status");f&&(f.textContent=`Could not load Google chats: ${Ms(l)}`)}}return e()?.addEventListener("input",n),document.querySelector("#google-import-retry-chat")?.addEventListener("change",o),document.querySelector("#refresh-google-import-chats")?.addEventListener("click",()=>{a()}),document.querySelector("#retry-google-import-chat")?.addEventListener("click",async()=>{const r=document.querySelector("#google-import-retry-chat"),s=document.querySelector("#retry-google-import-chat"),i=document.querySelector("#google-import-retry-status");if(!(!r?.value||!s||!i)){s.disabled=!0;try{const l=await chrome.runtime.sendMessage({type:"RETRY_GOOGLE_IMPORT_CHAT",sourceId:r.value});i.textContent=l.ok?"Retry started for the selected chat only. Follow its progress or cancel in the popup.":l.error??"Could not start this retry."}catch(l){i.textContent=`Could not start this retry: ${Ms(l)}`}finally{await a()}}}),a}const qs=16*1024*1024,aa=128*1024*1024,$l=2e3,Us="https://aistudio.google.com/";function jt(e){return e&&typeof e=="object"&&!Array.isArray(e)?e:null}function Gn(e){return typeof e=="string"?e:""}function Vs(e){return e.isThought===!0||e.thought===!0}function bn(e){if(Vs(e))return"";const t=Array.isArray(e.parts)?e.parts.map(jt).filter(o=>!!o):[];return t.some(o=>typeof o.text=="string")?t.filter(o=>!Vs(o)).map(o=>Gn(o.text)).join("").trim():Gn(e.text).trim()}function zs(e){return e==="model"||e==="assistant"?"assistant":e==="user"||e==="system"?e:null}function Fs(e){const t=typeof e=="string"?Date.parse(e):NaN;return Number.isFinite(t)&&t>0?t:void 0}async function qp(e){const t=await crypto.subtle.digest("SHA-256",new TextEncoder().encode(e));return Array.from(new Uint8Array(t),o=>o.toString(16).padStart(2,"0")).join("")}async function Up(e,t){const o=jt(e),n=jt(o?.chunkedPrompt);if(!o||!n||!Array.isArray(n.chunks))return null;const a=n.chunks.map(jt).filter(b=>!!b),r=[],s=jt(o.systemInstruction),i=s?bn(s):"";i&&r.push({role:"system",text:i.replace(/\s+/g," "),formattedText:i,order:0});const l=[];for(const b of a){const w=zs(b.role),C=bn(b);if(!w||!C)continue;r.push({role:w,text:C.replace(/\s+/g," "),formattedText:C,order:r.length});const A=Fs(b.createTime);A!==void 0&&l.push(A)}if(!r.some(b=>b.role==="user"||b.role==="assistant"))return null;const f=a.find(b=>zs(b.role)==="user"&&bn(b)),p=f&&Fs(f.createTime)!==void 0?JSON.stringify([f.createTime,bn(f)]):JSON.stringify(r.map(b=>[b.role,b.formattedText])),c=`drive-export-${await qp(p)}`,v=Gn(jt(o.runSettings)?.model).replace(/^models\//,"").trim(),y=Gn(o.title).trim()||t.split(/[\\/]/).pop()?.replace(/\.(?:json|txt)$/i,"").trim()||"AI Studio conversation";return{platform:"ai_studio",sourceId:c,title:y,url:Us,baseUrl:Us,isDeeplinkable:!1,...l.length?{createdAt:l.reduce((b,w)=>Math.min(b,w)),updatedAt:l.reduce((b,w)=>Math.max(b,w))}:{},...v&&v.length<=160?{models:[v]}:{},messages:r.map(b=>b.role==="assistant"&&v&&v.length<=160?{...b,model:v}:b)}}function Vp(e){return!e.endsWith("/")&&!/(^|\/)(?:__MACOSX|\.DS_Store|\._[^/]*)($|\/)/.test(e)&&!/\.(?:png|jpe?g|gif|webp|avif|svg|mp[34]|wav|ogg|webm|mov|pdf|zip)$/i.test(e)}async function zp(e){if(e.size>aa)throw new Error("Choose downloads smaller than 128 MB, or split the folder into smaller batches.");const t=new Uint8Array(await e.arrayBuffer());if(t[0]===80&&t[1]===75){let o=0,n=0;const a=fr(t,{filter:r=>{if(!Vp(r.name))return!1;if(o+=r.originalSize,n+=1,r.originalSize>qs||o>aa||n>$l)throw new Error("That ZIP is too large. Import up to 2,000 files per batch, with each chat below 16 MB and total text below 128 MB.");return!0}});return Object.entries(a).sort(([r],[s])=>r.localeCompare(s)).map(([r,s])=>({name:r,bytes:s}))}if(t.length>qs)throw new Error("That chat exceeds 16 MB. Choose a smaller AI Studio download.");return[{name:e.name,bytes:t}]}async function Fp(e,t){const o={saved:0,unchanged:0,skipped:0,failed:0,processed:0,total:0,cancelled:!1};let n=0;for(const a of e){if(t.shouldCancel?.()){o.cancelled=!0;break}let r;try{r=await zp(a)}catch(s){o.failed+=1,o.error=s instanceof Error?s.message:"That download could not be opened.",t.onProgress?.({...o});continue}o.total+=r.length,r.length||(o.skipped+=1);for(const s of r){if(t.shouldCancel?.()){o.cancelled=!0;break}if(n+=s.bytes.length,n>aa||o.processed>=$l)return o.failed+=1,o.error="Batch limit reached. Import remaining chats in a smaller batch (up to 2,000 files and 128 MB of text).",o;try{const i=JSON.parse(qa(s.bytes).replace(/^\uFEFF/,"")),l=await Up(i,s.name);if(!l)o.skipped+=1;else{const f=await t.index(l);if(!f.ok)throw new Error(f.error||"A chat could not be saved. Try importing it again.");f.changed===!1?o.unchanged+=1:o.saved+=1}}catch(i){o.failed+=1,o.error=i instanceof SyntaxError?"Some files were not readable AI Studio JSON downloads.":i instanceof Error?i.message:"A chat could not be saved."}o.processed+=1,t.onProgress?.({...o})}if(o.cancelled)break}return o}const Dp=`
  <section id="import-ai-studio-section" class="settings-section" data-settings-section data-settings-group="data" data-settings-label="AI Studio history" data-settings-search="Google AI Studio Drive download JSON zip import older chats" style="margin-top:16px;border:1px solid #dbe2cf;border-left:4px solid #3d6fa8;border-radius:12px;padding:14px 16px;background:#eef4fb;">
    <h2 style="margin:0 0 10px;font-size:16px;">Import Google AI Studio chats</h2>
    <p class="settings-card-description">For direct history import, <a href="https://aistudio.google.com/library" target="_blank" rel="noreferrer">open AI Studio</a> and choose <strong>Index older chats</strong> in LLMnesia. You can also import downloaded files below.</p>
    <p class="settings-card-description">Download saved chats from the <strong>Google AI Studio</strong> folder in Google Drive, then choose the files or the folder's ZIP below. Files without an extension work too.</p>
    <p style="color:#4f6576;font-size:12.5px;line-height:1.5;">Files are read on this device. No Google Drive connection is required. Only conversation text and system instructions are imported; images, audio, videos and tool activity are excluded. If Vault is enabled, imported chats sync using your existing settings.</p>
    <div class="settings-actions" style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;">
      <button id="import-ai-studio" class="settings-primary-action" type="button">Choose AI Studio files or ZIP</button>
      <button id="import-ai-studio-cancel" type="button" style="display:none;">Stop</button>
      <input id="import-ai-studio-files" type="file" multiple style="display:none;" />
    </div>
    <progress id="ai-studio-import-progress" max="1" value="0" style="display:none;width:100%;height:10px;margin-top:10px;"></progress>
    <div id="ai-studio-import-status" class="settings-status-panel" role="status" style="margin-top:10px;color:#2f4654;overflow-wrap:anywhere;">No import yet.</div>
    <details style="margin-top:10px;"><summary>How to download your chats</summary>
      <ol style="color:#526771;font-size:12px;line-height:1.5;">
        <li>Open Google Drive using the same Google account as AI Studio.</li>
        <li>Find the Google AI Studio folder and download individual chat files, or download the folder as a ZIP.</li>
        <li>Choose the downloaded files here. Importing the same download again updates its saved copy without creating another imported copy.</li>
      </ol>
      <p style="color:#526771;font-size:12px;">Drive downloads usually omit their original chat IDs, so imported copies do not link back to AI Studio and may be separate from chats previously saved with the browser pill. Keep the original files in Drive: downloading is enough.</p>
    </details>
  </section>`;function Gp(e){const t=document.querySelector("#import-ai-studio"),o=document.querySelector("#import-ai-studio-files"),n=document.querySelector("#import-ai-studio-cancel"),a=document.querySelector("#ai-studio-import-progress"),r=document.querySelector("#ai-studio-import-status");if(!t||!o||!n||!a||!r)return;let s=!1,i=!1;t.addEventListener("click",()=>o.click()),n.addEventListener("click",()=>{i=!0,n.disabled=!0,r.textContent="Stopping after the current chat..."}),o.addEventListener("change",()=>{const l=Array.from(o.files??[]);o.value="",!(s||!l.length)&&(s=!0,i=!1,t.disabled=!0,n.disabled=!1,n.style.display="inline-block",a.style.display="block",a.removeAttribute("value"),r.textContent="Reading your AI Studio downloads...",(async()=>{let f=0,p=!1;try{await e.markStarted(),p=!0;const c=await Fp(l,{shouldCancel:()=>i,index:async y=>await chrome.runtime.sendMessage({type:"INDEX_CONVERSATION",indexingMode:"backfill",kind:"playground",conversation:y})??{ok:!1,error:"The extension did not confirm this save. Reload LLMnesia and import the file again."},onProgress:y=>{f=y.saved,a.max=Math.max(1,y.total),a.value=y.processed,i||(r.textContent=`Reading ${y.processed} of ${y.total} files: ${y.saved} ${y.saved===1?"chat":"chats"} saved.`)}});f=c.saved;const v=c.cancelled?"Import stopped.":c.failed?"Import finished with errors.":c.saved+c.unchanged===0?"No AI Studio chats found.":"Import complete.";r.textContent=`${v} ${c.saved} ${c.saved===1?"chat":"chats"} saved, ${c.unchanged} already up to date, ${c.skipped} empty or unsupported files skipped, ${c.failed} failed.${c.error?` ${c.error}`:""}${c.cancelled?" Choose the same files again to resume.":""}`}catch(c){r.textContent=`Import failed: ${c instanceof Error?c.message:"Could not read those files."}`}finally{p&&await e.finalize(f).catch(()=>{}),await e.refreshStats().catch(()=>{}),a.style.display="none",n.style.display="none",t.disabled=!1,s=!1}})())})}const Ds=32*1024*1024,Gs=128*1024*1024,sa=2e3,Va="supported transcript files",Al=`Could not read this ZIP. If it is password protected, unzip it on your device first, then choose ${Va}.`;function jp(e){const t=new DataView(e.buffer,e.byteOffset,e.byteLength),o=()=>{throw new Error(Al)};let n=e.length-22;for(;n>=Math.max(0,e.length-65557)&&t.getUint32(n,!0)!==101010256;)n--;(n<0||n<e.length-65557||n+22+t.getUint16(n+20,!0)!==e.length)&&o(),(t.getUint16(n+4,!0)||t.getUint16(n+6,!0))&&o();let a=t.getUint16(n+10,!0),r=t.getUint32(n+16,!0);if(a===65535||r===4294967295){(n<20||t.getUint32(n-20,!0)!==117853008)&&o();const s=Number(t.getBigUint64(n-12,!0));(!Number.isSafeInteger(s)||s<0||s+56>n||t.getUint32(s,!0)!==101075792)&&o(),a=Number(t.getBigUint64(s+32,!0)),r=Number(t.getBigUint64(s+48,!0))}if(a>sa)throw new Error("ZIP limit reached: choose an archive with no more than 2,000 files.");for(let s=0;s<a;s++){if((!Number.isSafeInteger(r)||r<0||r+46>n||t.getUint32(r,!0)!==33639248)&&o(),t.getUint16(r+8,!0)&65)throw new Error(`This ZIP is password protected. Unzip it on your device first, then choose ${Va}.`);r+=46+t.getUint16(r+28,!0)+t.getUint16(r+30,!0)+t.getUint16(r+32,!0),r>n&&o()}}const Ne=e=>e&&typeof e=="object"&&!Array.isArray(e)?e:{},Tr=e=>typeof e=="string"?e:"";function js(e){const t=typeof e=="number"?e<1e12?e*1e3:e:typeof e=="string"?Date.parse(e):NaN;return Number.isFinite(t)&&t>0?t:void 0}function Hs(e){const t=e.isHuman??e.is_user??e.is_human??Ne(e.author).is_human;return t===!0?"user":t===!1?"assistant":e.role==="user"||e.role==="assistant"||e.role==="system"?e.role:"unknown"}async function Hp(e){return Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256",new TextEncoder().encode(JSON.stringify(e)))),t=>t.toString(16).padStart(2,"0")).join("")}async function Kp(e,t){e=e.replace(/^\uFEFF/,"");let o;try{o=JSON.parse(e)}catch{o=e.split(/\r?\n/).filter(l=>l.trim()).map(l=>JSON.parse(l))}const n=Ne(o),a=Array.isArray(o)?o:Array.isArray(n.messages)?n.messages:[],r=[];if(a.length&&a.every(i=>typeof Ne(i).chat_id=="string"&&typeof Ne(i).raw_content=="string"))throw new Error("Official account exports are not supported in this version. Choose CAI Tools Tavern JSONL or supported transcript JSON instead.");if(Array.isArray(n.history))throw new Error("This history layout is not supported. Choose a CAI Tools Tavern chat (.jsonl) instead.");if(a.length){const i=Ne(a[0]),l=typeof i.character_name=="string"&&!("mes"in i)?a.slice(1):a;if(!(l.length&&l.every(p=>{const c=Ne(p);return typeof c.mes=="string"&&typeof c.is_user=="boolean"||typeof c.message=="string"&&typeof c.isHuman=="boolean"})))throw new Error("Unsupported transcript layout. Choose CAI Tools Tavern JSONL or supported transcript JSON. Character cards are not chat transcripts.");r.push({rows:l.map(Ne),label:Tr(i.character_name)||Tr(Ne(l.find(p=>Hs(Ne(p))==="assistant")).name)||"Character.AI imported chat",created:js(i.create_date),format:"cai_tools"})}else throw new Error("No supported chat messages found. Character cards, screenshots and HTML are not supported.");const s=[];for(const i of r){const l=[],f=[];for(const y of i.rows){const b=Tr(y.raw_content??y.mes??y.message);if(!b.trim())continue;l.push({role:Hs(y),text:b.replace(/\s+/g," ").trim(),formattedText:b,order:l.length});const w=js(y.create_time??y.send_date);w!==void 0&&f.push(w)}if(!l.length)continue;const p=`file-export-${await Hp([i.label,i.created,l])}`;let c=i.created,v=i.created;for(const y of f)c=Math.min(c??y,y),v=Math.max(v??y,y);s.push({format:i.format,unknownRoles:l.filter(y=>y.role==="unknown").length,conversation:{platform:"character_ai",sourceId:p,title:i.label,messages:l,url:"https://character.ai/",baseUrl:"https://character.ai/",isDeeplinkable:!1,...c===void 0?{}:{createdAt:c,updatedAt:v}}})}return s}async function Yp(e,t){const o={saved:0,unchanged:0,failed:0,processed:0,unknownRoles:0,accountChats:0,cancelled:!1};let n=0,a=0;for(const r of e){if(t.shouldCancel?.()){o.cancelled=!0;break}try{if(r.size>Ds)throw new Error("Choose a file below 32 MB. Unzip large exports on your device and choose smaller transcript files.");const s=new Uint8Array(await r.arrayBuffer());let i;if(s[0]===80&&s[1]===75){jp(s);try{i=fr(s,{filter:f=>{if(!/\.(json|jsonl)$/i.test(f.name)||/(^|\/)__MACOSX\//.test(f.name))return!1;if(f.originalSize>Ds||n+f.originalSize>Gs||++a>sa)throw new Error("ZIP limit reached: 32 MB per file, 128 MB of text and 2,000 files per batch.");return n+=f.originalSize,!0}})}catch(f){throw f instanceof Error&&f.message.startsWith("ZIP limit reached:")?f:new Error(Al)}}else{if(++a>sa||(n+=s.length)>Gs)throw new Error("Batch limit reached. Choose fewer files (up to 2,000 and 128 MB total).");i={[r.name]:s}}const l=Object.entries(i).filter(([f])=>!/(^|\/)(user|character)\.json$/i.test(f));if(!l.length)throw new Error(`No transcript JSON found. If the ZIP is password protected, unzip it on your device first, then choose ${Va}.`);for(const[f,p]of l)try{const c=await Kp(qa(p),f);if(!c.length)throw new Error("No non-empty chat messages found.");for(const v of c){if(t.shouldCancel?.())return o.cancelled=!0,o;const y=await t.index(v.conversation);if(!y.ok)throw new Error(y.error||"Could not save this chat. Try importing the same file again.");y.changed===!1?o.unchanged++:o.saved++,o.unknownRoles+=v.unknownRoles,v.format==="account_messages"&&o.accountChats++,o.processed++,t.onProgress?.({...o})}}catch(c){o.failed++,o.error=c instanceof SyntaxError?"Invalid JSON. Choose a transcript JSON or JSONL file, not a screenshot or HTML page.":c instanceof Error?c.message:"Could not import this file."}}catch(s){o.failed++,o.error=s instanceof Error?s.message:"Could not open this file. Unzip password-protected exports on your device first."}t.onProgress?.({...o}),await new Promise(s=>setTimeout(s,0))}return o}const Wp=`
<section id="import-character-ai-section" class="settings-section" data-settings-section data-settings-group="data" data-settings-label="Character.AI files" data-settings-search="Character AI CAI Tools Tavern JSONL export import backup stories" style="margin-top:16px;border:1px solid #dbe2cf;border-left:4px solid #3d6fa8;border-radius:12px;padding:14px 16px;background:#eef4fb;">
  <h2 style="margin:0 0 10px;">Import saved Character.AI chats</h2>
  <p class="settings-card-description">Keep your stories readable and searchable, even when the original is unavailable. Choose CAI Tools Tavern chat files (.jsonl), supported transcript JSON, or a ZIP containing them. Character cards, HTML and screenshots are not supported.</p>
  <p class="settings-card-description">Official account exports are not supported in this version. Choose one of the transcript formats above.</p>
  <p style="color:#4f6576;font-size:12.5px;line-height:1.5;">Files are read on this device. If Vault is enabled, imported chats sync using your existing settings. Keep the original files. Identical snapshots are not duplicated; changed downloads and live captures can appear as separate copies to protect your existing chats. Password-protected ZIPs must be unzipped on your device first.</p>
  <div class="settings-actions" style="display:flex;gap:8px;flex-wrap:wrap;">
    <button id="import-character-ai-files" class="settings-primary-action" type="button">Choose chat files or ZIP</button>
    <button id="import-character-ai-stop" type="button" style="display:none;">Stop</button>
    <input id="character-ai-files" type="file" multiple accept=".json,.jsonl,.zip" style="display:none;" />
  </div>
  <div id="character-ai-file-status" class="settings-status-panel" role="status" style="margin-top:10px;overflow-wrap:anywhere;">No import yet.</div>
</section>`;function Jp(e){const t=document.querySelector("#import-character-ai-files"),o=document.querySelector("#character-ai-files"),n=document.querySelector("#import-character-ai-stop"),a=document.querySelector("#character-ai-file-status");if(!t||!o||!n||!a)return;let r=!1,s=!1;t.addEventListener("click",()=>o.click()),n.addEventListener("click",()=>{s=!0,n.disabled=!0,a.textContent="Stopping after the current chat..."}),o.addEventListener("change",()=>{const i=Array.from(o.files??[]);o.value="",!(r||!i.length)&&(r=!0,s=!1,t.disabled=!0,n.disabled=!1,n.style.display="inline-block",a.textContent="Reading your saved chats...",(async()=>{let l=0,f=!1;try{await e.markStarted(),f=!0;const p=await Yp(i,{shouldCancel:()=>s,index:async c=>await chrome.runtime.sendMessage({type:"INDEX_CONVERSATION",indexingMode:"backfill",conversation:c})??{ok:!1,error:"No save confirmation. Reload LLMnesia and try again."},onProgress:c=>{l=c.saved,s||(a.textContent=`${c.saved} chats saved, ${c.unchanged} already up to date, ${c.failed} failed.`)}});l=p.saved,a.textContent=`${p.cancelled?"Import stopped.":p.failed?"Import finished with errors.":p.saved+p.unchanged?"Import complete.":"No chats imported."} ${p.saved} saved, ${p.unchanged} already up to date, ${p.failed} failed.${p.unknownRoles?` ${p.unknownRoles} messages have unknown speakers; labels were not guessed.`:""}${p.accountChats?" Account-export reading is experimental: all supplied rows are kept, including possible alternative replies. Check your saved copies.":""}${p.error?` ${p.error}`:""}${p.cancelled?" Choose the same files again to resume.":""}`,Mt("export_import_completed","character_ai",{method:"file",count:p.saved,skipped:p.unchanged,failed:p.failed,unknown_turns:p.unknownRoles,outcome:p.cancelled?"stopped":p.failed?"partial":"completed"})}catch{a.textContent="Import failed. Your existing chats are safe. Reload LLMnesia and choose the files again."}finally{f&&await e.finalize(l).catch(()=>{}),await e.refreshStats().catch(()=>{}),t.disabled=!1,n.style.display="none",r=!1}})())})}const Zp="llmnesia-fs-handles",je="handles",za={claude_code:"claude-code-projects",codex:"codex-sessions",zcode:"zcode-db"};function gr(e){if(ae[e].nativeHostOnly)throw new Error(`${ae[e].label} sessions sync through the LLMnesia helper only.`)}const Xp=3,Ks=32;function Qp(){return typeof globalThis.showDirectoryPicker=="function"}function Fa(){return new Promise((e,t)=>{const o=indexedDB.open(Zp,1);o.onupgradeneeded=()=>{const n=o.result;n.objectStoreNames.contains(je)||n.createObjectStore(je)},o.onsuccess=()=>e(o.result),o.onerror=()=>t(o.error)})}function eu(e,t){return new Promise((o,n)=>{t.onsuccess=()=>o(t.result),t.onerror=()=>n(t.error)})}async function tu(e,t){const o=await Fa();try{const n=o.transaction(je,"readwrite");n.objectStore(je).put(t,za[e]),await new Promise((a,r)=>{n.oncomplete=()=>a(),n.onerror=()=>r(n.error),n.onabort=()=>r(n.error)})}finally{o.close()}}async function Il(e){const t=await Fa();try{const o=t.transaction(je,"readonly");return await eu(o.objectStore(je),o.objectStore(je).get(za[e]))??null}finally{t.close()}}async function ou(e){const t=await Fa();try{const o=t.transaction(je,"readwrite");o.objectStore(je).delete(za[e]),await new Promise((n,a)=>{o.oncomplete=()=>n(),o.onerror=()=>a(o.error)})}finally{t.close()}await vd(e)}let Ll=class extends Error{};async function nu(e){gr(e);const t=globalThis.showDirectoryPicker;if(!t)throw new Error("showDirectoryPicker is unavailable in this page.");let o;try{o=await t({id:`llmnesia-${e}`,mode:"read"})}catch(n){throw n instanceof Error&&n.name==="AbortError"?new Ll("Folder selection cancelled."):n}return await tu(e,o),o}async function _n(e,t){try{return await e.getDirectoryHandle(t)}catch{return null}}async function ru(e){for await(const t of e.values())if(t.kind==="directory"){for await(const o of t.values())if(o.kind==="file"&&o.name.endsWith(".jsonl"))return!0}return!1}const au=/^\d{4}$/,Ys=/^\d{1,2}$/;async function su(e){const t=[];for await(const o of e.values())if(o.kind==="file"){if(o.name.endsWith(".jsonl")&&o.name!=="session_index.jsonl")return!0}else au.test(o.name)&&t.push(o);for(const o of t)for await(const n of o.values())if(!(n.kind!=="directory"||!Ys.test(n.name))){for await(const a of n.values())if(!(a.kind!=="directory"||!Ys.test(a.name))){for await(const r of a.values())if(r.kind==="file"&&r.name.endsWith(".jsonl"))return!0}}return!1}async function iu(e,t){gr(e);const[o,n]=e==="claude_code"?[".claude","projects"]:[".codex","sessions"],a=e==="claude_code"?ru:su,r=await _n(t,o),s=[r?await _n(r,n):null,await _n(t,n),r,t];for(const i of s)if(i&&await a(i))return i;return null}async function Da(e,{prompt:t}){const o={mode:"read"};return!!(await e.queryPermission(o)==="granted"||t&&await e.requestPermission(o)==="granted")}async function Tl(e,t,o=Xp,n=[]){const{sessionIdFromFilename:a}=ae[e],r=[];for await(const s of t.values())if(s.kind==="file"){if(s.name.endsWith(".jsonl")&&s.name!=="session_index.jsonl"){const i=s;n.push({sessionId:a(s.name),getFile:()=>i.getFile()})}}else o>0&&r.push(s);for(const s of r)await Tl(e,s,o-1,n);return n}async function lu(e){for(const t of[await _n(e,".codex"),e])if(t)try{const o=await(await t.getFileHandle("session_index.jsonl")).getFile();return cl(await o.text())}catch{}return new Map}async function _l(e,t,o,n,a={}){const r=await xd(),s=await wd(),{parse:i}=ae[e],l={processed:0,total:t.length,indexed:0,skipped:0,empty:0};let f=0,p=0,c=0,v=!1;const y=async(b=!1)=>{if(!(p===0||c===0||!b&&c<Ks)){if(c=0,v)try{await Ed()}catch{return}await $d(r,s),p=0,v=!1}};for(const{sessionId:b,getFile:w}of t){l.processed+=1;try{const C=await w(),A=kd(e,b),L=r[A],S=o.get(b);if(!a.force&&L!==void 0&&C.lastModified<=L&&!await Sd(e,b,S,s))l.skipped+=1;else{const W=i(await C.text(),b,{title:S??s[A]??null});W?(await Cd(W,{origin:"import",kind:"archived"}),v=!0,l.indexed+=1):l.empty+=1,r[A]=C.lastModified,p+=1,c+=1}S&&s[A]!==S&&(s[A]=S,p+=1,c+=1),c>=Ks&&await y()}catch{f+=1}n?.(l)}return await y(!0),{...l,failed:f}}function Rl(e){const{label:t,pickerHintPath:o,posixPath:n}=ae[e];return new Error(`Couldn't find any ${t} sessions there — select your ${o} folder (or ${n}), not a parent folder.`)}async function Ga(e,t,o,n={}){gr(e);const a=await iu(e,t);if(!a)throw Rl(e);const r=e==="codex"?await lu(t):new Map;return _l(e,await Tl(e,a),r,o,n)}async function cu(e,t,o,n={}){gr(e);const{sessionIdFromFilename:a}=ae[e],r=Array.from(t),s=e==="codex"?await(async()=>{const l=r.find(f=>f.name==="session_index.jsonl");return l?cl(await l.text()):new Map})():new Map,i=r.filter(l=>l.name.endsWith(".jsonl")&&l.name!=="session_index.jsonl").map(l=>({sessionId:a(l.name),getFile:async()=>l}));if(i.length===0)throw Rl(e);return _l(e,i,s,o,n)}const du="Reload the extension to finish connecting.",pu="Enable automatic sync above to reconnect.",uu="Setup isn't finished. Run the install command below to connect your desktop AI app.",fu="The desktop connector was set up for a different copy of the extension. Run the install command below to repair it.",gu="The desktop connector couldn't start. Check Node.js is installed, then run the install command below.",mu="The desktop connector didn't answer. This retries on its own, so no action is needed unless it keeps happening.";function ja(e){switch(np(e)){case"permission_missing":return pu;case"worker_pre_grant":return du;case"host_not_installed":return uu;case"host_forbidden":return fu;case"host_start_failed":return gu;case"host_unreachable":return mu;default:return e}}const yu={applied:"Filed","already-applied":"Already filed",missing:"No longer in your library",stale:"Needs refresh",refused:"Refused"},hu={"unknown-source":"Reopen a Claude chat to detect this source again.","source-limit":"The local source limit was reached. Existing chats are unchanged.","untrusted-sender":"Only LLMnesia's own pages can do this.","invalid-input":"The request was not valid.","invalid-selection":"The selection was not valid.","invalid-scope":"That scope was not valid.","unknown-space":"That space no longer exists. Pick a space that does.","not-found":"That space no longer exists.","unknown-handoff":"That handoff already expired. Start again from search.","expired-handoff":"That handoff already expired. Start again from search.",duplicate:"A space with that identity already exists.","stale-revision":"This changed in another view. The list has been refreshed; try again.",protected:"Personal cannot be removed.",referenced:"This space still has chats placed in it (or rules pointing at it). Move those chats first, or keep the space.","missing-destination":"That space no longer exists. Pick a space that does.","unknown-preview":"This preview expired. Prepare it again to continue.","expired-preview":"This preview expired. Prepare it again to continue.","stale-placement":"This chat changed since the preview. Refresh the preview to review it again.","stale-destination":"The destination changed since the preview. Refresh the preview to review it again.","stale-lifetime":"A chat or space was removed and recreated since the preview. Refresh the preview to review it again.","identity-mismatch":"This chat changed since the preview. Refresh the preview to review it again.","missing-space":"The destination space was removed. Refresh the preview and pick another space.","rule-changed":"The rule behind this chat changed. Refresh the preview to review it again.","review-not-cleared":"This chat is under review; resolving it needs an explicit correction.","unresolved-decision":"This chat could not be filed from the current preview.","missing-conversation":"No longer in your library.","transaction-aborted":"The change did not complete. Nothing was half-applied; try again."};function ie(e){return e?hu[e]??e:""}function h(e,t,o){const n=document.createElement(e);return t&&(n.className=t),o!==void 0&&(n.textContent=o),n}function Ie(e,t){const o=e.find(a=>a.id===t);return o?e.filter(a=>a.name===o.name).length>1?`${o.name} (${o.id.slice(-4)})`:o.name:"Removed space"}function fe(e){return chrome.runtime.sendMessage(e)}const Ws="llmnesia-organisation-section-style";function bu(){if(document.getElementById(Ws))return;const e=document.createElement("style");e.id=Ws,e.textContent=`
    .llmorg-row { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; }
    .llmorg-list { margin: 8px 0 0; padding: 0; list-style: none; }
    .llmorg-list li { display: flex; align-items: center; gap: 8px; padding: 5px 0; flex-wrap: wrap; }
    .llmorg-space-name { font-weight: 600; color: #385066; }
    .llmorg-space-personal { font-size: 11px; color: #637785; }
    .llmorg-input { padding: 5px 8px; border-radius: 7px; border: 1px solid #c6d0b0; background: #fff; font-size: 12.5px; }
    .llmorg-button { padding: 6px 12px; border-radius: 8px; border: 1px solid #9fb08a; background: #fff; color: #385066; cursor: pointer; font-size: 12.5px; }
    .llmorg-button:hover:not(:disabled) { background: #f0f4ea; }
    .llmorg-button:disabled { opacity: 0.55; cursor: default; }
    .llmorg-button-primary { border-color: #2f7f99; background: #2f7f99; color: #fff; font-weight: 600; }
    .llmorg-button-primary:hover:not(:disabled) { background: #286d85; }
    .llmorg-button-danger { border-color: #b3563a; color: #8f3f27; }
    .llmorg-status { margin-top: 6px; font-size: 11.5px; color: #637785; }
    .llmorg-status[data-error="true"] { color: #8f3f27; }
    .llmorg-table { margin-top: 8px; border: 1px solid #dbe2cf; border-radius: 8px; overflow: hidden; }
    .llmorg-table table { border-collapse: collapse; width: 100%; font-size: 12.5px; }
    .llmorg-table th { text-align: left; background: #eef2e6; color: #526771; font-weight: 600; padding: 6px 10px; }
    .llmorg-table td { padding: 6px 10px; border-top: 1px solid #e6ebdc; color: #385066; word-break: break-word; }
    .llmorg-outcome { font-size: 11.5px; color: #526771; }
    .llmorg-block { margin-top: 12px; padding-top: 12px; border-top: 1px solid #e6ebdc; }
    .llmorg-heading { margin: 0 0 4px; font-size: 13px; color: #385066; }
    .llmorg-scope-option { display: inline-flex; align-items: center; gap: 6px; font-size: 12.5px; color: #385066; cursor: pointer; }
    .llmorg-note { margin: 6px 0 0; font-size: 11.5px; color: #65766a; line-height: 1.5; }
  `,document.head.appendChild(e)}function vu(e,t,o){bu();let n=null,a=null,r=null,s=null,i=!1,l=null,f=null,p=!1,c=[];const v=h("div","llmorg-root"),y=h("div"),b=document.createElement("input");b.type="checkbox",b.id="organisation-preview-toggle";const w=h("label","llmorg-scope-option");w.htmlFor="organisation-preview-toggle",w.append(b,document.createTextNode("Organise chats into Personal and work spaces"));const C=h("div","llmorg-block"),A=h("h3","llmorg-heading","Search scope"),L=h("div","llmorg-row"),S=h("p","llmorg-status");C.append(A,L,S);const W=h("div","llmorg-block"),Ce=h("h3","llmorg-heading","Spaces"),Ee=h("ul","llmorg-list"),oe=h("input","llmorg-input");oe.type="text",oe.placeholder="New space name, for example Acme",oe.setAttribute("aria-label","New space name");const gt=h("button","llmorg-button","Create space");gt.type="button";const z=h("p","llmorg-status"),bo=h("div","llmorg-row");bo.append(oe,gt),W.append(Ce,Ee,bo,z);const qt=h("div","llmorg-block"),Kc=h("h3","llmorg-heading","Organise existing chats"),We=h("div"),yn=h("p","llmorg-status");qt.append(Kc,We,yn);const ws=h("p","llmorg-note");ws.textContent="Organisation stays on this browser until you connect private filing to Vault below. Your existing chat sync and assistant access are unchanged. A named work space is private: it does not create an employer account, a paid plan or a team.";const q=h("p","llmorg-status"),Ir=h("div","llmorg-block"),Yc=h("h3","llmorg-heading","File new chats automatically"),Ut=h("div"),Vt=h("p","llmorg-status");Ir.append(Yc,Ut,Vt),v.append(y,ws,C,W,Ir,qt,q),h("div"),e.append(v);function Wc(){if(Ir.hidden=n?.enabled!==!0,Ut.textContent="",!n?.enabled)return;Ut.append(h("p","llmorg-note","Connect a detected Claude source once. Only chats created after connecting are filed automatically. Older chats keep their current placement. One source can be active in this preview; connecting another pauses the previous one. Account switching and paid workspaces are still being verified. ChatGPT automatic filing is unavailable until account identity is verified.")),n.sources?.length||Ut.append(h("p","llmorg-note","Open or continue a Claude chat to detect its source. There are no IDs or chat labels to enter."));for(const g of n.sources??[]){const R=h("div","llmorg-row"),x=`Claude source (${g.workspaceId.slice(-8)})`;R.append(h("span",void 0,x));const N=h("select","llmorg-input");N.setAttribute("aria-label",`Destination for ${x}`);for(const $ of n.spaces){const E=h("option",void 0,Ie(n.spaces,$.id));E.value=$.id,E.selected=$.id===g.destinationSpaceId,N.append(E)}const I=h("button","llmorg-button",g.paused?"Connect source":"Save destination");I.type="button",I.disabled=n.spaces.length===0;const B=async $=>{I.disabled=!0;try{const E=await fe({type:"ORGANISATION_CONNECT_SOURCE",sourceKey:g.sourceKey,destinationSpaceId:$,expectedRevision:g.revision});Vt.textContent=E.ok?$===null?"Source paused. Previously filed chats stay where they are.":"Connected. New chats created from now on will file here. Existing chats are unchanged.":ie(E.error),Vt.dataset.error=String(!E.ok)}catch{Vt.textContent="Could not save the source connection. Try again."}await $e()};if(I.addEventListener("click",()=>{B(N.value)}),R.append(N,I,h("span",void 0,g.paused?"Not active":"Connected")),!g.paused){const $=h("button","llmorg-button","Pause source");$.type="button",$.addEventListener("click",()=>{$.disabled=!0,B(null)}),R.append($)}Ut.append(R)}const m=h("button","llmorg-button","Retry unfinished filing");m.type="button",m.addEventListener("click",async()=>{m.disabled=!0;try{const g=await fe({type:"ORGANISATION_RETRY_CAPTURES"});Vt.textContent=g.ok?`${g.completed??0} saved filing operations completed. Chats whose source is still unknown are checked again when you reopen or continue them.`:ie(g.error)}catch{Vt.textContent="Could not retry filing. Saved chats are unchanged."}await $e()}),Ut.append(m)}b.addEventListener("change",async()=>{b.disabled=!0,q.removeAttribute("data-error"),q.textContent="";try{const m=await fe({type:"ORGANISATION_SET_PREVIEW_ENABLED",enabled:b.checked});m?.ok||(b.checked=n?.enabled===!0,q.dataset.error="true",q.textContent=ie(m?.error))}catch(m){b.checked=n?.enabled===!0,q.dataset.error="true",q.textContent=m instanceof Error?m.message:"Could not save the setting."}finally{b.disabled=!1,await $e()}}),gt.addEventListener("click",async()=>{const m=oe.value.trim();if(!m){z.dataset.error="true",z.textContent="Give the space a name first.";return}gt.disabled=!0,z.removeAttribute("data-error"),z.textContent="";try{const g=await fe({type:"ORGANISATION_CREATE_SPACE",name:m});g?.ok?oe.value="":(z.dataset.error="true",z.textContent=ie(g?.error))}catch(g){z.dataset.error="true",z.textContent=g instanceof Error?g.message:"Could not create the space."}finally{gt.disabled=!1,await $e()}});async function vo(m){S.removeAttribute("data-error"),S.textContent="";try{const g=await fe({type:"ORGANISATION_SET_SCOPE",scope:m});g?.ok||(S.dataset.error="true",S.textContent=ie(g?.error))}catch(g){S.dataset.error="true",S.textContent=g instanceof Error?g.message:"Could not save the scope."}await $e()}function Lr(m,g,R){const x=document.createElement("input");return x.type="radio",x.name=R,x.value=m,x.checked=g,x.addEventListener("change",()=>{x.checked&&(m==="unclassified"?(p=!1,vo({kind:"unclassified"})):m==="selected"?(p=!0,ks()):n&&(p=!1,vo({kind:"space",spaceId:m})))}),x}function ks(){if(L.textContent="",!n)return;if(!n.enabled){C.hidden=!0;return}C.hidden=!1;const m=n.scope,g="llmorg-scope",R=m.kind==="space"?m.spaceId:null,x=m.kind==="spaces"||p,N=h("label","llmorg-scope-option"),I=Lr("unclassified",!x&&m.kind==="unclassified",g);I.id="llmorg-scope-unclassified",N.htmlFor="llmorg-scope-unclassified",N.append(I,document.createTextNode("Unclassified")),L.append(N);for(const E of n.spaces){const O=h("label","llmorg-scope-option"),F=Lr(E.id,!x&&R===E.id,g);F.id=`llmorg-scope-${E.id}`,O.htmlFor=F.id,O.append(F,document.createTextNode(Ie(n.spaces,E.id))),L.append(O)}const B=h("label","llmorg-scope-option"),$=Lr("selected",x,g);if($.id="llmorg-scope-selected",B.htmlFor="llmorg-scope-selected",B.append($,document.createTextNode("Search selected spaces")),L.append(B),x){const E=m.kind==="spaces"?m:{spaceIds:m.kind==="space"?[m.spaceId]:[],includeUnclassified:m.kind==="unclassified"},O=h("div","llmorg-row");O.style.marginTop="6px";const F=E.includeUnclassified,pe=document.createElement("input");pe.type="checkbox",pe.id="llmorg-combo-unclassified",pe.checked=F,pe.addEventListener("change",()=>{vo({kind:"spaces",spaceIds:E.spaceIds,includeUnclassified:pe.checked})});const Y=h("label","llmorg-scope-option","Unclassified");Y.htmlFor="llmorg-combo-unclassified",O.append(pe,Y);for(const ue of n.spaces){const se=document.createElement("input");se.type="checkbox",se.id=`llmorg-combo-${ue.id}`,se.checked=E.spaceIds.includes(ue.id),se.addEventListener("change",()=>{const Ae=new Set(E.spaceIds);se.checked?Ae.add(ue.id):Ae.delete(ue.id),vo({kind:"spaces",spaceIds:Array.from(Ae),includeUnclassified:E.includeUnclassified})});const j=h("label","llmorg-scope-option");j.htmlFor=se.id,j.append(se,document.createTextNode(Ie(n.spaces,ue.id))),O.append(j)}L.append(O),E.spaceIds.length===0&&!F&&(S.dataset.error="true",S.textContent="No spaces selected: scoped search shows nothing until you pick at least one.")}n.missingSpaceIds.length>0&&(S.dataset.error="true",S.textContent="A selected space was removed. Choose a replacement scope; search stays narrowed until you do."),S.textContent===""&&(S.textContent=`Current scope: ${bp(m,E=>Ie(n.spaces,E))}. Changing the scope never changes where new chats are saved.`)}function xo(){if(Ee.textContent="",!n||!n.enabled){W.hidden=!0;return}W.hidden=!1;for(const m of n.spaces){const g=h("li"),R=h("span","llmorg-space-name",Ie(n.spaces,m.id));if(g.append(R),m.personal&&g.append(h("span","llmorg-space-personal","Personal is always available and cannot be removed")),f===m.id){const x=h("input","llmorg-input");x.type="text",x.value=m.name,x.setAttribute("aria-label",`New name for ${m.name}`);const N=h("button","llmorg-button llmorg-button-primary","Save name");N.type="button";const I=h("button","llmorg-button","Cancel");I.type="button",N.addEventListener("click",async()=>{const B=x.value.trim();if(!B)return;const $=await fe({type:"ORGANISATION_RENAME_SPACE",id:m.id,name:B,expectedRevision:m.revision});$?.ok?(f=null,z.removeAttribute("data-error"),z.textContent=""):(z.dataset.error="true",z.textContent=ie($?.error)),await $e()}),I.addEventListener("click",()=>{f=null,xo()}),g.append(x,N,I),window.setTimeout(()=>x.focus(),0)}else{const x=h("button","llmorg-button","Rename");x.type="button",x.addEventListener("click",()=>{f=m.id,l=null,xo()}),m.personal||g.append(x)}if(m.personal){Ee.append(g);continue}if(l===m.id){const x=h("span","llmorg-outcome","Remove this space? Chats stay in your library."),N=h("button","llmorg-button llmorg-button-danger","Confirm remove");N.type="button";const I=h("button","llmorg-button","Cancel");I.type="button",N.addEventListener("click",async()=>{const B=await fe({type:"ORGANISATION_REMOVE_SPACE",id:m.id});B?.ok?(l=null,z.removeAttribute("data-error"),z.textContent="",a===m.id&&(a=null)):(l=null,z.dataset.error="true",z.textContent=ie(B?.error)),await $e()}),I.addEventListener("click",()=>{l=null,xo()}),g.append(x,N,I)}else{const x=h("button","llmorg-button llmorg-button-danger","Remove");x.type="button",x.addEventListener("click",()=>{l=m.id,f=null,xo()}),g.append(x)}Ee.append(g)}}function ne(m,g=!1){g?yn.dataset.error="true":yn.removeAttribute("data-error"),yn.textContent=m}async function Jc(m){try{const g=await fe({type:"ORGANISATION_CLAIM_ORGANISER_HANDOFF",token:m});g?.ok&&g.documentIds?(r=null,s=null,c=Array.from(new Set(g.documentIds)),ne(`${c.length} ${c.length===1?"chat":"chats"} selected from search. Pick a destination, then preview.`)):ne(ie(g?.error??"unknown-handoff"),!0)}catch(g){ne(g instanceof Error?g.message:"Could not load the selection.",!0)}Je()}async function Zc(m){try{const g=await fe({type:"ORGANISATION_CLAIM_SCOPE_HANDOFF",token:m});g?.ok&&g.scope?(p=g.scope.kind==="spaces",q.removeAttribute("data-error"),q.textContent="Applying the scope chosen in your search bar...",await vo(g.scope),S.dataset.error||(q.textContent="Search scope updated from your search bar.")):(q.dataset.error="true",q.textContent=ie(g?.error??"unknown-handoff"))}catch(g){q.dataset.error="true",q.textContent=g instanceof Error?g.message:"Could not apply the requested scope."}}async function Xc(){if(!n||i||c.length===0)return;const m=a??n.spaces[0]?.id??null;if(!m){ne("Create a space first, or use Personal.",!0);return}a=m,i=!0,s=null,ne("Preparing preview..."),Je();try{const g=await fe({type:"ORGANISATION_PREPARE_PREVIEW",documentIds:c,destinationSpaceId:m});if(!g?.ok||!g.preview||!g.previewId)ne(ie(g?.error)||"Could not prepare the preview.",!0);else{const R=g.titles??{},x=g.preview.documents.map(I=>{const B=I.placement;let $;if(B.state==="placed"){const E=B.placement?.spaceId;$=E?Ie(n.spaces,E):"Placed"}else B.state==="needs-review"?$="Needs review":$="Unclassified";return{documentId:I.documentId,title:R[I.documentId]??I.documentId,current:$}});r={previewId:g.previewId,destinationSpaceId:g.preview.destinationSpaceId,documents:x,missingDocumentIds:g.preview.missingDocumentIds,confirmed:new Set(x.map(I=>I.documentId)),requestedCount:g.preview.requestedCount};const N=r.missingDocumentIds.length;ne(`Preview ready: ${x.length} ${x.length===1?"chat":"chats"} would move to ${Ie(n.spaces,r.destinationSpaceId)}.`+(N>0?` ${N} ${N===1?"chat is":"chats are"} no longer in your library.`:""))}}catch(g){ne(g instanceof Error?g.message:"Could not prepare the preview.",!0)}finally{i=!1,Je()}}async function Qc(){if(!(!n||!r||i||r.confirmed.size===0)){i=!0,ne("Filing selected chats..."),Je();try{const m=await fe({type:"ORGANISATION_APPLY_PREVIEW",previewId:r.previewId,confirmedDocumentIds:Array.from(r.confirmed)});if(!m?.ok||!m.report)ne(ie(m?.error)||"Could not apply the preview.",!0);else{s={...m.report,titles:{...ed()}};const g=s.counts,R=[];g.applied&&R.push(`${g.applied} filed`),g.alreadyApplied&&R.push(`${g.alreadyApplied} already filed`),g.missing&&R.push(`${g.missing} missing`),g.stale&&R.push(`${g.stale} need a refreshed preview`),g.refused&&R.push(`${g.refused} refused`),ne(R.length>0?`Done: ${R.join(", ")}.`:"Nothing was applied.")}}catch(m){ne(m instanceof Error?m.message:"Could not apply the preview.",!0)}finally{i=!1,Je()}}}function ed(){const m={};if(r)for(const g of r.documents)m[g.documentId]=g.title;return m}function Je(){if(We.textContent="",!n||!n.enabled){qt.hidden=!0;return}if(qt.hidden=!1,c.length===0){const O=h("p","llmorg-note");O.textContent="No chats selected yet. In search, tick the chats to organise, then choose Organise selected chats.";const F=h("button","llmorg-button","Open search");F.type="button",F.addEventListener("click",()=>{chrome.tabs.create({url:chrome.runtime.getURL("search.html")})}),We.append(O,F);return}const m=h("p","llmorg-note");m.textContent=`${c.length} ${c.length===1?"chat":"chats"} selected.`;const g=h("div","llmorg-row"),R=h("label","llmorg-scope-option");R.htmlFor="llmorg-organiser-destination",R.append(document.createTextNode("Destination"));const x=h("select","llmorg-input");x.id="llmorg-organiser-destination";for(const O of n.spaces){const F=document.createElement("option");F.value=O.id,F.textContent=Ie(n.spaces,O.id),x.append(F)}const N=a??n.spaces[0]?.id??"";x.value=N,a=N||null,x.addEventListener("change",()=>{a=x.value,r=null,s=null,ne("Destination changed. Prepare a new preview to continue."),Je()}),g.append(R,x);const I=h("div","llmorg-row");I.style.marginTop="8px";const B=h("button","llmorg-button llmorg-button-primary",r?"Refresh preview":"Preview");B.type="button",B.disabled=i,B.addEventListener("click",()=>{Xc()});const $=h("button","llmorg-button llmorg-button-primary","Apply to selected chats");$.type="button",$.disabled=i||!r||r.confirmed.size===0,$.addEventListener("click",()=>{Qc()});const E=h("button","llmorg-button","Clear selection");if(E.type="button",E.disabled=i,E.addEventListener("click",()=>{c=[],r=null,s=null,ne(""),Je()}),I.append(B,$,E),We.append(m,g,I),r){const O=h("div","llmorg-table"),F=document.createElement("table"),pe=document.createElement("thead"),Y=document.createElement("tr");for(const j of["Include","Chat","Current","After"]){const Ae=document.createElement("th");Ae.scope="col",Ae.textContent=j,Y.append(Ae)}pe.append(Y);const ue=document.createElement("tbody");for(const j of r.documents){const Ae=document.createElement("tr"),Ss=document.createElement("td"),zt=document.createElement("input");zt.type="checkbox",zt.checked=r.confirmed.has(j.documentId),zt.setAttribute("aria-label",`Include ${j.title}`),zt.addEventListener("change",()=>{zt.checked?r.confirmed.add(j.documentId):r.confirmed.delete(j.documentId),$.disabled=i||r.confirmed.size===0,se.textContent=`${r.confirmed.size} of ${r.documents.length} selected chats will be filed.`}),Ss.append(zt);const Cs=document.createElement("td");Cs.textContent=j.title;const Es=document.createElement("td");Es.textContent=j.current;const $s=document.createElement("td");$s.textContent=Ie(n.spaces,r.destinationSpaceId),Ae.append(Ss,Cs,Es,$s),ue.append(Ae)}F.append(pe,ue),O.append(F),We.append(O);const se=h("p","llmorg-status");if(se.textContent=`${r.confirmed.size} of ${r.documents.length} selected chats will be filed to ${Ie(n.spaces,r.destinationSpaceId)}. Preparing a preview changes nothing until you apply it.`,We.append(se),r.missingDocumentIds.length>0){const j=h("p","llmorg-status");j.dataset.error="true",j.textContent=`${r.missingDocumentIds.length} selected ${r.missingDocumentIds.length===1?"chat is":"chats are"} no longer in your library and will stay unchanged.`,We.append(j)}}if(s){const O=h("div","llmorg-block"),F=h("h3","llmorg-heading","Last result");O.append(F);const pe=h("ul","llmorg-list");for(const Y of s.items){const ue=h("li"),se=s.titles[Y.documentId]??Y.documentId,j=yu[Y.outcome];ue.append(h("span","llmorg-space-name",se)),ue.append(h("span","llmorg-outcome",j+(Y.reason&&(Y.outcome==="stale"||Y.outcome==="refused")?`: ${ie(Y.reason)}`:""))),pe.append(ue)}if(O.append(pe),s.counts.stale>0){const Y=h("p","llmorg-note");Y.textContent="Some chats changed after the preview. That needs an explicit refresh: use Refresh preview, review the new preview, then apply again. Nothing was filed twice.",O.append(Y)}We.append(O)}}function td(){y.textContent="",y.append(w),b.checked=n?.enabled===!0,ks(),xo(),Wc(),Je()}async function $e(){try{const m=await fe({type:"ORGANISATION_GET_STATE"});m?.ok?(n={ok:!0,enabled:m.enabled,scope:m.scope??hp,missingSpaceIds:m.missingSpaceIds??[],spaces:m.spaces??[],sources:m.sources??[],revisionToken:m.revisionToken??""},q.removeAttribute("data-error"),q.textContent=""):(q.dataset.error="true",q.textContent=ie(m?.error)||"Could not load organisation state.")}catch(m){q.dataset.error="true",q.textContent=m instanceof Error?m.message:"Could not load organisation state."}td()}return chrome.runtime.onMessage.addListener(m=>{m?.type==="ORGANISATION_CHANGED"&&$e()}),t&&Jc(t),(async()=>(await $e(),o&&await Zc(o)))(),{refresh:$e}}const xu=5e3;function wu(e,t={}){const o=t.now??Date.now,n=t.cooldownMs??xu;let a=0,r=null;return async()=>{if(r)return r;const s=o();if(s<a)return{kind:"cooldown",retryAt:a};a=s+n,r=e().then(i=>({kind:"response",response:i}));try{return await r}finally{r=null}}}function Js(e,t){return e?t===null?"unknown":t?"present":"absent":"absent"}function ku(e){const t=[],o=Js(e.vaultAvailable,e.vaultBackupExists);o==="present"?t.push("Your encrypted Vault backup is not deleted, and you can restore it to this browser or another one later."):o==="unknown"&&t.push("If you have set up Vault, its encrypted backup is not deleted and you can restore it later.");const n=Js(e.companionAvailable,e.companionCorpusExists);return n==="present"?t.push("The copy the desktop companion keeps on this computer is not deleted either; remove that folder yourself if you want it gone."):n==="unknown"&&t.push("If you set up the desktop companion, the copy it keeps on this computer is not deleted either."),t}function Ha(e){const t=ku(e),o=t.length>0?` ${t.join(" ")}`:"";return{description:`Permanently remove every indexed chat and saved memory from this browser.${o}`,confirm:`Delete all indexed conversations, messages, and token data from this browser profile?${o}`,done:t.length>0?`This browser's data is deleted.${o}`:"This browser's data is deleted."}}const Ka="Delete all cancelled. Nothing was deleted.",Su="Deleting this browser's data...",Cu="No destructive actions run.",Ya="DELETE",Eu=`Type ${Ya} to enable the delete button.`;function $u(e){return e.trim().toUpperCase()===Ya}function Wa(e){return e.filter(t=>t.source==="agent"&&!t.enabled&&t.agentReview!=="accepted"&&t.agentReview!=="rejected")}function Pl(e){return e.filter(t=>t.source!=="agent"||t.enabled||t.agentReview==="accepted")}async function Au(e,t){for(const o of Wa(e))await t(o.memoryId,!0)}const Iu="llmnesia-extension-biometric-unlock",Lu=1,kt="enrolments",Ja=1,ia=32,Nl=12,Zs=6e4;class Tu{store;credentials;randomBytes;constructor(t={}){this.store=t.store??new _u,this.credentials=t.credentials??Ru(),this.randomBytes=t.randomBytes??Pu}async hasEnrollment(t){try{const o=await this.store.read(t);return!o||!ei(o)||o.accountId!==t?(o&&await this.store.remove(t,o.enrolmentId),!1):!0}catch{return!1}}async prepareEnrollment(t,o){if(!t||!this.credentials||o.length===0)return null;const n=this.randomBytes(ia);let a=null;try{const r=await this.credentials.create({publicKey:{challenge:le(this.randomBytes(32)),rp:{name:"LLMnesia"},user:{id:le(this.randomBytes(32)),name:"LLMnesia",displayName:"LLMnesia"},pubKeyCredParams:[{type:"public-key",alg:-7},{type:"public-key",alg:-257}],authenticatorSelection:{authenticatorAttachment:"platform",residentKey:"required",userVerification:"required"},timeout:Zs,extensions:{prf:{}}}});if(!Xs(r)||r.getClientExtensionResults().prf?.enabled!==!0||(a=await this.assertPrf(r.rawId,le(n)),!a))return null;const{nonce:s,ciphertext:i}=await Mu(t,o,a,this.randomBytes);return{record:{version:Ja,accountId:t,enrolmentId:Array.from(this.randomBytes(16)),credentialId:Array.from(new Uint8Array(r.rawId)),salt:Array.from(n),nonce:Array.from(s),ciphertext:Array.from(i)}}}catch{return null}finally{n.fill(0),a?.fill(0)}}async save(t){await this.store.save(t.record)}async unlock(t){if(!t||!this.credentials)return null;let o=null;try{const n=await this.store.read(t);return!n||!ei(n)||n.accountId!==t?(n&&await this.store.remove(t,n.enrolmentId),null):(o=await this.assertPrf(le(new Uint8Array(n.credentialId)),le(new Uint8Array(n.salt))),o?await Ou(t,n,o):null)}catch{return null}finally{o?.fill(0)}}async remove(t,o){await this.store.remove(t,o?.record.enrolmentId)}async assertPrf(t,o){if(!this.credentials)return null;const n=await this.credentials.get({publicKey:{challenge:le(this.randomBytes(32)),allowCredentials:[{type:"public-key",id:t}],userVerification:"required",timeout:Zs,extensions:{prf:{eval:{first:o}}}}});if(!Xs(n))return null;const a=n.getClientExtensionResults().prf?.results?.first,r=a?Bu(a):null;return r?.byteLength===ia?r:null}}class _u{async read(t){const o=await _r();try{const n=await o.get(kt,t);return Qs(n)?n:null}finally{o.close()}}async save(t){const o=await _r();try{await o.put(kt,t,t.accountId)}finally{o.close()}}async remove(t,o){const n=await _r();try{if(!o){await n.delete(kt,t);return}const a=n.transaction(kt,"readwrite"),r=a.objectStore(kt),s=await r.get(t);Qs(s)&&Nu(s.enrolmentId,o)&&await r.delete(t),await a.done}finally{n.close()}}}function _r(){return Ad(Iu,Lu,{upgrade(e){e.objectStoreNames.contains(kt)||e.createObjectStore(kt)}})}function Ru(){return typeof navigator<"u"&&navigator.credentials?navigator.credentials:null}function Pu(e){const t=new Uint8Array(e);return crypto.getRandomValues(t),t}function Xs(e){return e!==null&&"rawId"in e&&typeof e.getClientExtensionResults=="function"}function Qs(e){if(!e||typeof e!="object")return!1;const t=e;return t.version===Ja&&typeof t.accountId=="string"&&Array.isArray(t.enrolmentId)&&Array.isArray(t.credentialId)&&Array.isArray(t.salt)&&Array.isArray(t.nonce)&&Array.isArray(t.ciphertext)}function ei(e){return e.accountId.length>0&&e.enrolmentId.length===16&&e.credentialId.length>0&&e.salt.length===ia&&e.nonce.length===Nl&&e.ciphertext.length>16&&[e.enrolmentId,e.credentialId,e.salt,e.nonce,e.ciphertext].every(t=>t.every(o=>Number.isInteger(o)&&o>=0&&o<=255))}function Nu(e,t){if(e.length!==t.length)return!1;let o=0;for(let n=0;n<e.length;n++)o|=e[n]^t[n];return o===0}async function Mu(e,t,o,n){const a=await crypto.subtle.importKey("raw",le(o),{name:"AES-GCM"},!1,["encrypt"]),r=n(Nl),s=new Uint8Array(await crypto.subtle.encrypt({name:"AES-GCM",iv:le(r),additionalData:Ml(e)},a,le(t)));return{nonce:r,ciphertext:s}}async function Ou(e,t,o){const n=await crypto.subtle.importKey("raw",le(o),{name:"AES-GCM"},!1,["decrypt"]);return new Uint8Array(await crypto.subtle.decrypt({name:"AES-GCM",iv:le(new Uint8Array(t.nonce)),additionalData:Ml(e)},n,le(new Uint8Array(t.ciphertext))))}function Ml(e){return le(new TextEncoder().encode(`llmnesia-extension-biometric-unlock:v${Ja}:${e}`))}function le(e){const t=new Uint8Array(e.byteLength);return t.set(e),t.buffer}function Bu(e){if(e instanceof ArrayBuffer)return new Uint8Array(e.slice(0));const t=e;return new Uint8Array(new Uint8Array(t.buffer,t.byteOffset,t.byteLength))}const qu="llmnesia-fs-handles",lt="handles",Za="mcp-corpus-root";function Ol(){return typeof globalThis.showDirectoryPicker=="function"}function Xa(){return new Promise((e,t)=>{const o=indexedDB.open(qu,1);o.onupgradeneeded=()=>{const n=o.result;n.objectStoreNames.contains(lt)||n.createObjectStore(lt)},o.onsuccess=()=>e(o.result),o.onerror=()=>t(o.error)})}async function Uu(e){const t=await Xa();try{const o=t.transaction(lt,"readwrite");o.objectStore(lt).put(e,Za),await new Promise((n,a)=>{o.oncomplete=()=>n(),o.onerror=()=>a(o.error),o.onabort=()=>a(o.error)})}finally{t.close()}}async function Bl(){const e=await Xa();try{const t=e.transaction(lt,"readonly");return await new Promise((n,a)=>{const r=t.objectStore(lt).get(Za);r.onsuccess=()=>n(r.result),r.onerror=()=>a(r.error)})??null}finally{e.close()}}async function Vu(){const e=await Xa();try{const t=e.transaction(lt,"readwrite");t.objectStore(lt).delete(Za),await new Promise((o,n)=>{t.oncomplete=()=>o(),t.onerror=()=>n(t.error)})}finally{e.close()}await Id()}class ql extends Error{}async function zu(){const e=globalThis.showDirectoryPicker;if(!e)throw new Error("showDirectoryPicker is unavailable in this page.");let t;try{t=await e({id:"llmnesia-corpus",mode:"readwrite"})}catch(o){throw o instanceof Error&&o.name==="AbortError"?new ql("Folder selection cancelled."):o}return await Uu(t),t}async function Fu(e,{prompt:t}){const o={mode:"readwrite"};return await e.queryPermission(o)==="granted"||await e.requestPermission(o)==="granted"}async function Du(e,t={}){const o=t.full===!0,n=await Ld({full:o,compress:!0});if(!n.result)return Td(o,n.priorWatermark);const a=await e.getDirectoryHandle("inbox",{create:!0});for(const s of n.result.chunks){const l=await(await a.getFileHandle(s.filename,{create:!0})).createWritable();try{await l.write(s.blob)}finally{await l.close()}}const r=await _d(n);return{full:o,conversationCount:n.result.conversationCount,messageCount:n.result.messageCount,chunkCount:n.result.chunks.length,watermark:r,upToDate:!1}}function Ul(e,t){e.input.type=t?"text":"password",e.button.textContent=t?"Hide":"Show",e.button.setAttribute("aria-pressed",String(t)),e.button.setAttribute("aria-label",`${t?"Hide":"Show"} ${e.label}`)}function Gu(e){e.button.addEventListener("click",()=>{const t=e.input.type==="password";Ul(e,t),e.input.focus()})}function la(e){if(!e||typeof e!="object"||Array.isArray(e))return null;const t=e;return typeof t.conversation_id=="string"&&t.conversation_id?t.conversation_id:typeof t.id=="string"&&t.id?t.id:null}function ju(e,t=new Map){if(!e||typeof e!="object"||Array.isArray(e))return null;const o=e,n=la(e);if(!n)return null;const a=o.mapping&&typeof o.mapping=="object"?Object.fromEntries(Object.entries(o.mapping).map(([i,l])=>{if(!l||typeof l!="object")return[i,l];const f=l,p=f.message?.content?.parts;return Array.isArray(p)?[i,{...f,message:{...f.message,content:{...f.message.content,parts:p.map(c=>{if(c?.content_type!=="image_asset_pointer")return c;const v=El(c.asset_pointer,t);return v?{...c,image_url:v}:c})}}}]:[i,l]})):o.mapping,r={...o,mapping:a,conversation_id:n},s=new URL(`https://chatgpt.com/c/${encodeURIComponent(n)}`);return kp(r,s)}const ca=new Set(["anthropic_console","generic"]),da="llmnesia.search.recentLimit",Vl=30,Hu=[30,50,100,250,500];function mr(e){return e?new Date(e).toLocaleString():"Never"}function jn(e){return e<1024?`${e} B`:e<1024*1024?`${(e/1024).toFixed(1)} KB`:e<1024*1024*1024?`${(e/(1024*1024)).toFixed(1)} MB`:`${(e/(1024*1024*1024)).toFixed(2)} GB`}function k(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#39;")}function Ze(e,t,o,n){return`
    <div class="options-stat-card" data-stat="${e}">
      <div class="options-stat-label">${t}</div>
      <strong class="options-stat-value"${n===void 0?"":` data-val="${n}"`}>${o}</strong>
    </div>
  `}function zl(){const e='<div class="options-stat-card"><span class="stats-skel" style="height:9px; width:64%; margin-bottom:8px;"></span><span class="stats-skel" style="height:16px; width:46%;"></span></div>',t=Array.from({length:8},()=>e).join(""),o='<div style="display:grid; grid-template-columns:120px 1fr auto; gap:10px; align-items:center;"><span class="stats-skel" style="height:10px; width:72%;"></span><span class="stats-skel" style="height:14px; border-radius:7px;"></span><span class="stats-skel" style="height:10px; width:70px;"></span></div>',n=Array.from({length:4},()=>o).join("");return`<div style="display:grid; grid-template-columns:repeat(auto-fit,minmax(180px,1fr)); gap:8px; align-items:stretch;">${t}</div><div style="margin-top:12px; border-top:1px dashed #d7dfcb; padding-top:10px;"><span class="stats-skel" style="height:11px; width:150px; margin-bottom:12px;"></span><div style="display:grid; gap:7px;">${n}</div></div>`}const vn=[{key:"d7",label:"7 days"},{key:"d30",label:"30 days"},{key:"d90",label:"90 days"},{key:"all",label:"All time"}],Ku=[{key:"chats",label:"Chats"},{key:"msgs",label:"Messages"}];let ct=[],Nt="all",Hn="chats";function Yu(e,t,o){if(t.startsWith("y")){const n=e.byYear[t.slice(1)];return n?o==="chats"?n.chats:n.msgs:0}return o==="chats"?t==="d7"?e.chats7:t==="d30"?e.chats30:t==="d90"?e.chats90:e.chatsAll:t==="d7"?e.msgs7:t==="d30"?e.msgs30:t==="d90"?e.msgs90:e.msgsAll}function pa(e=3){const t=new Set;for(const o of ct)for(const n of Object.keys(o.byYear))t.add(n);return Array.from(t).sort((o,n)=>Number(n)-Number(o)).slice(0,e)}function Fl(e){if(!e)return"no date";const t=Date.now()-e,o=864e5;if(t<o)return"today";const n=Math.floor(t/o);return n<7?`${n}d ago`:n<30?`${Math.floor(n/7)}w ago`:n<365?`${Math.floor(n/30)}mo ago`:`${Math.floor(n/365)}y ago`}const ua="width .5s cubic-bezier(.22,.61,.36,1), opacity .4s ease",Dl="transform .45s cubic-bezier(.22,.61,.36,1), opacity .35s ease";function Gl(){return typeof window.matchMedia=="function"&&window.matchMedia("(prefers-reduced-motion: reduce)").matches}function jl(e){return e?"background:#1f6fd6 !important; color:#fff !important; border:1px solid #1a5fb8 !important; font-weight:600 !important;":"background:#fff !important; color:#3a4b58 !important; border:1px solid #d3dcc4 !important; font-weight:400 !important;"}const Hl="padding:4px 10px; border-radius:7px !important; cursor:pointer; font-size:12px; transition:background .2s ease, color .2s ease, border-color .2s ease; ";function ti(e,t){e.setAttribute("aria-pressed",String(t)),e.style.cssText=Hl+jl(t)}function oi(e,t,o,n){return`<button type="button" data-${t}="${o}" aria-pressed="${e}" style="${Hl}${jl(e)}">${n}</button>`}function Kl(){const e=(s,i)=>`<div style="display:flex; align-items:center; gap:6px;"><span style="font-size:12px; color:#7a8a96;">${s}</span><div style="display:flex; gap:4px; flex-wrap:wrap;">${i}</div></div>`,t=pa().map(s=>({key:`y${s}`,label:s})),o=vn.findIndex(s=>s.key==="all"),a=(o>=0?[...vn.slice(0,o),...t,...vn.slice(o)]:[...vn,...t]).map(s=>oi(Nt===s.key,"range",s.key,s.label)).join(""),r=Ku.map(s=>oi(Hn===s.key,"metric",s.key,s.label)).join("");return`<div style="display:flex; flex-wrap:wrap; gap:16px; align-items:center; margin-top:8px;">${e("Active in",a)}${e("Show",r)}</div>`}function ni(e,t){const o=Rp(e.platform),n=Nt==="all";return`<div class="pf-row" data-platform="${k(e.platform)}" style="display:grid; grid-template-columns:120px 1fr auto; gap:10px; align-items:center; transition:${Dl};"><div style="overflow:hidden; text-overflow:ellipsis; white-space:nowrap; font-weight:600;">${k(o.label)}</div><div style="height:14px; border-radius:7px; background:${o.pillBg}; overflow:hidden;"><div class="pf-fill" style="height:100%; width:${t.barPct}%; border-radius:7px; background:${o.accent}; opacity:${t.barOpacity.toFixed(2)}; transition:${ua};"></div></div><div style="font-variant-numeric:tabular-nums; white-space:nowrap; color:#3a4b58;"><strong class="pf-value" data-val="${t.value}">${t.value.toLocaleString()}</strong> <span class="pf-pct" style="color:#7a8a96;">(${t.pct}%)</span><span class="pf-last" style="color:#9aa8b4; margin-left:8px; font-weight:400;${n?"":" display:none;"}">${n?k(Fl(e.lastUsedAt)):""}</span></div></div>`}function Yl(e,t,o){return{value:e,pct:o>0?Math.round(e/o*100):0,barPct:e>0&&t>0?Math.max(2,Math.round(e/t*100)):0,barOpacity:t>0?.5+.5*(e/t):.5}}function Wl(){const e=ct.map(n=>({u:n,value:Yu(n,Nt,Hn)})).sort((n,a)=>a.value-n.value||a.u.chatsAll-n.u.chatsAll||n.u.platform.localeCompare(a.u.platform)),t=e.reduce((n,a)=>Math.max(n,a.value),0),o=e.reduce((n,a)=>n+a.value,0);return{ordered:e,max:t,total:o}}function Jl(e=!1){const t={value:0,pct:0,barPct:0,barOpacity:.5},o=Wl();return`<div id="platform-breakdown-rows" style="margin-top:10px; display:grid; gap:7px;">${e?o.ordered.map(({u:a,value:r})=>ni(a,Yl(r,o.max,o.total))).join(""):[...ct].sort((a,r)=>r.chatsAll-a.chatsAll||a.platform.localeCompare(r.platform)).map(a=>ni(a,t)).join("")}<div id="platform-breakdown-empty" style="color:#496073; display:none;"></div></div>`}function Zl(){const e=String(new Date().getFullYear()),t=["J","F","M","A","M","J","J","A","S","O","N","D"],o=["January","February","March","April","May","June","July","August","September","October","November","December"];let n=0,a=0,r=0;const s=new Array(12).fill(0);for(const y of ct){const b=y.byYear[e];b&&(n+=b.chats,a+=b.msgs,r+=1);for(let w=0;w<12;w+=1){const C=y.byMonth[`${e}-${String(w+1).padStart(2,"0")}`];C&&(s[w]+=C.chats)}}if(n===0)return"";const i=Math.max(...s),l=i>0?s.indexOf(i):-1,f=s.map((y,b)=>{const w=y>0?Math.max(6,Math.round(y/i*100)):0,C=b===l;return`<div class="year-bar-col"><div class="year-bar-track" title="${o[b]} ${e}: ${y.toLocaleString()} chat${y===1?"":"s"}"><div class="year-bar${C?" peak":""}" style="height:${w}%;"></div></div><span class="year-bar-label">${t[b]}</span></div>`}).join(""),p=(y,b)=>`<div><div class="year-stat-num">${y}</div><div class="year-stat-label">${b}</div></div>`,c=r===1?"AI":"AIs",v=l>=0?`<div class="year-caption">Busiest in <strong>${o[l]}</strong> · ${i.toLocaleString()} chat${i===1?"":"s"}.</div>`:"";return`<div class="year-card"><div class="year-card-head">Your ${e} in AI</div><div class="year-stats">${p(n.toLocaleString(),"chats")}${p(a.toLocaleString(),"messages")}${p(String(r),c+" used")}</div><div class="year-spark">${f}</div>${v}</div>`}function Wu(){return`<div id="year-summary-slot">${Zl()}</div><strong>Usage by platform</strong><div id="platform-controls-slot">${Kl()}</div><div id="platform-rows-slot">${Jl()}</div>`}function Ju(e,t,o,n){if(n){e.style.transition=ua,e.style.width=`${t}%`,e.style.opacity=o.toFixed(2);return}e.style.transition="none",e.style.width=`${t}%`,e.style.opacity=o.toFixed(2),e.offsetWidth,e.style.transition=ua}function Xl(e,t,o){const n=Number(e.dataset.val??"0");if(e.dataset.val=String(t),!o||n===t){e.textContent=t.toLocaleString();return}const a=performance.now(),r=450,s=i=>{const l=Math.min(1,(i-a)/r),f=1-Math.pow(1-l,3);e.textContent=Math.round(n+(t-n)*f).toLocaleString(),l<1&&requestAnimationFrame(s)};requestAnimationFrame(s)}function Kn(e){const t=document.querySelector("#platform-breakdown-rows"),o=document.querySelector("#platform-breakdown-empty");if(!t)return;const n=e&&!Gl(),a=p=>t.querySelector(`.pf-row[data-platform="${p}"]`),{ordered:r,max:s,total:i}=Wl(),l=ct.length===0;o&&(l&&(o.textContent="No chats indexed yet."),o.style.display=l?"":"none");const f=new Map;n&&ct.forEach(p=>{const c=a(p.platform);c&&f.set(p.platform,c.getBoundingClientRect().top)}),r.forEach(p=>{const c=a(p.u.platform);c&&t.appendChild(c)}),o&&t.appendChild(o),r.forEach(p=>{const c=a(p.u.platform);if(!c)return;const v=c.querySelector(".pf-fill"),y=c.querySelector(".pf-value"),b=c.querySelector(".pf-pct"),w=c.querySelector(".pf-last"),C=Yl(p.value,s,i);b&&(b.textContent=`(${C.pct}%)`),w&&(w.textContent=Nt==="all"?Fl(p.u.lastUsedAt):"",w.style.display=Nt==="all"?"":"none"),y&&Xl(y,p.value,n),v&&Ju(v,C.barPct,C.barOpacity,n),n||(c.style.opacity=p.value===0?"0.4":"1")}),n&&(r.forEach(p=>{const c=a(p.u.platform),v=f.get(p.u.platform);if(!c||v===void 0)return;const y=v-c.getBoundingClientRect().top;c.style.transition="none",c.style.transform=y?`translateY(${y}px)`:""}),requestAnimationFrame(()=>{r.forEach(p=>{const c=a(p.u.platform);c&&(c.style.transition=Dl,c.style.transform="",c.style.opacity=p.value===0?"0.4":"1")})}))}function ri(){const e=document.querySelector("#platform-breakdown-block");e&&(e.querySelectorAll("[data-range]").forEach(t=>{t.addEventListener("click",()=>{const o=t.getAttribute("data-range");!o||o===Nt||(Nt=o,e.querySelectorAll("[data-range]").forEach(n=>{ti(n,n.getAttribute("data-range")===o)}),Kn(!0))})}),e.querySelectorAll("[data-metric]").forEach(t=>{t.addEventListener("click",()=>{const o=t.getAttribute("data-metric");!o||o===Hn||(Hn=o,e.querySelectorAll("[data-metric]").forEach(n=>{ti(n,n.getAttribute("data-metric")===o)}),Kn(!0))})}))}function Ql(e){const t=Number(e);return Hu.includes(t)?t:Vl}function V(e,t="Unknown runtime error"){return e instanceof Error?e.message:t}Cp("options_page","options");op();const ec=document.querySelector("#app");if(!ec)throw new Error("Options app root not found");const Se=/win/i.test(navigator.userAgent),Bt=/mac/i.test(navigator.userAgent),Zu=Se?"https://www.llmnesia.com/download/node/windows":Bt?"https://www.llmnesia.com/download/node/macos":"https://nodejs.org/en/download",Xu=Se?"Download Node.js for Windows":Bt?"Download Node.js for Mac":"Download the current Node.js LTS release",Rr=Se?"PowerShell":Bt?"Terminal":"your terminal",tc=Se?"Open PowerShell: press the Windows key, type PowerShell, then select Windows PowerShell. Do not choose Run as administrator.":Bt?"Open Terminal: press Command + Space, type Terminal, then press Return.":"Open your terminal app.",Qu=Se?"In PowerShell, right-click once to paste, then press Enter.":Bt?"In Terminal, press Command + V to paste, then press Return.":"Paste it in your terminal, then press Enter.",ai=Se?"Fully quit every browser window, then reopen your browser.":Bt?"Fully quit your browser with Command + Q—not just the window—then reopen it.":"Fully quit your browser, then reopen it.",ef=Se?' <a href="https://www.llmnesia.com/download/node/windows-arm64" target="_blank" rel="noopener" style="color: #2b6588;">Running Windows on an ARM device or in VMware on an Apple-silicon Mac? Use the ARM installer instead.</a>':"",tf="https://www.llmnesia.com/download/claude/llmnesia.mcpb",oc=3,of=oc+1,nf="Search for memory, backup, MCP, Vault…";let nc=null,rc=null;function Qa(){return{vaultAvailable:!0,vaultBackupExists:nc,companionAvailable:!0,companionCorpusExists:rc}}const es=Se?`cmd.exe /d /c npx --yes --loglevel=error --no-update-notifier @llmnesia/mcp@latest install ${chrome.runtime.id}`:`npx --yes --loglevel=error --no-update-notifier @llmnesia/mcp@latest install ${chrome.runtime.id}`,Xe=`padding: 6px 10px; border-radius: 8px; border: 1px solid ${u.tealEdge} !important; background: #fff !important; color: #1c5a6e !important; cursor: pointer; font-weight: 600; white-space: nowrap;`;ec.innerHTML=`
	  <style>
      :root {
        color-scheme: light;
      }
	    html, body {
	      margin: 0;
	      padding: 0;
	      overflow-x: hidden;
        background:
          radial-gradient(circle at 12% 0%, rgba(78, 138, 91, 0.08), transparent 28rem),
          radial-gradient(circle at 92% 12%, rgba(47, 127, 153, 0.07), transparent 25rem),
          ${u.paper};
	    }

	    *, *::before, *::after {
	      box-sizing: border-box;
	    }
      #llmnesia-options-root {
        color: ${u.ink} !important;
      }
      #llmnesia-options-root h1,
      #llmnesia-options-root h2 {
        color: #11273a;
        letter-spacing: 0;
      }
      #llmnesia-options-root a {
        color: #2b6588;
      }
      #llmnesia-options-root a:focus-visible,
      #llmnesia-options-root button:focus-visible,
      #llmnesia-options-root input:focus-visible,
      #llmnesia-options-root select:focus-visible,
      #llmnesia-options-root summary:focus-visible {
        outline: 3px solid rgba(47, 127, 153, 0.34);
        outline-offset: 2px;
      }
      #llmnesia-options-root section[data-settings-section],
      #llmnesia-options-root details[data-settings-section] {
        scroll-margin-top: 18px;
      }
      #llmnesia-options-root {
        display: flex;
        flex-direction: column;
      }
      .settings-header {
        order: 1;
        max-width: 760px;
        margin-bottom: 18px;
      }
      .settings-setup-card {
        order: 2;
        margin: 0 0 16px;
        border: 1px solid #254d52;
        border-radius: 16px;
        padding: 18px;
        background: linear-gradient(135deg, #17364e 0%, #24515a 54%, #315f4c 100%);
        box-shadow: 0 10px 28px rgba(18, 48, 59, 0.16);
      }
      .settings-setup-head {
        display: flex;
        align-items: baseline;
        justify-content: space-between;
        gap: 12px;
        flex-wrap: wrap;
      }
      .settings-setup-eyebrow,
      .settings-nav-label {
        color: #5f8669;
        font-size: 10px;
        font-weight: 700;
        letter-spacing: 0.08em;
        text-transform: uppercase;
      }
      .settings-setup-title {
        margin: 0;
        color: #fff !important;
        font-size: 18px;
      }
      .settings-setup-description {
        margin: 6px 0 14px;
        color: #dce9e4;
        font-size: 12.5px;
      }
      .settings-setup-card .settings-setup-eyebrow {
        color: #c8e9d4;
      }
      .settings-setup-card .settings-setup-head > span {
        color: #dcebe5 !important;
      }
      .settings-setup-grid {
        display: grid;
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 10px;
      }
      .settings-setup-link {
        position: relative;
        display: grid;
        grid-template-columns: 26px minmax(0, 1fr) auto;
        gap: 10px;
        align-items: center;
        min-width: 0;
        padding: 13px 14px;
        border: 1px solid rgba(255, 255, 255, 0.6);
        border-radius: 11px;
        background: #ffffff;
        color: #1c3d2a !important;
        text-decoration: none;
        box-shadow: 0 2px 6px rgba(10, 30, 40, 0.22);
        transition: border-color 0.15s ease, box-shadow 0.15s ease, transform 0.15s ease;
        overflow: hidden;
      }
      /* Every destination section opens with a 4px coloured left bar, so the
         tiles repeat that signature (colours set per accent below). */
      .settings-setup-link::before {
        content: "";
        position: absolute;
        left: 0;
        top: 0;
        bottom: 0;
        width: 4px;
        background: var(--setup-accent, #6fae85);
      }
      .settings-setup-link:hover {
        border-color: #6fae85;
        box-shadow: 0 4px 12px rgba(10, 30, 40, 0.3);
        transform: translateY(-1px);
      }
      .settings-setup-link:focus-visible {
        outline: 2px solid #fff;
        outline-offset: 2px;
      }
      /* Each accent mirrors the destination section's RENDERED palette. The
         sections' inline colours are overridden by the group rules above
         (.settings-section forces var(--settings-accent) with !important), so
         these match the vars, not the inline styles: vault = indigo (#506fca),
         green = connections cards (MCP and local sessions both render the
         connections green), blue = data cards (backup). */
      .settings-setup-link[data-accent="vault"] {
        --setup-accent: #506fca;
        border-color: #a3b4e8;
        background: linear-gradient(180deg, #ffffff, #f5f7ff);
        color: #294b9c !important;
      }
      .settings-setup-link[data-accent="vault"]:hover {
        border-color: #506fca;
      }
      .settings-setup-link[data-accent="green"] {
        --setup-accent: #4f8a5b;
        border-color: #a9cdb0;
        background: linear-gradient(180deg, #ffffff, #f3faf4);
        color: #244b32 !important;
      }
      .settings-setup-link[data-accent="green"]:hover {
        border-color: #315a3e;
      }
      .settings-setup-link[data-accent="blue"] {
        --setup-accent: #3d6fa8;
        border-color: #a8c2df;
        background: linear-gradient(180deg, #ffffff, #f3f8fd);
        color: #1d4f78 !important;
      }
      .settings-setup-link[data-accent="blue"]:hover {
        border-color: #4c88b8;
      }
      .settings-setup-number {
        display: inline-flex;
        width: 26px;
        height: 26px;
        align-items: center;
        justify-content: center;
        border-radius: 8px;
        background: #2e7d4f;
        color: #fff;
        font-size: 13px;
        font-weight: 800;
        box-shadow: inset 0 -1px 0 rgba(10, 30, 40, 0.25);
      }
      [data-accent="vault"] .settings-setup-number {
        background: #3956a7;
      }
      [data-accent="green"] .settings-setup-number {
        background: #315a3e;
      }
      [data-accent="blue"] .settings-setup-number {
        background: #3d6fa8;
      }
      [data-accent="vault"] .settings-setup-arrow { color: #506fca; }
      [data-accent="green"] .settings-setup-arrow { color: #315a3e; }
      [data-accent="blue"] .settings-setup-arrow { color: #3d6fa8; }
      .settings-setup-copy {
        min-width: 0;
      }
      .settings-setup-copy strong,
      .settings-setup-copy small {
        display: block;
      }
      .settings-setup-copy strong {
        font-size: 13.5px;
        font-weight: 750;
      }
      .settings-setup-copy small {
        margin-top: 3px;
        color: #3d5266;
        font-size: 12px;
        line-height: 1.4;
      }
      .settings-setup-arrow {
        color: #6fae85;
        font-size: 18px;
        font-weight: 700;
        transition: transform 0.15s ease;
      }
      .settings-setup-link:hover .settings-setup-arrow {
        transform: translateX(3px);
      }
      .settings-nav {
        position: sticky;
        top: 0;
        z-index: 4;
        order: 3;
        margin: 0 0 4px;
        padding: 11px 14px;
        border: 1px solid #d4ddd7;
        border-radius: 13px;
        background: rgba(255, 255, 255, 0.92);
        box-shadow: 0 5px 16px rgba(38, 61, 72, 0.08);
        backdrop-filter: blur(8px);
      }
      .settings-search-row {
        display: flex;
        align-items: center;
        gap: 8px;
      }
      .settings-search-label {
        flex: 0 0 auto;
        color: #2f4654;
        font-size: 12.5px;
        font-weight: 600;
      }
      .settings-search-wrap {
        position: relative;
        flex: 1 1 260px;
        min-width: 0;
      }
      .settings-search-wrap::before {
        position: absolute;
        top: 50%;
        left: 11px;
        color: #7a8a96;
        content: "⌕";
        font-size: 18px;
        line-height: 1;
        transform: translateY(-53%);
      }
      #settings-search {
        width: 100%;
        min-width: 0;
        padding: 8px 42px 8px 31px !important;
        border: 1px solid #cbd6d0 !important;
        border-radius: 8px;
        box-shadow: inset 0 1px 2px rgba(28, 54, 67, 0.05);
        font-size: 13px;
      }
      .settings-search-key {
        position: absolute;
        top: 50%;
        right: 8px;
        padding: 2px 5px;
        border: 1px solid #dbe2cf;
        border-radius: 4px;
        background: #f7f9f1;
        color: #7a8a96;
        font-family: "IBM Plex Mono", "SF Mono", "Consolas", monospace;
        font-size: 10px;
        transform: translateY(-50%);
      }
      #settings-search-status {
        margin: 6px 0 0 76px;
        color: #506271;
        font-family: "IBM Plex Mono", "SF Mono", "Consolas", monospace;
        font-size: 11px;
      }
      .settings-nav-links {
        display: flex;
        flex-wrap: wrap;
        gap: 5px;
        align-items: center;
        margin-top: 7px;
        padding-top: 7px;
        border-top: 1px solid #edf0ea;
      }
      .settings-nav-links a {
        padding: 4px 8px;
        border: 1px solid transparent;
        border-radius: 999px;
        color: #526b79;
        font-size: 11.5px;
        text-decoration: none;
      }
      .settings-nav-links a:hover,
      .settings-nav-links a[aria-current="true"] {
        border-color: #b7d8d0;
        background: #eaf5f2;
        color: #1c5a6e;
        font-weight: 600;
      }
      .settings-nav-links a[data-settings-nav="vault-card"] {
        border-color: #c4d0f3;
        background: #f2f5ff;
        color: #294b9c;
        font-weight: 650;
      }
      .settings-nav-links a[data-settings-nav="vault-card"]:hover,
      .settings-nav-links a[data-settings-nav="vault-card"][aria-current="true"] {
        border-color: #7b97df;
        background: #e3ebff;
        color: #1c3d8f;
      }
      .settings-group-heading {
        display: grid;
        grid-template-columns: auto 1fr;
        gap: 10px;
        align-items: center;
        margin: 28px 2px 0;
        color: #58706a;
      }
      .settings-group-heading[hidden] {
        display: none !important;
      }
      .settings-group-heading::after {
        height: 1px;
        background: linear-gradient(90deg, #cad5ce, transparent);
        content: "";
      }
      .settings-group-heading strong {
        color: #284459;
        font-size: 12px;
        letter-spacing: 0.075em;
        text-transform: uppercase;
      }
      .settings-group-heading span {
        display: block;
        margin-top: 2px;
        color: #526675;
        font-size: 11.5px;
        font-weight: 400;
        letter-spacing: 0;
        text-transform: none;
      }
      .settings-group-heading[data-settings-group-heading="overview"] strong { color: #4d6b39; }
      .settings-group-heading[data-settings-group-heading="knowledge"] strong { color: #23677d; }
      .settings-group-heading[data-settings-group-heading="connections"] strong { color: #315a3e; }
      .settings-group-heading[data-settings-group-heading="data"] strong { color: #315f91; }
      .settings-group-heading[data-settings-group-heading="advanced"] strong { color: #526771; }
      .settings-section {
        --settings-accent: #7a9b57;
        --settings-action: #4d6b39;
        --settings-edge: #b8c99c;
        --settings-tint: rgba(122, 155, 87, 0.13);
        --settings-label-tint: #edf4e2;
        order: 10;
        margin-top: 12px !important;
        border: 1px solid var(--settings-edge) !important;
        border-left: 6px solid var(--settings-accent) !important;
        border-radius: 14px !important;
        padding: 18px 19px !important;
        background: linear-gradient(105deg, var(--settings-tint) 0%, #fff 54%) !important;
        box-shadow: 0 4px 13px rgba(30, 55, 65, 0.08), inset 0 1px rgba(255, 255, 255, 0.82);
      }
      .settings-section[data-settings-group="knowledge"] {
        --settings-accent: #2f7f99;
        --settings-action: #23677d;
        --settings-edge: #9ac8d5;
        --settings-tint: rgba(47, 127, 153, 0.14);
        --settings-label-tint: #e1f2f6;
      }
      .settings-section[data-settings-group="connections"] {
        --settings-accent: #4f8a5b;
        --settings-action: #315a3e;
        --settings-edge: #a9cdb0;
        --settings-tint: rgba(79, 138, 91, 0.14);
        --settings-label-tint: #e5f2e7;
      }
      /* Google AI Mode inherits the connections group palette (green bar,
         label pill, tinted gradient) like the other connections cards; the
         old grey muting override hid all of it and made the card read as a
         bare box. Only the state pill and toggle get card-specific styles. */
      #llmnesia-options-root #google-ai-mode-state {
        display: inline-flex;
        align-items: center;
        padding: 4px 10px;
        border: 1px solid var(--settings-edge) !important;
        border-radius: 999px;
        background: var(--settings-label-tint) !important;
        color: var(--settings-action) !important;
        font-size: 11px !important;
        font-weight: 750 !important;
        letter-spacing: 0.05em;
        text-transform: uppercase;
      }
      #llmnesia-options-root #google-ai-mode-state[data-state="on"] {
        border-color: #a7d6bf !important;
        background: #f0faf4 !important;
        color: #20543b !important;
      }
      #llmnesia-options-root #google-ai-mode-state[data-state="off"] {
        border-color: #d5dedf !important;
        background: #f4f7f7 !important;
        color: #526771 !important;
      }
      #llmnesia-options-root #google-ai-mode-state[data-state="error"] {
        border-color: #e8c8a8 !important;
        background: #fdf3ea !important;
        color: #9a5b1c !important;
      }
      #llmnesia-options-root #google-ai-mode-toggle:disabled {
        opacity: 0.6;
        cursor: not-allowed;
        filter: none !important;
      }
      .settings-section[data-settings-group="data"] {
        --settings-accent: #3d6fa8;
        --settings-action: #315f91;
        --settings-edge: #a8c2df;
        --settings-tint: rgba(61, 111, 168, 0.14);
        --settings-label-tint: #e6eff9;
      }
      .settings-section[data-settings-group="advanced"] {
        --settings-accent: #87969d;
        --settings-action: #526771;
        --settings-edge: #c4cfd3;
        --settings-tint: rgba(90, 111, 122, 0.11);
        --settings-label-tint: #edf1f2;
      }
      #danger-zone-section {
        --settings-accent: #b83d3d;
        --settings-action: #983434;
        --settings-edge: #dfadad;
        --settings-tint: rgba(184, 61, 61, 0.12);
        --settings-label-tint: #fbeaea;
      }
      .settings-section[data-settings-label]::before {
        display: inline-flex;
        width: fit-content;
        margin-bottom: 5px;
        padding: 3px 7px;
        border: 1px solid var(--settings-edge);
        border-radius: 999px;
        background: var(--settings-label-tint);
        color: var(--settings-action);
        content: attr(data-settings-label);
        font-size: 10.5px;
        font-weight: 750;
        letter-spacing: 0.075em;
        text-transform: uppercase;
      }
      .settings-section:not(#corpus-native-card):not(#vault-card) > h2,
      .settings-section:not(#corpus-native-card):not(#vault-card) > div:first-child h2 {
        margin-top: 0 !important;
        color: #183346 !important;
        font-size: 17px !important;
        line-height: 1.3;
      }
      #danger-zone-section > h2 {
        color: #702525 !important;
      }
      .settings-card-description {
        max-width: 780px;
        margin-top: 6px !important;
        margin-bottom: 13px !important;
        color: #4d6254 !important;
        font-size: 13px;
        line-height: 1.58 !important;
      }
      .settings-card-description strong {
        color: #2a4533;
      }
      .settings-actions {
        display: flex;
        gap: 8px;
        align-items: center;
        flex-wrap: wrap;
      }
      .settings-status-panel {
        margin-top: 11px !important;
        padding: 9px 11px;
        border: 1px solid #d5dfd7;
        border-left: 3px solid var(--settings-accent);
        border-radius: 8px;
        background: #f7faf8;
        color: #344d3b !important;
        font-size: 12.5px;
        line-height: 1.5;
        overflow-wrap: anywhere;
        word-break: break-word;
      }
      .settings-status-panel:empty {
        display: none;
      }
      .settings-subpanel {
        border: 1px solid #d8e1da !important;
        border-radius: 10px !important;
        background: rgba(255, 255, 255, 0.82) !important;
      }
      .settings-section[data-settings-group="connections"] .settings-subpanel > div:first-child {
        color: var(--settings-action) !important;
      }
      .settings-section details > summary {
        color: #365166 !important;
        font-weight: 600;
      }
      #llmnesia-options-root input[type="text"],
      #llmnesia-options-root input[type="email"],
      #llmnesia-options-root input[type="search"],
      #llmnesia-options-root textarea,
      #llmnesia-options-root select {
        border-color: #bdcbc1 !important;
        border-radius: 8px !important;
        background: #fff !important;
        color: #203d2b !important;
      }
      #llmnesia-options-root .settings-primary-action {
        border-color: var(--settings-action) !important;
        background: var(--settings-action) !important;
        color: #fff !important;
        font-weight: 700 !important;
      }
      #llmnesia-options-root .settings-danger-action {
        border-color: #a13a3a !important;
        background: #a13a3a !important;
        color: #fff !important;
        font-weight: 700 !important;
      }
      /* The armed delete button only looks dangerous once the typed phrase
         matches; until then it reads as inert, not clickable. */
      #llmnesia-options-root .settings-danger-action:disabled {
        border-color: #d6a7a7 !important;
        background: #f1e3e3 !important;
        color: #a38383 !important;
        font-weight: 600 !important;
        cursor: not-allowed !important;
        filter: none !important;
      }
      #llmnesia-options-root button:not(:disabled):hover,
      #llmnesia-options-root .settings-setup-link:hover {
        filter: brightness(0.97);
      }
      .vault-paywall {
        display: flex;
        flex-direction: column;
        gap: 10px;
        margin-top: 12px;
      }
      .vault-paywall-status-card {
        display: grid;
        grid-template-columns: 30px minmax(0, 1fr);
        gap: 11px;
        padding: 13px 14px;
        border: 1px solid #d8c98a;
        border-radius: 10px;
        background: #fffaf0;
      }
      .vault-paywall-status-icon {
        display: inline-grid;
        width: 28px;
        height: 28px;
        border-radius: 50%;
        place-items: center;
        background: #8b6417;
        color: #fff;
        font-size: 17px;
        font-weight: 800;
        line-height: 1;
      }
      .vault-paywall-status-icon::before {
        content: "!";
      }
      .vault-paywall[data-state="never_subscribed"] .vault-paywall-status-card {
        border-color: #bad5df;
        background: #f3f9fb;
      }
      .vault-paywall[data-state="never_subscribed"] .vault-paywall-status-icon {
        background: #2f7187;
      }
      .vault-paywall[data-state="never_subscribed"] .vault-paywall-status-icon::before {
        content: "i";
        font-family: Georgia, serif;
      }
      #vault-paywall-status-line {
        color: #183346;
        font-size: 15px;
        font-weight: 750;
        line-height: 1.4;
      }
      #vault-paywall-account-line {
        margin-top: 3px;
        color: #556771;
        font-size: 11.5px;
        line-height: 1.4;
        overflow-wrap: anywhere;
      }
      .vault-paywall-reassurance {
        margin: 0;
        padding: 11px 13px;
        border: 1px solid #cfe0d2;
        border-left: 3px solid #4f8a5b;
        border-radius: 9px;
        background: #f5faf6;
        color: #314d3a;
        font-size: 12.5px;
        line-height: 1.55;
      }
      .vault-paywall-free-line {
        display: flex;
        gap: 7px;
        align-items: baseline;
        margin: 0;
        padding: 9px 11px;
        border: 1px solid #cfe0d2;
        border-radius: 9px;
        background: #f5faf6;
        color: #26402f;
        font-size: 11.5px;
        line-height: 1.5;
      }
      .vault-paywall-free-line::before {
        content: "✓";
        color: #4f8a5b;
        font-weight: 800;
      }
      .vault-plan-toggle {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 10px;
        margin-top: 2px;
      }
      .vault-plan-option {
        position: relative;
        display: flex;
        flex-direction: column;
        align-items: flex-start;
        gap: 3px;
        padding: 15px 14px 12px;
        border: 1.5px solid #c5d4f5;
        border-radius: 12px;
        background: #fff;
        color: #41564a;
        text-align: left;
        cursor: pointer;
        transition: border-color 120ms ease, box-shadow 120ms ease, background 120ms ease;
      }
      .vault-plan-option:hover {
        border-color: #8fa7e0;
      }
      .vault-plan-option.selected {
        border-color: #294b9c;
        background: linear-gradient(165deg, #f2f6ff 0%, #ffffff 72%);
        box-shadow: 0 0 0 1px #294b9c, 0 6px 14px rgba(35, 59, 136, 0.14);
      }
      .vault-plan-option.selected::after {
        content: "✓";
        position: absolute;
        top: 10px;
        right: 13px;
        display: grid;
        place-items: center;
        width: 16px;
        height: 16px;
        border-radius: 50%;
        background: #294b9c;
        color: #fff;
        font-size: 10px;
        font-weight: 800;
        line-height: 1;
      }
      .vault-plan-flag {
        position: absolute;
        top: -10px;
        left: 12px;
        padding: 2.5px 8px;
        border-radius: 999px;
        background: linear-gradient(135deg, #294b9c 0%, #172a62 100%);
        color: #fff;
        font-size: 9px;
        font-weight: 800;
        letter-spacing: 0.07em;
        text-transform: uppercase;
        box-shadow: 0 2px 6px rgba(23, 42, 98, 0.28);
      }
      .vault-plan-name {
        color: #5a6b92;
        font-size: 10.5px;
        font-weight: 750;
        letter-spacing: 0.06em;
        text-transform: uppercase;
      }
      .vault-plan-option.selected .vault-plan-name {
        color: #294b9c;
      }
      .vault-plan-price {
        color: #172a62;
        font-size: 19px;
        font-weight: 800;
        line-height: 1.15;
      }
      .vault-plan-per {
        color: #5a6b92;
        font-size: 11px;
        font-weight: 650;
      }
      .vault-plan-billed {
        color: #5a6b92;
        font-size: 10.5px;
        line-height: 1.4;
      }
      .vault-paywall-actions {
        display: flex;
        margin-top: 2px;
      }
      #llmnesia-options-root #vault-paywall-cta {
        flex: 1;
        min-height: 44px;
        padding: 11px 18px;
        border: 0 !important;
        border-radius: 11px !important;
        background: linear-gradient(135deg, #294b9c 0%, #172a62 100%) !important;
        color: #fff !important;
        font-size: 13.5px !important;
        font-weight: 750 !important;
        letter-spacing: 0.01em;
        box-shadow: 0 8px 18px rgba(23, 42, 98, 0.26), 0 2px 4px rgba(23, 42, 98, 0.16) !important;
        transition: filter 120ms ease, transform 120ms ease;
      }
      #llmnesia-options-root #vault-paywall-cta:hover {
        filter: brightness(1.09);
      }
      #llmnesia-options-root #vault-paywall-cta:active {
        transform: translateY(1px);
      }
      .vault-paywall-plan-note {
        margin: 0;
        color: #5b6e78;
        font-size: 11px;
        line-height: 1.5;
        text-align: center;
      }
      .vault-paywall-utilities {
        display: flex;
        gap: 18px;
        align-items: center;
        justify-content: center;
        flex-wrap: wrap;
        margin: 0;
      }
      #llmnesia-options-root .vault-paywall-utility {
        padding: 2px 0;
        border: 0 !important;
        border-radius: 3px !important;
        background: transparent !important;
        color: #536b77 !important;
        cursor: pointer;
        font-size: 11.5px;
        font-weight: 500;
        text-decoration: underline;
        text-decoration-color: #b5c3c9;
        text-underline-offset: 3px;
      }
      #llmnesia-options-root .vault-paywall-utility:hover {
        color: #294a5a !important;
        text-decoration-color: currentColor;
      }
      .vault-paywall-live-status {
        display: none;
        margin-top: 8px;
        color: #506a76;
        font-size: 11.5px;
        line-height: 1.5;
      }
      #corpus-sync-card {
        padding: 11px 16px !important;
      }
      #vault-card,
      #corpus-native-card {
        border-left-width: 1px !important;
        overflow: hidden;
      }
      #vault-card {
        --settings-accent: #506fca;
        --settings-action: #294b9c;
        --settings-edge: #3956a7;
        --settings-tint: rgba(80, 111, 202, 0.12);
        margin-top: 18px !important;
        padding: 0 !important;
        border: 1px solid #3956a7 !important;
        background: #fff !important;
        box-shadow: 0 10px 28px rgba(35, 59, 136, 0.18), 0 2px 5px rgba(30, 55, 65, 0.08) !important;
      }
      .vault-card-header {
        padding: 18px 18px 16px;
        background:
          radial-gradient(circle at 92% 8%, rgba(148, 178, 255, 0.35), transparent 26%),
          linear-gradient(135deg, #172a62 0%, #294b9c 58%, #506fca 100%);
        color: #fff;
      }
      .vault-card-kicker-row {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 8px;
        flex-wrap: wrap;
        margin-bottom: 8px;
      }
      .vault-card-badge {
        display: inline-flex;
        align-items: center;
        gap: 5px;
        padding: 4px 8px;
        border: 1px solid rgba(255, 255, 255, 0.48);
        border-radius: 999px;
        color: #fff;
        font-size: 10.5px;
        font-weight: 750;
        letter-spacing: 0.08em;
        text-transform: uppercase;
      }
      .vault-card-badge::before {
        content: "✦";
        font-size: 11px;
      }
      .vault-card-encryption-note {
        color: #fff;
        font-size: 12px;
        font-weight: 650;
      }
      #vault-card .vault-card-title {
        margin: 0 0 7px !important;
        color: #fff !important;
        font-size: 20px !important;
        line-height: 1.25;
      }
      #vault-card .vault-card-description {
        max-width: 690px;
        margin: 0 !important;
        color: #f7f9ff !important;
        font-size: 13.5px;
        line-height: 1.55 !important;
      }
      .vault-card-flow {
        display: flex;
        align-items: center;
        flex-wrap: wrap;
        gap: 7px;
        margin-top: 12px;
        padding: 9px 10px;
        border: 1px solid rgba(255, 255, 255, 0.52);
        border-radius: 9px;
        background: rgba(255, 255, 255, 0.97);
        color: #24365f;
        font-size: 12px;
      }
      .vault-card-flow strong {
        color: #1b3478;
      }
      .vault-card-flow-arrow {
        color: #6682cf;
        font-weight: 800;
      }
      .vault-card-flow-vault {
        padding: 4px 7px;
        border-radius: 6px;
        background: #e5edff;
        color: #24489d;
        font-weight: 750;
      }
      .vault-card-trust-note {
        margin: 9px 0 0;
        color: #f5f8ff;
        font-size: 12px;
        line-height: 1.5;
      }
      .vault-card-body {
        padding: 16px 18px 18px;
        background: linear-gradient(115deg, #f4f7ff 0%, #fff 42%);
      }
      #vault-card .vault-card-body > .vault-card-privacy {
        margin: 0 0 13px;
        padding: 10px 12px;
        border: 1px solid #c5d4f5;
        border-left: 4px solid #506fca;
        border-radius: 8px;
        background: #f8faff;
        color: #263d68;
        font-size: 12.5px;
        line-height: 1.55;
      }
      #vault-card .vault-card-body > .vault-card-privacy strong {
        color: #203d8a;
      }
      .vault-signin-success {
        display: none;
        align-items: flex-start;
        gap: 10px;
        margin-bottom: 14px;
        padding: 11px 13px;
        border: 1px solid #a7d6bf;
        border-radius: 10px;
        background: #f0faf4;
        color: #20543b;
        font-size: 13px;
        line-height: 1.45;
      }
      .vault-signin-success::before {
        content: "✓";
        display: grid;
        flex: 0 0 22px;
        height: 22px;
        place-items: center;
        border-radius: 50%;
        background: #287750;
        color: #fff;
        font-weight: 800;
      }
      .vault-ready-card {
        display: flex;
        align-items: flex-start;
        gap: 13px;
        padding: 16px;
        border: 1px solid #a9d6bd;
        border-radius: 12px;
        background: linear-gradient(135deg, #f0faf4, #fff 76%);
        box-shadow: 0 3px 12px rgba(32, 84, 59, 0.08);
      }
      .vault-ready-icon {
        display: grid;
        flex: 0 0 36px;
        height: 36px;
        place-items: center;
        border-radius: 10px;
        background: #287750;
        color: #fff;
        font-size: 21px;
        font-weight: 750;
      }
      .vault-ready-content { min-width: 0; }
      .vault-ready-kicker {
        color: #27684b;
        font-size: 10px;
        font-weight: 800;
        letter-spacing: 0.08em;
        text-transform: uppercase;
      }
      .vault-ready-title {
        margin: 2px 0 2px;
        color: #173b2a;
        font-size: 17px;
        line-height: 1.3;
      }
      #vault-account-line {
        overflow-wrap: anywhere;
        color: #3b5968;
        font-size: 13px;
      }
      .vault-ready-badges {
        display: flex;
        flex-wrap: wrap;
        gap: 7px;
        margin-top: 11px;
      }
      .vault-ready-badge {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 5px 9px;
        border: 1px solid #b9dcc8;
        border-radius: 999px;
        background: #fff;
        color: #20543b;
        font-size: 12px;
        font-weight: 700;
      }
      .vault-ready-badge::before {
        content: "✓";
        font-weight: 850;
      }
      /* Manage Vault actions: quiet gradient buttons with a soft hover lift,
         so the row reads as a finished control group instead of bare inputs.
         The global "#llmnesia-options-root button" rule forces background,
         colour, border, and radius on every button with !important, so these
         selectors carry the root prefix and !important to win the cascade
         (same pattern as ".settings-primary-action" above). */
      #llmnesia-options-root .vault-manage-btn {
        display: inline-flex !important;
        align-items: center !important;
        gap: 7px !important;
        padding: 9px 14px !important;
        border: 1px solid ${u.tealEdge} !important;
        border-radius: 10px !important;
        background: linear-gradient(180deg, #ffffff, #eaf3f6) !important;
        color: #17546a !important;
        font-size: 12.5px !important;
        font-weight: 650 !important;
        letter-spacing: 0.01em !important;
        white-space: nowrap;
        cursor: pointer;
        box-shadow: 0 1px 2px rgba(20, 36, 48, 0.16);
        transition: border-color 140ms ease, background 140ms ease, box-shadow 140ms ease, transform 140ms ease;
      }
      #llmnesia-options-root .vault-manage-btn:hover {
        border-color: ${u.teal} !important;
        background: linear-gradient(180deg, #ffffff, #dceef3) !important;
        box-shadow: 0 3px 8px rgba(47, 127, 153, 0.22);
        transform: translateY(-1px);
      }
      #llmnesia-options-root .vault-manage-btn:active {
        transform: translateY(0);
        box-shadow: 0 1px 2px rgba(20, 36, 48, 0.16);
      }
      #llmnesia-options-root .vault-manage-btn:focus-visible {
        outline: 2px solid ${u.teal} !important;
        outline-offset: 2px;
      }
      #llmnesia-options-root .vault-manage-btn:disabled {
        opacity: 0.55;
        cursor: default;
        transform: none;
        box-shadow: none;
      }
      #llmnesia-options-root .vault-manage-btn--primary {
        border-color: #26718a !important;
        background: linear-gradient(180deg, #358aa6, ${u.teal} 55%, #29708a) !important;
        color: #fff !important;
        text-shadow: 0 1px 0 rgba(20, 36, 48, 0.18);
        box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.22), 0 1px 2px rgba(20, 36, 48, 0.18);
      }
      #llmnesia-options-root .vault-manage-btn--primary:hover {
        border-color: #215f75 !important;
        background: linear-gradient(180deg, #3b95b3, #2f7f99 55%, #29708a) !important;
        box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.22), 0 3px 8px rgba(47, 127, 153, 0.3);
      }
      #llmnesia-options-root .vault-manage-btn--danger {
        border-color: #d7b1b1 !important;
        background: linear-gradient(180deg, #ffffff, #fdf0f0) !important;
        color: #8a2424 !important;
      }
      #llmnesia-options-root .vault-manage-btn--danger:hover {
        border-color: #b83d3d !important;
        background: linear-gradient(180deg, #ffffff, #fbe9e9) !important;
        box-shadow: 0 3px 8px rgba(184, 61, 61, 0.18);
      }
      /* The locked-panel and setup-walk buttons carry their sizes in inline
         styles (the global rule does not force padding), but their teal and
         white-on-teal colours need these winning rules to render at all. */
      #llmnesia-options-root #vault-unlock-btn,
      #llmnesia-options-root #vault-recover-submit,
      #llmnesia-options-root #vault-firstsync-btn,
      #llmnesia-options-root #vault-backup-btn {
        border-color: #26718a !important;
        background: linear-gradient(180deg, #358aa6, ${u.teal} 55%, #29708a) !important;
        color: #fff !important;
        font-weight: 650 !important;
        text-shadow: 0 1px 0 rgba(20, 36, 48, 0.18);
        box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.22), 0 1px 2px rgba(20, 36, 48, 0.18);
      }
      #llmnesia-options-root #vault-unlock-btn:hover,
      #llmnesia-options-root #vault-recover-submit:hover,
      #llmnesia-options-root #vault-firstsync-btn:hover,
      #llmnesia-options-root #vault-backup-btn:hover {
        background: linear-gradient(180deg, #3b95b3, #2f7f99 55%, #29708a) !important;
      }
      #llmnesia-options-root #vault-restore-btn {
        border-color: ${u.tealEdge} !important;
        background: linear-gradient(180deg, #ffffff, #eaf3f6) !important;
        color: #17546a !important;
        font-weight: 650 !important;
        box-shadow: 0 1px 2px rgba(20, 36, 48, 0.16);
      }
      #llmnesia-options-root #vault-restore-btn:hover {
        border-color: ${u.teal} !important;
        background: linear-gradient(180deg, #ffffff, #dceef3) !important;
      }
      .vault-sync-summary {
        margin-top: 12px;
        padding: 11px 13px;
        border: 1px solid #d5e0ed;
        border-radius: 10px;
        background: #fff;
        color: #3d5668;
        font-size: 12.5px;
        line-height: 1.5;
      }
      /* The Vault status pill in the page header, and its anchored panel.
         Same contract and vocabulary as the popup's pill; this surface simply
         anchors its recovery actions to the Vault card instead of a separate
         Settings page. */
      #vault-status-pill {
        display: none;
        position: relative;
        margin-top: 10px;
        max-width: 420px;
      }
      #vault-status-pill[data-visible="true"] { display: block; }
      #vault-status-pill-button {
        display: flex;
        align-items: center;
        gap: 7px;
        width: 100%;
        padding: 6px 12px;
        border: 1px solid #d5e0ed;
        border-radius: 999px;
        background: #f2f7f5;
        color: #2f5e53;
        font-size: 12px;
        font-weight: 700;
        line-height: 1.35;
        text-align: left;
        cursor: pointer;
      }
      #vault-status-pill-button:hover { background: #e9f2ef; }
      #vault-status-pill[data-tone="attention"] #vault-status-pill-button {
        background: #fdf3f3;
        border-color: #e5c9c9;
        color: #7a2626;
      }
      #vault-status-pill[data-tone="ok"] #vault-status-pill-button {
        background: #eef6f0;
        border-color: #cfe3d6;
        color: #2b5a3c;
      }
      .vault-status-pill-dot {
        flex: none;
        width: 8px;
        height: 8px;
        border-radius: 50%;
        background: currentColor;
        opacity: 0.55;
      }
      #vault-status-pill[data-tone="ok"] .vault-status-pill-dot { opacity: 0.8; }
      #vault-status-pill[data-busy="true"] .vault-status-pill-dot {
        animation: vault-status-pulse 1.1s ease-in-out infinite;
      }
      @keyframes vault-status-pulse {
        0%, 100% { opacity: 0.3; }
        50% { opacity: 0.95; }
      }
      @media (prefers-reduced-motion: reduce) {
        #vault-status-pill[data-busy="true"] .vault-status-pill-dot { animation: none; }
      }
      #vault-status-pill-panel {
        position: absolute;
        top: calc(100% + 6px);
        left: 0;
        right: 0;
        z-index: 80;
        padding: 16px;
        border: 1px solid #d8e4e0;
        border-radius: 12px;
        background: #fff;
        box-shadow: 0 8px 22px rgba(18, 48, 59, 0.14);
        color: #3d5668;
        font-size: 12.5px;
        line-height: 1.5;
      }
      #vault-status-pill-button::after { content: ""; width: 5px; height: 5px; border-right: 1.5px solid currentColor; border-bottom: 1.5px solid currentColor; transform: rotate(45deg); margin-left: auto; flex: none; }
      #vault-status-pill-button[aria-expanded="true"]::after { transform: rotate(225deg); }
      .vault-status-pill-actions {
        display: flex;
        flex-wrap: wrap;
        gap: 8px;
        margin-top: 14px;
        padding-top: 14px;
        border-top: 1px solid #e2ebe7;
      }
      .vault-status-pill-actions button {
        padding: 5px 12px;
        border: 1px solid #c4d6d0;
        border-radius: 8px;
        background: #f6faf8;
        color: #24413a;
        font-size: 12px;
        font-weight: 600;
        cursor: pointer;
      }
      .vault-status-pill-actions button:hover { background: #e9f2ef; }
      #vault-status-pill-sync-now, #vault-status-pill-recovery { background: #2f5e53; border-color: #2f5e53; color: #fff; }
      #vault-status-pill-sync-now:hover, #vault-status-pill-recovery:hover { background: #244a41; }
      .vault-status-pill-actions button:disabled { opacity: 0.6; cursor: default; }
      #vault-sync-line { font-weight: 700; }
      #vault-auto-sync-note { margin-top: 3px; }
      #vault-join-devices-line {
        margin-top: 12px;
        padding-left: 1px;
        color: #536b7c;
        font-size: 12.5px;
        line-height: 1.5;
      }
      #vault-card #vault-paywall-account-line,
      #vault-card .vault-paywall-live-status {
        color: #3f5059;
        font-size: 12.5px;
      }
      #vault-card #vault-status-line {
        color: #3d4f65 !important;
        font-size: 11.5px !important;
      }
      #settings-group-overview { order: 9; }
      #indexing-status { order: 10; }
      #backfill-section { order: 15; }
      #search-results-section { order: 20; }
      #search-results-section {
        margin-top: 8px !important;
        padding: 10px 14px !important;
        box-shadow: none;
      }
      #search-results-section h2 {
        margin: 0 !important;
        font-size: 14px !important;
      }
      #settings-group-connections { order: 29; }
      #vault-card { order: 30; }
      #corpus-native-card { order: 40; }
      #local-sessions-card { order: 50; }
      #google-ai-mode-card { order: 55; }
      #settings-group-knowledge { order: 59; }
      #memory-section { order: 60; }
      #starred-section { order: 70; }
      #settings-group-data { order: 79; }
      #backup-restore-section { order: 80; }
      #import-chatgpt-export-section { order: 90; }
      #import-ai-studio-section { order: 91; }
      #settings-group-advanced { order: 99; }
      #report-problem-section { order: 100; }
      #support-section { order: 110; }
      #founding-card { order: 115; }
      #technical-errors-section { order: 120; }
      #corpus-sync-card { order: 125; }
      #danger-zone-section { order: 130; }
      .settings-filter-empty {
        display: none;
        order: 1000;
        margin: 12px 0 18px;
        padding: 18px;
        border: 1px dashed #c6d0b0;
        border-radius: 10px;
        background: #fbfcf7;
        color: #4f6576;
        text-align: center;
      }
      @media (max-width: 620px) {
        .settings-setup-card {
          padding: 16px;
        }
        .settings-setup-grid {
          grid-template-columns: 1fr;
        }
        .settings-nav {
          position: static;
        }
        .settings-search-row {
          align-items: flex-start;
          flex-direction: column;
        }
        .settings-search-wrap {
          flex: 0 0 auto;
          width: 100%;
        }
        #settings-search-status {
          margin-left: 0;
        }
        .settings-group-heading {
          margin-top: 22px;
        }
        .settings-section {
          padding: 15px !important;
        }
        .settings-card-description {
          font-size: 12.5px;
        }
        .settings-status-panel {
          padding: 8px 10px;
        }
        .vault-paywall-actions {
          display: grid;
          grid-template-columns: minmax(0, 1fr);
        }
        .vault-plan-toggle {
          grid-template-columns: minmax(0, 1fr);
          gap: 12px;
        }
        #vault-paywall-cta {
          width: 100%;
        }
        .vault-paywall-utilities {
          align-items: flex-start;
          flex-direction: column;
          gap: 7px;
        }
      }
      @media (prefers-reduced-motion: reduce) {
        .settings-setup-link {
          transition: none;
        }
        .settings-setup-link:hover {
          transform: none;
        }
      }
      #llmnesia-options-root button {
        border-color: ${u.rule} !important;
        border-radius: ${u.rSm} !important;
        background: ${u.card} !important;
        color: ${u.ink2} !important;
        font: inherit;
      }
      #corpus-native-card {
        padding: 0 !important;
      }
      #llmnesia-options-root #corpus-native-enable,
      #llmnesia-options-root #corpus-native-copy-install {
        border-color: #244b32 !important;
        background: #315a3e !important;
        color: #fff !important;
        font-weight: 700 !important;
      }
      #report-problem,
      #founding-join {
        border-color: ${u.teal} !important;
        background: ${u.teal} !important;
        color: #fff !important;
        font-weight: 600 !important;
      }
      /* The pause control is deliberately a text link, not a solid button;
         its inline look needs !important to survive the global button rule. */
      #llmnesia-options-root #toggle-indexing {
        border: none !important;
        background: none !important;
        color: #6b8a5a !important;
      }
      #delete-all,
      #clear-error-logs {
        border-color: #d7b1b1 !important;
        background: #fff4f4 !important;
        color: #7a2626 !important;
      }
      #stats-content,
      #health-status,
      #migration-status,
      #backfill-status-text,
      #pin-status,
      #backup-status,
      #delete-status,
      #recent-limit-status,
      #error-log-status {
        color: ${u.ink3} !important;
        font-family: inherit !important;
        font-size: 12px !important;
        line-height: 1.5 !important;
        letter-spacing: 0 !important;
      }
      #llmnesia-options-root input,
      #llmnesia-options-root select {
        border-color: ${u.rule} !important;
        background: ${u.card} !important;
        color: ${u.ink} !important;
        font: inherit;
      }
      #llmnesia-options-root input[type="number"],
      #llmnesia-options-root select {
        font-family: "IBM Plex Mono", "SF Mono", "Consolas", monospace;
        font-size: 12px;
      }
      .options-stat-card {
        min-width: 0;
        overflow: hidden;
        border: 1px solid ${u.ruleSoft};
        border-left: 3px solid ${u.tealEdge};
        border-radius: ${u.rSm};
        background: ${u.card};
        padding: 8px;
      }
      .options-stat-label {
        color: ${u.ink3};
        font-family: "IBM Plex Mono", "SF Mono", "Consolas", monospace;
        font-size: 9.5px;
        font-weight: 600;
        line-height: 1;
        letter-spacing: 0;
        margin-bottom: 5px;
        text-transform: uppercase;
      }
      .options-stat-value {
        display: block;
        color: #163046;
        font-family: "IBM Plex Mono", "SF Mono", "Consolas", monospace;
        font-size: 16px;
        font-weight: 700;
        line-height: 1.2;
        letter-spacing: -0.01em;
        overflow-wrap: anywhere;
        word-break: break-word;
      }
      /* Pulsing placeholder blocks the stats skeleton is built from. */
      @keyframes stats-skel-pulse {
        0%, 100% { opacity: 0.5; }
        50% { opacity: 1; }
      }
      .stats-skel {
        display: block;
        border-radius: 4px;
        background: ${u.ruleSoft};
        animation: stats-skel-pulse 1.6s ease-in-out infinite;
      }
      @media (prefers-reduced-motion: reduce) {
        .stats-skel { animation: none; }
      }
      .year-card {
        border: 1px solid ${u.ruleSoft};
        border-left: 3px solid ${u.teal};
        border-radius: ${u.rSm};
        background: linear-gradient(180deg, ${u.card} 0%, ${u.tealSoft} 100%);
        padding: 14px 16px;
        margin-bottom: 16px;
      }
      .year-card-head {
        color: ${u.teal};
        font-family: "IBM Plex Mono", "SF Mono", "Consolas", monospace;
        font-size: 10px;
        font-weight: 700;
        letter-spacing: 0.05em;
        text-transform: uppercase;
        margin-bottom: 12px;
      }
      .year-stats {
        display: flex;
        flex-wrap: wrap;
        gap: 26px;
        align-items: flex-end;
      }
      .year-stat-num {
        color: #163046;
        font-size: 26px;
        font-weight: 700;
        line-height: 1;
        letter-spacing: -0.01em;
        font-variant-numeric: tabular-nums;
      }
      .year-stat-label {
        color: ${u.ink3};
        font-size: 11px;
        margin-top: 5px;
      }
      .year-spark {
        margin-top: 16px;
        display: flex;
        gap: 5px;
        align-items: flex-end;
      }
      .year-bar-col {
        flex: 1;
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 5px;
      }
      .year-bar-track {
        width: 100%;
        height: 46px;
        display: flex;
        align-items: flex-end;
      }
      .year-bar {
        width: 100%;
        min-height: 2px;
        border-radius: 3px 3px 2px 2px;
        background: ${u.tealEdge};
      }
      .year-bar.peak {
        background: ${u.teal};
      }
      .year-bar-label {
        color: ${u.ink3};
        font-size: 9px;
        font-variant-numeric: tabular-nums;
      }
      .year-caption {
        margin-top: 11px;
        color: ${u.ink3};
        font-size: 11.5px;
      }
      .year-caption strong {
        color: ${u.ink2};
        font-weight: 600;
      }
      .options-chip {
        display: inline-flex;
        align-items: center;
        max-width: 100%;
        border: 1px solid ${u.ruleSoft};
        border-radius: ${u.rPill};
        background: ${u.paperSoft};
        color: ${u.ink2};
        font-family: "IBM Plex Mono", "SF Mono", "Consolas", monospace;
        font-size: 10.5px;
        font-weight: 700;
        line-height: 1;
        padding: 4px 7px;
        white-space: nowrap;
      }
      .options-result-card {
        border: 1px solid ${u.ruleSoft};
        border-left: 3px solid ${u.tealEdge};
        border-radius: ${u.rSm};
        padding: 8px;
        background: ${u.card};
        width: 100%;
        max-width: 100%;
      }
      .options-memory-card {
        transition: border-color 0.12s ease, box-shadow 0.12s ease;
      }
      .options-memory-card:hover {
        border-left-color: ${u.teal};
        box-shadow: 0 1px 4px rgba(20, 49, 71, 0.07);
      }
      .options-memory-card:hover .memory-view-hint {
        color: ${u.teal};
      }
      .options-card-meta {
        color: ${u.ink3};
        font-family: "IBM Plex Mono", "SF Mono", "Consolas", monospace;
        font-size: 10.5px;
        line-height: 1.35;
        letter-spacing: 0;
      }
      .options-progress-track {
        margin-top: 8px;
        height: 8px;
        border: 1px solid ${u.ruleSoft} !important;
        border-radius: ${u.rPill};
        background: ${u.paperSoft} !important;
        overflow: hidden;
      }
      #backfill-progress-fill {
        background: linear-gradient(90deg, ${u.teal} 0%, #5f9cac 100%) !important;
      }
      /* The two long-running vault walks — uploading the existing corpus, and
         restoring it onto a new device — share one visual language: a calm
         pulsing dot, never a ticking counter. Either can take minutes over
         hundreds of conversations, and a number that visibly climbs turns
         background work into something the user feels obliged to sit and watch.
         Class-based rather than per-id so the second row cost no CSS at all.
         Shipped unconditionally since PV-01: the public store build now reaches
         the sign-in flow, so the walk-dot styles must be there too. */
      @keyframes vault-walk-pulse {
        0%, 100% { opacity: 0.28; }
        50% { opacity: 1; }
      }
      .vault-walk-dot {
        width: 8px;
        height: 8px;
        border-radius: 50%;
        background: ${u.teal};
        flex: 0 0 auto;
      }
      .vault-walk-dot[data-state="running"] {
        animation: vault-walk-pulse 1.8s ease-in-out infinite;
      }
      .vault-walk-dot[data-state="idle"] { background: ${u.tealEdge}; }
      .vault-walk-progress-fill {
        background: linear-gradient(90deg, ${u.teal} 0%, #5f9cac 100%) !important;
      }
      @keyframes vault-status-spin { to { transform: rotate(360deg); } }
      .vault-status-spinner {
        display: inline-block;
        width: 9px;
        height: 9px;
        margin-right: 5px;
        border: 1.5px solid ${u.tealEdge};
        border-top-color: ${u.teal};
        border-radius: 50%;
        vertical-align: -1px;
        animation: vault-status-spin 700ms linear infinite;
      }
      .vault-status-spinner[hidden] { display: none; }
      @media (prefers-reduced-motion: reduce) {
        .vault-walk-dot[data-state="running"] { animation: none; opacity: 0.7; }
        .vault-status-spinner { animation: none; opacity: 0.7; }
      }
      ${vp}
	  ${id}
	  </style>
	  <div id="llmnesia-options-root" style="max-width: 1000px; margin: 30px auto 52px; padding: 0 16px; font: 14px/1.5 'IBM Plex Sans', sans-serif; color: #102030; overflow-x: clip;">
    <div class="settings-header">
      <div style="color: #487852; font-size: 10px; font-weight: 700; letter-spacing: 0.08em; text-transform: uppercase;">Control center</div>
      <div class="settings-title-row">
        <h1 style="margin: 3px 0 8px; font-size: 28px;">LLMnesia Settings</h1>
        <div id="vault-status-pill" data-visible="true" data-condition="checking" data-tone="quiet" data-busy="true">
          <button id="vault-status-pill-button" type="button" aria-expanded="false" aria-controls="vault-status-pill-panel">
            ${ld}
            <span class="settings-vault-label" aria-hidden="true">Vault</span>
            <span id="vault-status-pill-label" aria-live="polite">Checking Vault…</span>
          </button>
          <div id="vault-status-pill-panel" hidden>
            <div class="vault-status-panel-head">
              <span class="vault-status-heading">Vault sync</span>
              <button id="vault-status-pill-sync-now" type="button" aria-label="Sync now" title="Sync now" hidden>Sync now</button>
            </div>
            <div class="vault-status-panel-body"><div id="vault-status-pill-facts"></div></div>
            <div class="vault-status-pill-actions">
              <button id="vault-status-pill-recovery" type="button" hidden></button>
            </div>
          </div>
        </div>
      </div>
      <p style="margin: 0; color: #395063;">Your LLMnesia history stays under your control. Manage search, saved context, connections, and backups here.</p>
      <button id="vault-status-attention" class="vault-status-attention" type="button" hidden></button>
    </div>

    <section class="settings-setup-card" aria-labelledby="settings-setup-title">
      <div class="settings-setup-head">
        <div>
          <div class="settings-setup-eyebrow">Start here</div>
          <h2 id="settings-setup-title" class="settings-setup-title">Setup essentials</h2>
        </div>
        <span style="color: #6a7f90; font-size: 11px;">One-time setup, then mostly hands-off</span>
      </div>
      <p class="settings-setup-description">The most important connections live here so you don’t have to hunt through the page.</p>
      <div class="settings-setup-grid">
        
        <a class="settings-setup-link" data-accent="vault" href="#vault-card">
          <span class="settings-setup-number">1</span>
          <span class="settings-setup-copy"><strong>Protect with Vault</strong><small>Encrypted sync, recovery, and every-device access</small></span>
          <span class="settings-setup-arrow" aria-hidden="true">→</span>
        </a>
        
        <a class="settings-setup-link" data-accent="green" href="#corpus-native-card">
          <span class="settings-setup-number">2</span>
          <span class="settings-setup-copy"><strong>Connect desktop AI</strong><small>MCP setup for Claude, Codex, and more</small></span>
          <span class="settings-setup-arrow" aria-hidden="true">→</span>
        </a>
        <a class="settings-setup-link" data-accent="green" href="#local-sessions-card">
          <span class="settings-setup-number">${oc}</span>
          <span class="settings-setup-copy"><strong>Add local AI sessions</strong><small>Bring Claude Code and Codex chats into search</small></span>
          <span class="settings-setup-arrow" aria-hidden="true">→</span>
        </a>
        <a class="settings-setup-link" data-accent="blue" href="#backup-restore-section">
          <span class="settings-setup-number">${of}</span>
          <span class="settings-setup-copy"><strong>Make a local backup</strong><small>Export before switching devices or profiles</small></span>
          <span class="settings-setup-arrow" aria-hidden="true">→</span>
        </a>
      </div>
    </section>

    <nav class="settings-nav" id="settings-navigation" aria-label="Settings navigation">
      <div class="settings-search-row">
        <label class="settings-search-label" for="settings-search">Find a setting</label>
        <div class="settings-search-wrap">
          <input id="settings-search" type="search" autocomplete="off" spellcheck="false" placeholder="${nf}" />
          <span class="settings-search-key" aria-hidden="true">/</span>
        </div>
      </div>
      <div id="settings-search-status" role="status" aria-live="polite">Showing all settings</div>
      <div class="settings-nav-links">
        <span class="settings-nav-label">Jump to</span>
        <a href="#vault-card" data-settings-nav="vault-card">Vault</a>
        <a href="#corpus-native-card" data-settings-nav="corpus-native-card">MCP</a>
        <a href="#indexing-status" data-settings-nav="indexing-status">Overview</a>
        <a href="#memory-section" data-settings-nav="memory-section">Search &amp; memory</a>
        <a href="#local-sessions-card" data-settings-nav="local-sessions-card">Local sessions</a>
        <a href="#backup-restore-section" data-settings-nav="backup-restore-section">Backup</a>
        <a href="#report-problem-section" data-settings-nav="report-problem-section">Support</a>
        <a href="#danger-zone-section" data-settings-nav="danger-zone-section">Danger zone</a>
      </div>
    </nav>

    <div id="settings-filter-empty" class="settings-filter-empty" role="status">No settings match that search. Try a broader term.</div>

    <div id="settings-group-overview" class="settings-group-heading" data-settings-group-heading="overview">
      <div><strong>Overview</strong><span>Health, search behavior, and indexing progress</span></div>
    </div>
    <div id="settings-group-knowledge" class="settings-group-heading" data-settings-group-heading="knowledge">
      <div><strong>Your knowledge</strong><span>Reusable memories and conversations worth keeping close</span></div>
    </div>
    <div id="settings-group-connections" class="settings-group-heading" data-settings-group-heading="connections">
      <div><strong>Connections</strong><span>Optional sources, local sessions, and desktop AI apps</span></div>
    </div>
    <div id="settings-group-data" class="settings-group-heading" data-settings-group-heading="data">
      <div><strong>Data &amp; recovery</strong><span>Move, restore, and protect your history</span></div>
    </div>
    <div id="settings-group-advanced" class="settings-group-heading" data-settings-group-heading="advanced">
      <div><strong>Help &amp; advanced</strong><span>Support, diagnostics, and sensitive actions</span></div>
    </div>

    <section id="indexing-status" class="settings-section" data-settings-section data-settings-group="overview" data-settings-label="Search health" data-settings-search="overview indexing status search health migration semantic meaning pause refresh" style="border: 1px solid #dbe2cf; border-left: 4px solid #7a9b57; border-radius: 12px; padding: 14px 16px; background: #fafcf4;">
      <div style="display: flex; gap: 8px; justify-content: space-between; align-items: center; flex-wrap: wrap;">
        <h2 style="margin: 0; font-size: 17px;">Indexing status</h2>
        <button id="refresh-stats" type="button" style="padding: 8px 12px; border-radius: 8px; border: 1px solid #c6d0b0; background: #fff; cursor: pointer;">Refresh</button>
      </div>
      <p class="settings-card-description" style="margin: 8px 0 0; color: #4f6576;">See whether your history is captured and ready to search.</p>
      <div id="stats-content" class="settings-status-panel" style="margin-top: 12px; color: #2f4654;">${zl()}</div>
      <div style="margin-top: 10px; display: flex; gap: 14px; flex-wrap: wrap; align-items: baseline;">
        <button id="toggle-indexing" type="button" title="Temporarily stop indexing new conversations, e.g. while you're on a chat you don't want saved. Search still works on what's already indexed." style="padding: 2px 0; border: none; background: none; color: #6b8a5a; font-size: 12.5px; text-decoration: underline; text-underline-offset: 2px; cursor: pointer;">Pause indexing</button>
      </div>
      <div class="settings-subpanel" style="margin-top:12px; padding:12px; border-top:1px dashed #d7dfcb;">
        <div style="font-weight:600; color:#2f4654;">Smarter search — find chats by meaning</div>
        <div id="semantic-coverage" style="color:#4f6576; margin-top:4px;">Search by meaning: checking…</div>
        <div style="display:flex; gap:10px; align-items:center; flex-wrap:wrap; margin-top:8px;">
          
        </div>
        
      </div>
      <div id="health-status" class="settings-status-panel" style="margin-top: 10px; color: #2f4654; overflow-wrap: anywhere; word-break: break-word;"></div>
      <div id="migration-status" class="settings-status-panel" style="display: none; margin-top: 6px; color: #516776; overflow-wrap: anywhere; word-break: break-word;">Migration status: checking...</div>
    </section>

    <section id="google-ai-mode-card" class="settings-section" data-settings-section data-settings-group="connections" data-settings-label="Google AI Mode" data-settings-search="Google AI Mode optional site access permission capture search conversations" style="margin-top: 16px;">
      <div style="display: flex; gap: 10px; justify-content: space-between; align-items: center; flex-wrap: wrap;">
        <h2 style="margin: 0; font-size: 16px;">Google AI Mode</h2>
        <span id="google-ai-mode-state" data-state="checking">Checking...</span>
      </div>
      <p class="settings-card-description" style="margin: 8px 0 0; color: #4f6576; line-height: 1.5;">Optional. Enable this only if you want LLMnesia to save full-page Google AI Mode conversations automatically.</p>
      <div style="display: flex; gap: 10px; align-items: center; flex-wrap: wrap; margin-top: 10px;">
        <button id="google-ai-mode-toggle" class="settings-primary-action" type="button" disabled style="padding: 8px 12px;">Checking access...</button>
        <span id="google-ai-mode-status" role="status" aria-live="polite" style="color: #526771; font-size: 12px;">Google site access is off.</span>
      </div>
      <details style="margin-top: 10px;">
        <summary style="cursor: pointer; font-size: 12px;">Why Chrome asks for Google site access</summary>
        <p style="margin: 7px 0 0; color: #4f6576; font-size: 12px; line-height: 1.55;">Chrome grants access at the Google domain level because it cannot limit a permission to the AI Mode URL parameter. LLMnesia activates conversation capture only on Google Search pages in AI Mode and ignores ordinary searches.</p>
      </details>
    </section>

    <section id="chatgpt-temporary-card" class="settings-section" data-settings-section data-settings-group="connections" data-settings-label="ChatGPT Temporary Chats" data-settings-search="ChatGPT temporary chats save opt in capture anonymous logged out privacy consent viewer" style="margin-top: 16px;">
      <h2 style="margin: 0; font-size: 16px;">ChatGPT Temporary Chats</h2>
      <p class="settings-card-description" style="margin: 8px 0 0; color: #4f6576; line-height: 1.5;">Preserve copies of Temporary Chats in LLMnesia. These chats have no original ChatGPT link and always open in the viewer.</p>
      <div style="display: flex; gap: 10px; align-items: center; flex-wrap: wrap; margin-top: 10px;">
        <label style="display: inline-flex; gap: 8px; align-items: center; cursor: pointer; font-weight: 700; font-size: 13px;">
          <input id="chatgpt-temporary-toggle" type="checkbox" />
          Save ChatGPT Temporary Chats
        </label>
        <span id="chatgpt-temporary-status" role="status" aria-live="polite" style="color: #526771; font-size: 12px;"></span>
      </div>
      <details style="margin-top: 10px;">
        <summary style="cursor: pointer; font-size: 12px;">What enabling this means</summary>
        <p style="margin: 7px 0 0; color: #4f6576; font-size: 12px; line-height: 1.55;">Off by default. Enabling this keeps a copy of each Temporary Chat in LLMnesia while you chat: enabling it preserves a copy in your index, and Vault sync may copy saved records to your other signed-in devices. Turning it off later stops future captures but does not delete copies already saved; delete those from search results as usual.</p>
      </details>
    </section>

    <section id="local-sessions-card" class="settings-section" data-settings-section data-settings-group="connections" data-settings-label="Local sources" data-settings-search="local coding sessions Claude Code Codex ZCode z.ai terminal IDE desktop app helper folder sync import" style="margin-top: 16px; border: 1px solid #ecccb9; border-left: 4px solid #d97757; border-radius: 12px; padding: 14px 16px; background: #fdf6f2;">
      <h2 style="margin: 0 0 10px; font-size: 16px; color: #8a4b2e;">Local coding sessions</h2>
      <p class="settings-card-description" style="margin: 0 0 10px; color: #4f6576;">Bring Claude Code, Codex, and ZCode chats into search. LLMnesia keeps only your prompts and the assistant’s replies—not commands, file reads, or tool output.</p>
      <div id="ls-helper-setup" class="settings-subpanel" style="display: none; margin: 0 0 12px; padding: 12px 14px; border: 1px solid #e6cdbb; border-radius: 10px; background: #fff8f3;">
        <div style="font-weight: 700; color: #315a3e; margin-bottom: 4px;">Recommended: keep all your tools in sync automatically</div>
        <p style="margin: 0 0 8px; color: #4d6254; font-size: 12.5px; line-height: 1.55;">Run one command, restart your browser, then connect the helper. After that, Claude Code, Codex, and ZCode sessions stay up to date without folder picking.</p>
        <div style="display: flex; gap: 8px; align-items: center; flex-wrap: wrap; margin-bottom: 8px;">
          <code id="ls-install-cmd" style="flex: 1 1 260px; min-width: 0; overflow-x: auto; white-space: nowrap; background: #fff; border: 1px solid #e0cdbf; border-radius: 6px; padding: 6px 9px; font-size: 12px; color: #5f4636;">npx -y @llmnesia/local-agent-host@latest</code>
          <button id="ls-copy-install" type="button" style="padding: 6px 12px; border-radius: 7px; border: 1px solid #d97757; background: #fff; color: #8a4b2e; cursor: pointer; font-weight: 600;">Copy</button>
        </div>
        <ol style="margin: 0 0 10px; padding: 0 0 0 18px; color: #4d6254; font-size: 12px; line-height: 1.6;">
          <li>Paste it into ${Rr} and run it (requires <a href="https://nodejs.org/" target="_blank" rel="noopener">a current, security-patched Node.js LTS release</a>).</li>
          <li>${ai}</li>
          <li>Return here and select <strong>Connect helper</strong>.</li>
        </ol>
        <button id="ls-connect" class="settings-primary-action" type="button" style="padding: 8px 12px; border-radius: 8px; border: 1px solid #d97757; background: #fff; color: #8a4b2e; cursor: pointer; font-weight: 600;">Connect helper</button>
        <details style="margin-top: 9px;">
          <summary style="cursor: pointer; font-size: 12px;">What the helper installs</summary>
          <p style="margin: 7px 0 0; color: #5d6f62; font-size: 12px;">One small script in <code>~/.llmnesia</code>, registered with your browser. It reads only Claude Code, Codex, and ZCode session data, has no network access, and keeps everything on this computer.</p>
        </details>
      </div>

      <div class="settings-subpanel" style="margin-top: 12px; padding: 12px 14px; border: 1px solid #eddbcf; border-radius: 10px; background: #fffdfb;">
        <div style="font-weight: 600; color: #8a4b2e; margin-bottom: 2px;">Claude Code</div>
        <p id="ls-hint-claude_code" style="margin: 0 0 8px; color: #6a7f90; font-size: 12px;">Add your local Claude Code sessions to search.</p>
        <div style="display: flex; gap: 8px; flex-wrap: wrap;">
          <button id="ls-choose-claude_code" class="settings-primary-action" type="button" style="padding: 8px 12px; border-radius: 8px; border: 1px solid #d97757; background: #fff; color: #8a4b2e; cursor: pointer; font-weight: 600;">Choose folder</button>
          <button id="ls-copy-path-claude_code" type="button" style="display: none; padding: 8px 12px; border-radius: 8px; border: 1px solid #c6d0b0; background: #fff; color: #3f5568; cursor: pointer;">Copy path</button>
          <button id="ls-rescan-claude_code" type="button" style="display: none; padding: 8px 12px; border-radius: 8px; border: 1px solid #c6d0b0; background: #fff; cursor: pointer;">Rescan for new sessions</button>
          <button id="ls-forget-claude_code" type="button" style="display: none; padding: 8px 12px; border-radius: 8px; border: 1px solid #d7b1b1; background: #fff4f4; color: #7a2626; cursor: pointer;">Forget folder</button>
          <input id="ls-dir-input-claude_code" type="file" webkitdirectory multiple style="display: none;" />
        </div>
        <div id="ls-status-claude_code" class="settings-status-panel" style="margin-top: 10px; color: #2f4654; overflow-wrap: anywhere; word-break: break-word;">Not connected.</div>
      </div>

      <div class="settings-subpanel" style="margin-top: 10px; padding: 12px 14px; border: 1px solid #e0e3e7; border-radius: 10px; background: #fbfbfc;">
        <div style="font-weight: 600; color: #3f4753; margin-bottom: 2px;">Codex</div>
        <p id="ls-hint-codex" style="margin: 0 0 8px; color: #6a7f90; font-size: 12px;">Add your local Codex sessions to search.</p>
        <div style="display: flex; gap: 8px; flex-wrap: wrap;">
          <button id="ls-choose-codex" class="settings-primary-action" type="button" style="padding: 8px 12px; border-radius: 8px; border: 1px solid #98a0ab; background: #fff; color: #3f4753; cursor: pointer; font-weight: 600;">Choose folder</button>
          <button id="ls-copy-path-codex" type="button" style="display: none; padding: 8px 12px; border-radius: 8px; border: 1px solid #c6d0b0; background: #fff; color: #3f5568; cursor: pointer;">Copy path</button>
          <button id="ls-rescan-codex" type="button" style="display: none; padding: 8px 12px; border-radius: 8px; border: 1px solid #c6d0b0; background: #fff; cursor: pointer;">Rescan for new sessions</button>
          <button id="ls-forget-codex" type="button" style="display: none; padding: 8px 12px; border-radius: 8px; border: 1px solid #d7b1b1; background: #fff4f4; color: #7a2626; cursor: pointer;">Forget folder</button>
          <input id="ls-dir-input-codex" type="file" webkitdirectory multiple style="display: none;" />
        </div>
        <div id="ls-status-codex" class="settings-status-panel" style="margin-top: 10px; color: #2f4654; overflow-wrap: anywhere; word-break: break-word;">Not connected.</div>
      </div>

      <div class="settings-subpanel" style="margin-top: 10px; padding: 12px 14px; border: 1px solid #e6c6d0; border-radius: 10px; background: #fdf9fa;">
        <div style="font-weight: 600; color: #732840; margin-bottom: 2px;">ZCode (z.ai)</div>
        <p id="ls-hint-zcode" style="margin: 0 0 8px; color: #6a7f90; font-size: 12px;">Add your local ZCode sessions to search.</p>
        <div style="display: flex; gap: 8px; flex-wrap: wrap;">
          <button id="ls-choose-zcode" class="settings-primary-action" type="button" style="display: none; padding: 8px 12px; border-radius: 8px; border: 1px solid #8c3049; background: #fff; color: #732840; cursor: pointer; font-weight: 600;">Sync now</button>
          <button id="ls-copy-path-zcode" type="button" style="display: none; padding: 8px 12px; border-radius: 8px; border: 1px solid #c6d0b0; background: #fff; color: #3f5568; cursor: pointer;">Copy path</button>
          <button id="ls-rescan-zcode" type="button" style="display: none; padding: 8px 12px; border-radius: 8px; border: 1px solid #c6d0b0; background: #fff; cursor: pointer;">Rescan for new sessions</button>
          <button id="ls-forget-zcode" type="button" style="display: none; padding: 8px 12px; border-radius: 8px; border: 1px solid #d7b1b1; background: #fff4f4; color: #7a2626; cursor: pointer;">Forget folder</button>
          <input id="ls-dir-input-zcode" type="file" webkitdirectory multiple style="display: none;" />
        </div>
        <div id="ls-status-zcode" class="settings-status-panel" style="margin-top: 10px; color: #2f4654; overflow-wrap: anywhere; word-break: break-word;">Not connected.</div>
      </div>

      <div id="ls-brave-help" style="display: none; margin-top: 12px; padding: 10px 12px; border: 1px solid #e6d3c6; border-radius: 8px; background: #fbf1ea; font-size: 12px; color: #5f4636; line-height: 1.55;">
        <strong>Optional, Brave only:</strong> the one-time helper above is the smoothest path (it syncs in the background). But if you'd rather not run a terminal command, you can upgrade <strong>Choose folder</strong> so Brave remembers the folder and rescans on its own. Turn on Brave's File System Access flag — Brave blocks links to its flags page, so:
        <div style="display: flex; gap: 8px; align-items: center; flex-wrap: wrap; margin: 8px 0;">
          <code style="background: #fff; border: 1px solid #e0cdbf; border-radius: 6px; padding: 3px 7px;">brave://flags/#file-system-access-api</code>
          <button id="ls-copy-flag" type="button" style="padding: 5px 10px; border-radius: 7px; border: 1px solid #d0b9a8; background: #fff; cursor: pointer;">Copy address</button>
        </div>
        <ol style="margin: 0 0 0 18px; padding: 0;">
          <li>Paste it into Brave's address bar and press Enter (typing it yourself is the only way — links to it are blocked).</li>
          <li>Set the flag to <strong>Enabled</strong>, then click <strong>Relaunch</strong>.</li>
          <li>Reopen this Settings page — <strong>Choose folder</strong> now remembers your folder and rescans on its own. (If the flag isn't listed, search "File System Access" on that page.)</li>
        </ol>
      </div>
    </section>

    <section id="backfill-section" class="settings-section" data-settings-section data-settings-group="overview" data-settings-label="Import progress" data-settings-search="older chats backfill import progress pause" style="display: none; margin-top: 16px; border: 1px solid #dbe2cf; border-left: 4px solid #c98a2e; border-radius: 12px; padding: 14px 16px; background: #fdf6e8;">
      <h2 style="margin: 0; font-size: 16px;">Indexing older chats</h2>
      <div class="options-progress-track" style="margin-top: 8px; height: 8px; border: 1px solid #cbd9e6; border-radius: 999px; background: #edf3f8; overflow: hidden;">
        <div id="backfill-progress-fill" style="height: 100%; width: 0%; background: linear-gradient(90deg, #2f7f99 0%, #49b08f 100%); transition: width 0.4s ease;"></div>
      </div>
      <div id="backfill-status-text" class="settings-status-panel" style="margin-top: 6px; color: #4f6576;">Working…</div>
      <p style="margin: 8px 0 0; color: #7a8a96; font-size: 13px;">Start or pause imports from the extension popup on a supported AI tab.</p>
    </section>

    <section id="memory-section" class="settings-section" data-settings-section data-settings-group="knowledge" data-settings-label="Reusable context" data-settings-search="memory memories save import ChatGPT Claude auto every new chat" style="margin-top: 16px; border: 1px solid #dbe2cf; border-left: 4px solid #2f7f99; border-radius: 12px; padding: 14px 16px; background: #eef6f8;">
      <div style="display: flex; justify-content: space-between; align-items: center; gap: 8px; flex-wrap: wrap;">
        <h2 style="margin: 0; font-size: 16px;">Memory <span style="font-size: 11px; font-weight: 400; color: #8a7a5a; background: #faf5e4; border: 1px solid #e8dfc0; border-radius: 4px; padding: 2px 6px; vertical-align: middle;">Beta</span></h2>
      </div>
      <p class="settings-card-description" style="margin: 8px 0 0; color: #4f6576;">Save something once, then reuse it in any new AI chat.</p>

      <div id="memory-example-chips" style="margin-top: 12px;">
        <div style="font-weight: 600; color: #2f4419; margin-bottom: 4px;">What should every AI know about you?</div>
        <div style="display: flex; gap: 6px; flex-wrap: wrap;">
          <button type="button" class="memory-example-chip" data-example="I prefer concise, direct answers — skip the preamble and get to the point." style="padding: 6px 12px; border-radius: 999px; border: 1px solid #c3d29a; background: #f5f9e9; color: #2f4419; cursor: pointer; font-size: 12.5px;">How I like answers</button>
          <button type="button" class="memory-example-chip" data-example="My role: e.g. a software engineer working mostly in TypeScript." style="padding: 6px 12px; border-radius: 999px; border: 1px solid #c3d29a; background: #f5f9e9; color: #2f4419; cursor: pointer; font-size: 12.5px;">My role</button>
          <button type="button" class="memory-example-chip" data-example="A project I'm currently working on: e.g. rebuilding our onboarding flow." style="padding: 6px 12px; border-radius: 999px; border: 1px solid #c3d29a; background: #f5f9e9; color: #2f4419; cursor: pointer; font-size: 12.5px;">A current project</button>
          <button type="button" class="memory-example-chip" data-example="A preference: e.g. always write plain TypeScript, no frameworks unless I ask." style="padding: 6px 12px; border-radius: 999px; border: 1px solid #c3d29a; background: #f5f9e9; color: #2f4419; cursor: pointer; font-size: 12.5px;">A coding preference</button>
        </div>
      </div>

      <button id="toggle-add-form" type="button" hidden style="margin-top: 12px; padding: 7px 12px; border-radius: 8px; border: 1px solid #c6d0b0; background: #fff; color: #3f5568; cursor: pointer; font-size: 13px;">+ Add memory</button>

      <div id="memory-add-form-wrap" class="settings-subpanel" style="margin-top: 12px; display: grid; gap: 8px; border: 1px solid #e3e9d6; border-radius: 10px; padding: 12px; background: #fcfdf7;">
        <textarea id="memory-text" placeholder="The memory itself, in your own words (e.g. I prefer concise answers and vanilla TypeScript, no frameworks)." rows="3" style="width: 100%; box-sizing: border-box; padding: 8px; border-radius: 8px; border: 1px solid #c6d0b0; resize: vertical; font-family: inherit;"></textarea>
        <input id="memory-label" type="text" placeholder="Optional label (e.g. Code style) — leave blank to use the start of the memory" style="width: 100%; box-sizing: border-box; padding: 8px; border-radius: 8px; border: 1px solid #c6d0b0; font-family: inherit; font-size: 13px;" />
        <div style="display: flex; gap: 12px; align-items: center; flex-wrap: wrap;">
          <label for="memory-pinned" style="display: inline-flex; align-items: center; gap: 6px; color: #3f5568; cursor: pointer; font-size: 13px;">
            <input id="memory-pinned" type="checkbox" />
            <span>Auto — add to every new chat</span>
          </label>
          <button id="add-memory" class="settings-primary-action" type="button" style="margin-left: auto; padding: 8px 14px; border-radius: 8px; border: 1px solid #9fb37e; background: #eef4dd; color: #2f4419; cursor: pointer; font-weight: 600;">Save memory</button>
        </div>
        <div style="color: #8a97a0; font-size: 11.5px;">Auto memories are added to every new chat automatically, so they use a few tokens. Leave off to keep a memory available to pick from the pill when you want it.</div>
      </div>

      <details style="margin-top: 10px;">
        <summary style="cursor: pointer; color: #4f6576; font-size: 13px; padding: 4px 0;">Already saved in ChatGPT or Claude? Import it instead</summary>
        <div class="settings-subpanel" style="margin-top: 10px; display: grid; gap: 8px; border: 1px solid #c3d29a; border-radius: 10px; padding: 12px; background: #f5f9e9;">
          <div style="font-weight: 600; color: #2f4419;">Paste your exported memory</div>
          <div style="display: flex; gap: 8px; align-items: center; flex-wrap: wrap;">
            <label for="memory-import-platform" style="color: #4f6576; font-size: 13px;">From</label>
            <select id="memory-import-platform" style="flex: 0 1 auto; padding: 8px; border-radius: 8px; border: 1px solid #c6d0b0; background: #fff;">
              <option value="chatgpt">ChatGPT</option>
              <option value="claude">Claude</option>
              <option value="gemini">Gemini</option>
              <option value="copilot">Copilot</option>
              <option value="deepseek">DeepSeek</option>
              <option value="kimi">Kimi</option>
              <option value="generic">Other</option>
            </select>
          </div>
          <div id="memory-import-hint" style="color: #4f6576; font-size: 12px;"></div>
          <textarea id="memory-import-text" rows="5" placeholder="Paste the memory here..." style="width: 100%; box-sizing: border-box; padding: 8px; border-radius: 8px; border: 1px solid #c6d0b0; resize: vertical; font-family: inherit;"></textarea>
          <div style="display: flex; gap: 8px; align-items: center; flex-wrap: wrap;">
            <button id="copy-export-prompt" type="button" style="padding: 8px 12px; border-radius: 8px; border: 1px solid #c6d0b0; background: #fff; cursor: pointer; font-size: 13px;">Copy export prompt</button>
            <button id="import-memory" class="settings-primary-action" type="button" style="margin-left: auto; padding: 8px 16px; border-radius: 8px; border: 1px solid #9fb37e; background: #eef4dd; color: #2f4419; cursor: pointer; font-weight: 600;">Save this memory</button>
          </div>
          <div id="memory-import-status" style="color: #2f4654; font-size: 12px; overflow-wrap: anywhere;"></div>
        </div>
      </details>

      <div id="pending-memory-review" class="settings-subpanel" style="margin-top: 14px; border: 1px solid #d7dfc8; border-radius: 10px; padding: 12px; background: #fbfcf7;">
        <div style="display: flex; justify-content: space-between; align-items: center; gap: 10px; flex-wrap: wrap;">
          <div>
            <h3 style="margin: 0; color: #2f4419; font-size: 14px;">Pending review</h3>
            <p style="margin: 3px 0 0; color: #5f7066; font-size: 12px;">Suggestions from connected assistants stay off until you enable them.</p>
          </div>
          <button id="enable-all-pending-memories" type="button" hidden style="padding: 7px 12px; border-radius: 8px; border: 1px solid #9fb37e; background: #eef4dd; color: #2f4419; cursor: pointer; font-weight: 600; font-size: 12px;">Enable all</button>
        </div>
        <div id="pending-memory-list" style="margin-top: 9px; display: grid; gap: 8px;">Loading suggestions...</div>
      </div>

      <div id="memory-manage-tools" hidden style="margin-top: 12px; display: flex; gap: 8px; align-items: center;">
        <input id="memory-filter" type="text" placeholder="Filter memories..." style="flex: 1 1 200px; min-width: 0; padding: 8px; border-radius: 8px; border: 1px solid #c6d0b0;" />
        <button id="refresh-memories" type="button" style="padding: 8px 12px; border-radius: 8px; border: 1px solid #c6d0b0; background: #fff; cursor: pointer;">Refresh</button>
      </div>
      <div id="memory-list" style="margin-top: 10px; display: grid; gap: 8px; max-height: 420px; overflow-y: auto; overflow-x: hidden; padding-right: 2px;">Loading memories...</div>
      <div id="memory-status" class="settings-status-panel" style="margin-top: 10px; color: #2f4654; overflow-wrap: anywhere;"></div>
    </section>

	    <section id="starred-section" class="settings-section" data-settings-section data-settings-group="knowledge" data-settings-label="Quick access" data-settings-search="starred starred conversations pins favorites quick access cleanup" style="margin-top: 16px; border: 1px solid #dbe2cf; border-left: 4px solid #b8901f; border-radius: 12px; padding: 14px 16px; background: #fdf8e8;">
	      <div style="display: flex; justify-content: space-between; align-items: center; gap: 8px; flex-wrap: wrap;">
	        <h2 style="margin: 0; font-size: 16px;">Starred Conversations</h2>
	        <div style="display: flex; gap: 8px; align-items: center; flex-wrap: wrap;">
	          <label for="pin-only" style="display: inline-flex; align-items: center; gap: 6px; color: #3f5568;">
	            <input id="pin-only" type="checkbox" checked />
	            <span>Starred only</span>
	          </label>
	          <button id="refresh-pins" type="button" style="padding: 8px 12px; border-radius: 8px; border: 1px solid #c6d0b0; background: #fff; cursor: pointer;">Refresh list</button>
	        </div>
	      </div>
	      <p class="settings-card-description" style="margin: 8px 0 0; color: #4f6576;">Star important chats to keep them easy to find.</p>
	      <div style="margin-top: 10px; display: flex; gap: 8px; align-items: center; flex-wrap: wrap;">
	        <input id="pin-filter" type="text" placeholder="Filter by title/platform..." style="flex: 1 1 280px; min-width: 0; padding: 8px; border-radius: 8px; border: 1px solid #c6d0b0;" />
	        <button id="clear-pin-filter" type="button" style="padding: 8px 12px; border-radius: 8px; border: 1px solid #c6d0b0; background: #fff; cursor: pointer;">Clear</button>
	      </div>
	      <div id="pin-list" style="margin-top: 10px; display: grid; gap: 8px; max-height: 420px; overflow-y: auto; overflow-x: hidden; padding-right: 2px;">Loading conversations...</div>
	      <div id="pin-status" class="settings-status-panel" style="margin-top: 10px; color: #2f4654; overflow-wrap: anywhere;">Star a chat to keep it close. Unstar it to remove the mark.</div>
	    </section>

    <section id="search-results-section" class="settings-section" data-settings-section data-settings-group="overview" data-settings-label="Search display" data-settings-search="search results matches limit performance speed" style="margin-top: 8px; border: 1px solid #dbe2cf; border-left: 4px solid #7a8a96; border-radius: 12px; padding: 10px 14px; background: #f7f9fa;">
      <div style="display: flex; align-items: center; justify-content: space-between; gap: 10px; flex-wrap: wrap;">
        <div>
          <h2>Search results</h2>
          <div style="margin-top: 1px; color: #637785; font-size: 11.5px;">Also available in the main search window.</div>
        </div>
        <label for="recent-limit" style="display: inline-flex; align-items: center; gap: 7px; color: #385066; font-size: 12px; white-space: nowrap;">
          <span>Max results</span>
          <select id="recent-limit" aria-label="Maximum search results" style="padding: 5px 8px; border-radius: 7px; border: 1px solid #c6d0b0; background: #fff; min-width: 74px;">
          <option value="30">30</option>
          <option value="50">50</option>
          <option value="100">100</option>
          <option value="250">250</option>
          <option value="500">500</option>
        </select>
        </label>
      </div>
      <div id="recent-limit-status" style="margin-top: 4px; color: #637785; font-size: 11.5px;">Applies to recent and typed searches.</div>
    </section>

    

    <section id="report-problem-section" class="settings-section" data-settings-section data-settings-group="advanced" data-settings-label="Help" data-settings-search="report problem support contact diagnostics snapshot search misses indexing stops" style="margin-top: 16px; border: 1px solid #dbe2cf; border-left: 4px solid #c26a2e; border-radius: 12px; padding: 16px 18px; background: #fdf3ea;">
      <h2 style="margin: 0 0 10px; font-size: 16px;">Report a Problem</h2>
      <p class="settings-card-description" style="margin: 0 0 12px; color: #4f6576; line-height: 1.5;">Open the contact form with a pre-filled report when chats are missing or indexing stops.</p>
      <div class="settings-actions" style="display: flex; gap: 10px; align-items: center; flex-wrap: wrap;">
        <button id="report-problem" class="settings-primary-action" type="button" style="padding: 8px 14px; border-radius: 8px; border: 1px solid #2f7f99; background: #2f7f99; color: #fff; cursor: pointer; font-weight: 600;">Report a problem</button>
        <label style="display: flex; align-items: center; gap: 6px; font-size: 12px; color: #4e6578; cursor: pointer;">
          <input id="options-snapshot-toggle" type="checkbox" checked />
          Include diagnostic snapshot (no message text)
        </label>
      </div>
      <p style="margin: 9px 0 0; font-size: 11.5px; color: #65766a; line-height: 1.5;">You can edit everything before submitting. The snapshot is structural only: no message text and no URLs.</p>
      <details style="margin-top: 10px;">
        <summary style="cursor: pointer;">Try quick fixes first</summary>
        <p style="margin: 7px 0 0; color: #526771; font-size: 12px;">Refresh the AI page, re-enable its site permission, and check the <a href="https://github.com/nicholasgriffintn/llmnesia#supported-sites" target="_blank" rel="noopener">supported sites list</a>.</p>
      </details>
    </section>

    <section id="backup-restore-section" class="settings-section" data-settings-section data-settings-group="data" data-settings-label="Local recovery" data-settings-search="backup restore export import file device browser profile local" style="margin-top: 16px; border: 1px solid #dbe2cf; border-left: 4px solid #3d6fa8; border-radius: 12px; padding: 14px 16px; background: #eef4fb;">
      <h2 style="margin: 0 0 10px; font-size: 16px;">Backup & Restore</h2>
      <p class="settings-card-description" style="margin: 0 0 10px; color: #4f6576;">Download a backup before switching devices or browser profiles. Import brings one back.</p>
      <div class="settings-actions" style="display: flex; gap: 8px; flex-wrap: wrap; align-items: center;">
        <button id="export-backup" class="settings-primary-action" type="button" style="padding: 8px 12px; border-radius: 8px; border: 1px solid #c6d0b0; background: #fff; cursor: pointer;">Export backup</button>
        <button id="import-backup" type="button" style="padding: 8px 12px; border-radius: 8px; border: 1px solid #c6d0b0; background: #fff; cursor: pointer;">Import backup</button>
        <button id="import-backup-cancel" type="button" style="display: none; padding: 8px 12px; border-radius: 8px; border: 1px solid #d5b0b0; background: #fff; color: #a23c3c; cursor: pointer;">Stop</button>
        <input id="import-backup-file" type="file" accept=".jsonl,.jsonl.gz,.json,application/json,application/gzip" style="display: none;" />
      </div>
      <progress id="backup-progress" max="100" value="0" style="display: none; width: 100%; height: 10px; margin-top: 10px;"></progress>
      <div id="backup-status" class="settings-status-panel" style="margin-top: 10px; color: #2f4654; overflow-wrap: anywhere; word-break: break-word;">No backup action yet.</div>
      <div style="margin-top: 14px; padding-top: 12px; border-top: 1px solid #dbe2cf;">
        <h3 style="margin: 0 0 6px; font-size: 13.5px;">Automatic daily backup (opt-in)</h3>
        <p style="margin: 0 0 8px; color: #4f6576; font-size: 12.5px; line-height: 1.45;">
          Keep up to 3 verified backup versions inside this Chrome profile, refreshed about once a day.
          The newest backup is only kept after its checksum verifies; a failed write never touches the
          previous versions. Because the copies live inside the browser profile, they do not protect
          against a full disk, a wiped profile, or drive failure: use <strong>Export backup</strong> for
          a copy outside the browser.
        </p>
        <label style="display: flex; align-items: center; gap: 8px; margin-bottom: 8px; cursor: pointer;">
          <input id="rolling-backup-enabled" type="checkbox" style="cursor: pointer;" />
          <span style="font-size: 12.5px;">Back up my chats automatically (daily)</span>
        </label>
        <div class="settings-actions" style="display: flex; gap: 8px; flex-wrap: wrap; align-items: center;">
          <button id="rolling-backup-now" type="button" style="padding: 8px 12px; border-radius: 8px; border: 1px solid #c6d0b0; background: #fff; cursor: pointer;">Back up now</button>
          <button id="rolling-backup-restore" type="button" style="padding: 8px 12px; border-radius: 8px; border: 1px solid #c6d0b0; background: #fff; cursor: pointer;">Restore from latest backup</button>
        </div>
        <div id="rolling-backup-status" class="settings-status-panel" style="margin-top: 10px; color: #2f4654; overflow-wrap: anywhere; word-break: break-word;">Automatic backups are off.</div>
      </div>
    </section>

    <section id="import-chatgpt-export-section" class="settings-section" data-settings-section data-settings-group="data" data-settings-label="Complete history" data-settings-search="ChatGPT history export data controls zip import older chats" style="margin-top: 16px; border: 1px solid #dbe2cf; border-left: 4px solid #3d6fa8; border-radius: 12px; padding: 14px 16px; background: #eef4fb;">
      <h2 style="margin: 0 0 10px; font-size: 16px;">Import your full ChatGPT history</h2>
      <p class="settings-card-description" style="margin: 0 0 10px; color: #4f6576;">Import ChatGPT’s data-export <code>.zip</code> for the most complete copy of older chats. Existing chats are not duplicated.</p>
      <div class="settings-actions" style="display: flex; gap: 8px; flex-wrap: wrap; align-items: center;">
        <button id="import-chatgpt-export" class="settings-primary-action" type="button" style="padding: 8px 12px; border-radius: 8px; border: 1px solid #c6d0b0; background: #fff; cursor: pointer;">Choose ChatGPT export .zip</button>
        <button id="import-chatgpt-export-cancel" type="button" style="display: none; padding: 8px 12px; border-radius: 8px; border: 1px solid #d5b0b0; background: #fff; color: #a23c3c; cursor: pointer;">Stop</button>
        <input id="import-chatgpt-export-file" type="file" accept=".zip,application/zip" style="display: none;" />
      </div>
      <progress id="chatgpt-export-progress" max="100" value="0" style="display: none; width: 100%; height: 10px; margin-top: 10px;"></progress>
      <div id="chatgpt-export-status" class="settings-status-panel" style="margin-top: 10px; color: #2f4654; overflow-wrap: anywhere; word-break: break-word;">No import yet.</div>
      <details style="margin-top: 10px;">
        <summary style="cursor: pointer;">How to get the export file</summary>
        <p style="margin: 7px 0 0; color: #526771; font-size: 12px;">In ChatGPT, open <strong>Settings → Data controls → Export data</strong>. ChatGPT emails the file later—usually within a few hours, but occasionally after a day or two. LLMnesia reads only the chat text.</p>
      </details>
    </section>

    ${Dp}
    ${Wp}

    

    <section id="technical-errors-section" class="settings-section" data-settings-section data-settings-group="advanced" data-settings-label="Diagnostics" data-settings-search="technical error log errors adapter logs export clear diagnostics google ai mode import retry report missing older messages" style="margin-top: 16px; border: 1px solid #dbe2cf; border-left: 4px solid #9a6b6b; border-radius: 12px; padding: 12px 16px; background: #faf5f5;">
      <div style="display: flex; justify-content: space-between; align-items: center; gap: 8px; flex-wrap: wrap;">
        <h2 style="margin: 0; font-size: 14px;">Technical error log</h2>
        <div style="display: flex; gap: 8px; flex-wrap: wrap;">
          <button id="refresh-error-logs" type="button" style="padding: 8px 12px; border-radius: 8px; border: 1px solid #c6d0b0; background: #fff; cursor: pointer;">Refresh logs</button>
          <button id="copy-error-logs" type="button" style="padding: 8px 12px; border-radius: 8px; border: 1px solid #c6d0b0; background: #fff; cursor: pointer;">Copy logs</button>
          <button id="export-error-logs" type="button" style="padding: 8px 12px; border-radius: 8px; border: 1px solid #c6d0b0; background: #fff; cursor: pointer;">Export JSON</button>
          <button id="clear-error-logs" type="button" style="padding: 8px 12px; border-radius: 8px; border: 1px solid #d7b1b1; background: #fff4f4; color: #7a2626; cursor: pointer;">Clear logs</button>
        </div>
      </div>
      <p class="settings-card-description" style="margin: 8px 0 0; color: #4f6576;">For troubleshooting and bug reports. You can ignore this unless support asks for it.</p>
      <div style="margin-top: 12px;">
        <strong style="font-size: 13px;">Last adapter errors</strong>
        <div id="adapter-errors-list" style="margin-top: 6px; display: grid; gap: 4px; min-width: 0; color: #2f4654;">No adapter errors recorded.</div>
      </div>
      <div id="error-log-status" class="settings-status-panel" style="margin-top: 12px; color: #2f4654; overflow-wrap: anywhere;">Captures recent extension errors automatically.</div>
      <div id="error-log-list" style="margin-top: 10px; display: grid; gap: 8px; max-height: 320px; overflow-y: auto; overflow-x: hidden; padding-right: 2px;">Loading error logs...</div>
      <details style="margin-top: 16px; border-top: 1px solid #ecdcdc; padding-top: 12px;">
        <summary style="cursor: pointer; font-size: 13px;">Google AI Mode imports</summary>
        <p class="settings-card-description" style="margin: 8px 0 10px; color: #4f6576;">Missing older messages in a Google chat? Retry it here. Google may not return everything.</p>
        <label for="google-import-retry-filter" style="display: block; font-size: 12px; color: #4f6576;">Chat to retry</label>
        <input id="google-import-retry-filter" type="search" placeholder="Search by title or ID" autocomplete="off" style="display: block; width: 100%; box-sizing: border-box; margin: 6px 0; padding: 8px 10px; font: inherit; font-size: 12px;" />
        <select id="google-import-retry-chat" size="7" aria-label="Google chats available to retry" style="display: block; width: 100%; max-width: 100%; box-sizing: border-box; margin: 0; padding: 4px; font: inherit; font-size: 12px;" disabled></select>
        <div id="google-import-retry-detail" style="margin: 6px 0 10px; color: #637785; font-size: 12px; overflow-wrap: anywhere;"></div>
        <div style="display: flex; gap: 8px; flex-wrap: wrap;">
          <button id="refresh-google-import-chats" type="button" style="padding: 8px 12px; border-radius: 8px; border: 1px solid #c6d0b0; background: #fff; cursor: pointer;">Refresh list</button>
          <button id="retry-google-import-chat" type="button" style="padding: 8px 12px; border-radius: 8px; border: 1px solid #c6d0b0; background: #fff; cursor: pointer;" disabled>Retry chat</button>
        </div>
        <div id="google-import-retry-status" role="status" style="margin-top: 8px;"></div>
        <p style="margin: 8px 0 0; color: #637785; font-size: 12px;">Keep a Google AI Mode tab open. Follow progress or stop a retry from the LLMnesia toolbar icon.</p>
        <div style="margin-top: 14px; padding-top: 12px; border-top: 1px dashed #d9c7c7;">
          <button id="export-google-import-report" type="button" style="padding: 8px 12px; border-radius: 8px; border: 1px solid #c6d0b0; background: #fff; cursor: pointer;">Export import report</button>
          <span style="margin-left: 8px; color: #637785; font-size: 12px;">Titles, chat IDs and message counts only. No message text.</span>
          <div id="google-import-report-status" role="status" style="margin-top: 8px;"></div>
        </div>
      </details>
    </section>

    ${`
    <section id="vault-card" class="settings-section" data-settings-section data-settings-group="connections" data-settings-search="Vault encrypted sync backup recovery passphrase email device restore lock subscription billing payment invoice cancellation" style="margin-top: 16px; border: 1px solid ${u.tealEdge}; border-left: 4px solid ${u.teal}; border-radius: 12px; padding: 14px 16px; background: ${u.tealSoft};">
      <div class="vault-card-header">
        <div class="vault-card-kicker-row">
          <span class="vault-card-badge">Vault</span>
          <span class="vault-card-encryption-note">End-to-end encrypted</span>
        </div>
        <h2 class="vault-card-title">Keep your history safe on every device</h2>
        <p class="vault-card-description">Vault keeps an encrypted copy of your conversations and memories, ready to restore on a new device and stay in sync wherever you work.</p>
        <div class="vault-card-flow" role="group" aria-label="Your conversations are encrypted in Vault and available only on your devices">
          <strong>Your conversations</strong>
          <span class="vault-card-flow-arrow" aria-hidden="true">→</span>
          <span class="vault-card-flow-vault">Encrypted Vault</span>
          <span class="vault-card-flow-arrow" aria-hidden="true">→</span>
          <strong>Your devices</strong>
        </div>
        <p class="vault-card-trust-note">Only your devices can decrypt your data. LLMnesia cannot read your conversations.</p>
      </div>
      <div class="vault-card-body">
      <p class="vault-card-privacy"><strong>Your passphrase stays private.</strong> LLMnesia cannot recover a lost passphrase, so you stay in control of your encrypted history.</p>
      <div id="vault-signin-success" class="vault-signin-success" role="status" aria-live="polite"></div>

      <div id="vault-signed-out" style="display: none;">
        <p style="margin: 0 0 8px; color: #3d5f6c; font-size: 12.5px;">New to Vault? Enter the email you want to use and we will send a sign-in code. Already subscribed on the website? Use the email you used at checkout.</p>
        <p style="margin: 0 0 10px; color: #5b7683; font-size: 12px; line-height: 1.5;">Already have a Vault on another device or browser? Continue with the email address it was created under, then unlock it here with the same passphrase. You won't create a second Vault.</p>
        <div style="display: flex; gap: 8px; flex-wrap: wrap;">
          <input id="vault-email" type="email" aria-label="Vault email address" autocomplete="email" placeholder="you@example.com" style="flex: 1; min-width: 200px; padding: 8px 10px; border-radius: 8px;" />
          <button id="vault-send-code" type="button" style="padding: 8px 12px; border-radius: 8px; border: 1px solid ${u.teal}; background: ${u.teal}; color: #fff; cursor: pointer; font-weight: 600;">Continue with email</button>
        </div>
      </div>

      <div id="vault-code-step" style="display: none;">
        <p style="margin: 0 0 8px; color: #3d5f6c;">Check <strong id="vault-code-email"></strong> for your sign-in code, including your spam folder. Use the code from the most recent email.</p>
        <div style="display: flex; gap: 8px; flex-wrap: wrap;">
          <input id="vault-code" type="text" aria-label="Vault sign-in code" inputmode="numeric" autocomplete="one-time-code" placeholder="8-digit code" style="width: 140px; padding: 8px 10px; border-radius: 8px;" />
          <button id="vault-verify-code" type="button" style="padding: 8px 12px; border-radius: 8px; border: 1px solid ${u.teal}; background: ${u.teal}; color: #fff; cursor: pointer; font-weight: 600;">Confirm email</button>
          <button id="vault-resend-code" type="button" style="padding: 8px 12px; border-radius: 8px; border: 1px solid ${u.tealEdge}; background: #fff; cursor: pointer;">Resend</button>
          <button id="vault-cancel-code" type="button" style="padding: 8px 12px; border-radius: 8px; border: 1px solid ${u.tealEdge}; background: #fff; cursor: pointer;">Use a different email</button>
        </div>
      </div>

      <div id="vault-create-step" style="display: none;">
        <p style="margin: 0 0 8px; color: #3d5f6c;"><strong>Create your private passphrase.</strong> It is separate from your email code, stays on your device, and cannot be reset by LLMnesia.</p>
        <div style="display: flex; gap: 8px; flex-wrap: wrap; margin-bottom: 6px;">
          <input id="vault-new-passphrase" type="password" placeholder="Passphrase" spellcheck="false" autocapitalize="off" autocorrect="off" style="flex: 1; min-width: 180px; padding: 8px 10px; border-radius: 8px;" />
          <button id="vault-new-passphrase-visibility" type="button" aria-controls="vault-new-passphrase" aria-pressed="false" aria-label="Show passphrase" style="${Xe}">Show</button>
          <input id="vault-confirm-passphrase" type="password" placeholder="Confirm passphrase" spellcheck="false" autocapitalize="off" autocorrect="off" style="flex: 1; min-width: 180px; padding: 8px 10px; border-radius: 8px;" />
          <button id="vault-confirm-passphrase-visibility" type="button" aria-controls="vault-confirm-passphrase" aria-pressed="false" aria-label="Show confirm passphrase" style="${Xe}">Show</button>
        </div>
        <div id="vault-passphrase-strength" style="margin: 0 0 10px; font-size: 11.5px; color: #5b7683;"></div>
        <button id="vault-create-continue" type="button" style="padding: 8px 12px; border-radius: 8px; border: 1px solid ${u.teal}; background: ${u.teal}; color: #fff; cursor: pointer; font-weight: 600;">Continue to recovery key</button>

        <div id="vault-recovery-key-block" style="display: none; margin-top: 14px; padding: 12px 14px; border: 1px solid ${u.tealEdge}; border-radius: 10px; background: #fff;">
          <div style="font-weight: 600; color: #1c5a6e; margin-bottom: 6px;">Save your recovery key</div>
          <p style="margin: 0 0 8px; color: #3d5f6c; font-size: 12.5px; line-height: 1.55;">Store this somewhere safe. It is the only way to regain access if you forget your passphrase.</p>
          <div style="display: flex; gap: 8px; align-items: center; flex-wrap: wrap; margin-bottom: 10px;">
            <code id="vault-recovery-key" style="flex: 1 1 260px; min-width: 0; overflow-wrap: anywhere; white-space: normal; background: ${u.paperSoft}; border: 1px solid ${u.ruleSoft}; border-radius: 6px; padding: 8px 10px; font-size: 12.5px; letter-spacing: 0.02em;"></code>
            <button id="vault-copy-recovery" type="button" style="padding: 6px 12px; border-radius: 7px; border: 1px solid ${u.teal}; background: #fff; color: #1c5a6e; cursor: pointer; font-weight: 600;">Copy</button>
          </div>
          <label style="display: flex; gap: 8px; align-items: flex-start; font-size: 12.5px; color: #3d5f6c; cursor: pointer;">
            <input id="vault-ack-checkbox" type="checkbox" style="margin-top: 2px;" />
            <span>I've saved this recovery key somewhere safe. If I lose both my passphrase and this key, my data cannot be recovered.</span>
          </label>
          <button id="vault-confirm-create" type="button" disabled style="margin-top: 10px; padding: 8px 12px; border-radius: 8px; border: 1px solid ${u.teal}; background: ${u.teal}; color: #fff; cursor: pointer; font-weight: 600; opacity: 0.5;">Finish setting up Vault</button>
        </div>
      </div>

      <div id="vault-unlock-step" style="display: none;">
        <p id="vault-unlock-copy" style="margin: 0 0 8px; color: #3d5f6c; font-size: 12.5px;">You already have a Vault for this email. Enter its passphrase to open it on this device.</p>
        <div id="vault-biometric-unlock" style="display: none; margin: 0 0 10px;">
          <button id="vault-biometric-unlock-btn" type="button" style="padding: 8px 12px; border-radius: 8px; border: 1px solid ${u.teal}; background: ${u.teal}; color: #fff; cursor: pointer; font-weight: 600;">Unlock with biometrics</button>
          <div style="display: inline-block; margin: 0 8px; color: #5b7683; font-size: 12px;">or use your passphrase</div>
        </div>
        <div style="display: flex; gap: 8px; flex-wrap: wrap;">
          <input id="vault-unlock-passphrase" type="password" placeholder="Your private passphrase" spellcheck="false" autocapitalize="off" autocorrect="off" style="flex: 1; min-width: 180px; padding: 8px 10px; border-radius: 8px;" />
          <button id="vault-unlock-passphrase-visibility" type="button" aria-controls="vault-unlock-passphrase" aria-pressed="false" aria-label="Show passphrase" style="${Xe}">Show</button>
          <button id="vault-unlock-btn" type="button" style="padding: 8px 12px; border-radius: 8px; border: 1px solid ${u.teal}; background: ${u.teal}; color: #fff; cursor: pointer; font-weight: 600;">Unlock Vault</button>
        </div>
        <button id="vault-recover-toggle" type="button" style="margin-top: 12px; padding: 0; border: 0; background: none; color: #1c5a6e; text-decoration: underline; cursor: pointer;">Forgot passphrase? Use recovery key</button>
        <div id="vault-recover-form" style="display: none; margin-top: 12px; padding: 12px 14px; border: 1px solid ${u.tealEdge}; border-radius: 10px; background: #fff;">
          <p style="margin: 0 0 10px; color: #3d5f6c; font-size: 12.5px; line-height: 1.55;">Enter the recovery key you saved when creating this Vault, then choose a new passphrase. The key has 14 dash-separated groups: 13 groups of four symbols and a final group of three. Keep the key private. Recovery requires an internet connection.</p>
          <label for="vault-recover-key" style="display: block; margin-bottom: 4px; font-size: 12.5px; font-weight: 600;">Recovery key</label>
          <input id="vault-recover-key" type="password" autocomplete="off" spellcheck="false" style="box-sizing: border-box; width: 100%; padding: 8px 10px; margin-bottom: 8px;" />
          <button id="vault-recover-show-key" type="button" style="margin-bottom: 10px; padding: 0; border: 0; background: none; color: #1c5a6e; text-decoration: underline; cursor: pointer;">Show recovery key</button>
          <label for="vault-recover-passphrase" style="display: block; margin-bottom: 4px; font-size: 12.5px; font-weight: 600;">New passphrase</label>
          <div style="display: flex; gap: 8px; align-items: stretch; margin-bottom: 10px;">
            <input id="vault-recover-passphrase" type="password" autocomplete="new-password" spellcheck="false" autocapitalize="off" autocorrect="off" style="flex: 1; min-width: 0; box-sizing: border-box; padding: 8px 10px;" />
            <button id="vault-recover-passphrase-visibility" type="button" aria-controls="vault-recover-passphrase" aria-pressed="false" aria-label="Show new passphrase" style="${Xe}">Show</button>
          </div>
          <label for="vault-recover-confirm" style="display: block; margin-bottom: 4px; font-size: 12.5px; font-weight: 600;">Confirm new passphrase</label>
          <div style="display: flex; gap: 8px; align-items: stretch; margin-bottom: 10px;">
            <input id="vault-recover-confirm" type="password" autocomplete="new-password" spellcheck="false" autocapitalize="off" autocorrect="off" style="flex: 1; min-width: 0; box-sizing: border-box; padding: 8px 10px;" />
            <button id="vault-recover-confirm-visibility" type="button" aria-controls="vault-recover-confirm" aria-pressed="false" aria-label="Show confirm new passphrase" style="${Xe}">Show</button>
          </div>
          <div><button id="vault-recover-submit" type="button" style="padding: 8px 12px; border-radius: 8px; border: 1px solid ${u.teal}; background: ${u.teal}; color: #fff; cursor: pointer; font-weight: 600;">Reset passphrase and unlock</button></div>
        </div>
      </div>

      <div id="vault-unlocked-panel" style="display: none;">
        <div class="vault-ready-card">
          <span class="vault-ready-icon" aria-hidden="true">✓</span>
          <div class="vault-ready-content">
            <div class="vault-ready-kicker">Vault connected</div>
            <h3 class="vault-ready-title">Your Vault is unlocked</h3>
            <div id="vault-account-line"></div>
            <div class="vault-ready-badges" aria-label="Vault status">
              <span class="vault-ready-badge">Subscription active</span>
              <span class="vault-ready-badge">Unlocked on this device</span>
            </div>
          </div>
        </div>
        <div class="vault-sync-summary">
          <div id="vault-sync-line"><span id="vault-sync-spinner" class="vault-status-spinner" aria-hidden="true" hidden></span><span id="vault-sync-text"></span></div>
          <div id="vault-sync-error-line" style="display: none; color: #7a2626;"></div>
          <div id="vault-auto-sync-note">Sync is automatic. Vault keeps this device up to date in the background.</div>
        </div>
        <div id="vault-join-devices-line">To use this Vault on another device or browser, sign in there with this email and unlock it with the same passphrase.</div>
        <div id="vault-phone-pair-card" style="display: none; margin-top: 12px; border: 1px solid #cfdcd4; border-radius: 12px; background: linear-gradient(160deg, #f4f9f6 0%, #eef4f8 100%); padding: 12px; gap: 12px; align-items: center; flex-wrap: wrap;">
          <div id="vault-phone-pair-qr" style="flex: 0 0 auto; line-height: 0;"></div>
          <div style="flex: 1 1 200px; min-width: 0;">
            <strong style="display: block; color: #1d3a2b; font-size: 13.5px;">Take your archive to your phone</strong>
            <p style="margin: 4px 0 0; color: #4c6355; font-size: 12px; line-height: 1.5;">Scan with your phone's camera to open the Vault web app with your email already filled in. Enter your passphrase once there, then turn on Face ID or fingerprint for one-tap return.</p>
            <a href="https://vault.llmnesia.com" target="_blank" rel="noopener noreferrer" style="display: inline-block; margin-top: 6px; color: #2b6588; font-size: 12px;">vault.llmnesia.com &rarr;</a>
          </div>
        </div>
        <div id="vault-firstsync-row" style="margin-top: 8px; display: none; align-items: center; gap: 8px; flex-wrap: wrap;">
          <span id="vault-firstsync-dot" class="vault-walk-dot" data-state="idle"></span>
          <span id="vault-firstsync-text" style="color: #5b7683; font-size: 12.5px; flex: 1 1 240px; min-width: 0;"></span>
          <button id="vault-firstsync-btn" type="button" style="padding: 6px 12px; border-radius: 8px; border: 1px solid ${u.teal}; background: ${u.teal}; color: #fff; cursor: pointer; font-weight: 600; font-size: 12.5px;"></button>
        </div>
        <div id="vault-firstsync-progress" style="display: none; margin-top: 6px;">
          <div class="options-progress-track">
            <div id="vault-firstsync-progress-fill" class="vault-walk-progress-fill" style="height: 100%; width: 0%; transition: width 220ms ease;"></div>
          </div>
        </div>
        <div id="vault-backup-row" style="margin-top: 8px; display: none; align-items: center; gap: 8px; flex-wrap: wrap;">
          <span id="vault-backup-dot" class="vault-walk-dot" data-state="idle"></span>
          <span id="vault-backup-text" style="color: #5b7683; font-size: 12.5px; flex: 1 1 240px; min-width: 0;"></span>
          <button id="vault-backup-btn" type="button" style="padding: 6px 12px; border-radius: 8px; border: 1px solid ${u.teal}; background: ${u.teal}; color: #fff; cursor: pointer; font-weight: 600; font-size: 12.5px;"></button>
        </div>
        <div id="vault-backup-progress" style="display: none; margin-top: 6px;">
          <div class="options-progress-track">
            <div id="vault-backup-progress-fill" class="vault-walk-progress-fill" style="height: 100%; width: 0%; transition: width 220ms ease;"></div>
          </div>
        </div>
        <div id="vault-restore-row" style="margin-top: 8px; display: none; align-items: center; gap: 8px; flex-wrap: wrap;">
          <span id="vault-restore-dot" class="vault-walk-dot" data-state="idle"></span>
          <span id="vault-restore-text" style="color: #5b7683; font-size: 12.5px; flex: 1 1 240px; min-width: 0;"></span>
          <button id="vault-restore-btn" type="button" style="padding: 6px 12px; border-radius: 8px; border: 1px solid ${u.teal}; background: #fff; color: #1c5a6e; cursor: pointer; font-weight: 600; font-size: 12.5px;"></button>
        </div>
        <div id="vault-restore-progress" style="display: none; margin-top: 6px;">
          <div class="options-progress-track">
            <div id="vault-restore-progress-fill" class="vault-walk-progress-fill" style="height: 100%; width: 0%; transition: width 220ms ease;"></div>
          </div>
        </div>
        <div id="vault-incoming-row" style="margin-top: 8px; display: none; align-items: center; gap: 8px; flex-wrap: wrap;">
          <span id="vault-incoming-dot" class="vault-walk-dot" data-state="running"></span>
          <span id="vault-incoming-text" style="color: #5b7683; font-size: 12.5px; flex: 1 1 240px; min-width: 0;"></span>
        </div>
        <div id="vault-incoming-progress" style="display: none; margin-top: 6px;">
          <div class="options-progress-track">
            <div id="vault-incoming-progress-fill" class="vault-walk-progress-fill" style="height: 100%; width: 0%; transition: width 220ms ease;"></div>
          </div>
        </div>
        <details style="margin-top: 10px; color: #3d5f6c; font-size: 12.5px;">
          <summary style="cursor: pointer;">Manage Vault</summary>
          <p style="margin: 8px 0 0;">Manage billing, invoices, or cancellation securely through Stripe.</p>
          <div style="margin-top: 8px; display: flex; gap: 8px; flex-wrap: wrap;">
            <button id="vault-manage-subscription-btn" class="vault-manage-btn vault-manage-btn--primary" type="button">Manage subscription</button>
            <button id="vault-lock-btn" class="vault-manage-btn" type="button">Lock Vault</button>
            <button id="vault-biometric-toggle" class="vault-manage-btn" type="button">Enable biometric unlock</button>
            <button id="vault-change-passphrase-toggle" class="vault-manage-btn" type="button">Change passphrase</button>
            <button id="vault-sign-out-btn" class="vault-manage-btn vault-manage-btn--danger" type="button">Sign out</button>
          </div>
        <div id="vault-change-passphrase-form" style="display: none; margin-top: 12px; padding: 12px 14px; border: 1px solid ${u.tealEdge}; border-radius: 10px; background: #fff;">
          <div style="display: flex; gap: 8px; flex-wrap: wrap; margin-bottom: 8px;">
            <input id="vault-old-passphrase" type="password" placeholder="Current passphrase" spellcheck="false" autocapitalize="off" autocorrect="off" style="flex: 1; min-width: 160px; padding: 8px 10px; border-radius: 8px;" />
            <button id="vault-old-passphrase-visibility" type="button" aria-controls="vault-old-passphrase" aria-pressed="false" aria-label="Show current passphrase" style="${Xe}">Show</button>
          </div>
          <div style="display: flex; gap: 8px; flex-wrap: wrap; margin-bottom: 8px;">
            <input id="vault-newer-passphrase" type="password" placeholder="New passphrase" spellcheck="false" autocapitalize="off" autocorrect="off" style="flex: 1; min-width: 160px; padding: 8px 10px; border-radius: 8px;" />
            <button id="vault-newer-passphrase-visibility" type="button" aria-controls="vault-newer-passphrase" aria-pressed="false" aria-label="Show new passphrase" style="${Xe}">Show</button>
            <input id="vault-newer-confirm" type="password" placeholder="Confirm new passphrase" spellcheck="false" autocapitalize="off" autocorrect="off" style="flex: 1; min-width: 160px; padding: 8px 10px; border-radius: 8px;" />
            <button id="vault-newer-confirm-visibility" type="button" aria-controls="vault-newer-confirm" aria-pressed="false" aria-label="Show confirm new passphrase" style="${Xe}">Show</button>
          </div>
          <button id="vault-change-passphrase-submit" class="vault-manage-btn vault-manage-btn--primary" type="button">Change passphrase</button>
        </div>
        </details>
      </div>

      <div id="vault-status-line" role="status" aria-live="polite" style="margin-top: 10px; color: ${u.ink3}; font-family: 'IBM Plex Mono', 'SF Mono', 'Consolas', monospace; font-size: 10.5px; line-height: 1.35; overflow-wrap: anywhere;"><span id="vault-status-spinner" class="vault-status-spinner" aria-hidden="true"></span><span id="vault-status-text">Loading Vault…</span></div>

      <!-- Shown to signed-in, non-entitled users, in place of the Vault panel
           (PV-01 routes here; PV-03 fills it in). It takes the whole seat
           rather than sitting beside a disabled panel: a Vault card with
           buttons that would fail server-side is worse than no card, because
           the failure only shows up after the click.
           The data line is the load-bearing one. A lapsed owner keeps the local
           index but cannot use the encrypted remote copy until renewal, so the
           copy in shared/vault_paywall.ts states both facts directly. -->
      <div id="vault-paywall-seat" class="vault-paywall" style="display: none;" data-state="never_subscribed">
        <div class="vault-paywall-status-card">
          <span class="vault-paywall-status-icon" aria-hidden="true"></span>
          <div>
            <div id="vault-paywall-status-line"></div>
            <div id="vault-paywall-account-line"></div>
          </div>
        </div>
        <div id="vault-paywall-data-line" class="vault-paywall-reassurance" style="display: none;"></div>
        <div class="vault-paywall-free-line">${xp({mcp:!0})}</div>
        <div class="vault-plan-toggle" id="vault-plan-toggle" role="group" aria-label="Billing frequency">
          <button id="vault-plan-annual" type="button" class="vault-plan-option selected" aria-pressed="true">
            <span class="vault-plan-flag">${mt.annualFlag}</span>
            <span class="vault-plan-name">Yearly</span>
            <span class="vault-plan-price">${mt.annualPrice}<span class="vault-plan-per">${mt.annualPer}</span></span>
            <span class="vault-plan-billed">${mt.annualBilled}</span>
          </button>
          <button id="vault-plan-monthly" type="button" class="vault-plan-option" aria-pressed="false">
            <span class="vault-plan-name">Monthly</span>
            <span class="vault-plan-price">${mt.monthlyPrice}<span class="vault-plan-per">${mt.monthlyPer}</span></span>
            <span class="vault-plan-billed">${mt.monthlyBilled}</span>
          </button>
        </div>
        <div class="vault-paywall-actions">
          <button id="vault-paywall-cta" type="button">Continue to checkout</button>
        </div>
        <p class="vault-paywall-plan-note">Opens Stripe's secure checkout — cancel anytime.</p>
        <div class="vault-paywall-utilities" aria-label="Vault account actions">
          <button id="vault-paywall-recheck-btn" class="vault-paywall-utility" type="button">I've subscribed, check again</button>
          <button id="vault-paywall-sign-out-btn" class="vault-paywall-utility" type="button">Sign out</button>
        </div>
        <div id="vault-paywall-recheck-status" class="vault-paywall-live-status" role="status" aria-live="polite"></div>
      </div>
      </div>
    </section>
    `}
    ${`
    <section id="corpus-native-card" class="settings-section" data-settings-section data-settings-group="connections" data-settings-search="MCP desktop AI Claude Desktop Claude Code Codex Cursor local access sync Node.js terminal install command permission extension" style="margin-top: 18px; border: 1px solid #315a3e; border-radius: 14px; padding: 0; background: #fff; overflow: hidden; box-shadow: 0 8px 24px rgba(31, 67, 43, 0.12);">
      <div style="padding: 18px 18px 16px; background: linear-gradient(135deg, #173f2a 0%, #2d6140 100%);">
        <div style="display: flex; align-items: center; justify-content: space-between; gap: 8px; flex-wrap: wrap; margin-bottom: 8px;">
          <span style="display: inline-flex; align-items: center; padding: 4px 8px; border: 1px solid rgba(255,255,255,0.38); border-radius: 999px; color: #fff; font-size: 10.5px; font-weight: 750; letter-spacing: 0.08em; text-transform: uppercase;">MCP connection</span>
          <span style="color: #dcebe1; font-size: 11.5px; font-weight: 600;">Runs on this computer</span>
        </div>
        <h2 style="margin: 0 0 7px; font-size: 20px; line-height: 1.25; color: #fff;">Use your chat history in desktop AI apps</h2>
        <p style="margin: 0; color: #e5f0e8; line-height: 1.55;">Search and reopen past chats from Claude, ChatGPT, Codex, Cursor, and other compatible apps.</p>
      <div id="corpus-native-flow" role="group" aria-label="Your chats pass through LLMnesia on this computer to your desktop AI using a local connection" style="display: flex; align-items: center; flex-wrap: wrap; gap: 7px; margin: 12px 0 9px; padding: 9px 10px; border: 1px solid rgba(255,255,255,0.5); border-radius: 9px; background: #fff; color: #243c30; font-size: 12px;">
        <span style="display: inline-flex; align-items: center; gap: 6px; font-weight: 600; white-space: nowrap;">
          <svg aria-hidden="true" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#487852" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M7 8h10a3 3 0 0 1 3 3v2a3 3 0 0 1-3 3h-5l-4 3v-3H7a3 3 0 0 1-3-3v-2a3 3 0 0 1 3-3Z"/><path d="M8 12h.01M12 12h.01M16 12h.01"/></svg>
          Your chats
        </span>
        <span aria-hidden="true" style="color: #66816d; font-weight: 800;">→</span>
        <span style="display: inline-flex; align-items: center; gap: 6px; padding: 4px 7px; border-radius: 6px; background: #e9f4ea; color: #285233; font-weight: 700; white-space: nowrap;">
          <svg aria-hidden="true" width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="#285233" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="10" width="14" height="10" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></svg>
          LLMnesia <span style="font-weight: 500; color: #5a7260;">on this computer</span>
        </span>
        <span aria-hidden="true" style="color: #66816d; font-weight: 800;">→</span>
        <span style="display: inline-flex; align-items: center; gap: 6px; font-weight: 600; white-space: nowrap;">
          <svg aria-hidden="true" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#487852" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="13" rx="2"/><path d="M8 21h8M12 17v4"/></svg>
          Desktop AI
        </span>
        <span style="display: inline-flex; align-items: center; gap: 4px; margin-left: auto; color: #487852; font-weight: 600; white-space: nowrap;">
          <svg aria-hidden="true" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#487852" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m5 12 4 4L19 6"/></svg>
          Local connection
        </span>
      </div>
        <p style="margin: 0; color: #dcebe1; font-size: 11.5px; line-height: 1.5;">LLMnesia keeps the index and connection local. Your AI app’s privacy terms apply to results it uses.</p>
      </div>
      <div style="padding: 15px 18px 18px;">
        <div style="padding: 10px 12px; border: 1px solid #c9d8cd; border-left: 4px solid #315a3e; border-radius: 8px; background: #f4f8f5;">
          <div style="margin-bottom: 2px; color: #52705b; font-size: 10.5px; font-weight: 750; letter-spacing: 0.07em; text-transform: uppercase;">Connection status</div>
          <div id="corpus-native-status" style="color: #203d2b; font-weight: 650; overflow-wrap: anywhere; word-break: break-word;">Checking…</div>
          <div id="corpus-native-lastsync" style="margin-top: 3px; color: #647a6a; font-size: 12px;"></div>
      </div>
      <div id="corpus-native-install" style="display: block; margin-top: 14px; padding: 14px; background: #fff; border: 1px solid #c7d5ca; border-radius: 10px;">
        <div id="corpus-native-install-steps" style="display: block;">
          <div style="display: flex; align-items: center; gap: 9px; font-weight: 700; color: #203d2b; margin-bottom: 5px;"><span aria-hidden="true" style="display: inline-flex; align-items: center; justify-content: center; flex: 0 0 28px; width: 28px; height: 28px; border-radius: 50%; background: #315a3e; color: #fff; font-size: 13px;">1</span><span>Install the desktop connector <span id="corpus-native-connector-state" style="display: none; margin-left: 4px; color: #2f7544;">✓ Done</span></span></div>
          <p style="margin: 0 0 9px 37px; color: #4d6254; font-size: 13px;">This command installs the connector and connects supported apps on this computer.</p>
          <div id="corpus-native-node-help" style="margin: 7px 0 11px 37px; padding: 10px 11px; border: 1px solid #d8cba5; border-radius: 8px; background: #fffaf0; color: #4c4a3f; font-size: 12.5px;">
            <div style="display: flex; align-items: flex-start; gap: 8px;">
              <span aria-hidden="true" style="display: inline-flex; align-items: center; justify-content: center; flex: 0 0 24px; width: 24px; height: 24px; border-radius: 6px; background: #e9f4ea; color: #285233;">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3v12M7 10l5 5 5-5"/><path d="M5 21h14"/></svg>
              </span>
              <div><strong>A patched Node.js LTS release is required (22.23.4+ or 24.22.1+).</strong> Already have it? Skip this download.</div>
            </div>
            <a href="${Zu}" target="_blank" rel="noopener" style="display: inline-block; margin-top: 7px; padding: 6px 9px; border: 1px solid #b9cdb8; border-radius: 6px; background: #fff; color: #285233; text-decoration: none; font-weight: 600;">${Xu}</a>
            <p style="margin: 6px 0 0; color: #6b6759; font-size: 12px;">Use the installer’s default options, then continue below. Docker is not needed.${ef}</p>
          </div>
          <p id="corpus-native-install-copy" style="display: flex; align-items: flex-start; gap: 8px; margin: 8px 0 8px 37px; color: #344d3b; font-size: 13px;">
            <span aria-hidden="true" style="display: inline-flex; align-items: center; justify-content: center; flex: 0 0 24px; width: 24px; height: 24px; border-radius: 6px; background: #edf2f5; color: #365166;">
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="16" rx="2"/><path d="m7 9 3 3-3 3M13 15h4"/></svg>
            </span>
            <strong id="corpus-native-install-copy-text">Next: ${tc}</strong>
          </p>
          <div style="margin: 0 0 7px 37px; color: #203d2b; font-size: 13px; font-weight: 700;">Run this command in ${Rr}:</div>
          <code id="corpus-native-install-cmd" style="display: block; margin: 0 0 9px 37px; padding: 10px; background: #182c21; border: 1px solid #182c21; border-radius: 7px; color: #f1faf4; font-size: 12px; line-height: 1.5; white-space: pre-wrap; overflow-wrap: anywhere;">${es}</code>
          <button id="corpus-native-copy-install" type="button" style="margin-left: 37px; padding: 9px 13px; border-radius: 7px; border: 1px solid #244b32; background: #315a3e; color: #fff; cursor: pointer; font-weight: 700;">Copy install command</button>
          <p style="margin: 8px 0 0 37px; color: #617064; font-size: 12px;">${Qu} It may take up to a minute. Keep ${Rr} open until it says Done.</p>
          <p style="margin: 9px 0 0 37px; padding: 8px 10px; border-left: 3px solid #ad7927; background: #fff8e8; color: #624b22; font-size: 12px;"><strong>Important:</strong> plain <code>npm install @llmnesia/mcp</code> only downloads the package. It does not register the browser connector. Run the exact <code>npx … install</code> command above.</p>

          <div style="margin-top: 15px; padding-top: 15px; border-top: 1px solid #d5ded7;">
            <div style="display: flex; align-items: center; gap: 9px; font-weight: 700; color: #203d2b; margin-bottom: 5px;"><span aria-hidden="true" style="display: inline-flex; align-items: center; justify-content: center; flex: 0 0 28px; width: 28px; height: 28px; border-radius: 50%; background: #315a3e; color: #fff; font-size: 13px;">2</span><span>Restart your browser</span></div>
            <p style="margin: 0 0 9px 37px; color: #4d6254; font-size: 13px;">${ai} This lets the browser find the newly installed connector.</p>
          </div>

          <div style="margin-top: 15px; padding-top: 15px; border-top: 1px solid #d5ded7;">
            <div style="display: flex; align-items: center; gap: 9px; font-weight: 700; color: #203d2b; margin-bottom: 5px;"><span aria-hidden="true" style="display: inline-flex; align-items: center; justify-content: center; flex: 0 0 28px; width: 28px; height: 28px; border-radius: 50%; background: #315a3e; color: #fff; font-size: 13px;">3</span><span>Enable automatic sync <span id="corpus-native-permission-state" style="display: none; margin-left: 4px; color: #2f7544;">✓ Done</span></span></div>
            <p style="margin: 0 0 9px 37px; color: #4d6254; font-size: 13px;">Allow LLMnesia to use the connector and keep your desktop AI copy up to date.</p>
            <button id="corpus-native-enable" type="button" style="margin-left: 37px; padding: 9px 13px; border-radius: 8px; border: 1px solid #244b32; background: #315a3e; color: #fff; cursor: pointer; font-weight: 700;">I’ve installed and restarted — enable sync</button>
          </div>

          <div id="corpus-native-finish" style="display: none; align-items: flex-start; gap: 8px; margin: 12px 0 0 37px; padding: 10px 12px; border-radius: 7px; background: #eaf5ed; color: #203d2b; font-size: 13px;"><span aria-hidden="true" style="display: inline-flex; align-items: center; justify-content: center; flex: 0 0 22px; width: 22px; height: 22px; border-radius: 50%; background: #315a3e; color: #fff; font-weight: 700;">✓</span><span>${Se?"<strong>Connected.</strong> Your browser can reach the local connector. Supported desktop AI apps found during setup can now use LLMnesia. If you use Claude Desktop, complete step 4 below.":"<strong>Connected.</strong> Your browser can reach the local connector. Reopen your connected AI app, then ask it to <em>“Search my LLMnesia history for…”</em>"}</span></div>
          ${Se?`
          <div id="corpus-native-claude-windows" style="margin-top: 15px; padding-top: 15px; border-top: 1px solid #d5ded7;">
            <div style="display: flex; align-items: center; gap: 9px; font-weight: 700; color: #203d2b; margin-bottom: 5px;"><span aria-hidden="true" style="display: inline-flex; align-items: center; justify-content: center; flex: 0 0 28px; width: 28px; height: 28px; border-radius: 50%; background: #315a3e; color: #fff; font-size: 13px;">4</span><span>Add Claude Desktop on Windows</span></div>
            <p style="margin: 0 0 9px 37px; color: #4d6254; font-size: 13px;">Claude needs one extra, one-time extension install. Other supported apps do not.</p>
            <a href="${tf}" target="_blank" rel="noopener" style="display: inline-block; margin-left: 37px; padding: 9px 13px; border-radius: 7px; background: #315a3e; color: #fff; text-decoration: none; font-weight: 700;">Download LLMnesia for Claude</a>
            <p style="margin: 8px 0 0 37px; color: #4d6254; font-size: 13px;">In Claude Desktop, open <strong>Settings → Extensions → Advanced settings → Install extension</strong>, choose the downloaded file, then fully quit and reopen Claude.</p>
          </div>`:""}
        </div>
      </div>
      <details id="corpus-native-details" style="display: none; margin-top: 12px; color: #4d6254; font-size: 12px;">
        <summary style="cursor: pointer;">Connection details</summary>
        <div id="corpus-native-location" style="display: none; margin-top: 8px; overflow-wrap: anywhere; word-break: break-word;"></div>
        <span id="corpus-native-manual" style="display: none; margin-top: 8px;">Need to update it now?
          <button id="corpus-native-sync-now" type="button" style="padding: 4px 8px; border-radius: 6px; border: 1px solid #c6d0b0; background: #fff; cursor: pointer; font-size: 12px;">Sync now</button>
          <button id="corpus-native-full-sync" type="button" style="padding: 4px 8px; border-radius: 6px; border: 1px solid #c6d0b0; background: #fff; cursor: pointer; font-size: 12px;">Rebuild local history</button>
        </span>
      </details>
      </div>
    </section>
    `}
    
    <section id="danger-zone-section" class="settings-section" data-settings-section data-settings-group="advanced" data-settings-label="Permanent action" data-settings-search="danger zone delete remove all data conversations memories permanent" style="margin-top: 16px; border: 1px solid #ecc6c6; border-left: 4px solid #b83d3d; border-radius: 12px; padding: 14px 16px; background: #fff8f8;">
      <h2 style="margin: 0 0 10px; font-size: 16px; color: #6f1d1d;">Danger Zone</h2>
      <p id="delete-all-description" class="settings-card-description" style="margin: 0 0 10px; color: #7a3b3b;">${k(Ha(Qa()).description)}</p>
      <button id="delete-all" class="settings-danger-action" type="button" style="padding: 8px 12px; border-radius: 8px; border: 1px solid #d6a7a7; background: #fff; cursor: pointer;">Delete data on this browser</button>
      <div id="delete-all-confirm" style="display: none; margin-top: 10px; padding: 10px 12px; border: 1px solid #ecc6c6; border-radius: 8px; background: #fff;">
        <label for="delete-all-confirm-input" style="display: block; margin: 0 0 8px; font-size: 12px; color: #7a3b3b;">${k(Eu)}</label>
        <input id="delete-all-confirm-input" type="text" autocomplete="off" autocapitalize="none" spellcheck="false" placeholder="${k(Ya)}" style="width: 140px; padding: 6px 8px; border-radius: 6px; border: 1px solid #d6a7a7; font-size: 13px; letter-spacing: 0.08em;" />
        <button id="delete-all-confirm-btn" class="settings-danger-action" type="button" disabled style="margin-left: 8px; padding: 6px 12px; border-radius: 8px; border: 1px solid #d6a7a7; cursor: not-allowed;">Delete this browser's data</button>
        <button id="delete-all-cancel-btn" type="button" style="margin-left: 8px; padding: 6px 12px; border-radius: 8px; border: 1px solid #d6a7a7; background: #fff; color: #6f1d1d; cursor: pointer;">Cancel</button>
      </div>
      <div id="delete-status" class="settings-status-panel" style="margin-top: 10px; color: #6a3333; overflow-wrap: anywhere; word-break: break-word;">${k(Cu)}</div>
    </section>

    <section id="support-section" class="settings-section" data-settings-section data-settings-group="advanced" data-settings-label="Contact" data-settings-search="support contact privacy help" style="margin-top: 16px; border: 1px solid #dbe2cf; border-left: 4px solid #8a9aa3; border-radius: 12px; padding: 12px 16px; background: #f7f9fa;">
      <h2 style="margin: 0 0 8px; font-size: 14px;">Support</h2>
      <p class="settings-card-description" style="margin: 0; color: #466173;">Get help or report a problem.</p>
      <div class="settings-actions">
        <a href="https://llmnesia.com/#contact" target="_blank" rel="noopener" style="display: inline-block; padding: 8px 12px; border: 1px solid #526771; border-radius: 8px; background: #526771; color: #fff; text-decoration: none; font-weight: 700;">Open contact form</a>
      </div>
    </section>
  </div>
`;const to=document.querySelector("#settings-search"),si=document.querySelector("#settings-search-status"),ii=document.querySelector("#settings-filter-empty"),li=Array.from(document.querySelectorAll("[data-settings-section]")),rf=Array.from(document.querySelectorAll("[data-settings-group-heading]")),ts=Array.from(document.querySelectorAll("[data-settings-nav]"));function ci(e){return e.style.display!=="none"&&!e.hidden}function os(){const e=window.location.hash.replace(/^#/,"");for(const t of ts)t.setAttribute("aria-current",String(t.dataset.settingsNav===e))}function ns(e){const t=e.trim().toLocaleLowerCase();let o=0;for(const n of li){const a=`${n.dataset.settingsSearch??""} ${n.textContent??""}`.toLocaleLowerCase(),r=t.length===0||a.includes(t);n.hidden=!r,r&&ci(n)&&(o+=1)}for(const n of ts){const a=document.getElementById(n.dataset.settingsNav??""),r=a?`${a.dataset.settingsSearch??""} ${a.textContent??""}`.toLocaleLowerCase():"";n.hidden=t.length>0&&!r.includes(t)}for(const n of rf){const a=n.dataset.settingsGroupHeading,r=li.some(s=>s.dataset.settingsGroup===a&&ci(s));n.hidden=t.length>0&&!r}ii&&(ii.style.display=t.length>0&&o===0?"block":"none"),si&&(si.textContent=t.length===0?`Showing ${o} settings sections`:o===0?"No matching settings":`${o} matching settings section${o===1?"":"s"}`)}to?.addEventListener("input",()=>{ns(to.value)});to?.addEventListener("keydown",e=>{e.key==="Escape"&&(to.value="",ns(""),to.blur())});for(const e of ts)e.addEventListener("click",()=>{window.setTimeout(os,0)});window.addEventListener("hashchange",os);document.addEventListener("keydown",e=>{const o=e.target?.matches("input, textarea, select, [contenteditable='true']")??!1;e.key==="/"&&!o&&(e.preventDefault(),to?.focus())});ns("");os();const xe=document.querySelector("#stats-content"),So=document.querySelector("#refresh-stats"),$o=document.querySelector("#toggle-indexing"),ke=document.querySelector("#google-ai-mode-toggle"),oo=document.querySelector("#google-ai-mode-state"),me=document.querySelector("#google-ai-mode-status"),Kt=document.querySelector("#chatgpt-temporary-toggle"),no=document.querySelector("#chatgpt-temporary-status");function ac(e){no&&(no.textContent=e?"Enabled. Temporary Chats are saved while open; each copy opens in the viewer.":"Off. Temporary Chats are not saved.",no.style.color=e?"#315a3e":"#526771")}async function af(){if(Kt){try{const e=await chrome.storage.local.get(ra);Kt.checked=e[ra]===!0}catch{Kt.checked=!1}ac(Kt.checked)}}Kt?.addEventListener("change",()=>{const e=Kt.checked===!0;chrome.storage.local.set({[ra]:e}).then(()=>ac(e)).catch(()=>{no&&(no.textContent="Could not save the setting. Try again.",no.style.color="#8a4b2e")})});af();const yt=document.querySelector("#semantic-coverage"),ht=document.querySelector("#semantic-engine-check"),fa=document.querySelector("#semantic-probe-query"),bt=document.querySelector("#semantic-probe-run"),vt=document.querySelector("#semantic-selftest"),xt=document.querySelector("#export-eval-corpus"),_=document.querySelector("#semantic-eval-output"),di=document.querySelector("#health-status"),Yt=document.querySelector("#migration-status"),pi=document.querySelector("#backfill-section"),Pr=document.querySelector("#backfill-progress-fill"),ui=document.querySelector("#backfill-status-text");let Nr=null,Be=null,Ht=null,ga=!1,rs=null;function Co(e){return e?_p(e):Tp.join("/")}function sf(e,t){if(!Pr)return;let o=0,n="linear-gradient(90deg, #2f7f99 0%, #49b08f 100%)";e?.active?(t?.phase==="running"&&t.total>0?o=Math.max(2,Math.min(100,Math.round(t.processed/t.total*100))):t?.phase==="done"?o=100:o=18,e.paused&&(n="#9aa8b4")):t?.phase==="done"&&(o=100),Pr.style.width=`${o}%`,Pr.style.background=n}function lf(e){const{state:t,progress:o,activeTabPlatform:n,queue:a}=e;if(t.active){const r=Co(t.platform);if(n&&t.platform&&n!==t.platform)return a.find(i=>i.platform===n)?`${r} is indexing. ${Co(n)} is queued.`:`${r} is indexing. Queue ${Co(n)} from this tab if needed.`;if(t.paused)return"Paused.";if(o?.phase==="running"){const s=o.total>0?` (${o.processed}/${o.total})`:"";if(o.lastIndexedTitle){const i=Ip(!!o.lastIndexedChanged,!!o.lastIndexedIsNew),l=o.lastIndexedPartialDepth?t.platform==="google_ai_mode"?" (captured in part, click Start after this run to retry)":" (partial depth, will retry)":"";return`${i}: ${o.lastIndexedTitle}${l}${s}`}return o.lastSkippedTitle?`Skipped: ${o.lastSkippedTitle} (${o.lastSkippedReason??"not indexable"})${s}`:`Indexing older chats on ${r}…${s}`}if(o?.phase==="collecting"){const s=o.total>0?` (${o.total} found so far)`:"";return`Fetching your ${r} chat list…${s}`}return o?.phase==="pruning"?"Checking what's already indexed…":`Indexing older chats on ${r}…`}if(n&&a.find(s=>s.platform===n))return`${Co(n)} is queued.`;if(n==="ai_studio"){const r=ad(o?.lastError);if(r)return r}return o?.lastError==="history_list_unavailable"?`Couldn’t reach your ${Co(n)} chat history. Try the import again later.`:o?.phase==="done"?Lp(o,n??t.platform):n?"Ready to index older chats.":"Open a supported AI tab, then start from the extension popup."}async function cf(){let e;try{e=await chrome.tabs.query({active:!0,currentWindow:!0})}catch{return null}const t=e[0],o=typeof t?.id=="number"?t.id:null,n=t?await sd(t):null;return!n||typeof o!="number"||o<=0?null:{platform:n,seedTabId:o}}async function fi(){let e;try{e=await chrome.runtime.sendMessage({type:"GET_BACKFILL_STATUS"})}catch{return}if(!e.ok)return;const o=(await cf())?.platform??null,{state:n,progress:a,queue:r,progressByPlatform:s}=e;if(pi&&(pi.style.display=n.active?"":"none"),!n.active)return;const i=o&&s[o]?s[o]??null:a,l=o&&n.platform!==o?null:n;sf(l,i),ui&&(ui.textContent=lf({state:n,progress:i,activeTabPlatform:o,queue:r}))}function df(){fi(),Nr!==null&&clearInterval(Nr),Nr=setInterval(()=>{fi()},1200)}const tn=document.querySelector("#export-backup"),on=document.querySelector("#import-backup"),nn=document.querySelector("#import-backup-cancel"),Rn=document.querySelector("#import-backup-file"),gi=document.querySelector("#backup-status"),xn=document.querySelector("#backup-progress");let ma=!1;const Oe=document.querySelector("#rolling-backup-enabled"),Mr=document.querySelector("#rolling-backup-now"),Or=document.querySelector("#rolling-backup-restore"),U=document.querySelector("#rolling-backup-status");function as(e){if(!e.enabled)return"Automatic backups are off.";const t=[];return e.lastCompletedAt?t.push(`Last completed ${new Date(e.lastCompletedAt).toLocaleString()} (${e.versions[0]?.conversationCount??0} conversations).`):t.push("No backup completed yet."),e.lastError&&t.push(`Last problem: ${e.lastError}`),t.push(`${e.versions.length}/${e.retentionCount} versions kept in the browser profile.`),t.join(" ")}async function pf(){if(!(!U||!Oe))try{const e=await chrome.runtime.sendMessage({type:"GET_ROLLING_BACKUP_STATUS"});if(!e?.ok){U.textContent="Could not read backup status.";return}Oe.checked=e.status.enabled,U.textContent=as(e.status)}catch(e){U.textContent=`Could not read backup status: ${e instanceof Error?e.message:String(e)}`}}Oe?.addEventListener("change",async()=>{if(!Oe||!U)return;const e=Oe.checked;Oe.disabled=!0,e&&(U.textContent="Starting your first local backup...");try{const t=await chrome.runtime.sendMessage({type:"SET_ROLLING_BACKUP_ENABLED",enabled:e});t?.ok?U.textContent=as(t.status):(Oe.checked=!e,U.textContent=`Could not ${e?"enable":"disable"} automatic backups.`)}catch(t){Oe.checked=!e,U.textContent=`Could not update automatic backups: ${t instanceof Error?t.message:String(t)}`}finally{Oe.disabled=!1}});Mr?.addEventListener("click",async()=>{if(U){Mr?.setAttribute("disabled","true"),U.textContent="Backing up...";try{const e=await chrome.runtime.sendMessage({type:"RUN_ROLLING_BACKUP_NOW"});e?.ok?U.textContent=as(e.status):U.textContent=`Backup failed: ${e?.error??"no response"}`}catch(e){U.textContent=`Backup failed: ${e instanceof Error?e.message:String(e)}`}finally{Mr?.removeAttribute("disabled")}}});Or?.addEventListener("click",async()=>{if(U){Or?.setAttribute("disabled","true"),U.textContent="Looking for a verified backup...";try{const e=await ap();if(!e){U.textContent="No verified backup found. Nothing was changed. Run a backup first, or check whether backups are enabled.";return}U.textContent=`Restoring ${e.name}...`,await fn();const t=new File([e.blob],e.name,{type:"application/gzip"}),o=await fc(()=>dl(t,void 0,{shouldCancel:()=>!1}));await dt(o.imported);const n=o.alreadyImported>0?` (${o.alreadyImported} already present, skipped)`:"";U.textContent=`Restore finished: ${o.imported}/${o.total} conversations restored${n}`+(o.failed>0?`, ${o.failed} failed.`:". Existing chats were not changed.")+(o.privateOrganisation?` ${o.privateOrganisation.message}`:""),await ve()}catch(e){await dt(1),U.textContent=`Restore failed: ${e instanceof Error?e.message:String(e)} Existing chats were not changed.`}finally{Or?.removeAttribute("disabled")}}});pf();const ya=document.querySelector("#import-chatgpt-export"),rn=document.querySelector("#import-chatgpt-export-cancel"),Pn=document.querySelector("#import-chatgpt-export-file"),wn=document.querySelector("#chatgpt-export-progress"),mi=document.querySelector("#chatgpt-export-status");let Ao=!1;Gp({markStarted:fn,finalize:dt,refreshStats:ve});Jp({markStarted:fn,finalize:dt,refreshStats:ve});const uf=document.querySelector("#local-sessions-card"),et=document.querySelector("#ls-connect"),Yn=document.querySelector("#ls-brave-help"),ff=document.querySelector("#ls-copy-flag"),Wn=document.querySelector("#ls-helper-setup"),Wt=document.querySelector("#ls-install-cmd"),gf=document.querySelector("#ls-copy-install");function Br(e){return{chooseBtn:document.querySelector(`#ls-choose-${e}`),rescanBtn:document.querySelector(`#ls-rescan-${e}`),forgetBtn:document.querySelector(`#ls-forget-${e}`),copyPathBtn:document.querySelector(`#ls-copy-path-${e}`),dirInput:document.querySelector(`#ls-dir-input-${e}`),statusNode:document.querySelector(`#ls-status-${e}`),hintNode:document.querySelector(`#ls-hint-${e}`)}}const ee={claude_code:Br("claude_code"),codex:Br("codex"),zcode:Br("zcode")},Ue=document.querySelector("#delete-all"),yi=document.querySelector("#delete-status"),Jn=document.querySelector("#delete-all-confirm"),nt=document.querySelector("#delete-all-confirm-input"),Zn=document.querySelector("#delete-all-confirm-btn"),mf=document.querySelector("#delete-all-cancel-btn"),yf=document.querySelector("#refresh-pins"),ro=document.querySelector("#pin-filter"),hf=document.querySelector("#clear-pin-filter"),yr=document.querySelector("#pin-only"),rt=document.querySelector("#pin-list"),hi=document.querySelector("#pin-status"),re=document.querySelector("#memory-list"),kn=document.querySelector("#pending-memory-list"),Io=document.querySelector("#enable-all-pending-memories"),bi=document.querySelector("#memory-status"),sc=document.querySelector("#memory-filter"),bf=document.querySelector("#refresh-memories"),Ve=document.querySelector("#memory-text"),qr=document.querySelector("#memory-label"),Ur=document.querySelector("#memory-pinned"),vf=document.querySelector("#add-memory"),vi=document.querySelector("#memory-example-chips"),No=document.querySelector("#memory-add-form-wrap"),xi=document.querySelector("#memory-manage-tools"),Jt=document.querySelector("#toggle-add-form"),Sn=document.querySelector("#memory-import-text"),xf=document.querySelector("#import-memory"),Lo=document.querySelector("#copy-export-prompt"),hr=document.querySelector("#memory-import-platform"),Cn=document.querySelector("#memory-import-hint"),wi=document.querySelector("#memory-import-status"),an={chatgpt:"ChatGPT",claude:"Claude",gemini:"Gemini",copilot:"Copilot",deepseek:"DeepSeek",kimi:"Kimi",generic:"Other AI"},ki=`Export everything you know about me — both your saved memories and anything you've learned about me from past conversations. Keep my own words verbatim where you can, especially for instructions and preferences.

Output these categories, in this order:
1. Instructions — rules I've asked you to follow (tone, format, style, always/never do X) and corrections to your behaviour.
2. Identity — name, location, background, languages, interests.
3. Career — current and past roles, companies, skill areas.
4. Projects — things I've built or committed to (one entry per project: what it does, status, key decisions). Start each with the project name.
5. Preferences — opinions, tastes, and working-style preferences.

Format: a section header per category. Under each, one entry per line as:
[YYYY-MM-DD] - entry
Use [unknown] if no date is known. Wrap the whole thing in one code block. After it, tell me whether that's everything or more remains.`,ao=document.querySelector("#recent-limit"),Si=document.querySelector("#recent-limit-status"),wf=document.querySelector("#refresh-error-logs"),kf=document.querySelector("#export-error-logs"),Sf=document.querySelector("#copy-error-logs"),Cf=document.querySelector("#clear-error-logs"),Ci=document.querySelector("#adapter-errors-list"),Ei=document.querySelector("#error-log-status"),St=document.querySelector("#error-log-list"),$i=document.querySelector("#founding-card"),Ef=document.querySelector("#founding-join"),$f=document.querySelector("#founding-not-now"),Af=document.querySelector("#report-problem"),If=document.querySelector("#options-snapshot-toggle");async function Lf(){try{const e=await chrome.storage.local.get([Ts,_s,Rs]);return{indexingEnabled:e[Ts]!==!1,semanticSearchEnabled:e[_s]===!0,memoryLayerEnabled:e[Rs]!==!1}}catch{return{}}}async function Tf(){let e;try{e=(await chrome.tabs.query({})).filter(n=>{if(!n.url)return!1;try{return wl(new URL(n.url))!==null}catch{return!1}}).sort((n,a)=>(a.lastAccessed??0)-(n.lastAccessed??0))[0]}catch{return null}return typeof e?.id!="number"?null:{tab:e,result:await od(e.id)}}Af?.addEventListener("click",()=>{(async()=>{const e=Ap("general"),t=await Lf();let o="general",n=window.location.href,a=null,r=null,s=null;if(If?.checked){const l=await Tf();if(l){s=l.result,r=l.result.capture,a=r?.snapshot??"(Page capture unavailable. See capture error codes above.)",n=l.tab.url??n;try{o=new URL(n).hostname,e.hostname=o,e.adapter_version=wl(new URL(n))??"n/a"}catch{}}else a="(No supported chat tab was found. Open the affected AI page and try again.)"}const i=cd({hostname:o,fullUrl:n,healthRecord:e,snapshot:a,environment:t,liveDiagnostic:r,captureResult:s});chrome.tabs.create({url:i})})()});let ic=!1,ce=[];function tt(e){di&&(di.textContent=e)}function Vr(e){Yt&&(Yt.textContent=e)}function ye(e){gi&&(gi.textContent=e)}function Xn(e,t,o){const n=e>=0&&t>0;xn&&(xn.style.display=n?"block":"none",n&&(xn.max=t,xn.value=Math.min(e,t))),nn&&(nn.style.display=n&&o?"inline-block":"none")}function ge(e){mi&&(mi.textContent=e)}function En(e,t){const o=e>=0&&t>0;wn&&(wn.style.display=o?"block":"none",o&&(wn.max=t,wn.value=Math.min(e,t))),rn&&(rn.style.display=o?"inline-block":"none")}function Ct(e){yi&&(yi.textContent=e)}function lc(){const e=document.querySelector("#delete-all-description");e&&(e.textContent=Ha(Qa()).description)}function ze(e){hi&&(hi.textContent=e)}function Qn(e){Si&&(Si.textContent=e)}function Fe(e){Ei&&(Ei.textContent=e)}function cc(e){return e.length===0?"<div style='color:#4f6576;'>No errors captured yet.</div>":e.map(t=>{const o=new Date(t.at).toLocaleString(),n=[t.url,t.line?`line ${t.line}`:"",t.column?`col ${t.column}`:""].filter(Boolean).join(" • "),a=t.stack?`<pre style="margin: 6px 0 0; padding: 6px; border: 1px solid #e2e8ef; border-radius: 8px; background: #f8fbff; color: #2d4158; font: 11px/1.4 'IBM Plex Mono', monospace; white-space: pre-wrap; overflow-wrap: anywhere;">${k(t.stack)}</pre>`:"",r=t.details?`<div style="margin-top: 4px; color: #4f6576; font-size: 12px; overflow-wrap: anywhere;">${k(t.details)}</div>`:"";return`
        <article style="border: 1px solid #d7dfcb; border-radius: 10px; padding: 8px; background: #fff;">
          <div style="display: flex; justify-content: space-between; gap: 8px; flex-wrap: wrap;">
            <strong style="color: #17364e; overflow-wrap: anywhere;">${k(t.message)}</strong>
            <span style="color: #5f7384; font-size: 12px;">${o}</span>
          </div>
          <div style="margin-top: 4px; color: #4f6576; font-size: 12px; overflow-wrap: anywhere;">
            ${k(t.source)} • ${k(t.context)}
          </div>
          ${n?`<div style="margin-top: 4px; color: #4f6576; font-size: 12px; overflow-wrap: anywhere;">${k(n)}</div>`:""}
          ${r}
          ${a}
        </article>
      `}).join("")}function dc(e){ic=e,$i&&($i.style.display="none")}async function _f(e){try{await chrome.runtime.sendMessage({type:"UPDATE_FOUNDING_STATS_SNAPSHOT",conv_count:e.conversationCount,msg_count:e.messageCount})}catch{}}async function Rf(){}function br(e,t){const o=URL.createObjectURL(t),n=document.createElement("a");n.href=o,n.download=e,n.click(),window.setTimeout(()=>URL.revokeObjectURL(o),2e3)}const Pf=Bp();document.querySelector("#export-google-import-report")?.addEventListener("click",async()=>{const e=document.querySelector("#google-import-report-status");try{const t=await chrome.storage.local.get(Ls),o=rp(t[Ls],chrome.runtime.getManifest().version),n=new Date().toISOString().replace(/[:.]/g,"-");br(`llmnesia-google-import-report-${n}.json`,new Blob([JSON.stringify(o,null,2)],{type:"application/json"})),e&&(e.textContent=`Exported ${o.partial.length} partial, ${o.failed.length} failed and ${o.unresolved.length} unfinished chats. ${o.unknownCoverage.length} with unknown coverage. ${o.entries.length} chat attempts recorded.`)}catch(t){e&&(e.textContent=`Could not export the Google import report: ${V(t)}`)}});async function ss(){if(!St)return;St.textContent="Loading error logs...";let e;try{e=await chrome.runtime.sendMessage({type:"GET_EXTENSION_ERROR_LOGS",limit:Ep})}catch(t){St.textContent=`Failed to load logs: ${V(t)}`,Fe("Error log unavailable.");return}if(!e.ok){St.textContent=`Failed to load logs: ${e.error}`,Fe("Error log unavailable.");return}ce=e.logs,St.innerHTML=cc(ce),Fe(ce.length===0?"No errors captured yet.":`Showing ${ce.length} most recent error entr${ce.length===1?"y":"ies"}.`)}async function Nf(){if(window.confirm("Clear all captured extension error logs?")){Fe("Clearing logs...");try{const t=await chrome.runtime.sendMessage({type:"CLEAR_EXTENSION_ERROR_LOGS"});if(!t.ok){Fe(`Failed to clear logs: ${t.error}`);return}ce=[],St&&(St.innerHTML=cc(ce)),Fe("Error logs cleared.")}catch(t){Fe(`Failed to clear logs: ${V(t)}`)}}}async function Mf(){if(ce.length===0&&await ss(),ce.length===0){Fe("No logs available to export.");return}const e=new Date().toISOString().replace(/[:.]/g,"-"),t=new Blob([JSON.stringify(ce,null,2)],{type:"application/json"});br(`llmnesia-error-logs-${e}.json`,t),Fe(`Exported ${ce.length} log entr${ce.length===1?"y":"ies"}.`)}async function vr(){if($o)try{const e=await chrome.runtime.sendMessage({type:"GET_INDEXING_ENABLED"});if(!e.ok){$o.textContent="Indexing status error";return}$o.textContent=e.enabled?"Pause indexing":"Resume indexing"}catch{$o.textContent="Indexing status error"}}let er=null;function ha(e,t){er=e,ke&&(ke.disabled=!1,ke.textContent=e?"Disable Google AI Mode":"Enable Google AI Mode"),oo&&(oo.textContent=e?"Enabled":"Off",oo.dataset.state=e?"on":"off"),me&&(me.textContent=t??(e?"Google AI Mode conversations are captured automatically.":"Google site access is off."))}async function sn(){try{ha(await sp())}catch(e){er=null,ke&&(ke.disabled=!0,ke.textContent="Access unavailable"),oo&&(oo.textContent="Unavailable",oo.dataset.state="error"),me&&(me.textContent=`Could not check Google access: ${V(e)}`)}}async function Of(){if(!(!ke||er===null)){if(ke.disabled=!0,!er){ke.textContent="Waiting for Chrome...",me&&(me.textContent="Approve Google site access in Chrome to enable capture.");try{const e=await ip();ha(e,e?"Enabled. Any open Google AI Mode conversation is ready to capture.":"Permission was not granted. Google site access remains off.")}catch(e){await sn(),me&&(me.textContent=`Google capture could not start: ${V(e)}`)}return}ke.textContent="Removing access...",me&&(me.textContent="Removing Google site access...");try{const e=await lp();ha(!e,e?"Google site access was removed. Existing saved conversations remain in your index.":"Chrome did not remove all Google site access. Check the extension's site access settings.")}catch(e){await sn(),me&&(me.textContent=`Could not remove Google access: ${V(e)}`)}}}let at=null,tr=!1,zr="",Fr="";function Dr(){return ct.map(e=>e.platform).sort().join("|")}function pc(e){return xe?.querySelector(`[data-stat="${e}"] .options-stat-value`)??null}function Eo(e,t){const o=pc(e);o&&(o.textContent=t)}function Gr(e,t){const o=pc(e);o&&Xl(o,t,!Gl())}function Bf(e){return`
    <div id="stats-cards-grid" style="display:grid; grid-template-columns:repeat(auto-fit,minmax(180px,1fr)); gap:8px; align-items:stretch;">
      ${Ze("estimated-bytes","Estimated bytes",jn(e.totalEstimatedBytes))}
      ${Ze("budget","Budget",jn(e.budgetBytes))}
      ${Ze("conversations","Conversations",String(e.conversationCount),e.conversationCount)}
      ${Ze("messages","Messages",String(e.messageCount),e.messageCount)}
      ${Ze("hot-warm","Hot / Warm",`${e.hotCount} / ${e.warmCount}`)}
      ${Ze("tokens","Tokens",String(e.tokenCount),e.tokenCount)}
      ${Ze("avg-postings","Avg postings/token",e.averagePostingsPerToken.toFixed(2))}
      ${Ze("last-indexed","Last indexed",mr(e.lastIndexedAt))}
    </div>
  `}function qf(e){if(!xe)return;const t=xe.querySelector("#stats-cards-grid");if(tr&&t){Eo("estimated-bytes",jn(e.totalEstimatedBytes)),Eo("budget",jn(e.budgetBytes)),Gr("conversations",e.conversationCount),Gr("messages",e.messageCount),Eo("hot-warm",`${e.hotCount} / ${e.warmCount}`),Gr("tokens",e.tokenCount),Eo("avg-postings",e.averagePostingsPerToken.toFixed(2)),Eo("last-indexed",mr(e.lastIndexedAt));const o=xe.querySelector("#year-summary-slot");o&&(o.innerHTML=Zl());const n=pa().join(",");if(n!==Fr){const r=xe.querySelector("#platform-controls-slot");r&&(r.innerHTML=Kl()),Fr=n,ri()}const a=Dr()!==zr;if(a){const r=xe.querySelector("#platform-rows-slot");r&&(r.innerHTML=Jl(!0)),zr=Dr()}Kn(!a);return}xe.innerHTML=`
    ${Bf(e)}
    <div id="platform-breakdown-block" style="margin-top:12px; border-top:1px dashed #d7dfcb; padding-top:10px; min-width:0;">${Wu()}</div>
  `,tr=!0,zr=Dr(),Fr=pa().join(","),ri(),requestAnimationFrame(()=>Kn(!0))}function Ai(e){if(tr){tt(`Failed to refresh stats: ${e}`);return}xe&&(xe.textContent=`Failed to load stats: ${e}`)}async function ve(){if(!xe)return;tr||(xe.innerHTML=zl());let e;try{e=await chrome.runtime.sendMessage({type:"GET_INDEX_STATS",detail:"full"})}catch(i){Ai(i instanceof Error?i.message:"Unknown runtime error");return}if(!e.ok){Ai(e.error);return}const{conversationCount:t,usageByPlatform:o,lastErrorByPlatform:n}=e.stats,a=at===null;at=t,a&&Pc(),ct=o.filter(i=>!ca.has(i.platform));const r=Object.entries(n).filter(([i])=>!ca.has(i)).sort((i,l)=>l[1].at-i[1].at).slice(0,8),s=r.length===0?"<div style='color:#496073; overflow-wrap:anywhere; word-break:break-word;'>No adapter errors recorded.</div>":r.map(([i,l])=>`<div style='overflow-wrap:anywhere; word-break:break-word;'><strong>${k(i)}</strong>: ${k(l.error)} <span style='color:#5f7384'>(${new Date(l.at).toLocaleString()})</span></div>`).join("");qf(e.stats),Ci&&(Ci.innerHTML=s),await _f(e.stats),ic||await Rf(),await vr(),await jf(),await mo()}async function Uf(){if(!yt)return;let e,t;try{[e,t]=await Promise.all([chrome.runtime.sendMessage({type:"GET_SEMANTIC_COVERAGE"}),chrome.runtime.sendMessage({type:"GET_SEMANTIC_SEARCH_ENABLED"})])}catch(a){yt.textContent=`Search by meaning: unavailable (${a instanceof Error?a.message:"runtime error"})`;return}if(!e.ok){yt.textContent=`Search by meaning: unavailable (${e.error})`;return}t.ok&&!t.enabled&&chrome.runtime.sendMessage({type:"SET_SEMANTIC_SEARCH_ENABLED",enabled:!0});const{embedded:o,total:n}=e.coverage;rs={embedded:o,total:n},n===0?yt.textContent="Search by meaning is on — nothing indexed yet.":o>=n?yt.textContent=`Search by meaning is on — all ${n} chats ready.`:yt.textContent=`Search by meaning is on — getting ready in the background (${o} of ${n} chats ready).`}function mo(){if(Ht)return Ht;const e=Uf().finally(()=>{Ht===e&&(Ht=null);const t=ga;if(ga=!1,t&&!document.hidden&&pl(rs)!==Rd){mo();return}Vf()});return Ht=e,e}function Vf(){if(Be!==null&&(window.clearTimeout(Be),Be=null),!yt||document.hidden)return;const e=pl(rs);e!==null&&(Be=window.setTimeout(()=>{Be=null,mo()},e))}document.addEventListener("visibilitychange",()=>{if(document.hidden){Be!==null&&(window.clearTimeout(Be),Be=null);return}mo()});try{chrome.storage.onChanged.addListener((e,t)=>{if(t!=="local"||document.hidden)return;const o=!!e[cp],n=e[Pd]?.newValue==="dirty";if(o||n){if(Ht){ga=!0;return}if(Be!==null)return;mo()}})}catch{}function zf(e){if(!e.ok)return e.note;const t=r=>`${Math.round(r*100)}%`,o=e.auc>=.85?"STRONG":e.auc>=.7?"OK":e.auc>=.6?"WEAK":"POOR (near random)",n=e.floorSweep.map(r=>`  ${r.floor.toFixed(2)}   prec ${t(r.precision).padStart(4)}   recall ${t(r.recall).padStart(4)}   F1 ${r.f1.toFixed(2)}`).join(`
`),a=r=>r.map(s=>`  "${s.term}" (${s.relevant} chats) AUC ${s.auc.toFixed(2)}, recall@20 ${t(s.recallAt20)}, median score ${s.medianRelevantScore.toFixed(2)}`).join(`
`);return[`Semantic self-test — ${e.embeddedDocs} embedded / ${e.corpusSize} chats, ${e.probeTerms} probe terms`,"",`Separability (AUC): ${e.auc.toFixed(3)}  → ${o}`,`Recall@10 ${t(e.recallAt10)}   Recall@20 ${t(e.recallAt20)}   MRR ${e.mrr.toFixed(3)}   nDCG@10 ${e.ndcg10.toFixed(3)}`,"",`Relevant-chat scores:    p25 ${e.relevantScore.p25.toFixed(2)}  p50 ${e.relevantScore.p50.toFixed(2)}  p75 ${e.relevantScore.p75.toFixed(2)}  p90 ${e.relevantScore.p90.toFixed(2)}`,`Irrelevant-chat scores:  p50 ${e.irrelevantScore.p50.toFixed(2)}  p90 ${e.irrelevantScore.p90.toFixed(2)}  p99 ${e.irrelevantScore.p99.toFixed(2)}`,"","Floor sweep (precision/recall of relevant chats at each cutoff):",n,"","Weakest topics:",a(e.weakestProbes),"","Strongest topics:",a(e.strongestProbes),"",e.note].join(`
`)}async function Ff(){if(!ht||!_)return;ht.disabled=!0;const e=ht.textContent;ht.textContent="Testing…",_.style.display="block",_.textContent="Loading the semantic engine and embedding a few test phrases…";try{const t=await chrome.runtime.sendMessage({type:"RUN_SEMANTIC_ENGINE_CHECK"});if(!t.ok){_.textContent=`❌ Semantic engine FAILED to load:

${t.error}`;return}const o=t.check,n=o.dim===384&&o.margin>.1;_.textContent=[n?"✅ Semantic engine works.":"⚠️ Engine loaded, but results look off.","",`Model: ${t.modelId}`,`Vector size: ${o.dim}  (expected 384)`,`Model load: ${o.loadMs} ms   ·   3 embeds: ${o.embedMs} ms`,`Related phrases scored ${o.relatedScore.toFixed(3)} vs unrelated ${o.unrelatedScore.toFixed(3)} (gap ${o.margin.toFixed(3)} — bigger is better).`].join(`
`)}catch(t){_.textContent=`❌ Semantic engine FAILED:

${t instanceof Error?t.message:"Unknown error"}`}finally{ht.disabled=!1,ht.textContent=e??"Test semantic engine"}}async function uc(){if(!fa||!bt||!_)return;const e=fa.value.trim();if(!e)return;bt.disabled=!0;const t=bt.textContent;bt.textContent="Probing…",_.style.display="block",_.textContent=`Finding chats closest in meaning to "${e}"…`;try{const o=await chrome.runtime.sendMessage({type:"SEMANTIC_SEARCH_PROBE",query:e});if(!o.ok){_.textContent=`Probe failed: ${o.error}`;return}if(o.hits.length===0){_.textContent='No semantic results. Is the index built and the engine working? Check the coverage line above and "Test semantic engine" first.';return}const n=o.hits.map((a,r)=>{const s=a.score>=o.floor?"✓":"·";return`${String(r+1).padStart(2)}. ${a.score.toFixed(3)} ${s} [${a.platform}] ${a.title}`});_.textContent=[`Closest chats by meaning to: "${o.query}"`,`✓ = above the ${o.floor.toFixed(2)} floor (would surface in search)   ·  · = below floor (hidden)`,"",...n].join(`
`)}catch(o){_.textContent=`Probe failed: ${o instanceof Error?o.message:"Unknown error"}`}finally{bt.disabled=!1,bt.textContent=t??"Probe meaning"}}async function Df(){if(!vt||!_)return;vt.disabled=!0;const e=vt.textContent;vt.textContent="Running…",_.style.display="block",_.textContent="Running semantic self-test against your local index…";try{const t=await chrome.runtime.sendMessage({type:"RUN_SEMANTIC_EVAL"});if(!t.ok){_.textContent=`Self-test failed: ${t.error}`;return}console.log("[LLMnesia] semantic self-test",t.report),_.textContent=zf(t.report)}catch(t){_.textContent=`Self-test failed: ${t instanceof Error?t.message:"Unknown error"}`}finally{vt.disabled=!1,vt.textContent=e??"Run semantic self-test"}}async function Gf(){if(!xt)return;xt.disabled=!0;const e=xt.textContent;xt.textContent="Exporting…";try{const t=await chrome.runtime.sendMessage({type:"EXPORT_EVAL_CORPUS"});if(!t.ok){_&&(_.style.display="block",_.textContent=`Eval corpus export failed: ${t.error}`);return}br("corpus-eval.json",new Blob([JSON.stringify(t.corpus)],{type:"application/json"}))}catch(t){_&&(_.style.display="block",_.textContent=`Eval corpus export failed: ${t instanceof Error?t.message:"Unknown error"}`)}finally{xt.disabled=!1,xt.textContent=e??"Export eval corpus"}}async function jf(){try{const e=await Nd();if(e.state==="done"){Yt&&(Yt.style.display="none");return}if(Yt&&(Yt.style.display=""),e.state==="in_progress"){Vr(`Migration status: in progress${e.cursor?` (last doc: ${e.cursor})`:""}.`);return}Vr("Migration status: pending (runs automatically on DB use).")}catch(e){const t=e instanceof Error?e.message:"Unknown error";Vr(`Migration status unavailable: ${t}`)}}async function Hf(){tt("Updating indexing state...");let e;try{e=await chrome.runtime.sendMessage({type:"TOGGLE_INDEXING_ENABLED"})}catch(t){tt(`Failed to toggle indexing: ${V(t)}`);return}if(!e.ok){tt(`Failed to toggle indexing: ${e.error}`);return}tt(`Indexing is now ${e.enabled?"active":"paused"}.`),await vr()}async function fc(e){let t=!1;try{const o=await chrome.runtime.sendMessage({type:"GET_INDEXING_ENABLED"});t=o.ok&&o.enabled}catch{t=!1}if(t)try{await chrome.runtime.sendMessage({type:"SET_INDEXING_ENABLED",enabled:!1})}catch(o){throw new Error(`Failed to pause indexing: ${V(o)}`)}try{return await e()}finally{if(t)try{await chrome.runtime.sendMessage({type:"SET_INDEXING_ENABLED",enabled:!0})}catch(o){tt(`Warning: failed to resume indexing: ${V(o)}`)}await vr()}}async function Kf(){ye("Preparing backup export..."),tn?.setAttribute("disabled","true"),on?.setAttribute("disabled","true");let e=0;try{const t=await Od({chunkBytes:Number.MAX_SAFE_INTEGER,compress:!0,onProgress:({conversationsDone:a,conversationsTotal:r})=>{Xn(a,r,!1);const s=Date.now();s-e<150||(e=s,ye(`Exporting… ${a} of ${r} conversations.`))}});if(t.chunks.length===0){ye("Nothing to export — index is empty.");return}const o=t.chunks[0],n=o.filename.replace(/-part-\d+/,"");br(n,o.blob),ye(`Exported ${t.conversationCount} conversations and ${t.messageCount} messages.`)}catch(t){const o=t instanceof Error?t.message:"Unknown backup export error";ye(`Export failed: ${o}`)}finally{Xn(-1,0,!1),tn?.removeAttribute("disabled"),on?.removeAttribute("disabled")}}async function Yf(e){ma=!1,ye(`Importing ${e.name}...`),tn?.setAttribute("disabled","true"),on?.setAttribute("disabled","true"),nn?.removeAttribute("disabled");try{await fn();let t=0;const o=()=>ma,n=s=>{Xn(s.total,s.totalHint??Math.max(s.total,1),!0);const i=Date.now();if(i-t<150)return;t=i;const l=s.alreadyImported>0?`, ${s.alreadyImported} already had`:"";ye(`Importing ${e.name}: ${s.imported} saved${l}, ${s.total} processed…`)},a=await fc(async()=>{if(e.name.toLowerCase().endsWith(".json")){const s=JSON.parse(await e.text());return Bd(s,n,{shouldCancel:o})}return dl(e,n,{shouldCancel:o})});await dt(a.imported);const r=a.alreadyImported>0?` (${a.alreadyImported} already imported, skipped)`:"";a.cancelled?ye(`Import stopped: ${a.imported}/${a.total} conversations imported${r} (${a.failed} failed). Choose the same file again to resume.`):a.privateOrganisation&&!a.privateOrganisation.restored?ye(`Chats imported: ${a.imported}/${a.total}${r} (${a.failed} failed). ${a.privateOrganisation.message}`):ye(`Import complete: ${a.imported}/${a.total} conversations imported${r} (${a.failed} failed).${a.privateOrganisation?` ${a.privateOrganisation.message}`:""}`),await ve()}catch(t){await dt(1);const o=t instanceof Error?t.message:"Unknown backup import error";ye(`Import failed: ${o}`)}finally{Xn(-1,0,!1),tn?.removeAttribute("disabled"),on?.removeAttribute("disabled")}}function Ii(e){const t=e.split("/").pop()??e;return t==="conversations.json"||/^conversations-\d+\.json$/.test(t)}function Wf(e){const t=fr(e,{filter:n=>Ii(n.name)}),o=Object.keys(t).filter(Ii).sort();return o.length===0?null:o.map(n=>t[n])}async function Jf(e){Ao=!1,ge(`Reading ${e.name}…`),ya?.setAttribute("disabled","true"),rn?.removeAttribute("disabled");try{const t=new Uint8Array(await e.arrayBuffer());ge("Unpacking your chats from the export…");let o;try{o=Wf(t)}catch(A){const L=A instanceof Error?A.message:String(A);ge(`That .zip couldn't be opened (${L}). Make sure it's the unmodified file ChatGPT emailed you.`);return}if(!o){ge("Couldn't find your conversations inside that .zip. Make sure it's the export from ChatGPT's Settings → Data controls → Export data.");return}const n=[];try{for(const A of o){const L=JSON.parse(qa(A));Array.isArray(L)&&n.push(...L)}}catch{ge("That export's conversation list couldn't be read. It may be incomplete — try exporting from ChatGPT again.");return}if(n.length===0){ge("That file didn't look like a ChatGPT export (no conversations inside).");return}const a=Pp(t),r=n.length;let s=0,i=0,l=0,f=0,p=0;ge("Checking which chats are already imported…");const c=[];for(const A of n){const L=la(A);L&&c.push(L)}let v=null;try{const A=new Set,L=2e3;for(let S=0;S<c.length;S+=L){const W=c.slice(S,S+L),Ce=await chrome.runtime.sendMessage({type:"LIST_INDEXED_SOURCE_IDS",platform:"chatgpt",sourceIds:W});if(!Ce?.ok||!Array.isArray(Ce.unindexedSourceIds))throw new Error("skip-check unavailable");for(const Ee of Ce.unindexedSourceIds)A.add(Ee)}v=A}catch{v=null}En(0,r);for(let A=0;A<n.length&&!Ao;A+=1){const L=n[A],S=la(L);if(v&&S&&!v.has(S)&&!Np(L,a))f+=1;else{const Ee=ju(L,a);if(!Ee)i+=1;else try{(await chrome.runtime.sendMessage({type:"INDEX_CONVERSATION",indexingMode:"backfill",conversation:Ee}))?.ok?s+=1:l+=1}catch{l+=1}}const W=s+i+l+f,Ce=Date.now();Ce-p>150&&(p=Ce,En(W,r),ge(`Importing your ChatGPT history… ${W} of ${r} chats read, ${s} saved.`))}En(-1,r);const y=`${s} of ${r} chats saved from your export.`,b=f>0?` ${f} were already imported.`:"",w=i>0?` ${i} had no text to save (image-only or empty).`:"",C=l>0?` ${l} could not be saved.`:"";ge(Ao?`Import stopped. ${y}${b}${w}${C} Choose the same .zip again to resume.`:`Import complete: ${y}${b}${w}${C}`),Mt("export_import_completed","chatgpt",{count:s,skipped:i,failed:l,outcome:Ao?"stopped":"completed"}),await ve()}catch(t){const o=t instanceof Error?t.message:"Unknown import error";ge(`Import failed: ${o}`)}finally{En(-1,0),ya?.removeAttribute("disabled")}}function T(e,t){const o=ee[e].statusNode;o&&(o.textContent=t)}function gc(e){et&&(et.style.background=e?"#d97757":"#fff",et.style.color=e?"#fff":"#8a4b2e")}function mc(){Wt&&(Wt.textContent=Zt),gc(!1),Wn?.style.setProperty("display","block");for(const e of _e){if(ae[e].nativeHostOnly)continue;const t=ee[e];t.copyPathBtn?.style.setProperty("display","inline-block"),t.hintNode&&(t.hintNode.innerHTML=`<strong>Prefer not to use the terminal?</strong> Click <strong>Choose folder</strong>, then in the file dialog ${hc}, paste the copied path (<code>${ls(e)}</code>), press Enter, and choose <strong>Open</strong>. Your browser won't let you pick your Home folder, so this points it straight at your sessions.`)}}function Zf(){Wn?.style.setProperty("display","none");for(const e of _e)ee[e].copyPathBtn?.style.setProperty("display","none")}function Xf(e){const t=[`Indexed ${e.indexed} session${e.indexed===1?"":"s"}`];return e.skipped&&t.push(`${e.skipped} unchanged`),e.empty&&t.push(`${e.empty} with no chat content`),e.failed&&t.push(`${e.failed} failed to read`),`${t.join(" · ")}. Search updates as embeddings backfill.`}function yc(e){const t=ee[e];t.chooseBtn?.style.setProperty("display","none"),t.rescanBtn?.style.setProperty("display","inline-block"),t.forgetBtn?.style.setProperty("display","inline-block")}const is=Qp(),Qf=Se,eg=Bt;function ls(e){const t=ae[e];return Qf?t.windowsPath:t.posixPath}const hc=eg?"press <strong>⌘⇧G</strong> (Go to Folder)":"press <strong>Ctrl+L</strong>",Zt=`npx -y @llmnesia/local-agent-host@latest ${chrome.runtime.id}`;let ba=null,xr=!1;chrome.storage.onChanged.addListener((e,t)=>{t!=="local"||!e[Md]||!xr||yl().then(o=>{for(const n of o)ee[n.source].chooseBtn?.hasAttribute("disabled")||T(n.source,hl(n))})});const cs={claude_code:{connected:"claude_code_connected",importCompleted:"claude_code_import_completed"},codex:{connected:"codex_connected",importCompleted:"codex_import_completed"},zcode:{connected:"zcode_connected",importCompleted:"zcode_import_completed"}};async function dt(e){if(e<=0){await chrome.storage.local.remove(kl);return}await chrome.runtime.sendMessage({type:"FINALIZE_CONVERSATION_IMPORT",imported:e}).catch(()=>{})}async function fn(){await chrome.storage.local.set({[kl]:!0})}async function uo(e,t,o){const n=ee[e];n.rescanBtn?.setAttribute("disabled","true"),n.chooseBtn?.setAttribute("disabled","true");const a=r=>{T(e,`Scanning ${r.processed}/${r.total} — indexed ${r.indexed}, skipped ${r.skipped}…`)};try{await fn();const r=await o(a),s=t==="native"?(await yl()).find(l=>l.source===e):void 0,i=r.failures?.[0];T(e,`${Xf(r)}${s?` ${hl(s)}`:""}${i?` First error: ${i.message}`:""}`),await dt(r.indexed),r.indexed>0&&Mt(cs[e].importCompleted,void 0,{method:t,count:r.indexed,skipped:r.skipped})}catch(r){await dt(1),T(e,`Scan failed: ${r instanceof Error?r.message:String(r)}`)}finally{n.rescanBtn?.removeAttribute("disabled"),n.chooseBtn?.removeAttribute("disabled")}}async function tg(e){if(xr){await uo(e,"native",o=>bl(o,{force:!1,sources:[e]}));return}if(ae[e].nativeHostOnly){T(e,`${ae[e].label} sessions sync through the helper. Set up the one-time helper above, then click Connect helper.`);return}if(!is){ee[e].dirInput?.click();return}T(e,"Opening folder picker…");let t;try{t=await nu(e)}catch(o){o instanceof Ll?T(e,"No folder chosen."):T(e,`Couldn't open the folder picker: ${o instanceof Error?o.message:String(o)}`);return}if(!await Da(t,{prompt:!0})){T(e,"Read permission denied.");return}yc(e),Mt(cs[e].connected,void 0,{method:"folder"}),await uo(e,"folder",o=>Ga(e,t,o,{force:!0}))}async function og(e){const t=ee[e].dirInput,o=t?.files;if(!o||o.length===0){T(e,"No folder chosen.");return}await uo(e,"folder",n=>cu(e,o,n)),t&&(t.value="")}async function ng(e){const t=await Il(e);if(!t){T(e,"No folder connected — choose one first.");return}if(!await Da(t,{prompt:!0})){T(e,"Read permission denied — reconnect the folder.");return}await uo(e,"folder",o=>Ga(e,t,o,{force:!1}))}async function rg(e){await ou(e);const t=ee[e];t.chooseBtn?.style.setProperty("display","inline-block"),t.rescanBtn?.style.setProperty("display","none"),t.forgetBtn?.style.setProperty("display","none"),xr||mc(),T(e,"Folder forgotten. Already-indexed sessions remain searchable — delete them in Manage or Danger Zone.")}async function bc(e){xr=!0;const t=e>=Ba,o=e>=ml;chrome.runtime.sendMessage({type:"ENABLE_CLAUDE_CODE_AUTOSYNC"}).catch(()=>{}),Yn&&(Yn.style.display="none"),Zf();const n=["claude_code"];t&&n.push("codex"),o&&n.push("zcode");for(const a of n){const r=ee[a];r.chooseBtn&&(r.chooseBtn.textContent="Sync now",r.chooseBtn.style.setProperty("display","inline-block")),r.rescanBtn?.style.setProperty("display","none"),r.forgetBtn?.style.setProperty("display","none"),r.hintNode&&(r.hintNode.textContent=`The LLMnesia helper is installed — your ${ae[a].label} sessions sync automatically, in the background too. Click Sync now to check for new ones right away.`),T(a,`Helper connected. Syncing ${ae[a].label} sessions…`)}if(!t){const a=ee.codex;a.hintNode&&(a.hintNode.innerHTML=`Your installed helper predates Codex support. Re-run <code>${Zt}</code> in your terminal (then fully quit and reopen your browser) to sync Codex automatically too — or connect the folder below.`),T("codex","Helper installed, but too old for Codex."),Wn?.style.setProperty("display","block"),Wt&&(Wt.textContent=Zt)}if(!o){const a=ee.zcode;a.hintNode&&(a.hintNode.innerHTML=`Your installed helper predates ZCode support. Re-run <code>${Zt}</code> in your terminal (then fully quit and reopen your browser) to sync ZCode automatically too.`),T("zcode","Helper installed, but too old for ZCode."),Wn?.style.setProperty("display","block"),Wt&&(Wt.textContent=Zt)}for(const a of n)await uo(a,"native",r=>bl(r,{force:!1,sources:[a]}))}async function ag(){et?.setAttribute("disabled","true");for(const a of _e)T(a,"Requesting browser permission…");let e;try{e=await chrome.permissions.request({permissions:["nativeMessaging"]})}catch(a){const r=`Permission request failed: ${a instanceof Error?a.message:String(a)}`;for(const s of _e)T(s,r);et?.removeAttribute("disabled");return}if(!e){for(const a of _e)T(a,"Permission denied — click Connect helper to allow it, or use Choose folder instead.");et?.removeAttribute("disabled");return}for(const a of _e)T(a,"Looking for the helper…");const t=await gl();if(t!==null){for(const a of _e)a==="codex"&&t<Ba||a==="zcode"&&t<ml||Mt(cs[a].connected,void 0,{method:"native"});await bc(t);return}const n=ba!==null&&Date.now()-ba<1800*1e3?"Permission granted, but the helper isn't answering yet — this usually means the browser wasn't fully quit and reopened after running the command. Fully quit (not just close the window), reopen, then click Connect helper again.":"Permission granted, but the helper isn't answering yet. Copy the command above, run it in a terminal, fully quit and reopen your browser, then click Connect helper again. Need Node first? nodejs.org has an installer.";for(const a of _e)T(a,n);et?.removeAttribute("disabled")}async function Li(e){const t="Not connected. Set up the one-time helper above, or use Choose folder.";if(ae[e].nativeHostOnly){const n=ee[e];n.chooseBtn?.style.setProperty("display","none"),n.copyPathBtn?.style.setProperty("display","none"),n.rescanBtn?.style.setProperty("display","none"),n.forgetBtn?.style.setProperty("display","none"),n.hintNode&&(n.hintNode.textContent=`${ae[e].label} sessions sync through the LLMnesia helper above — there is no folder to pick.`),T(e,"Not connected. Set up the one-time helper above.");return}if(!is){const n=ee[e].hintNode;n&&(n.innerHTML=`<strong>Prefer not to use the terminal?</strong> Click <strong>Choose folder</strong>, ${hc}, paste the copied path (<code>${ls(e)}</code>), and choose <strong>Upload</strong>. Brave re-reads only new chats each time — to have it remember the folder and rescan on its own, turn on the flag below.`),T(e,t);return}const o=await Il(e);if(!o){T(e,t);return}yc(e),await Da(o,{prompt:!1})?(T(e,"Folder connected. Checking for new sessions…"),await uo(e,"folder",n=>Ga(e,o,n,{force:!1}))):T(e,"Folder connected but needs permission again — click Rescan to reconnect.")}async function sg(){if(uf){if(qd()&&await Ud()){const e=await gl();if(e!==null){await bc(e),e<Ba&&await Li("codex");return}}mc(),!is&&Yn&&(Yn.style.display="block");for(const e of _e)await Li(e)}}async function ds(){try{const e=await chrome.runtime.sendMessage({type:"VAULT_STATUS"});return e.ok&&e.status.lastSyncedAt!==null}catch{return!1}}const pt=document.querySelector("#vault-card"),ln=document.querySelector("#vault-signed-out"),Mo=document.querySelector("#vault-email"),Nn=document.querySelector("#vault-send-code"),va=document.querySelector("#vault-code-step"),Ti=document.querySelector("#vault-code-email"),Ke=document.querySelector("#vault-code"),De=document.querySelector("#vault-signin-success"),gn=document.querySelector("#vault-verify-code"),mn=document.querySelector("#vault-resend-code"),vc=document.querySelector("#vault-cancel-code"),xa=document.querySelector("#vault-create-step"),Ge=document.querySelector("#vault-new-passphrase"),ig=document.querySelector("#vault-new-passphrase-visibility"),Et=document.querySelector("#vault-confirm-passphrase"),lg=document.querySelector("#vault-confirm-passphrase-visibility"),or=document.querySelector("#vault-passphrase-strength"),$t=document.querySelector("#vault-create-continue"),nr=document.querySelector("#vault-recovery-key-block"),wa=document.querySelector("#vault-recovery-key"),Ft=document.querySelector("#vault-copy-recovery"),Oo=document.querySelector("#vault-ack-checkbox"),we=document.querySelector("#vault-confirm-create"),ka=document.querySelector("#vault-unlock-step"),_i=document.querySelector("#vault-unlock-copy"),$n=document.querySelector("#vault-biometric-unlock"),Mn=document.querySelector("#vault-biometric-unlock-btn"),st=document.querySelector("#vault-unlock-passphrase"),cg=document.querySelector("#vault-unlock-passphrase-visibility"),Sa=document.querySelector("#vault-unlock-btn"),dg=document.querySelector("#vault-recover-toggle"),Bo=document.querySelector("#vault-recover-form"),Tt=document.querySelector("#vault-recover-key"),qo=document.querySelector("#vault-recover-show-key"),Uo=document.querySelector("#vault-recover-passphrase"),pg=document.querySelector("#vault-recover-passphrase-visibility"),Vo=document.querySelector("#vault-recover-confirm"),ug=document.querySelector("#vault-recover-confirm-visibility"),Ca=document.querySelector("#vault-recover-submit"),Ea=document.querySelector("#vault-unlocked-panel"),jr=document.querySelector("#vault-phone-pair-card"),Ri=document.querySelector("#vault-phone-pair-qr"),rr=document.querySelector("#vault-account-line"),Dt=document.querySelector("#vault-sync-line"),Hr=document.querySelector("#vault-sync-text"),Pi=document.querySelector("#vault-sync-spinner"),Gt=document.querySelector("#vault-sync-error-line"),To=document.querySelector("#vault-manage-subscription-btn"),fg=document.querySelector("#vault-lock-btn"),cn=document.querySelector("#vault-biometric-toggle"),gg=document.querySelector("#vault-change-passphrase-toggle"),mg=document.querySelector("#vault-sign-out-btn"),On=document.querySelector("#vault-change-passphrase-form"),zo=document.querySelector("#vault-old-passphrase"),yg=document.querySelector("#vault-old-passphrase-visibility"),Fo=document.querySelector("#vault-newer-passphrase"),hg=document.querySelector("#vault-newer-passphrase-visibility"),Do=document.querySelector("#vault-newer-confirm"),bg=document.querySelector("#vault-newer-confirm-visibility"),$a=document.querySelector("#vault-change-passphrase-submit"),Ni=document.querySelector("#vault-status-text"),Mi=document.querySelector("#vault-status-spinner"),At=document.querySelector("#vault-paywall-seat"),Oi=document.querySelector("#vault-paywall-account-line"),Bi=document.querySelector("#vault-paywall-status-line"),Kr=document.querySelector("#vault-paywall-data-line"),Te=document.querySelector("#vault-paywall-cta"),Aa=document.querySelector("#vault-plan-annual"),Ia=document.querySelector("#vault-plan-monthly");let xc="annual";const Bn=document.querySelector("#vault-paywall-recheck-btn"),Yr=document.querySelector("#vault-paywall-recheck-status"),qi=wu(()=>chrome.runtime.sendMessage({type:"VAULT_REFRESH_ENTITLEMENT"})),vg=document.querySelector("#vault-paywall-sign-out-btn"),La=document.querySelector("#vault-firstsync-row"),xg=document.querySelector("#vault-firstsync-dot"),Ui=document.querySelector("#vault-firstsync-text"),Xt=document.querySelector("#vault-firstsync-btn"),Wr=document.querySelector("#vault-firstsync-progress"),Vi=document.querySelector("#vault-firstsync-progress-fill"),Ta=document.querySelector("#vault-backup-row"),wg=document.querySelector("#vault-backup-dot"),zi=document.querySelector("#vault-backup-text"),D=document.querySelector("#vault-backup-btn"),Jr=document.querySelector("#vault-backup-progress"),Fi=document.querySelector("#vault-backup-progress-fill"),dn=document.querySelector("#vault-restore-row"),kg=document.querySelector("#vault-restore-dot"),Di=document.querySelector("#vault-restore-text"),ot=document.querySelector("#vault-restore-btn"),Zr=document.querySelector("#vault-restore-progress"),Gi=document.querySelector("#vault-restore-progress-fill"),Xr=document.querySelector("#vault-incoming-row"),Qr=document.querySelector("#vault-incoming-text"),An=document.querySelector("#vault-incoming-progress"),ji=document.querySelector("#vault-incoming-progress-fill");let Go=null,_a=0,fo=null,It=null;const Lt=new Tu;let Ye=null,M=null,G=0,Ra=!1;function ut(){Ye?.fill(0),Ye=null}function Hi(e){Mn?.toggleAttribute("disabled",e),Mn&&(Mn.textContent=e?"Waiting for biometrics…":"Unlock with biometrics")}async function Sg(e){if(!(!e||Ye))try{const t=await chrome.storage.session.get([Ps,Ns]);if(M!==e||t[Ns]!==e)return;const o=t[Ps];typeof o=="string"&&o.length>0&&(Ye=Uint8Array.from(atob(o),n=>n.charCodeAt(0)))}catch{}}async function ar(e,t){if(!e){Ra=!1,$n&&($n.style.display="none");return}const o=await Lt.hasEnrollment(e);M===e&&(Ra=o,cn&&(cn.textContent=o?"Disable biometric unlock":"Enable biometric unlock"),$n&&($n.style.display=!t&&o?"":"none"),_i&&!t&&(_i.textContent=o?"You already have a Vault for this email. Use your device biometrics, or enter its passphrase.":"You already have a Vault for this email. Enter its passphrase to open it on this device."))}function wr(e){let t="";for(const o of e)t+=String.fromCharCode(o);return btoa(t)}function d(e,t=!1){Ni&&(Ni.textContent=e),Mi&&(Mi.hidden=!t)}function Cg(){De&&(De.style.display="none",De.textContent="",delete De.dataset.email)}function kr(){for(const e of[ln,va,xa,ka,Ea,At])e&&(e.style.display="none")}function Ki(e){pt&&(pt.style.display=""),kr(),d(e)}function Eg(e){if(e.length===0)return"";if(e.length<8)return"Too short — use at least 8 characters";const t=[/[a-z]/,/[A-Z]/,/[0-9]/,/[^a-zA-Z0-9]/].filter(o=>o.test(e)).length;return e.length>=16&&t>=3?"Strong":e.length>=12&&t>=2?"Good":"OK — longer or more varied is stronger"}const wc=[];function ft(e,t,o){if(!e||!t)return;const n={input:e,button:t,label:o};wc.push(n),Gu(n)}function Sr(...e){for(const t of e){const o=wc.find(n=>n.input===t);o&&Ul(o,!1)}}function kc(){It?.vaultKey.fill(0),It=null,Ge&&(Ge.value="",Ge.removeAttribute("disabled")),Et&&(Et.value="",Et.removeAttribute("disabled")),Sr(Ge,Et),or&&(or.textContent=""),nr&&(nr.style.display="none"),Oo&&(Oo.checked=!1),we&&(we.setAttribute("disabled","true"),we.style.opacity="0.5"),$t&&($t.style.display="")}function sr(){Bo&&(Bo.style.display="none"),Tt&&(Tt.value="",Tt.type="password"),Uo&&(Uo.value=""),Vo&&(Vo.value=""),Sr(Uo,Vo),qo&&(qo.textContent="Show recovery key")}function $g(e){const t=Date.now()-e,o=Math.round(t/6e4);if(o<1)return"just now";if(o<60)return`${o}m ago`;const n=Math.round(o/60);if(n<24)return`${n}h ago`;const a=Math.round(n/24);return a<7?`${a}d ago`:new Date(e).toLocaleDateString()}let ir=null,lr=null,pn=!1;function go(e,t){ir=e,lr=t;const o=nd(t);if(o){const n=rd(o);Dt&&(Dt.style.display="none"),Gt&&(Gt.style.display="",Gt.textContent=n.tone==="attention"?`⚠ ${n.text}`:n.text,Gt.title=t?`${t.message} (${mr(t.at)})`:"");return}if(Gt&&(Gt.style.display="none"),Dt&&(Dt.style.display="",Pi&&(Pi.hidden=!pn),Hr)){const n=ps?.copy,a=pn?"Syncing now":n??(e?`Vault last synced ${$g(e)}`:"Vault is ready to sync");if(_a>0){const r=_a;Hr.textContent=`${a} · Some saved items need checking. Use Restore again.`,Dt.title=`${r} ${r===1?"item was":"items were"} skipped in earlier syncs. Restore again rechecks the Vault and shows why any still cannot be added here.`}else Hr.textContent=a,Dt.title=""}}const qe=document.querySelector("#vault-status-pill"),so=document.querySelector("#vault-status-pill-button"),Ag=document.querySelector("#vault-status-pill-panel"),Pa=document.querySelector("#vault-status-pill-facts"),Qt=document.querySelector("#vault-status-pill-sync-now"),_t=document.querySelector("#vault-status-pill-recovery");let ps=null;const Cr=dd({root:qe,button:so,panel:Ag,syncNow:Qt,render:Ig,refresh:yo,async runSync(){return(await chrome.runtime.sendMessage({type:"VAULT_SYNC_NOW"}))?.ok===!0}});let Yi=0;function Na(e){Cr.clear(),ps=null,fd({root:qe,button:so,facts:Pa,syncNow:Qt,recovery:_t,label:document.querySelector("#vault-status-pill-label"),attention:document.querySelector("#vault-status-attention")},e)}Na("checking");async function yo(){if(!qe)return;const e=++Yi,t=await gd();if(e!==Yi)return;if(!t){Na("unavailable");return}if(!md(t)){Na(t.status.available?"setup":"unavailable");return}const o=yd(t,Date.now());Cr.update(o)}function Ig(e){if(!qe)return;ps=e,qe.dataset.visible="true",qe.dataset.tone=e.tone,qe.dataset.condition=e.condition;const t=document.querySelector("#vault-status-attention");t&&(t.hidden=e.tone!=="attention",t.textContent=hn(e)),qe.dataset.busy=e.busy?"true":"false",so?.setAttribute("aria-label",`Vault status: ${e.copy}`),so&&(so.title=hn(e));const o=document.querySelector("#vault-status-pill-label");if(o&&o.textContent!==hn(e)&&(o.textContent=hn(e)),Qt&&(Qt.hidden=!1,Qt.disabled=e.busy||!e.canSyncNow,hd(Qt,e.busy)),_t){const n={signin:"Go to sign-in",unlock:"Go to unlock",subscription:"Review subscription",update:"How to update"},a=e.recovery;_t.hidden=a===null,_t.textContent=a===null?"":n[a]}Pa&&bd(Pa,e,()=>{Cr.close(),pt?.scrollIntoView({behavior:"smooth",block:"start"}),fs().then(()=>{dn?.style.display!=="none"&&dn?.scrollIntoView({behavior:"smooth",block:"center"}),ot?.style.display!=="none"&&ot?.focus({preventScroll:!0})})}),go(ir,lr)}qe&&so&&(document.querySelector("#vault-status-attention")?.addEventListener("click",()=>_t?.click()),_t&&_t.addEventListener("click",()=>{Cr.close(),pt?.scrollIntoView({behavior:"smooth",block:"start"}),pt?.focus?.()}),chrome.storage.onChanged.addListener((e,t)=>{t==="local"&&(dp in e||pp in e||up in e||pd.some(o=>o in e))&&Lg()}),ud(()=>{yo()}));let In=null;function Lg(){In&&clearTimeout(In),In=setTimeout(()=>{In=null,yo()},200)}async function Wi(e){At&&(At.style.display="");const t=wp({email:e.email,hasVault:e.hasVault===!0||e.unlocked,lastSyncedAt:e.lastSyncedAt,lastSyncErrorKind:e.lastSyncError?.kind??null});At&&(At.dataset.state=t.state),Oi&&(Oi.textContent=t.accountLine),Bi&&(Bi.textContent=t.statusLine),Kr&&(Kr.textContent=t.dataLine,Kr.style.display=t.dataLine?"":"none"),Te&&(Te.textContent=t.actionLabel)}function Re(e){Yr&&(Yr.textContent=e,Yr.style.display=e?"":"none")}async function Ji(){if(!(!qi||Bn?.disabled)){Bn?.setAttribute("disabled","true"),Re(ko.checking);try{const e=await qi();if(e.kind==="cooldown"){Re(ko.cooldown);return}if(e.response.ok&&e.response.entitled===!0){Re(ko.confirmed),await te();return}Re(ko.unconfirmed)}catch{Re(ko.failed)}finally{Bn?.removeAttribute("disabled")}}}async function Tg(){if(!Te||Te.disabled)return;const e=Te.textContent??"Continue to checkout";Te.setAttribute("disabled","true"),Te.textContent=wo.opening,Re("");let t;try{t=await chrome.runtime.sendMessage({type:"VAULT_CREATE_CHECKOUT",plan:xc})}catch{t={ok:!1,error:"checkout_unavailable"}}if(Te.textContent=e,Te.removeAttribute("disabled"),!t||typeof t.ok!="boolean"){Re(wo.unavailable);return}if(!t.ok){if(t.error==="subscription_already_exists"){Re(wo.alreadySubscribed),chrome.tabs.create({url:Cl});return}Re(wo.unavailable);return}await chrome.tabs.create({url:t.url}),Re(wo.opened)}function Zi(e){xc=e,Aa?.classList.toggle("selected",e==="annual"),Aa?.setAttribute("aria-pressed",e==="annual"?"true":"false"),Ia?.classList.toggle("selected",e==="monthly"),Ia?.setAttribute("aria-pressed",e==="monthly"?"true":"false")}async function _g(){if(!To||To.disabled)return;To.setAttribute("disabled","true");let e;try{e=await chrome.runtime.sendMessage({type:"VAULT_CREATE_PORTAL"})}catch{e=void 0}finally{To.removeAttribute("disabled")}if(e?.ok&&typeof e.url=="string"){await chrome.tabs.create({url:e.url});return}await chrome.tabs.create({url:Cl})}function Rg(e){return e.available?e.signedIn?e.lastSyncedAt!==null?!0:e.hasVault:null:!1}let Xi=null,Qi=!1;async function Pg(e){if(!jr||!Ri)return;const t=e?.trim().toLowerCase()||null;if(!(Xi===t&&jr.style.display!=="none"))try{const{vaultPairingQrSvg:o,vaultPairingUrl:n}=await un(async()=>{const{vaultPairingQrSvg:a,vaultPairingUrl:r}=await import("./vault_pair_qr.js");return{vaultPairingQrSvg:a,vaultPairingUrl:r}},[]);Ri.innerHTML=o(n(t),{pixels:136}),jr.style.display="flex",Xi=t,Qi||(Qi=!0,Mt("vault_phone_qr_shown"))}catch{}}async function Sc(e){if(nc=Rg(e),lc(),!pt)return;(!e.signedIn||e.email?.toLowerCase()!==De?.dataset.email)&&Cg();const t=e.signedIn?e.accountId:null;if(t!==M&&(G++,ut(),sr(),M=t),e.unlocked||(ut(),On?.style.display!=="none"&&gs()),e.unlocked&&sr(),Nc(),he("hidden","",null),Qe(),J("hidden","",null),wt(),Z("hidden","",null),Xg(),Ro(null),jg(),go(null,null),yo(),pt.style.display="",kr(),!e.available){d("Vault is temporarily unavailable. Reload Settings to try again.");return}if(!e.signedIn){ln&&(ln.style.display=""),d("");return}if(e.entitled===null){d("Checking your Vault subscription…",!0);return}if(e.entitled!==!0){await Wi(e),d("");return}if(e.unlocked){Ea&&(Ea.style.display=""),rr&&(rr.textContent=e.email??"Account email unavailable"),Pg(e.email),go(e.lastSyncedAt,e.lastSyncError),Pc(),Zg(),Gg(),Tc(),await Sg(e.accountId),await ar(e.accountId,!0),d("");return}d("Checking for an existing Vault…",!0);let o;try{o=await chrome.runtime.sendMessage({type:"VAULT_GET_WRAPPED_KEY"})}catch(n){d(`Could not check Vault status: ${V(n)}`);return}if(!o.ok){if(/vault_not_entitled|not[_ ]entitled/i.test(o.error)){await Wi({...e}),d("");return}d(`Could not check Vault status: ${o.error}`);return}if(d(""),o.wrappedVaultKey){ka&&(ka.style.display=""),Sr(st),await ar(e.accountId,!1);try{(await chrome.storage.local.get("llmnesia.vault.deviceKeyUnreadable"))["llmnesia.vault.deviceKeyUnreadable"]===!0&&d("This device needs your passphrase again")}catch{}}else kc(),xa&&(xa.style.display="")}async function te(e={}){if(!pt)return;let t;try{t=await chrome.runtime.sendMessage({type:"VAULT_STATUS"})}catch(o){Ki(`Vault status unavailable: ${V(o)}`);return}if(!t.ok){Ki(`Vault status unavailable: ${t.error}`);return}if(await Sc(t.status),e.forceEntitlement){try{await chrome.runtime.sendMessage({type:"VAULT_REFRESH_ENTITLEMENT"})}catch{}await te()}}async function Cc(){if(Nn?.disabled)return;const e=Yd(Mo?.value??"");if(!Wd(e)){d("Enter a valid email address.");return}d("Sending code…",!0),Nn?.setAttribute("disabled","true");try{const t=await chrome.runtime.sendMessage({type:"VAULT_REQUEST_CODE",email:e});if(!t.ok){d(t.error);return}fo=e,Mo&&(Mo.value=e),Ti&&(Ti.textContent=e),Ke&&(Ke.value=""),kr(),va&&(va.style.display=""),d("")}catch(t){d(Ua(t,"send"))}finally{Nn?.removeAttribute("disabled")}}function cr(e){for(const t of[mn,gn,vc,Ke])t&&(t.disabled=e)}async function Ng(){if(!(!fo||mn?.disabled||gn?.disabled)){d("Resending code…",!0),cr(!0);try{const e=await chrome.runtime.sendMessage({type:"VAULT_REQUEST_CODE",email:fo});e.ok&&Ke&&(Ke.value=""),d(e.ok?"New code sent. Use the code in the most recent email.":e.error)}catch(e){d(Ua(e,"send"))}finally{cr(!1)}}}function Mg(){mn?.disabled||gn?.disabled||(fo=null,kr(),ln&&(ln.style.display=""),d(""),Ke&&(Ke.value=""),Mo?.focus())}async function Ec(){if(gn?.disabled||mn?.disabled)return;const e=fo,t=Jd(Ke?.value??"");if(!e){d("Start over. Enter your email again.");return}if(!/^\d{6,8}$/.test(t)){d("Enter the code from your email.");return}d("Verifying…",!0),cr(!0);try{const o=await chrome.runtime.sendMessage({type:"VAULT_VERIFY_CODE",email:e,code:t});if(!o.ok){d(o.error);return}fo=null,await te(),De&&(De.textContent=`Email confirmed. You're signed in to Vault as ${e}.`,De.dataset.email=e.toLowerCase(),De.style.display="flex")}catch(o){d(Ua(o,"verify"))}finally{cr(!1)}}async function Og(){const e=Ge?.value??"",t=Et?.value??"";if(e.length<8){d("Passphrase must be at least 8 characters.");return}if(e!==t){d("Passphrases don't match.");return}d("Securing your Vault…",!0),$t?.setAttribute("disabled","true");try{const o=await un(()=>import("./index.js"),__vite__mapDeps([0,1,2,3])),n=o.generateVaultKey(),a=await o.deriveWrappingKey(e),r=await o.wrapVaultKey(n,a),s=o.encodeRecoveryKey(n);a.key.fill(0),It={vaultKey:n,wrappedVaultKey:r},wa&&(wa.textContent=s),nr&&(nr.style.display=""),Ge?.setAttribute("disabled","true"),Et?.setAttribute("disabled","true"),$t&&($t.style.display="none"),d("")}catch(o){d(V(o))}finally{$t?.removeAttribute("disabled")}}async function Bg(){if(It){d("Finishing Vault setup…",!0),we?.setAttribute("disabled","true");try{const e=await chrome.runtime.sendMessage({type:"VAULT_SET_KEY",vaultKey:wr(It.vaultKey),expectedUserId:M??void 0,wrappedVaultKey:It.wrappedVaultKey});if(!e.ok){d(e.error);return}ut(),Ye=new Uint8Array(It.vaultKey),Mt("vault_created"),kc(),await te()}catch(e){d(V(e))}finally{we?.removeAttribute("disabled")}}}async function $c(){const e=M,t=G,o=st?.value??"";if(!o){d("Enter your passphrase.");return}if(!e){d(K("U09"));return}d("Unlocking your Vault…",!0),Sa?.setAttribute("disabled","true");let n="U01",a=null;try{const r=await chrome.runtime.sendMessage({type:"VAULT_GET_WRAPPED_KEY"});if(!r.ok){d(po(r.error,"U01"));return}if(!r.wrappedVaultKey){d(K("U08"));return}n="U06";const s=await un(()=>import("./index.js"),__vite__mapDeps([0,1,2,3]));try{a=await s.unlockVaultKey(r.wrappedVaultKey,o)}catch(l){d(vl(l));return}if(t!==G||e!==M){a.fill(0),d(K("U09"));return}n="U07";const i=await chrome.runtime.sendMessage({type:"VAULT_SET_KEY",vaultKey:wr(a),expectedUserId:e,expectedWrappedKeyId:JSON.stringify(r.wrappedVaultKey)});if(!i.ok){a.fill(0),d(po(i.error,"U07"));return}if(t!==G||e!==M){a.fill(0);return}ut(),Ye=a,a=null,st&&(st.value=""),d(""),await te()}catch{d(K(n))}finally{a?.fill(0),Sa?.removeAttribute("disabled")}}async function qg(){const e=Tt?.value??"",t=Uo?.value??"",o=Vo?.value??"",n=M,a=G;if(!n){d(K("R06"));return}if(t.length<8){d(K("R02"));return}if(t!==o){d(K("R02"));return}d("Checking recovery key and securing your Vault…",!0),Ca?.setAttribute("disabled","true");let r=null,s="R07";try{const i=await un(()=>import("./index.js"),__vite__mapDeps([0,1,2,3]));try{r=i.decodeRecoveryKey(e)}catch(y){if(y instanceof i.RecoveryKeyError)if(y.reason==="wrong length"){const b=i.recoveryKeySymbolCount(e);d(`Recovery key has ${b} symbols after removing separators; this key format uses ${i.RECOVERY_KEY_SYMBOLS}. (Support code: R01)`)}else if(y.reason==="no key found in text"){const b=i.recoveryKeySymbolCount(e);d(`The pasted text has ${b} symbols after removing separators. No checksum-valid 55-symbol recovery key was found in it. (Support code: R01)`)}else y.reason==="multiple keys"?d("The pasted text contains more than one valid recovery key. Paste only the key for this Vault. (Support code: R01)"):y.reason==="too much text"?d("The pasted text is too long. Copy only the recovery key and its nearby label. (Support code: R01)"):y.reason==="invalid character"?d("Recovery key contains a character outside its letters and numbers. Check for note formatting or extra text. (Support code: R01)"):d("Recovery key has the right length, but its checksum does not match. Check your saved copy for a changed character. (Support code: R01)");else d(K("R01"));return}s="R03";const l=await chrome.runtime.sendMessage({type:"VAULT_GET_WRAPPED_KEY"});if(!l.ok){d(po(l.error,"R03"));return}if(!l.wrappedVaultKey){d(K("R11"));return}const f=JSON.stringify(l.wrappedVaultKey);s="R07";const p=await i.deriveWrappingKey(t);let c;try{c=await i.wrapVaultKey(r,p)}finally{p.key.fill(0)}if(a!==G||n!==M){d(K("R06"));return}s="R08";const v=await chrome.runtime.sendMessage({type:"VAULT_RECOVER_KEY",vaultKey:wr(r),wrappedVaultKey:c,expectedUserId:n,expectedWrappedKeyId:f});if(!v.ok){d(po(v.error,"R08"));return}if(a!==G||n!==M){d(K("R13"));return}s="R09",ut(),Ye=new Uint8Array(r),st&&(st.value=""),sr(),await te(),d("Passphrase reset. Vault unlocked.")}catch{d(K(s))}finally{r?.fill(0),Ca?.removeAttribute("disabled")}}async function Ug(){const e=M,t=G;if(!e)return;d("Confirm with your device biometrics to unlock."),Hi(!0);let o=null;try{if(o=await Lt.unlock(e),t!==G||e!==M)return;if(!o){d("Biometrics could not unlock this Vault. Use your passphrase.");return}const n=await chrome.runtime.sendMessage({type:"VAULT_SET_KEY",vaultKey:wr(o),expectedUserId:e});if(t!==G||e!==M)return;if(!n.ok){d(n.error);return}ut(),Ye=o,o=null,await te()}catch{t===G&&e===M&&d("Biometrics could not unlock this Vault. Use your passphrase.")}finally{o?.fill(0),Hi(!1)}}async function Vg(){const e=M,t=G;if(e){cn?.setAttribute("disabled","true");try{if(Ra){await Lt.remove(e),await ar(e,!0),d("Biometric unlock disabled on this device.");return}const o=Ye;if(!o){d("Lock your Vault, then use your passphrase before enabling biometrics on this device.");return}d("Confirm with your device biometrics to enable biometric unlock.");const n=await Lt.prepareEnrollment(e,o);if(!n||t!==G||e!==M){d("Biometric unlock could not be enabled on this device.");return}if(await Lt.save(n),t!==G||e!==M){await Lt.remove(e,n);return}await ar(e,!0),d("Biometric unlock enabled on this device.")}catch{d("Biometric unlock could not be enabled on this device.")}finally{cn?.removeAttribute("disabled")}}}async function zg(){G++,ut(),await chrome.runtime.sendMessage({type:"VAULT_LOCK"}),await te()}async function Ac(){window.confirm("Sign out of Vault? Your local index stays intact and nothing is deleted — you can sign back in any time.")&&(G++,ut(),M&&await Lt.remove(M).catch(()=>{}),await chrome.runtime.sendMessage({type:"VAULT_SIGN_OUT"}),await te())}let ea=null;async function dr(e){const t=ea===null,o=ea===e;ea=e,!(t||o)&&await ve()}function Fg(e){const{pushed:t,incoming:o,formatUpgradeQueued:n=0,formatUpgradeContinuing:a=!1}=e,r=(l,f)=>`${l} ${f}${l===1?"":"s"}`,s=[];if(t>0&&s.push(`${r(t,"change")} saved to your Vault`),o.applied>0&&s.push(`${r(o.applied,"conversation")} added from your other devices`),o.deleted>0&&s.push(`${r(o.deleted,"conversation")} removed`),o.failed>0&&s.push(`${r(o.failed,"record")} couldn't be read`),n>0){const l=a?" The rest will continue in the background.":"";return`Preparing richer message formatting for ${r(n,"conversation")}.${l}`}if(s.length===0)return"Vault synced. Everything was already up to date.";const i=o.complete?"":" Still catching up, this will continue in the background.";return`Vault synced. ${s.join(", ")}.${i}`}async function Dg(){d("Syncing your Vault…");const e=D?.textContent??"";D&&(D.textContent="Syncing…",D.setAttribute("disabled","true"));try{const t=await chrome.runtime.sendMessage({type:"VAULT_SYNC_NOW"});if(!t){d("Vault did not return a sync result. Check the status above.");return}if(!t.ok){d(t.error);return}if("deduped"in t||!("result"in t)||!t.result?.incoming){await te(),d("A background Vault sync was already running. Check the status above.");return}await te(),d(Fg(t.result));const{applied:o,deleted:n}=t.result.incoming;(o>0||n>0)&&await ve()}catch(t){d(V(t))}finally{D&&(D.textContent=e||"Sync now",D.removeAttribute("disabled")),yo()}}let jo=null,_o=!1;function Gg(){jo===null&&(jo=window.setInterval(async()=>{try{const e=await chrome.runtime.sendMessage({type:"VAULT_SYNC_STATUS"});if(!e.ok)return;e.syncing&&!_o?(_o=!0,pn=!0,go(ir,lr),D&&!it&&(D.textContent="Syncing…",D.setAttribute("disabled","true"))):!e.syncing&&_o&&(_o=!1,pn=!1,go(ir,lr),D&&!it&&(D.textContent="Sync now",D.removeAttribute("disabled")))}catch{}},2e3))}function jg(){jo!==null&&(window.clearInterval(jo),jo=null,_o=!1,pn=!1)}let it=!1,qn=!1,Ho=null;const us=45e3;function J(e,t,o){if(Ta){if(Ta.style.display=e==="hidden"?"none":"flex",e==="hidden"){Le(null);return}wg?.setAttribute("data-state",e),zi&&(zi.textContent=t),D&&(D.style.display=o?"":"none",D.textContent=o??"",D.removeAttribute("disabled"))}}function Le(e){if(!Jr||!Fi)return;if(!e||e.total<=0){Jr.style.display="none";return}Jr.style.display="";const t=Math.max(0,Math.min(100,Math.round(e.done/e.total*100)));Fi.style.width=`${t}%`}function Hg(e,t){const o="Sending your conversations…";return t&&t>0?`${o} ${e}/${t}`:o}async function pr(){if(!Ta)return;let e;try{e=await chrome.runtime.sendMessage({type:"VAULT_UPLOAD_PROGRESS"})}catch{J("hidden","",null);return}if(!e.ok){J("hidden","",null);return}const t=e.progress;if(qn&&it&&t?.phase!=="done"){J("running","Stopping after this batch…",null),Le(t?.total?{done:t.queued,total:t.total}:null);return}if(!t){if(it){J("running","Sending your conversations…","Stop");return}if(at===0){J("idle","Nothing here to send yet.",null),Le(null),Qe();return}if(await ds()){J("idle","Vault backup is set up. Check the latest sync time above.","Sync now"),Le(null),Qe();return}J("idle","Not everything is backed up yet.","Sync to Vault"),Le(null),Qe();return}if(t.phase==="done"){if(at===null?t.total===0:at===0){J("idle","Nothing here to send yet.",null),Le(null),Qe();return}J("idle","Initial backup complete. Check the latest sync time above.","Sync now"),Le(null),Qe();return}if(t.cancelled){J("idle",`Paused — ${t.queued} sent.`,"Resume"),Le(t.total?{done:t.queued,total:t.total}:null),Qe();return}it||Date.now()-t.updatedAt<us?(J("running",Hg(t.queued,t.total),"Stop"),Le(t.total?{done:t.queued,total:t.total}:null),Ic()):(J("idle","Unfinished — continuing automatically.","Continue now"),Le(t.total?{done:t.queued,total:t.total}:null),Qe())}function Ic(){Ho===null&&(Ho=window.setInterval(()=>{pr()},3e3))}function Qe(){Ho!==null&&(window.clearInterval(Ho),Ho=null)}async function Kg(){const e=D?.textContent??"";if(e==="Stop"){qn=!0,J("running","Stopping after this batch…",null),await chrome.runtime.sendMessage({type:"VAULT_CANCEL_INITIAL_UPLOAD"}).catch(()=>{});return}if(e==="Sync now"){await Dg(),await pr();return}if(!it){it=!0,qn=!1,J("running","Syncing your conversations to your Vault…","Stop"),Ic();try{const t=await chrome.runtime.sendMessage({type:"VAULT_RUN_INITIAL_UPLOAD",resume:e==="Resume"||e==="Continue now"});t.ok||d(t.error)}catch(t){d(V(t))}finally{it=!1,qn=!1,await te(),await pr()}}}let Rt=!1,Un=!1,Ko=null;function Z(e,t,o){if(dn){if(dn.style.display=e==="hidden"?"none":"flex",e==="hidden"){Me(null);return}kg?.setAttribute("data-state",e),Di&&(Di.textContent=t),ot&&(ot.style.display=o?"":"none",ot.textContent=o??"",ot.removeAttribute("disabled"))}}function Me(e){if(!Zr||!Gi)return;if(!e||e.total<=0){Zr.style.display="none";return}Zr.style.display="";const t=Math.max(0,Math.min(100,Math.round(e.done/e.total*100)));Gi.style.width=`${t}%`}const Yg=5e3,el=50;async function Lc(){try{const e=await chrome.runtime.sendMessage({type:"VAULT_INCOMING_PROGRESS"});return e.ok&&e.progress!==null}catch{return!1}}function Wg(e,t,o){return`${o==="checking"?"Checking your Vault after reconnect":"Bringing your Vault here"}… ${e.toLocaleString()} of ${t.toLocaleString()}`}function Ro(e){if(Xr){if(!e||e.total<=0){Xr.style.display="none",An&&(An.style.display="none");return}if(Xr.style.display="flex",Qr){const t=Wg(e.done,e.total,e.mode),o=e.total>el&&e.mode==="importing";Qr.textContent=o?`${t} This continues automatically in the background.`:t,Qr.title=e.total>el?e.mode==="checking"?"Your local Vault is already current so far. This verification safely checks remote updates and deletions without importing duplicates.":"This looks like a first sync — a large Vault can take a while, sometimes an hour or more. It keeps going in the background, even if you close this page.":""}if(An&&ji){An.style.display="";const t=Math.max(0,Math.min(100,Math.round(e.done/e.total*100)));ji.style.width=`${t}%`}}}async function Jg(){yo();let e;try{e=await chrome.runtime.sendMessage({type:"VAULT_STATUS"})}catch{return}if(!e.ok||!e.status.unlocked)return;const t=e.status;if(t.entitled!==!0){await Sc(t);return}rr&&(rr.textContent=t.email??"Account email unavailable"),go(t.lastSyncedAt,t.lastSyncError)}async function Tc(){if(io||Rt){Ro(null);return}let e,t;try{[e,t]=await Promise.all([chrome.runtime.sendMessage({type:"VAULT_INCOMING_PROGRESS"}),chrome.runtime.sendMessage({type:"VAULT_RESTORE_PROGRESS"})])}catch{return}if(e.ok&&(_a=Math.max(0,Math.floor(e.unappliable??0))),t.ok&&t.progress&&!t.progress.cancelled&&t.progress.phase!=="done"&&Date.now()-t.progress.updatedAt<us){Ro(null);return}if(!e.ok||!e.progress){Ro(null);return}const{remaining:n,total:a,mode:r}=e.progress;Ro({done:Math.max(0,a-n),total:a,mode:r}),await dr(`incoming:${n}`)}function Zg(){Go===null&&(Go=window.setInterval(()=>{Tc(),Jg()},Yg))}function Xg(){Go!==null&&(window.clearInterval(Go),Go=null)}function tl(e,t,o){const n=e===0?"Your Vault is already on this device.":`Restored ${e} ${e===1?"conversation":"conversations"} from your Vault.`;if(t===0)return n;const a=`${n} ${_c(t,o)}`,r=Qg(o);return r?`${a} (${r})`:a}function _c(e,t){let o=null,n=0;for(const[r,s]of Object.entries(t))s>n&&(o=r,n=s);if(o===null&&e>0)return`${e} couldn't be read. Run Restore again to see why.`;const a=e!==1;switch(o){case"decrypt":return a?`${e} couldn't be unlocked. If that's most of your Vault, the passphrase on this device doesn't match the one it was saved with.`:"1 couldn't be unlocked.";case"empty":return a?`${e} had no messages saved, so there was nothing to bring back.`:"1 had no messages saved, so there was nothing to bring back.";case"write":return`${e} couldn't be saved to this device.`;case"unknown-kind":return a?`${e} were saved by a newer version and were left alone.`:"1 was saved by a newer version and was left alone.";case"parse":case"invalid":case null:return a?`${e} couldn't be read.`:"1 couldn't be read."}}function Qg(e){const t=Object.entries(e).filter(([,o])=>o>0).sort((o,n)=>n[1]-o[1]).map(([o,n])=>`${o} ${n}`);return t.length>0?t.join(", "):""}async function fs(){if(!dn)return;let e;try{e=await chrome.runtime.sendMessage({type:"VAULT_RESTORE_PROGRESS"})}catch{Z("hidden","",null);return}if(!e.ok){Z("hidden","",null);return}const t=e.progress,o=t?.total?{done:t.restored+t.skipped+t.failed,total:t.total}:null;if(Un&&Rt&&t?.phase!=="done"){Z("running","Stopping after this batch…",null),Me(o);return}if(!t){if(Rt){Z("running","Fetching your Vault…","Stop");return}if(await Lc()){Z("hidden","",null),wt();return}if(await ds()){Z("idle",tl(0,0,{}),"Restore again"),Me(null),wt();return}Z("idle","Nothing restored yet.","Restore"),Me(null),wt();return}if(t.phase==="done"){Z("idle",tl(t.restored,t.failed,t.failures??{}),"Restore again"),Me(null),wt(),await dr(`done:${t.restored}`);return}if(t.cancelled){Z("idle",`Paused — ${t.restored} restored.`,"Resume"),Me(o),wt();return}if(Rt||Date.now()-t.updatedAt<us){if(t.phase==="pull")Z("running","Fetching your Vault…","Stop"),Me(null);else{const a=t.restored+t.skipped+t.failed;Z("running",t.total?`Restoring… ${a}/${t.total}`:"Restoring…","Stop"),Me(o),await dr(`records:${Math.floor(t.restored/100)}`)}Rc()}else Z("idle","Unfinished — continuing automatically.","Continue now"),Me(o),wt()}function Rc(){Ko===null&&(Ko=window.setInterval(()=>{fs()},3e3))}function wt(){Ko!==null&&(window.clearInterval(Ko),Ko=null)}async function em(){const e=ot?.textContent??"";if(e==="Stop"){Un=!0,Z("running","Stopping after this batch…",null),await chrome.runtime.sendMessage({type:"VAULT_CANCEL_RESTORE"}).catch(()=>{});return}if(!Rt){Rt=!0,Un=!1,Z("running","Fetching your Vault…","Stop"),Rc();try{const t=await chrome.runtime.sendMessage({type:"VAULT_RUN_RESTORE",resume:e==="Resume"||e==="Continue now",restart:e==="Restore again"});t.ok||d(t.error)}catch(t){d(V(t))}finally{Rt=!1,Un=!1,await te()}}}let io=!1,Vn=!1,eo=null,Yo=null;function he(e,t,o){if(La){if(La.style.display=e==="hidden"?"none":"flex",e==="hidden"){Wo(null);return}xg?.setAttribute("data-state",e),Ui&&(Ui.textContent=t),Xt&&(Xt.style.display=o?"":"none",Xt.textContent=o??"",Xt.removeAttribute("disabled"))}}function Wo(e){if(!Wr||!Vi)return;if(!e||e.total<=0){Wr.style.display="none";return}Wr.style.display="";const t=Math.max(0,Math.min(100,Math.round(e.done/e.total*100)));Vi.style.width=`${t}%`}async function tm(){if(!La)return!1;if(io)return!0;let e,t,o,n;try{[e,t,o,n]=await Promise.all([chrome.runtime.sendMessage({type:"VAULT_RESTORE_PROGRESS"}),chrome.runtime.sendMessage({type:"VAULT_UPLOAD_PROGRESS"}),Lc(),ds()])}catch{return he("hidden","",null),!1}const a=e.ok&&e.progress===null,r=t.ok&&t.progress===null;return!a||!r||o||n?(he("hidden","",null),!1):(he("idle",at===0?"Nothing on this device yet.":"This device isn't synced yet. Vault syncs on its own; this moves everything over right now.",at===0?"Bring my Vault here":"Sync this device"),Wo(null),!0)}async function Pc(){await tm()||(he("hidden","",null),pr(),fs())}function om(){Yo===null&&(Yo=window.setInterval(()=>{nm()},3e3))}function Nc(){Yo!==null&&(window.clearInterval(Yo),Yo=null)}async function nm(){if(!(!io||Vn)){if(eo==="restore"){const e=await chrome.runtime.sendMessage({type:"VAULT_RESTORE_PROGRESS"}).catch(()=>null),t=e?.ok?e.progress:null;if(!t||t.phase==="pull"){he("running","Fetching your Vault…","Stop"),Wo(null);return}const o=t.restored+t.skipped+t.failed;he("running",t.total?`Bringing your Vault here… ${o}/${t.total}`:"Bringing your Vault here…","Stop"),Wo(t.total?{done:o,total:t.total}:null),await dr(`firstsync-restore:${Math.floor(t.restored/100)}`)}else if(eo==="upload"){const e=await chrome.runtime.sendMessage({type:"VAULT_UPLOAD_PROGRESS"}).catch(()=>null),t=e?.ok?e.progress:null;if(!t)return;he("running",t.total?`Sending your conversations… ${t.queued}/${t.total}`:"Sending your conversations…","Stop"),Wo(t.total?{done:t.queued,total:t.total}:null)}}}async function rm(){for(;;){const e=await chrome.runtime.sendMessage({type:"VAULT_RUN_RESTORE"});if(!e.ok||e.result.complete||e.result.cancelled)return e}}async function am(){for(;;){const e=await chrome.runtime.sendMessage({type:"VAULT_RUN_INITIAL_UPLOAD"});if(!e.ok||e.result.complete||e.result.cancelled)return e}}async function sm(e){const[t,o]=await Promise.all([chrome.runtime.sendMessage({type:"VAULT_RESTORE_PROGRESS"}),e?chrome.runtime.sendMessage({type:"VAULT_UPLOAD_PROGRESS"}):Promise.resolve({ok:!0,progress:null})]),n=t.ok?t.progress?.restored??0:0,a=t.ok?t.progress?.failed??0:0,r=(t.ok?t.progress?.failures:void 0)??{},s=o.ok?o.progress?.queued??0:0;let i;return n>0&&s>0?i=`Brought ${n} down, sent ${s} up.`:n>0?i=`Brought ${n} ${n===1?"conversation":"conversations"} down.`:s>0?i=`Sent ${s} ${s===1?"conversation":"conversations"} up.`:i="Already up to date.",a===0?i:`${i} ${_c(a,r)}`}async function im(){if((Xt?.textContent??"")==="Stop"){Vn=!0,he("running","Stopping after this batch…",null);const t=eo==="upload"?"VAULT_CANCEL_INITIAL_UPLOAD":"VAULT_CANCEL_RESTORE";await chrome.runtime.sendMessage({type:t}).catch(()=>{});return}if(!io){io=!0,Vn=!1;try{eo="restore",he("running","Bringing your Vault here…","Stop"),om();const t=await rm();if(!t.ok){d(t.error);return}if(t.result.cancelled)return;const o=at!==0;if(o){eo="upload",he("running","Sending your conversations…","Stop");const n=await am();if(!n.ok){d(n.error);return}if(n.result.cancelled)return}he("idle",await sm(o),null)}catch(t){d(V(t))}finally{io=!1,Vn=!1,eo=null,Nc(),await te(),await ve()}}}function gs(){if(!On)return;const e=On.style.display!=="none";On.style.display=e?"none":"",e&&(zo&&(zo.value=""),Fo&&(Fo.value=""),Do&&(Do.value=""),Sr(zo,Fo,Do))}async function lm(){const e=M,t=G;if(!e){d(K("R06"));return}const o=zo?.value??"",n=Fo?.value??"",a=Do?.value??"";if(!o){d("Enter your current passphrase.");return}if(n.length<8){d("New passphrase must be at least 8 characters.");return}if(n!==a){d("New passphrases don't match.");return}d("Changing passphrase…",!0),$a?.setAttribute("disabled","true");let r="C01";try{const s=await chrome.runtime.sendMessage({type:"VAULT_GET_WRAPPED_KEY"});if(!s.ok){d(po(s.error,"C01"));return}if(!s.wrappedVaultKey){d(K("U08"));return}r="U06";const i=await un(()=>import("./index.js"),__vite__mapDeps([0,1,2,3]));let l;try{l=await i.changePassphrase(s.wrappedVaultKey,o,n)}catch(p){d(vl(p));return}if(t!==G||e!==M){d(K("R06"));return}r="C02";const f=await chrome.runtime.sendMessage({type:"VAULT_UPDATE_WRAPPED_KEY",wrappedVaultKey:l,expectedUserId:e,expectedWrappedKeyId:JSON.stringify(s.wrappedVaultKey)});if(!f.ok){d(po(f.error,"C02"));return}if(t!==G||e!==M){d(K("R13"));return}r="C03",gs(),d("Passphrase changed.")}catch{d(K(r))}finally{$a?.removeAttribute("disabled")}}Nn?.addEventListener("click",()=>{Cc()});Mo?.addEventListener("keydown",e=>{e.key==="Enter"&&Cc()});gn?.addEventListener("click",()=>{Ec()});Ke?.addEventListener("keydown",e=>{e.key==="Enter"&&Ec()});mn?.addEventListener("click",()=>{Ng()});vc?.addEventListener("click",Mg);Ge?.addEventListener("input",()=>{or&&(or.textContent=Eg(Ge?.value??""))});$t?.addEventListener("click",()=>{Og()});Oo?.addEventListener("change",()=>{!we||!Oo||(Oo.checked?(we.removeAttribute("disabled"),we.style.opacity="1"):(we.setAttribute("disabled","true"),we.style.opacity="0.5"))});Ft?.addEventListener("click",()=>{const e=wa?.textContent??"";navigator.clipboard.writeText(e).then(()=>{Ft&&(Ft.textContent="Copied ✓",setTimeout(()=>{Ft.textContent="Copy"},1500))}).catch(()=>{Ft&&(Ft.textContent="Press ⌘C to copy")})});we?.addEventListener("click",()=>{Bg()});Sa?.addEventListener("click",()=>{$c()});dg?.addEventListener("click",()=>{Bo&&(Bo.style.display==="none"?Bo.style.display="":sr())});qo?.addEventListener("click",()=>{if(!Tt||!qo)return;const e=Tt.type==="text";Tt.type=e?"password":"text",qo.textContent=e?"Show recovery key":"Hide recovery key"});Ca?.addEventListener("click",()=>{qg()});Mn?.addEventListener("click",()=>{Ug()});st?.addEventListener("keydown",e=>{e.key==="Enter"&&$c()});ft(Ge,ig,"passphrase");ft(Et,lg,"confirm passphrase");ft(st,cg,"passphrase");ft(Uo,pg,"new passphrase");ft(Vo,ug,"confirm new passphrase");ft(zo,yg,"current passphrase");ft(Fo,hg,"new passphrase");ft(Do,bg,"confirm new passphrase");Xt?.addEventListener("click",()=>{im()});D?.addEventListener("click",()=>{Kg()});ot?.addEventListener("click",()=>{em()});fg?.addEventListener("click",()=>{zg()});cn?.addEventListener("click",()=>{Vg()});gg?.addEventListener("click",gs);$a?.addEventListener("click",()=>{lm()});mg?.addEventListener("click",()=>{Ac()});{vg?.addEventListener("click",()=>{Ac()}),To?.addEventListener("click",()=>{_g()}),Te?.addEventListener("click",()=>{Tg()}),Aa?.addEventListener("click",()=>Zi("annual")),Ia?.addEventListener("click",()=>Zi("monthly")),Bn?.addEventListener("click",()=>{Ji()});const e=()=>{!At||At.style.display==="none"||Ji()};window.addEventListener("focus",e),document.addEventListener("visibilitychange",()=>{document.visibilityState==="visible"&&e()})}te({forceEntitlement:!0});async function Mc(){const e=Ha(Qa());if(!window.confirm(e.confirm)){Ct(Ka);return}Ct(Su),Ue&&(Ue.disabled=!0);try{let o;try{o=await chrome.runtime.sendMessage({type:"DELETE_ALL_DATA"})}catch(n){Ct(`Delete failed: ${V(n)}`);return}if(!o.ok){Ct(`Delete failed: ${o.error}`);return}Ct(e.done),await ve(),await Er()}finally{Ue&&(Ue.disabled=!1)}}async function cm(e){const t=await chrome.runtime.sendMessage({type:"OPEN_FOUNDING_FORM",markCompleted:e});if(!t.ok)throw new Error(t.error)}async function dm(){const e=await chrome.runtime.sendMessage({type:"DISMISS_FOUNDING_PROMPT"});if(!e.ok)throw new Error(e.error)}async function pm(){if(ao)try{const e=await chrome.storage.local.get(da),t=Ql(e[da]);ao.value=String(t),Qn("Applies to both empty and typed searches. Lower limits usually feel faster because fewer results are rendered.")}catch(e){const t=e instanceof Error?e.message:"Unknown storage error";ao.value=String(Vl),Qn(`Failed to load setting: ${t}`)}}async function um(e){try{await chrome.storage.local.set({[da]:e}),Qn(`Saved: showing up to ${e} results per search.`)}catch(t){const o=t instanceof Error?t.message:"Unknown storage error";Qn(`Failed to save setting: ${o}`)}}let Q=[];const Jo=new Set,Zo=new Set;function Oc(){Q.sort((e,t)=>e.pinned!==t.pinned?e.pinned?-1:1:t.updatedAt-e.updatedAt)}function Bc(e){const t=Q.find(n=>n.docId===e),o=t?.localTitle?.trim()||t?.title?.trim();return o?`"${o}"`:"conversation"}async function fm(e,t,o){if(e.length===0)return;let n=0;const a=Math.max(1,Math.min(e.length,t));await Promise.all(Array.from({length:a},async()=>{for(;;){const r=n;if(n+=1,r>=e.length)return;await o(e[r])}}))}async function gm(e){const t=e.filter(o=>o.platform==="anthropic_console"&&(zd(o.title)||As(o.title)||As(o.preview))||o.platform==="ai_studio"&&(Qd(o.title)||Is(o.title)||Is(o.preview)));await fm(t,6,async o=>{try{const n=await jd(o.docId);o.platform==="anthropic_console"?(o.title=Hd(n,o.title),o.preview=Kd(n,o.preview)):o.platform==="ai_studio"&&(o.title=ep(n,o.title),o.preview=tp(n,o.preview))}catch{}})}function mm(e){const t=new Date(e.updatedAt).toLocaleString(),o=Jo.has(e.docId),n=Zo.has(e.docId),a=o||n,r=o?"Saving...":e.pinned?"Unstar":"Star",s=e.pinned?"#fff1d6":"#eaf3de",i=e.pinned?"#d9bb79":"#c2d0ad",l=k(e.localTitle||e.title||"Untitled"),f=k(Sl(e.preview||"")),p=k(e.platform),c=k(e.docId);return`
    <div class="options-result-card">
      <div style="display: grid; grid-template-columns: minmax(0, 1fr) auto; align-items: flex-start; gap: 8px;">
        <div style="min-width: 0; overflow: hidden;">
          <div style="font-weight: 600; color: #153147; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">${l}</div>
          <div class="options-card-meta" style="margin-top: 2px; overflow-wrap: anywhere;">${p} &bull; ${e.indexLevel} &bull; ${e.messageCount} msgs &bull; ${t}</div>
          <div style="margin-top: 4px; color: #516776; font-size: 12px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">${f}</div>
        </div>
        <div style="display: grid; gap: 6px;">
          <button data-action="pin" data-doc-id="${c}" data-next-pin="${e.pinned?"false":"true"}" type="button" ${a?"disabled":""} style="padding: 6px 10px; border-radius: 8px; border: 1px solid ${i}; background: ${s}; cursor: ${a?"wait":"pointer"}; white-space: nowrap; opacity: ${a?"0.72":"1"};">${r}</button>
          <button data-action="remove" data-doc-id="${c}" type="button" ${a?"disabled":""} style="padding: 6px 10px; border-radius: 8px; border: 1px solid #d7b1b1; background: #fff4f4; color: #7a2626; cursor: ${a?"wait":"pointer"}; white-space: nowrap; opacity: ${a?"0.72":"1"};">${n?"Removing...":"Remove"}</button>
        </div>
      </div>
    </div>
  `}function ym(){const e=yr?.checked??!0,t=ro?.value?.trim().toLowerCase()??"";return!t&&!e?Q:Q.filter(o=>{if(e&&!o.pinned)return!1;if(!t)return!0;const n=`${o.localTitle??""}
${o.title||""}`.toLowerCase(),a=Sl(o.preview||"").toLowerCase(),r=o.platform.toLowerCase();return n.includes(t)||a.includes(t)||r.includes(t)})}function hm(){if(!rt)return;const e=Array.from(rt.querySelectorAll("button[data-action][data-doc-id]"));for(const t of e)t.addEventListener("click",()=>{const o=t.dataset.action,n=t.dataset.docId??"";if(n){if(o==="pin"){const a=t.dataset.nextPin==="true";bm(n,a);return}o==="remove"&&vm(n)}})}function He(){if(!rt)return;const e=ym();if(e.length===0){const t=yr?.checked??!0,n=!!ro?.value?.trim()?"No conversations match this filter.":t?"No starred conversations yet.":"No conversations found.";rt.innerHTML=`<div style='color:#4f6576;'>${n}</div>`;return}rt.innerHTML=e.map(mm).join(""),hm()}async function Er(){if(rt){rt.textContent="Loading conversations...";try{const e=yr?.checked??!0;Q=(await Vd(250,{pinnedOnly:e})).filter(o=>!ca.has(o.platform)),await gm(Q),Oc(),He();const t=Q.filter(o=>o.pinned).length;ze(`Showing ${Q.length} recent docs. Starred: ${t}.`)}catch(e){const t=e instanceof Error?e.message:"Unknown error";rt.textContent=`Failed to load conversations: ${t}`}}}async function bm(e,t){if(Jo.has(e)||Zo.has(e))return;const o=Bc(e);Jo.add(e),He(),ze(`${t?"Starring":"Unstarring"} ${o}...`);try{if(!await Dd(e,t)){ze(`Failed to ${t?"star":"unstar"} ${o}: conversation not found.`);return}const a=Q.findIndex(s=>s.docId===e);a>=0&&(Q[a]={...Q[a],pinned:t}),Oc(),He();const r=Q.filter(s=>s.pinned).length;ze(`${t?"Starred":"Unstarred"} ${o}. Starred: ${r}.`)}catch(n){const a=n instanceof Error?n.message:"Unknown error";ze(`Failed to update star for ${o}: ${a}`)}finally{Jo.delete(e),He()}}async function vm(e){if(Jo.has(e)||Zo.has(e))return;const t=Bc(e);if(window.confirm(`Remove ${t} from local index?`)){Zo.add(e),He(),ze(`Removing ${t}...`);try{if(!await Gd(e)){ze(`${t} was already removed.`);return}Q=Q.filter(r=>r.docId!==e),He();const a=Q.filter(r=>r.pinned).length;ze(`Removed ${t}. Starred: ${a}.`),await ve()}catch(n){const a=n instanceof Error?n.message:"Unknown error";ze(`Failed to remove ${t}: ${a}`)}finally{Zo.delete(e),He()}}}let P=[];const zn=new Set;let lo=null;const Fn=new Set;let Pe=!1;function H(e){bi&&(bi.textContent=e)}function xm(e){const t=k(e.memoryId),o="font-size: 11px; font-weight: 600; color: #5b6b54; text-transform: uppercase; letter-spacing: 0.03em;",n="width: 100%; box-sizing: border-box; padding: 8px 10px; border-radius: 8px; border: 1px solid #c6d0b0; background: #fff; font-family: inherit; font-size: 13px;";return`
    <div class="options-result-card" style="border-left-color: #9fb37e; background: #fcfdf7;">
      <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 10px;">
        <span style="font-size: 13px;">✎</span>
        <span style="font-weight: 600; color: #2f4419; font-size: 13px;">Editing memory</span>
      </div>
      <div style="display: grid; gap: 12px;">
        <label style="display: grid; gap: 4px;">
          <span style="${o}">Label</span>
          <input data-edit-field="label" data-memory-id="${t}" type="text" value="${k(e.label)}" placeholder="Short label (e.g. Code style)" style="${n}" />
        </label>
        <label style="display: grid; gap: 4px;">
          <span style="${o}">Memory</span>
          <textarea data-edit-field="text" data-memory-id="${t}" rows="5" placeholder="The memory itself, in your own words." style="${n} resize: vertical; line-height: 1.5;">${k(e.text)}</textarea>
        </label>
        <div style="display: flex; gap: 8px; align-items: center; justify-content: flex-end; border-top: 1px solid #e8eed9; padding-top: 10px;">
          <button data-action="cancel-edit-memory" data-memory-id="${t}" type="button" style="padding: 7px 14px; border-radius: 8px; border: 1px solid #c6d0b0; background: #fff; color: #4f6576; cursor: pointer; font-size: 13px;">Cancel</button>
          <button data-action="save-edit-memory" data-memory-id="${t}" type="button" style="padding: 7px 16px; border-radius: 8px; border: 1px solid #9fb37e; background: #eef4dd; color: #2f4419; cursor: pointer; font-weight: 600; font-size: 13px;">Save changes</button>
        </div>
      </div>
    </div>
  `}function qc(){return'<span class="agent-memory-badge" style="display: inline-flex; align-items: center; flex: 0 0 auto; padding: 2px 6px; border: 1px solid #b8c99a; border-radius: 999px; background: #f1f6e7; color: #486027; font-size: 10px; font-weight: 600; letter-spacing: 0.01em;">Assistant suggestion</span>'}function wm(e){if(e.memoryId===lo)return xm(e);const t=Fn.has(e.memoryId),o=e.text.length>240,n=t||!o?k(e.text):k(e.text.slice(0,240))+"…",a=zn.has(e.memoryId),r=a?"Removing...":"Delete",s=a?"disabled":"",i=k(e.memoryId),l=[];e.sourcePlatform&&an[e.sourcePlatform]&&l.push(an[e.sourcePlatform]),l.push(Sp(e.text.length));const f=l.map(oe=>k(oe)).join(" &bull; "),p=e.enabled?e.pinned?"auto":"on":"off",c={off:"background: #e4e7e0 !important; color: #5a6b58 !important; font-weight: 600;",on:"background: #cfe6a3 !important; color: #33500f !important; font-weight: 600;",auto:"background: #bfe0ef !important; color: #12455f !important; font-weight: 600;"},v="border: 0 !important; padding: 4px 9px; font-size: 11px; line-height: 1.3; cursor: pointer; background: transparent !important; color: #93a07e !important;",y=(oe,gt,z)=>{const bo=p===oe,qt=oe==="off"?"":"border-left: 1px solid #dbe2cf;";return`<button type="button" data-action="mem-state" data-memory-id="${i}" data-state="${oe}" title="${k(z)}" aria-pressed="${bo}" style="${v}${qt}${bo?c[oe]:""}">${gt}</button>`},b='<div role="group" aria-label="Memory usage" style="display: inline-flex; border: 1px solid #c6d0b0; border-radius: 8px; overflow: hidden; background: #fff; flex: 0 0 auto;">'+y("off","Off","Off — never added to chats")+y("on","On","On — available to pick in the memory pill")+y("auto","Auto","Auto — added to every new chat automatically")+"</div>",w="width: 28px; height: 28px; display: inline-flex; align-items: center; justify-content: center; padding: 0; border-radius: 7px; border: 1px solid; cursor: pointer; font-size: 13px; line-height: 1;",A=!!e.sourceUrl&&(e.sourcePlatform?mp(e.sourcePlatform,e.sourceUrl):yp(e.sourceUrl))?`<button data-action="open-memory-source" data-memory-id="${i}" title="Open the conversation this came from" aria-label="Open source conversation" style="${w} border-color: #c6d0b0; background: #fff; color: #2f4654;">↗</button>`:"",L=t?"margin-top: 4px; color: #516776; font-size: 12px; line-height: 1.45; white-space: pre-wrap; overflow-wrap: anywhere;":"margin-top: 4px; color: #516776; font-size: 12px; overflow: hidden; text-overflow: ellipsis; max-height: 3.6em; line-height: 1.4;",S=o?`<span class="memory-view-hint" style="color: #93a07e; font-size: 11px;">${t?"Show less":"Show more"}</span>`:"",W=o?`Click to ${t?"collapse":"view"} · double-click to edit`:"Double-click to edit",Ce=o?`class="memory-card-body" data-action="view-memory" data-memory-id="${i}" title="${W}" style="min-width: 0; overflow: hidden; cursor: pointer;"`:`class="memory-card-body" data-memory-id="${i}" title="${W}" style="min-width: 0; overflow: hidden;"`;return`
    <div class="${o?"options-memory-card options-result-card":"options-result-card"}" style="opacity: ${e.enabled?"1":"0.55"};">
      <div style="display: grid; grid-template-columns: minmax(0, 1fr) auto; align-items: center; gap: 10px;">
        <div ${Ce}>
          <div style="display: flex; align-items: center; gap: 6px; min-width: 0;">
            <span style="font-weight: 600; color: #153147; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">${k(e.label)}</span>
            ${e.source==="agent"?qc():""}
          </div>
          <div class="options-card-meta" style="margin-top: 2px;">${f}${S?" &bull; "+S:""}</div>
          <div style="${L}">${n}</div>
        </div>
        <div style="display: flex; align-items: center; gap: 6px; flex: 0 0 auto;">
          ${b}
          ${A}
          <button data-action="edit-memory" data-memory-id="${i}" title="Edit memory" aria-label="Edit memory" style="${w} border-color: #c6d0b0; background: #fff; color: #2f4654;">✎</button>
          <button data-action="delete-memory" data-memory-id="${i}" title="${r} memory" aria-label="${r} memory" style="${w} border-color: #d7b1b1; background: #fff4f4; color: #7a2626;" ${s}>${a?"…":"🗑"}</button>
        </div>
      </div>
    </div>
  `}function km(e){const t=k(e.memoryId),o=e.text.length>240?`${k(e.text.slice(0,240))}…`:k(e.text);return`
    <div class="pending-memory-card options-result-card" style="border-left-color: #9fb37e; background: #fff;">
      <div style="display: grid; grid-template-columns: minmax(0, 1fr) auto; align-items: center; gap: 10px;">
        <div style="min-width: 0; overflow: hidden;">
          <div style="display: flex; align-items: center; gap: 6px; min-width: 0;">
            <span style="font-weight: 600; color: #153147; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">${k(e.label)}</span>
            ${qc()}
          </div>
          <div style="margin-top: 4px; color: #516776; font-size: 12px; line-height: 1.45; overflow-wrap: anywhere;">${o}</div>
        </div>
        <div style="display: flex; align-items: center; gap: 6px; flex-wrap: wrap; justify-content: flex-end;">
          <button data-action="reject-pending-memory" data-memory-id="${t}" type="button" ${Pe?"disabled":""} style="padding: 7px 12px; border-radius: 8px; border: 1px solid #d7b1b1; background: #fff4f4; color: #7a2626; cursor: pointer; font-weight: 600; font-size: 12px;">Reject</button>
          <button data-action="enable-pending-memory" data-memory-id="${t}" type="button" ${Pe?"disabled":""} style="padding: 7px 12px; border-radius: 8px; border: 1px solid #9fb37e; background: #eef4dd; color: #2f4419; cursor: pointer; font-weight: 600; font-size: 12px;">Enable</button>
        </div>
      </div>
    </div>
  `}function Sm(){const e=Pl(P),t=sc?.value?.trim().toLowerCase()??"";return t?e.filter(o=>o.label.toLowerCase().includes(t)||o.text.toLowerCase().includes(t)||o.kind.toLowerCase().includes(t)||(o.tags??[]).some(n=>n.toLowerCase().includes(t))):e}function ms(){if(!kn||!Io)return;const e=Wa(P);if(Io.hidden=e.length===0,Io.disabled=Pe,Io.textContent=Pe?"Enabling...":"Enable all",e.length===0){kn.innerHTML='<div style="color: #5f7066; padding: 2px 0; font-size: 12px;">No pending suggestions</div>';return}kn.innerHTML=e.map(km).join("");for(const t of Array.from(kn.querySelectorAll("button[data-action]")))t.addEventListener("click",()=>{const o=t.dataset.memoryId;o&&(t.dataset.action==="enable-pending-memory"?ol(o,"accept"):t.dataset.action==="reject-pending-memory"&&ol(o,"reject"))})}function Cm(){const e=P.length===0;vi&&(vi.hidden=!e),Jt&&(Jt.hidden=e),xi&&(xi.hidden=e),No&&(No.style.display=e?"grid":"none"),Jt&&(Jt.textContent="+ Add memory")}function be(){if(Cm(),ms(),!re)return;const e=Sm();if(e.length===0){if(Pl(P).length>0){re.innerHTML='<div style="color: #4f6576; padding: 4px 2px;">No memories match your filter.</div>';return}if(P.length>0){re.innerHTML='<div style="color: #4f6576; padding: 4px 2px;">No other memories yet.</div>';return}re.innerHTML="";return}re.innerHTML=e.map(wm).join(""),$m()}async function Em(e){const t=P.find(o=>o.memoryId===e);if(t?.sourceUrl)try{await chrome.runtime.sendMessage({type:"OPEN_MEMORY_SOURCE",url:t.sourceUrl,selectedText:t.text,label:t.label,msgStartIndex:typeof t.sourceMsgStart=="number"?t.sourceMsgStart:-1})}catch(o){const n=o instanceof Error?o.message:"Unknown error";H(`Could not open the source conversation: ${n}`)}}function $m(){if(!re)return;const e=Array.from(re.querySelectorAll("button[data-action]"));for(const o of e)o.addEventListener("click",()=>{const n=o.dataset.memoryId;if(n)if(o.dataset.action==="delete-memory")Rm(n);else if(o.dataset.action==="mem-state"){const a=o.dataset.state;a==="off"?ta(n,{enabled:!1}):a==="on"?ta(n,{enabled:!0,pinned:!1}):a==="auto"&&ta(n,{enabled:!0,pinned:!0})}else o.dataset.action==="edit-memory"?(lo=n,be()):o.dataset.action==="cancel-edit-memory"?(lo=null,be()):o.dataset.action==="save-edit-memory"?Tm(n):o.dataset.action==="open-memory-source"&&Em(n)});const t=Array.from(re.querySelectorAll(".memory-card-body"));for(const o of t){let n=null;o.addEventListener("click",()=>{const a=o.dataset.memoryId;if(a){if(n!==null){window.clearTimeout(n),n=null,lo=a,be();return}n=window.setTimeout(()=>{n=null,o.dataset.action==="view-memory"&&(Fn.has(a)?Fn.delete(a):Fn.add(a),be())},220)}})}}async function ho(){if(re){re.textContent="Loading memories...";try{P=await fl(),be();const e=P.filter(t=>t.pinned).length;H(`${P.length} memor${P.length===1?"y":"ies"}, ${e} on auto.`)}catch(e){const t=e instanceof Error?e.message:"Unknown error";re.textContent=`Failed to load memories: ${t}`}}}function Pt(e,t){chrome.runtime.sendMessage({type:e,memoryId:t}).catch(()=>{})}async function Am(){const e=Ve?.value?.trim()??"";if(!e){H("Enter the memory text before adding."),Ve?.focus();return}const t=Date.now(),o=qr?.value?.trim()??"",n={memoryId:crypto.randomUUID(),kind:"preference",label:(o||e).slice(0,48),text:e,source:"manual",pinned:Ur?.checked??!1,enabled:!0,createdAt:t,updatedAt:t};try{await ul(n),Pt("QUEUE_MEMORY_PUT",n.memoryId),Ve&&(Ve.value=""),qr&&(qr.value=""),Ur&&(Ur.checked=!1),await ho(),Ot(),chrome.runtime.sendMessage({type:"TRACK_ACTIVATION_EVENT",event:"memory_created",source:"manual"}).catch(()=>{}),H("Memory added.")}catch(a){const r=a instanceof Error?a.message:"Unknown error";H(`Failed to add memory: ${r}`)}}function Xo(e){wi&&(wi.textContent=e)}async function Im(){const e=Sn?.value?.trim()??"";if(!e){Xo("Paste the memory above first."),Sn?.focus();return}const t=hr?.value||"generic",o=an[t??"generic"]??"Other AI",n=Date.now();try{const a=(await fl()).filter(s=>s.source==="imported");for(const s of a)s.sourcePlatform!==t&&s.pinned&&(await Dn(s.memoryId,{pinned:!1},s.updatedAt),Pt("QUEUE_MEMORY_PUT",s.memoryId));const r=a.find(s=>s.sourcePlatform===t);if(r)await Dn(r.memoryId,{text:e,label:`${o} memory`,pinned:!0,enabled:!0}),Pt("QUEUE_MEMORY_PUT",r.memoryId);else{const s={memoryId:crypto.randomUUID(),kind:"profile",label:`${o} memory`,text:e,source:"imported",sourcePlatform:t,pinned:!0,enabled:!0,createdAt:n,updatedAt:n};await ul(s),Pt("QUEUE_MEMORY_PUT",s.memoryId)}Sn&&(Sn.value=""),await ho(),Ot(),chrome.runtime.sendMessage({type:"TRACK_ACTIVATION_EVENT",event:"memory_created",platformSource:t,source:"import"}).catch(()=>{}),Xo(`Saved your ${o} memory. It's pre-selected on new chats — switch in the picker anytime.`)}catch(a){const r=a instanceof Error?a.message:"Unknown error";Xo(`Failed to save: ${r}`)}}function Uc(){const e=hr?.value||"generic",t=an[e]??"the other AI";e==="claude"?(Cn&&(Cn.textContent="In Claude: Settings → Capabilities → Memory. Copy what it shows and paste it below — no prompt needed."),Lo&&(Lo.style.display="none")):(Cn&&(Cn.textContent=`Copy the export prompt, paste it into ${t}, then paste its full reply into the box below.`),Lo&&(Lo.style.display=""))}async function Lm(){const e=hr?.value||"generic",t=an[e]??"the other AI";try{await navigator.clipboard.writeText(ki),Xo(`Prompt copied. Paste it into ${t}, then paste its reply into the box above.`)}catch{Xo(`Couldn't copy automatically — here's the prompt:
`+ki)}}async function Tm(e){if(!re)return;const t=re.querySelector(`input[data-edit-field="label"][data-memory-id="${CSS.escape(e)}"]`),o=re.querySelector(`textarea[data-edit-field="text"][data-memory-id="${CSS.escape(e)}"]`),n=o?.value?.trim()??"";if(!n){H("Memory text can't be empty."),o?.focus();return}const a=t?.value?.trim()||n.slice(0,48);try{const r=await Dn(e,{label:a,text:n});r&&(Pt("QUEUE_MEMORY_PUT",e),P=P.map(s=>s.memoryId===e?r:s)),lo=null,be(),Ot(),H("Memory updated.")}catch(r){const s=r instanceof Error?r.message:"Unknown error";H(`Failed to update memory: ${s}`)}}async function Vc(e,t){const o=await chrome.runtime.sendMessage({type:"TOGGLE_MEMORY",memoryId:e,enabled:t});if(!o?.ok||!o.memory)throw new Error(o?.error||"The memory could not be updated.");return o.memory}async function ol(e,t){if(!Pe){Pe=!0,ms();try{const o=await chrome.runtime.sendMessage({type:"REVIEW_AGENT_MEMORY",memoryId:e,decision:t});if(!o?.ok||!o.memory)throw new Error(o?.error||"The suggestion could not be reviewed.");const n=o.memory;P=P.map(a=>a.memoryId===e?n:a),Ot(),H(t==="accept"?"Suggestion enabled.":"Suggestion rejected and removed.")}catch(o){const n=o instanceof Error?o.message:"Unknown error";H(`Could not ${t==="accept"?"enable":"reject"} the suggestion: ${n}`)}finally{Pe=!1,be()}}}async function _m(){if(Pe)return;const e=Wa(P).length;if(e!==0){Pe=!0,ms(),H(`Enabling ${e} suggestion${e===1?"":"s"}...`);try{await Au(P,async(t,o)=>{await Vc(t,o)}),Ot(),H(`${e} suggestion${e===1?"":"s"} enabled.`)}catch(t){const o=t instanceof Error?t.message:"Unknown error";H(`Some suggestions could not be enabled: ${o}`)}finally{Pe=!1,await ho()}}}async function ta(e,t){try{const o=Object.keys(t),n=o.length===1&&typeof t.enabled=="boolean"?await Vc(e,t.enabled):await Dn(e,t);if(n){o.length===1&&typeof t.enabled=="boolean"||Pt("QUEUE_MEMORY_PUT",e),P=P.map(r=>r.memoryId===e?n:r),be(),Ot();const a=P.filter(r=>r.pinned).length;H(`${P.length} memor${P.length===1?"y":"ies"}, ${a} on auto.`)}}catch(o){const n=o instanceof Error?o.message:"Unknown error";H(`Failed to update memory: ${n}`)}}async function Rm(e){if(!zn.has(e)){zn.add(e),be(),H("Removing memory...");try{await Fd(e),Pt("QUEUE_MEMORY_TOMBSTONE",e),P=P.filter(t=>t.memoryId!==e),be(),Ot(),H(`Memory removed. ${P.length} remaining.`)}catch(t){const o=t instanceof Error?t.message:"Unknown error";H(`Failed to remove memory: ${o}`)}finally{zn.delete(e),be()}}}vf?.addEventListener("click",()=>{Am()});for(const e of Array.from(document.querySelectorAll(".memory-example-chip")))e.addEventListener("click",()=>{Ve&&(Ve.value=e.dataset.example??"",Ve.focus(),Ve.select())});Jt?.addEventListener("click",()=>{if(!No)return;const e=No.style.display!=="none";No.style.display=e?"none":"grid",Jt.textContent=e?"+ Add memory":"Cancel",e||Ve?.focus()});xf?.addEventListener("click",()=>{Im()});Lo?.addEventListener("click",()=>{Lm()});hr?.addEventListener("change",()=>{Uc()});Uc();bf?.addEventListener("click",()=>{ho()});Io?.addEventListener("click",()=>{_m()});try{chrome.storage.onChanged.addListener((e,t)=>{t!=="local"||!e[fp]||lo===null&&ho()})}catch{}sc?.addEventListener("input",()=>{be()});window.location.hash==="#memory-section"&&requestAnimationFrame(()=>{document.getElementById("memory-section")?.scrollIntoView({behavior:"smooth",block:"start"})});window.location.hash==="#import-chatgpt-export-section"&&requestAnimationFrame(()=>{const e=document.getElementById("import-chatgpt-export-section");if(e?.scrollIntoView({behavior:"smooth",block:"start"}),e){const t=e.style.boxShadow;e.style.transition="box-shadow 0.4s ease",e.style.boxShadow="0 0 0 3px #3d6fa8",window.setTimeout(()=>{e.style.boxShadow=t},1600)}});window.location.hash==="#corpus-native-card"&&requestAnimationFrame(()=>{const e=document.getElementById("corpus-native-card");if(e?.scrollIntoView({behavior:"smooth",block:"start"}),e){const t=e.style.boxShadow;e.style.transition="box-shadow 0.4s ease",e.style.boxShadow="0 0 0 3px #4f8a5b",window.setTimeout(()=>{e.style.boxShadow=t},1600)}});window.location.hash==="#local-sessions-card"&&requestAnimationFrame(()=>{const e=document.getElementById("local-sessions-card");if(e?.scrollIntoView({behavior:"smooth",block:"start"}),e){const t=e.style.boxShadow;e.style.transition="box-shadow 0.4s ease",e.style.boxShadow="0 0 0 3px #d97757",window.setTimeout(()=>{e.style.boxShadow=t},1600)}});let oa=!1;So?.addEventListener("click",()=>{oa||!So||(oa=!0,So.textContent="Refreshing…",ve().finally(()=>{oa=!1,So&&(So.textContent="Refresh")}))});$o?.addEventListener("click",()=>{Hf()});ke?.addEventListener("click",()=>{Of()});chrome.permissions.onAdded.addListener(e=>{xl(e.origins)&&sn()});chrome.permissions.onRemoved.addListener(e=>{xl(e.origins)&&sn()});ht?.addEventListener("click",()=>{Ff()});bt?.addEventListener("click",()=>{uc()});fa?.addEventListener("keydown",e=>{e.key==="Enter"&&(e.preventDefault(),uc())});vt?.addEventListener("click",()=>{Df()});xt?.addEventListener("click",()=>{Gf()});tn?.addEventListener("click",()=>{Kf()});on?.addEventListener("click",()=>{Rn?.click()});Rn?.addEventListener("change",()=>{const e=Rn.files?.[0];e&&(Yf(e),Rn.value="")});nn?.addEventListener("click",()=>{ma=!0,nn.setAttribute("disabled","true"),ye("Stopping after the current conversation…")});ya?.addEventListener("click",()=>{Pn?.click()});Pn?.addEventListener("change",()=>{const e=Pn.files?.[0];e&&(Jf(e),Pn.value="")});rn?.addEventListener("click",()=>{Ao=!0,rn.setAttribute("disabled","true"),ge("Stopping after the current chat…")});function $r(e,t,o,n){e?.addEventListener("click",()=>{navigator.clipboard.writeText(t()).then(()=>{e.textContent="Copied ✓",n?.(),setTimeout(()=>{e.textContent=o},1500)}).catch(()=>{e.textContent="Press ⌘C to copy"})})}for(const e of _e){const t=ee[e];t.chooseBtn?.addEventListener("click",()=>{tg(e)}),t.dirInput?.addEventListener("change",()=>{og(e)}),t.rescanBtn?.addEventListener("click",()=>{ng(e)}),t.forgetBtn?.addEventListener("click",()=>{rg(e)}),$r(t.copyPathBtn,()=>ls(e),"Copy path")}et?.addEventListener("click",()=>{ag()});$r(ff,()=>"brave://flags/#file-system-access-api","Copy address");$r(gf,()=>Zt,"Copy",()=>{ba=Date.now(),gc(!0)});sg();function Pm(){!Jn||!Ue||(Jn.style.display="block",Ue.style.display="none",nt&&(nt.value="",nt.focus()),ys(!1))}function ur(){!Jn||!Ue||(Jn.style.display="none",Ue.style.display="",nt&&(nt.value=""),ys(!1))}function ys(e){Zn&&(Zn.disabled=!e)}Ue?.addEventListener("click",Pm);nt?.addEventListener("input",()=>{ys($u(nt.value))});nt?.addEventListener("keydown",e=>{e.key==="Escape"?(ur(),Ct(Ka)):e.key==="Enter"&&!Zn?.disabled&&(ur(),Mc())});Zn?.addEventListener("click",()=>{ur(),Mc()});mf?.addEventListener("click",()=>{ur(),Ct(Ka)});yf?.addEventListener("click",()=>{Er()});ro?.addEventListener("input",()=>{He()});hf?.addEventListener("click",()=>{ro&&(ro.value="",ro.focus()),He()});yr?.addEventListener("change",()=>{Er()});ao?.addEventListener("change",()=>{const e=Ql(ao.value);ao.value=String(e),um(e)});wf?.addEventListener("click",()=>{ss()});kf?.addEventListener("click",()=>{Mf()});$r(Sf,()=>$p(ce),"Copy logs");Cf?.addEventListener("click",()=>{Nf()});Ef?.addEventListener("click",()=>{cm(!0).then(()=>dc(!1)).catch(e=>tt(`Failed to open Vault updates: ${V(e)}`))});$f?.addEventListener("click",()=>{dm().then(()=>dc(!1)).catch(e=>tt(`Failed to dismiss Vault updates: ${V(e)}`))});df();mo();Promise.all([Pf(),pm(),ss(),ve(),vr(),sn(),ho()]).then(()=>Er());{const e=document.querySelector("#organisation-section-body");if(e){const t=new URLSearchParams(window.location.search);vu(e,t.get("organise"),t.get("organiseScope"))}}const Nm=document.querySelector("#corpus-sync-card"),hs=document.querySelector("#corpus-connect"),bs=document.querySelector("#corpus-sync-now"),vs=document.querySelector("#corpus-full-sync"),xs=document.querySelector("#corpus-disconnect"),nl=document.querySelector("#corpus-sync-status");function de(e){nl&&(nl.textContent=e)}function zc(){hs?.style.setProperty("display","none"),bs?.style.setProperty("display","inline-block"),vs?.style.setProperty("display","inline-block"),xs?.style.setProperty("display","inline-block")}function Mm(e){return e.upToDate?"MCP corpus sync is already up to date — nothing new to send.":`${e.full?"Full MCP corpus sync":"MCP corpus synced"}: wrote ${e.conversationCount} conversation(s) in ${e.chunkCount} file(s) to the corpus inbox. The companion will pick them up.`}async function Fc(e,t){if(!await Fu(e,{prompt:!0})){de("Write permission denied — reconnect the folder.");return}de(t?"Re-syncing the whole MCP corpus…":"Syncing the MCP corpus…");try{const o=await Du(e,{full:t});de(Mm(o))}catch(o){de(`MCP corpus sync failed: ${o instanceof Error?o.message:String(o)}`)}}async function Om(){if(!Ol()){de("This browser doesn't support the folder picker needed for corpus sync.");return}de("Opening folder picker…");let e;try{e=await zu()}catch(t){t instanceof ql?de("No folder chosen."):de(`Couldn't open the folder picker: ${t instanceof Error?t.message:String(t)}`);return}zc(),await Fc(e,!0)}async function Dc(e){const t=await Bl();if(!t){de("No folder connected — connect one first.");return}await Fc(t,e)}async function Bm(){await Vu(),hs?.style.setProperty("display","inline-block"),bs?.style.setProperty("display","none"),vs?.style.setProperty("display","none"),xs?.style.setProperty("display","none"),de("Disconnected. The corpus files already written remain on disk; the companion keeps them.")}async function qm(){if(!Nm)return;if(!Ol()){de("This browser doesn't support the folder picker needed for corpus sync.");return}if(!await Bl()){de("Not connected.");return}zc(),de("Connected. Click Sync now to push new conversations to the companion.")}hs?.addEventListener("click",()=>{Om()});bs?.addEventListener("click",()=>{Dc(!1)});vs?.addEventListener("click",()=>{Dc(!0)});xs?.addEventListener("click",()=>{Bm()});qm();const Um=document.querySelector("#corpus-native-card"),Qo=document.querySelector("#corpus-native-enable"),Ln=document.querySelector("#corpus-native-manual"),Vm=document.querySelector("#corpus-native-sync-now"),zm=document.querySelector("#corpus-native-full-sync"),rl=document.querySelector("#corpus-native-status"),al=document.querySelector("#corpus-native-lastsync"),Fm=document.querySelector("#corpus-native-install"),Dm=document.querySelector("#corpus-native-install-steps"),sl=document.querySelector("#corpus-native-install-cmd"),en=document.querySelector("#corpus-native-copy-install"),Gm=document.querySelector("#corpus-native-permission-state"),Gc=document.querySelector("#corpus-native-connector-state"),il=document.querySelector("#corpus-native-install-copy-text"),jm=document.querySelector("#corpus-native-node-help"),Hm=document.querySelector("#corpus-native-finish"),Km=document.querySelector("#corpus-native-details"),na=document.querySelector("#corpus-native-location");function X(e){rl&&(rl.textContent=e)}function Ym(e){if(!e)return"No history has been added yet.";const t=mr(e.at);return e.ok?`Last updated ${t}.`:`Last update (${t}) didn’t finish: ${ja(e.error)}`}function Ma(e){al&&(al.textContent=Ym(e))}function Po(e,t=!1,o=!1){Fm?.style.setProperty("display","block"),Dm?.style.setProperty("display","block"),Qo?.style.setProperty("display",t?"none":"inline-block"),Gm?.style.setProperty("display",t?"inline":"none"),Gc?.style.setProperty("display",o?"inline":"none"),jm?.style.setProperty("display",o?"none":"block"),Hm?.style.setProperty("display",o?"flex":"none"),en&&(en.textContent=o?"Copy repair command":"Copy install command"),il&&(il.textContent=o?"The desktop connector is installed. Run the command again only if you need to repair it or connect another supported desktop AI app.":`Next: ${tc}`),t&&sl&&(sl.textContent=es)}function Tn(e){Km?.style.setProperty("display",e?"":"none"),na&&(na.style.display=e?"":"none",na.textContent=e?`Stored locally at ${e}`:"")}async function jc(){const e=await chrome.runtime.sendMessage({type:"GET_CORPUS_NATIVE_STATUS"});return e.ok?(rc=e.corpus.present,lc(),Ma(e.lastSync),e.hostSupported?e.corpus.present?(Ln?.style.setProperty("display","inline"),Po(!0,!0,!0),Tn(e.corpus.root??null),X("Ready. Your LLMnesia history stays up to date automatically."),e):e.permissionGranted?(X("The connector isn’t available yet. Run Step 1, then fully quit and reopen your browser."),Ln?.style.setProperty("display","none"),Tn(null),Po(!0,!0),e):(X("Setup isn’t finished. Install the connector, restart your browser, then enable automatic sync."),Ln?.style.setProperty("display","none"),Tn(null),Po(!0,!1),e):(X(e.permissionGranted?"The connector isn’t available yet. Run Step 1, then fully quit and reopen your browser.":"Setup isn’t finished. Install the connector, restart your browser, then enable automatic sync."),Ln?.style.setProperty("display","none"),Tn(null),Po(!0,e.permissionGranted,!1),e)):(X(`Couldn't check status: ${ja(e.error)}`),e)}const Wm=3e3;let co=null,Oa=!1;function ll(){co!==null&&(window.clearTimeout(co),co=null)}function Hc(){co!==null||Oa||(co=window.setTimeout(()=>{co=null,Jm()},Wm))}async function Jm(){const e=await jc();if(!e.ok||!e.permissionGranted){ll();return}if(!e.corpus.present){Hc();return}Oa=!0,ll();try{X("Desktop connector found. Adding your existing history…"),await Ar(!0)}finally{Oa=!1}}async function Zm(){X("Connecting this browser…"),Qo?.setAttribute("disabled","true");let e;try{e=await chrome.permissions.request({permissions:["nativeMessaging"]})}catch(t){X(`Permission request failed: ${t instanceof Error?t.message:String(t)}`),Qo?.removeAttribute("disabled");return}if(!e){X("Permission wasn’t granted. Allow it when you’re ready to connect this browser."),Qo?.removeAttribute("disabled");return}X("Finishing setup. Settings will reopen in a moment…");try{await chrome.storage.local.set({[gp]:Date.now()})}catch{}chrome.runtime.reload()}async function Ar(e){X(e?"Rebuilding your local history…":"Updating your local history…");const t=await chrome.runtime.sendMessage({type:"CORPUS_NATIVE_SYNC",full:e});if(!t.ok){const o=ja(t.error);X(`Couldn’t update your local history: ${o}`),Ma({at:Date.now(),ok:!1,error:o});return}X(t.report.upToDate?"Ready. Your local history is already up to date.":"Ready. Your local history is up to date."),Ma({at:Date.now(),ok:!0,report:t.report})}Qo?.addEventListener("click",()=>{Zm()});en?.addEventListener("click",()=>{navigator.clipboard.writeText(es).then(()=>{en.textContent="Copied",window.setTimeout(()=>{const e=Gc?.style.display==="inline";en.textContent=e?"Copy repair command":"Copy install command"},1800)},()=>{X("Couldn’t copy the command. Select the command shown above and copy it manually.")})});Vm?.addEventListener("click",()=>{Ar(!1)});zm?.addEventListener("click",()=>{Ar(!0)});async function Xm(){try{await chrome.permissions.contains({permissions:["nativeMessaging"]})&&Po(!0,!0,!1)}catch{}const e=await jc();if(!(!e.ok||!e.permissionGranted)){if(!e.corpus.present){Hc();return}(!e.lastSync||!e.lastSync.ok)&&(X("Desktop connector found. Adding your existing history…"),await Ar(!0))}}Um&&Xm();
//# sourceMappingURL=options.js.map
