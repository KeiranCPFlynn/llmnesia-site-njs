import"./modulepreload-polyfill.js";import{s as xe}from"./search_invite.js";import{T as Et,b5 as Be,V as ct,P as ze,bX as Ct,bY as Lt}from"./db.js";import{i as Tt,T as k}from"./theme.js";import{g as St}from"./platform_styles.js";import{c as Ve,l as $t,N as Mt}from"./capture_provenance.js";import{c as Nt,C as Rt,S as It}from"./vault_payoff_card.js";import{m as qe,o as je,u as _t}from"./conversation_counter.js";import{a as Pt}from"./public_storage_copy.js";import{m as At,a as Ot,V as Ht}from"./vault_hook.js";import{F as ie}from"./founding.js";import{j as Fe,n as Ut}from"./backfill.js";import{c as Dt,r as Bt}from"./prompt_coordinator.js";import{C as zt,g as Vt,e as qt}from"./continue_targets.js";import{c as Ke,s as jt}from"./claude_scheduled_task.js";import"./organisation_scope.js";import"./analytics.js";import"./error_logging.js";import"./vault_payoff.js";function Ft(e,t){if(!t?.length)return;const r=document.createElement("div");r.className="message-images";for(const o of t){let i;try{i=new URL(xe(o.dataUrl)??o.url)}catch{continue}if(i.protocol!=="https:"&&i.protocol!=="http:"&&!xe(i.href))continue;const s=document.createElement("a");s.className="message-image";const d=xe(o.dataUrl);s.href=d?/^https?:\/\//.test(o.url)?o.url:"#":i.href,d&&s.addEventListener("click",w=>{w.preventDefault();const a=document.createElement("dialog");a.setAttribute("aria-label","Conversation image");const p=document.createElement("img");p.src=d,p.alt=o.alt||"Conversation image",p.style.maxWidth="90vw",p.style.maxHeight="85vh";const y=document.createElement("button");y.textContent="Close",y.addEventListener("click",()=>a.close()),a.addEventListener("close",()=>a.remove()),a.append(y,document.createElement("br"),p),document.body.append(a),a.showModal()}),s.target="_blank",s.rel="noreferrer",s.title="Open full-size image";const c=document.createElement("img");c.src=i.href,c.loading="lazy",c.alt=o.alt||"Conversation image",o.width&&(c.width=o.width),o.height&&(c.height=o.height),c.addEventListener("error",()=>{c.remove(),s.textContent="Image unavailable. Reopen the original chat to capture it again.",s.title="Open the original image"}),s.append(c),r.append(s)}r.childElementCount&&e.append(r)}function de(e){return`'${e.replace(/'/g,"'\\''")}'`}function pe(e){return`'${e.replace(/'/g,"''")}'`}function dt(e){return/mac/i.test(e)}function ne(e){return/win/i.test(e)}function re(){return typeof navigator>"u"?"":navigator.userAgent}function pt(e){return`codex://threads/${encodeURIComponent(e)}`}function mt(e){return`claude://resume?session=${encodeURIComponent(e)}`}function Kt(e){return`zcode://workspace/open?path=${encodeURIComponent(e)}`}const Wt=80;function We(e){return typeof e=="string"?e.replace(/\s+/g," ").trim():""}function Yt(e,t=Wt){if(e.length<=t)return e;let r=t;e.charCodeAt(r-1)>=55296&&e.charCodeAt(r-1)<=56319&&(r-=1);const o=e.slice(0,r),i=o.lastIndexOf(" ");return(i>t/2?o.slice(0,i):o).trimEnd()}function Gt(e,t){return Yt(We(e)||We(t))}function Zt(e,t=re()){const r=dt(t)?"Command+K":"Ctrl+K";return`ZCode has no direct link to a chat yet. ${e?"Open the project":"Open ZCode"}, press ${r} in ZCode, paste the phrase, and pick the task.`}function ut(e,t,r,o){return ne(o)?`if (Get-Command ${e} -ErrorAction SilentlyContinue) { ${t} } else { Start-Process ${pe(r)} }`:dt(o)?`if command -v ${e} >/dev/null 2>&1; then ${t}; else open ${de(r)}; fi`:t}function Qt(e,t=re()){const r=ne(t)?pe(e):de(e);return ut("codex",`codex resume ${r}`,pt(e),t)}function Xt(e,t=re()){const r=ne(t)?pe(e):de(e);return ut("claude",`claude --resume ${r}`,mt(e),t)}function Jt(e,t,r=re()){return t?ne(r)?`Set-Location -LiteralPath ${pe(t)}; ${e}`:`cd ${de(t)} && ${e}`:e}function en(e=re()){return ne(e)?"Prefer PowerShell, or nothing opened? Run:":"Prefer the terminal, or nothing opened? Run:"}const Ye={claude_code:{heading:"Reopen in Claude Code.",buttonLabel:"Open in Claude Desktop",appHint:"Requires the Claude Desktop app",deepLink:mt,command:Xt},codex:{heading:"Reopen in Codex.",buttonLabel:"Open in ChatGPT",appHint:"Requires the ChatGPT desktop app",deepLink:pt,command:Qt},zcode:{heading:"Reopen in ZCode.",buttonLabel:"Open project in ZCode",appHint:"Opens this session's project in the ZCode desktop app (ZCode has no link to a specific chat yet)",deepLink:(e,t)=>t?Kt(t):null,searchButtonLabel:"Copy ZCode search phrase"}};function ht(e){if(!e)return"missing";const{indexedAt:t,lastSeenAt:r,estimatedBytes:o,searchDocLength:i,indexLevel:s,...d}=e;return JSON.stringify(d)}function Ee(){const e=window.getSelection();return document.visibilityState!=="hidden"&&(!e||e.isCollapsed)}function tn(e){let t=e.initialRevision,r=!1,o=!1;const i=async()=>{if(!(o||r||!Ee())){r=!0;try{const c=await e.read(),w=ht(c);!o&&Ee()&&w!==t&&await e.refresh(c)!==!1&&(t=w)}catch(c){e.onError(c)}finally{r=!1}}},s=()=>{i()},d=window.setInterval(s,3e3);return window.addEventListener("focus",s),document.addEventListener("visibilitychange",s),()=>{o=!0,window.clearInterval(d),window.removeEventListener("focus",s),document.removeEventListener("visibilitychange",s)}}const Z={enabled:!0,minSearchOpens:5,minInstallAgeDays:7,cooldownDays:60,maxImpressions:2},nn="https://chromewebstore.google.com/detail/leekfgbdojiaabifbjbbgiiclannjdkf/reviews",se={headline:"Finding what you need?",body:"A quick review helps others discover LLMnesia.",cta:"Leave a review",dismiss:"Not now"},Ce="llmnesia.reviewPrompt.impressions",Le="llmnesia.reviewPrompt.lastShownAt",Te="llmnesia.reviewPrompt.clicked",Se="llmnesia.reviewPrompt.dismissedAt",Ge=1440*60*1e3;function J(e){const t=Number(e);return Number.isFinite(t)&&t>0?Math.floor(t):0}async function ft(){try{const e=await chrome.storage.local.get([Ce,Le,Te,Se]);return{impressions:J(e[Ce]),lastShownAt:J(e[Le]),clicked:e[Te]===!0,dismissedAt:J(e[Se])}}catch{return{impressions:0,lastShownAt:0,clicked:!1,dismissedAt:0}}}async function rn(e=Date.now()){try{const t=await ft();await chrome.storage.local.set({[Ce]:t.impressions+1,[Le]:e})}catch{}}async function an(){try{await chrome.storage.local.set({[Te]:!0})}catch{}}async function Ze(e=Date.now()){try{await chrome.storage.local.set({[Se]:e})}catch{}}function on(e,t){const r=e.installTs>0?Math.floor((t-e.installTs)/Ge):0,o={searchOpenCount:e.searchOpenCount,installAgeDays:r,impressionNumber:e.impressions+1};if(!e.enabled)return{eligible:!1,reason:"disabled",...o};if(e.clicked)return{eligible:!1,reason:"clicked",...o};if(e.impressions>=Z.maxImpressions)return{eligible:!1,reason:"cap_reached",...o};if(e.searchOpenCount<Z.minSearchOpens)return{eligible:!1,reason:"too_few_opens",...o};if(!(e.checklistComplete||e.backfillComplete))return{eligible:!1,reason:"not_activated",...o};if(e.installTs<=0||r<Z.minInstallAgeDays)return{eligible:!1,reason:"too_new",...o};const i=Math.max(e.lastShownAt,e.dismissedAt);return i>0&&t-i<Z.cooldownDays*Ge?{eligible:!1,reason:"cooldown",...o}:{eligible:!0,...o}}async function sn(){const e=await ft();let t=0,r=0,o=!1,i=!1;try{const s=await chrome.storage.local.get([ie.installTs,ie.resultOpenCount,Fe,...qe.map(c=>je[c])]);t=J(s[ie.installTs]),r=J(s[ie.resultOpenCount]),o=qe.every(c=>s[je[c]]===!0);const d=Ut(s[Fe]);i=Object.values(d).some(c=>c?.hasBackfillRun===!0)}catch{}return{enabled:Z.enabled,clicked:e.clicked,impressions:e.impressions,lastShownAt:e.lastShownAt,dismissedAt:e.dismissedAt,installTs:t,searchOpenCount:r,checklistComplete:o,backfillComplete:i}}async function ln(e=Date.now()){const t=await sn();return on(t,e)}function le(e,t,r){chrome.runtime.sendMessage({type:"TRACK_REVIEW_PROMPT_EVENT",event:e,impressionNumber:t.impressionNumber,searchOpenCount:t.searchOpenCount,installAgeDays:t.installAgeDays,dismissalType:r}).catch(()=>{})}async function cn(e){const t=await ln();if(!t.eligible||!await Dt("review"))return e.textContent="",!1;const r={impressionNumber:t.impressionNumber,searchOpenCount:t.searchOpenCount,installAgeDays:t.installAgeDays};await rn(),await Bt("review"),le("review_prompt_shown",r),e.textContent="";const o=document.createElement("div");o.className="vault-hook";const i=document.createElement("button");i.className="vault-dismiss",i.type="button",i.setAttribute("aria-label","Dismiss"),i.textContent="✕",i.addEventListener("click",()=>{Ze(),le("review_prompt_dismissed",r,"close"),e.textContent=""}),o.append(i);const s=document.createElement("div");s.className="vault-headline",s.textContent=se.headline,o.append(s);const d=document.createElement("div");d.className="vault-body",d.textContent=se.body,o.append(d);const c=document.createElement("div");c.className="vault-wl-row";const w=document.createElement("button");w.className="vault-wl-btn",w.type="button",w.textContent=se.cta,w.addEventListener("click",()=>{an(),le("review_prompt_clicked",r),chrome.tabs.create({url:nn}),e.textContent=""}),c.append(w);const a=document.createElement("button");return a.className="vault-wl-btn ghost",a.type="button",a.textContent=se.dismiss,a.addEventListener("click",()=>{Ze(),le("review_prompt_dismissed",r,"not_now"),e.textContent=""}),c.append(a),o.append(c),e.append(o),!0}Tt("viewer_page","viewer");const gt=document.querySelector("#viewer");if(!gt)throw new Error("Viewer root not found");const _=gt,W=new URLSearchParams(window.location.search),j=W.get("docId")?.trim()??"",ee=W.get("q")?.trim()??"",Qe=W.get("msg"),ce=W.get("memoryId")?.trim()??"",dn=W.get("via")==="deleted",we=Et(ee),pn=new Rt;let bt="missing",ye,Xe,vt;const $e={user:"User",assistant:"Assistant",system:"System",unknown:"Unknown"};function Je(e){return new Date(e).toLocaleString()}function et(e){return new Date(e).toLocaleDateString(void 0,{year:"numeric",month:"short",day:"numeric"})}function A(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#39;")}function mn(e){return e.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")}function tt(e,t){let r=t instanceof HTMLElement?t:t.parentElement;for(;r&&r!==e;){if(r.dataset.msgIndex!==void 0)return parseInt(r.dataset.msgIndex,10);r=r.parentElement}return-1}function Q(e,t,r){if(!r.length){e.append(t);return}const o=new RegExp(`(${r.map(mn).join("|")})`,"gi");let i=0;for(const s of t.matchAll(o)){const d=s.index??0;d>i&&e.append(t.slice(i,d));const c=document.createElement("mark");c.textContent=s[0],e.append(c),i=d+s[0].length}i<t.length&&e.append(t.slice(i))}function nt(e){return/^\s*\|.*\|\s*$/.test(e)}function un(e){return/^\s*\|(?:\s*:?-{1,}:?\s*\|)+\s*$/.test(e)}function rt(e){return e.trim().replace(/^\|/,"").replace(/\|$/,"").split(new RegExp("(?<!\\\\)\\|")).map(t=>t.trim().replace(/\\\|/g,"|"))}function at(e,t,r){const o=/```(\w*)\n?([\s\S]*?)```/g;let i=0,s;function d(p,y){const g=new RegExp("`([^`]+)`|\\*\\*(?=\\S)(.+?)(?<=\\S)\\*\\*|(?<![\\p{L}\\p{N}_])__(?=\\S)(.+?)(?<=\\S)__(?![\\p{L}\\p{N}_])|\\*(?=\\S)(.+?)(?<=\\S)\\*|(?<![\\p{L}\\p{N}_])_(?=\\S)(.+?)(?<=\\S)_(?![\\p{L}\\p{N}_])","gu");let v=0,f;for(;(f=g.exec(y))!==null;){if(f.index>v&&Q(p,y.slice(v,f.index),r),f[1]!==void 0){const E=document.createElement("code");E.textContent=f[1],p.append(E)}else if(f[2]!==void 0||f[3]!==void 0){const E=document.createElement("strong");Q(E,f[2]??f[3],r),p.append(E)}else{const E=document.createElement("em");Q(E,f[4]??f[5],r),p.append(E)}v=f.index+f[0].length}v<y.length&&Q(p,y.slice(v),r)}function c(p,y,g){if(!g)return!1;for(let v=y;v<p.length;v++){const f=p[v];if(f.trim()!=="")return g==="ul"?/^[-*]\s+/.test(f):/^\d+\.\s+/.test(f)}return!1}function w(p,y){const g=y.split(`
`);let v=0,f=null,E=null;function $(){f&&(p.append(f),f=null,E=null)}for(;v<g.length;){const O=g[v];if(nt(O)&&v+1<g.length&&un(g[v+1])){$();const C=document.createElement("table"),H=document.createElement("thead"),N=document.createElement("tr");for(const I of rt(O)){const z=document.createElement("th");d(z,I),N.append(z)}H.append(N),C.append(H),v+=2;const F=document.createElement("tbody");for(;v<g.length&&nt(g[v]);){const I=document.createElement("tr");for(const z of rt(g[v])){const Y=document.createElement("td");d(Y,z),I.append(Y)}F.append(I),v++}C.append(F),p.append(C);continue}const M=O.match(/^(#{1,3})\s+(.*)/),P=O.match(/^[-*]\s+(.*)/),B=O.match(/^(\d+)\.\s+(.*)/);if(M){$();const C=M[1].length,H=["h1","h2","h3"][C-1],N=document.createElement(H);d(N,M[2]),p.append(N)}else if(P){(E!=="ul"||f===null)&&($(),f=document.createElement("ul"),E="ul");const C=document.createElement("li");d(C,P[1]),f.append(C)}else if(B){(E!=="ol"||f===null)&&($(),f=document.createElement("ol"),f.start=Number(B[1]),E="ol");const C=document.createElement("li");d(C,B[2]),f.append(C)}else if(O.trim()==="")c(g,v+1,E)||$();else{$();const C=document.createElement("p");d(C,O),p.append(C)}v++}$()}for(;(s=o.exec(t))!==null;){const p=t.slice(i,s.index);p&&w(e,p);const y=document.createElement("pre"),g=document.createElement("code");s[1]&&(g.className=`language-${s[1]}`),g.textContent=s[2].replace(/\n$/,""),y.append(g),e.append(y),i=s.index+s[0].length}const a=t.slice(i);a&&w(e,a)}const h={lens:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"></circle><path d="m21 21-4.3-4.3"></path></svg>',shieldTag:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2 4 5v6c0 5 3.4 7.8 8 9 4.6-1.2 8-4 8-9V5l-8-3Z"></path></svg>',shieldCheck:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3 5 6v5c0 4.4 3 6.9 7 8 4-1.1 7-3.6 7-8V6l-7-3Z"></path><path d="m9 12 2 2 4-4"></path></svg>',external:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path><path d="M15 3h6v6"></path><path d="M10 14 21 3"></path></svg>',copy:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="11" height="11" rx="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg>',check:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="m20 6-11 11-5-5"></path></svg>',brokenFolder:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M4 7V5a2 2 0 0 1 2-2h3l2 2h7a2 2 0 0 1 2 2v3"></path><path d="M4 11v6a2 2 0 0 0 2 2h11"></path><path d="m3 3 18 18"></path></svg>',pin:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M9 4h6l-1 5 3 3v2H7v-2l3-3-1-5Z"></path><path d="M12 15v5"></path></svg>',refresh:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a9 9 0 1 1-2.64-6.36"></path><path d="M21 4v5h-5"></path></svg>'};function hn(){_.innerHTML=`
    <style>
      :root {
        color-scheme: light;
        --paper: ${k.paper};
        --paper-2: ${k.paperSoft};
        --card: ${k.card};
        --rule: ${k.rule};
        --rule-soft: ${k.ruleSoft};
        --ink: ${k.ink};
        --ink-2: ${k.ink2};
        --ink-3: ${k.ink3};
        --teal: ${k.teal};
        --teal-soft: ${k.tealSoft};
        --teal-edge: ${k.tealEdge};
        --rust: #c6572f;
        --on-bg: ${k.onBg};
        --on-edge: ${k.onEdge};
        --on-ink: ${k.onInk};
        --font: "IBM Plex Sans", ui-sans-serif, system-ui, -apple-system, "Segoe UI", sans-serif;
        --mono: "IBM Plex Mono", ui-monospace, "SF Mono", "Cascadia Code", Menlo, monospace;
        /* Per-platform accent; overwritten once the conversation loads. */
        --p-accent: ${k.teal};
        --p-card: ${k.card};
        --p-pill-bg: ${k.tealSoft};
        --p-pill-border: ${k.tealEdge};
        --p-pill-text: ${k.ink2};
      }

      * { box-sizing: border-box; }

      body {
        margin: 0;
        background:
          radial-gradient(60rem 30rem at 82% -6%, rgba(47, 127, 153, 0.07), transparent 70%),
          var(--paper);
        color: var(--ink);
        font-family: var(--font);
        line-height: 1.6;
        -webkit-font-smoothing: antialiased;
      }

      /* ===== Slim page chrome ===== */
      .topbar {
        position: sticky;
        top: 0;
        z-index: 20;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 1rem;
        padding: 0.6rem 1.25rem;
        background: color-mix(in srgb, var(--paper) 88%, transparent);
        backdrop-filter: blur(8px);
        border-bottom: 1px solid var(--rule);
      }
      .brand {
        display: inline-flex;
        align-items: center;
        gap: 0.5rem;
        font-weight: 700;
        font-size: 0.9rem;
        letter-spacing: -0.01em;
        white-space: nowrap;
      }
      .brand .mark {
        display: inline-grid;
        place-items: center;
        width: 1.4rem;
        height: 1.4rem;
        border-radius: 6px;
        background: var(--teal-soft);
        border: 1px solid var(--teal-edge);
        color: var(--teal);
      }
      .brand .mark svg { width: 15px; height: 15px; }
      .brand b { font-family: var(--mono); font-weight: 600; }
      .topbar-title {
        flex: 1;
        min-width: 0;
        text-align: center;
        font-size: 0.8rem;
        color: var(--ink-3);
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        opacity: 0;
        transition: opacity 0.2s;
      }
      .offline-tag {
        display: inline-flex;
        align-items: center;
        gap: 0.4rem;
        padding: 0.28rem 0.6rem 0.28rem 0.5rem;
        border-radius: 999px;
        background: var(--on-bg);
        border: 1px solid var(--on-edge);
        color: var(--on-ink);
        font-family: var(--mono);
        font-size: 0.66rem;
        font-weight: 600;
        letter-spacing: 0.04em;
        text-transform: uppercase;
        white-space: nowrap;
      }
      .offline-tag svg { width: 13px; height: 13px; }

      /* ===== Reading column ===== */
      .wrap {
        max-width: 46rem;
        margin: 0 auto;
        padding: 1.4rem 1.5rem 4rem;
      }

      .status {
        margin: 2rem 0;
        color: var(--ink-3);
        text-align: center;
        font-size: 0.9rem;
      }

      /* ===== Provenance header ===== */
      .head { margin-bottom: 0.8rem; }
      .head[hidden] { display: none; }
      .head-eyebrow {
        display: flex;
        align-items: center;
        gap: 0.55rem;
        margin-bottom: 0.55rem;
        flex-wrap: wrap;
      }
      .platform-badge {
        display: inline-flex;
        align-items: center;
        gap: 0.4rem;
        padding: 0.26rem 0.6rem;
        border-radius: 999px;
        background: var(--p-pill-bg);
        border: 1px solid var(--p-pill-border);
        color: var(--p-pill-text);
        font-size: 0.72rem;
        font-weight: 600;
      }
      .platform-badge .dot {
        width: 0.5rem;
        height: 0.5rem;
        border-radius: 50%;
        background: var(--p-accent);
      }
      .source-badge {
        display: inline-flex;
        align-items: center;
        gap: 0.35rem;
        padding: 0.26rem 0.6rem 0.26rem 0.5rem;
        border-radius: 999px;
        background: var(--paper-2);
        border: 1px solid var(--rule);
        color: var(--ink-2);
        font-size: 0.72rem;
        font-weight: 600;
      }
      .source-badge svg { width: 13px; height: 13px; color: var(--teal); }
      .head h1 {
        margin: 0 0 0.45rem;
        font-size: clamp(1.55rem, 3.2vw, 2.05rem);
        line-height: 1.15;
        letter-spacing: -0.02em;
        font-weight: 700;
        text-wrap: balance;
      }
      .meta-line {
        display: flex;
        align-items: center;
        flex-wrap: wrap;
        gap: 0.5rem 0.7rem;
        font-family: var(--mono);
        font-size: 0.73rem;
        color: var(--ink-3);
        letter-spacing: 0.01em;
      }
      .meta-line .sep { opacity: 0.45; }
      .meta-line b { color: var(--ink-2); font-weight: 600; }

      /* ===== Optional header information ===== */
      .head-extras {
        margin-top: 0.65rem;
      }
      .head-extra-controls {
        display: flex;
        align-items: center;
        flex-wrap: wrap;
        gap: 0.25rem 1rem;
      }
      .head-extra-toggle {
        display: inline-flex;
        align-items: center;
        gap: 0.35rem;
        padding: 0;
        border: 0;
        background: transparent;
        cursor: pointer;
        color: var(--ink-3);
        font-family: var(--font);
        font-size: 0.75rem;
        font-weight: 600;
      }
      .head-extra-toggle::before { content: "+"; color: var(--teal); font-weight: 700; }
      .head-extra-toggle[aria-expanded="true"]::before { content: "−"; }
      .head-extra-toggle:hover { color: var(--teal); }
      .head-extra-toggle:focus-visible { outline: 2px solid var(--teal); outline-offset: 3px; border-radius: 3px; }
      .head-extra-toggle svg { width: 14px; height: 14px; color: var(--teal); }
      .head-extra-toggle.details-toggle {
        font-family: var(--mono);
        font-size: 0.7rem;
        letter-spacing: 0.06em;
        text-transform: uppercase;
      }
      .head-extra-panel {
        margin-top: 0.5rem;
        padding: 0.7rem 0.85rem;
        border: 1px solid var(--rule-soft);
        border-radius: 8px;
        background: var(--card);
        color: var(--ink-2);
        font-size: 0.82rem;
        line-height: 1.55;
      }
      .head-extra-panel[hidden] { display: none; }
      .head-extra-panel[data-kind="assure"] { border-color: var(--teal-edge); background: var(--teal-soft); }
      .head-extra-panel p { margin: 0; }
      .assure-icon {
        flex: none;
        display: inline-grid;
        place-items: center;
        width: 2rem;
        height: 2rem;
        border-radius: 8px;
        background: var(--card);
        border: 1px solid var(--teal-edge);
        color: var(--teal);
      }
      .assure-icon svg { width: 17px; height: 17px; }

      /* Shown when a saved transcript predates an extraction fix (e.g. turns
         stored with an "unknown" role). Warmer rust tone to read as an
         actionable heads-up rather than the reassuring teal banner above. */
      .reindex-nudge {
        display: flex;
        align-items: flex-start;
        gap: 0.75rem;
        margin: 0.75rem 0 0;
        padding: 0.85rem 1rem;
        border: 1px solid color-mix(in srgb, var(--rust) 35%, var(--rule));
        border-radius: 12px;
        background: color-mix(in srgb, var(--rust) 8%, var(--card));
      }
      .reindex-nudge .assure-icon {
        border-color: color-mix(in srgb, var(--rust) 35%, var(--rule));
        color: var(--rust);
      }
      .reindex-nudge p { margin: 0; font-size: 0.85rem; line-height: 1.55; color: var(--ink-2); }
      .reindex-nudge p strong { color: var(--ink); font-weight: 600; }
      .reindex-nudge a { color: var(--rust); font-weight: 600; text-decoration: none; }
      .reindex-nudge a:hover { text-decoration: underline; }

      /* ===== Terminal fallback for local sessions ===== */
      .resume-card p { margin-bottom: 0.5rem; }
      .resume-cmd { display: flex; align-items: center; gap: 0.5rem; flex-wrap: wrap; }
      .resume-cmd code {
        flex: 1 1 260px;
        min-width: 0;
        overflow-x: auto;
        white-space: nowrap;
        font-family: var(--mono);
        font-size: 0.78rem;
        padding: 0.5rem 0.65rem;
        border-radius: 8px;
        background: var(--card);
        border: 1px solid var(--rule);
        color: var(--ink);
      }

      /* ===== Actions ===== */
      .actions {
        display: flex;
        flex-wrap: wrap;
        gap: 0.5rem;
        margin: 0.75rem 0 0;
      }
      .btn {
        display: inline-flex;
        align-items: center;
        gap: 0.45rem;
        padding: 0.5rem 0.85rem;
        border-radius: 8px;
        border: 1px solid var(--teal-edge);
        background: transparent;
        color: var(--teal);
        font-family: var(--font);
        font-size: 0.82rem;
        font-weight: 600;
        cursor: pointer;
        text-decoration: none;
        transition: background 0.18s, border-color 0.18s, transform 0.18s;
      }
      .btn svg { width: 15px; height: 15px; }
      .btn:hover { background: var(--teal-soft); border-color: var(--teal); transform: translateY(-1px); }
      .btn.subtle { border-color: var(--rule); color: var(--ink-2); }
      .btn.subtle:hover { background: var(--paper-2); border-color: var(--ink-3); }
      .btn.is-done { color: var(--on-ink); border-color: var(--on-edge); background: var(--on-bg); }

      .details-grid {
        display: grid;
        gap: 0.4rem;
        margin: 0;
        font-size: 0.78rem;
      }
      .details-grid div {
        display: flex;
        gap: 0.6rem;
        flex-wrap: wrap;
      }
      .details-grid dt {
        min-width: 8.5rem;
        color: var(--ink-3);
        font-weight: 500;
      }
      .details-grid dd {
        margin: 0;
        color: var(--ink-2);
        font-family: var(--mono);
        word-break: break-all;
      }

      .divider {
        margin: 0.9rem 0 1.2rem;
        border: none;
        border-top: 1px solid var(--rule);
      }
      .divider[hidden] { display: none; }

      /* ===== Transcript ===== */
      .transcript { display: grid; gap: 1.1rem; }
      .turn {
        display: grid;
        grid-template-columns: 2rem minmax(0, 1fr);
        gap: 0.85rem;
      }
      .avatar {
        flex: none;
        display: inline-grid;
        place-items: center;
        width: 2rem;
        height: 2rem;
        border-radius: 8px;
        font-family: var(--mono);
        font-size: 0.72rem;
        font-weight: 700;
        margin-top: 0.15rem;
        background: var(--paper-2);
        border: 1px solid var(--rule);
        color: var(--ink-2);
      }
      .turn.assistant .avatar {
        background: var(--p-pill-bg);
        border-color: var(--p-pill-border);
        color: var(--p-pill-text);
      }
      .turn-body { min-width: 0; }
      .turn-meta {
        display: flex;
        align-items: center;
        gap: 0.5rem;
        margin-bottom: 0.4rem;
        font-family: var(--mono);
        font-size: 0.68rem;
        letter-spacing: 0.06em;
        text-transform: uppercase;
      }
      .turn-role { font-weight: 700; color: var(--ink-2); }
      .turn.assistant .turn-role { color: var(--p-pill-text); }
      .turn-num { color: var(--ink-3); opacity: 0.7; }

      /* Per-message copy button: tucked into the turn's meta row, invisible
         until the turn is hovered (or the button focused) so the reading
         column stays quiet. Touch devices have no hover, so keep it faintly
         visible there instead. */
      .turn-copy {
        margin-left: auto;
        display: inline-grid;
        place-items: center;
        width: 1.55rem;
        height: 1.55rem;
        padding: 0;
        border-radius: 6px;
        border: 1px solid var(--rule);
        background: var(--card);
        color: var(--ink-3);
        cursor: pointer;
        opacity: 0;
        transition: opacity 0.15s ease, color 0.15s ease, border-color 0.15s ease;
      }
      .turn-copy svg { width: 12px; height: 12px; }
      .turn:hover .turn-copy,
      .turn-copy:focus-visible { opacity: 1; }
      .turn-copy:hover { color: var(--teal); border-color: var(--teal-edge); }
      .turn-copy.is-done { opacity: 1; color: var(--teal); border-color: var(--teal-edge); }
      .turn-copy.is-failed { opacity: 1; color: var(--rust); border-color: color-mix(in srgb, var(--rust) 35%, var(--rule)); }
      @media (hover: none) {
        .turn-copy { opacity: 0.55; }
      }

      .bubble {
        border: 1px solid var(--rule);
        border-radius: 12px;
        padding: 0.85rem 1.05rem;
        background: var(--card);
        font-size: 0.94rem;
        line-height: 1.68;
        color: var(--ink);
        overflow-wrap: break-word;
      }
      .turn.user .bubble { background: var(--paper-2); border-color: var(--rule-soft); }
      .turn.assistant .bubble {
        border-left: 3px solid var(--p-accent);
        background: var(--p-card);
      }
      .bubble > :first-child { margin-top: 0; }
      .bubble > :last-child { margin-bottom: 0; }
      .bubble p { margin: 0 0 0.7rem; }
      .bubble .scheduled-task summary { cursor: pointer; color: var(--ink-2); font-weight: 600; }
      .bubble .scheduled-task[open] summary { margin-bottom: 0.8rem; }
      .bubble h1, .bubble h2, .bubble h3 {
        margin: 0.2rem 0 0.55rem;
        font-size: 1rem;
        font-weight: 700;
        letter-spacing: -0.01em;
        line-height: 1.3;
      }
      .bubble ul, .bubble ol { margin: 0 0 0.7rem; padding-left: 1.3rem; }
      .bubble li { margin: 0.2rem 0; }
      .bubble li::marker { color: var(--teal); }
      .bubble code {
        font-family: var(--mono);
        font-size: 0.83em;
        background: var(--paper-2);
        border: 1px solid var(--rule-soft);
        border-radius: 5px;
        padding: 0.08em 0.38em;
      }
      .bubble pre {
        margin: 0 0 0.7rem;
        padding: 0.8rem 0.9rem;
        background: #fbfaf3;
        border: 1px solid var(--rule);
        border-radius: 8px;
        overflow-x: auto;
      }
      .bubble pre code {
        background: none;
        border: none;
        padding: 0;
        font-size: 0.82rem;
        line-height: 1.6;
        color: var(--ink-2);
        white-space: pre;
      }
      .bubble table {
        display: block;
        width: 100%;
        margin: 0 0 0.7rem;
        border-collapse: collapse;
        overflow-x: auto;
        font-size: 0.86rem;
      }
      .bubble th, .bubble td {
        padding: 0.4rem 0.6rem;
        border: 1px solid var(--rule);
        text-align: left;
        vertical-align: top;
      }
      .bubble thead th {
        background: var(--paper-2);
        font-weight: 600;
        color: var(--ink);
      }
      .bubble tbody tr:nth-child(even) td {
        background: color-mix(in srgb, var(--paper-2) 45%, transparent);
      }
      .message-images {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(10rem, 1fr));
        gap: 0.6rem;
        margin: 0.1rem 0 0.7rem;
      }
      .message-image {
        display: block;
        min-width: 0;
        overflow: hidden;
        border: 1px solid var(--rule);
        border-radius: 8px;
        background: var(--paper-2);
      }
      .message-image:hover { border-color: var(--teal-edge); }
      .message-image img {
        display: block;
        width: 100%;
        max-height: 28rem;
        object-fit: contain;
        background: var(--paper-2);
      }
      mark {
        background: color-mix(in srgb, var(--rust) 16%, transparent);
        color: var(--ink);
        border-radius: 3px;
        padding: 0 2px;
      }

      /* ===== Empty / error states ===== */
      .empty-card {
        display: grid;
        place-items: center;
        text-align: center;
        gap: 0.55rem;
        padding: 2.6rem 1.5rem;
        margin: 1.5rem 0;
        border: 1px dashed var(--rule);
        border-radius: 14px;
        background: color-mix(in srgb, var(--paper-2) 55%, var(--card));
      }
      .empty-icon {
        display: inline-grid;
        place-items: center;
        width: 3rem;
        height: 3rem;
        border-radius: 12px;
        background: var(--card);
        border: 1px solid var(--rule);
        color: var(--ink-3);
        margin-bottom: 0.2rem;
      }
      .empty-icon svg { width: 22px; height: 22px; }
      .empty-card h2 { margin: 0; font-size: 1.1rem; font-weight: 700; }
      .empty-card p { margin: 0; max-width: 30rem; font-size: 0.88rem; color: var(--ink-3); line-height: 1.6; }
      .empty-card .actions { margin-top: 0.6rem; justify-content: center; }
      .empty-card code {
        font-family: var(--mono);
        font-size: 0.8rem;
        background: var(--paper-2);
        border: 1px solid var(--rule-soft);
        border-radius: 5px;
        padding: 0.08em 0.38em;
        word-break: break-all;
      }

      @media (max-width: 560px) {
        .turn { grid-template-columns: 1.7rem minmax(0, 1fr); gap: 0.6rem; }
        .topbar-title { display: none; }
      }
      ${Ht}
    </style>
    <header class="topbar">
      <span class="brand">
        <span class="mark" aria-hidden="true">${h.lens}</span>
        LLMnesia <b>viewer</b>
      </span>
      <span class="topbar-title" id="topbar-title"></span>
      <span class="offline-tag" title="This copy is stored on your device">
        ${h.shieldTag}
        Offline copy
      </span>
    </header>
    <main class="wrap" id="viewer-app">
      <p id="viewer-status" class="status">Loading transcript…</p>
      <div class="head" id="viewer-head" hidden></div>
      <div id="vault-post-search"></div>
      <div id="review-post-search"></div>
      <hr class="divider" id="viewer-divider" hidden />
      <div id="viewer-transcript" class="transcript"></div>
      <section id="vault-footer" class="vault-footer" data-visible="false"></section>
    </main>
  `}function ke(e,t){const r=document.createElement("div");r.className="empty-card";const o=document.createElement("span");o.className="empty-icon",o.setAttribute("aria-hidden","true"),o.innerHTML=t.icon;const i=document.createElement("h2");i.textContent=t.heading;const s=document.createElement("p");if(s.textContent=t.body,r.append(o,i,s),t.detail){const d=document.createElement("p"),c=document.createElement("code");c.textContent=t.detail,d.append(c),r.append(d)}if(t.actionLabel&&t.actionHref){const d=document.createElement("div");d.className="actions";const c=document.createElement("a");c.className="btn",c.href=t.actionHref,c.target="_blank",c.rel="noreferrer",c.innerHTML=`${h.external}<span>${A(t.actionLabel)}</span>`,d.append(c),r.append(d)}e.append(r)}function X(e,t){const r=t.formattedText??t.text,o=e==="codex"&&Ct(r)?Lt(r)??"Question reply unavailable":r;return qt(e,o)}function ot(e){return e?.length?e.join(", "):"Not reported by provider"}function it(e,t,r,o){const i=[`# ${e||"Untitled"}`,`Platform: ${r}`,""];for(const s of o)i.push(`## ${$e[s.role]}`,X(t,s).trim(),"");return i.join(`
`).trim()+`
`}function fn(){return typeof crypto<"u"&&typeof crypto.randomUUID=="function"?crypto.randomUUID():`${Date.now()}-${Math.random().toString(36).slice(2,10)}`}function gn(e,t){const r="llmnesia-continue";try{const o=new URL(e);o.searchParams.set(r,t);const i=new URLSearchParams(o.hash.startsWith("#")?o.hash.slice(1):o.hash);return i.set(r,t),o.hash=i.toString(),o.toString()}catch{const o=`${r}=${encodeURIComponent(t)}`;return e.includes("#")?`${e}&${o}`:`${e}#${o}`}}async function st(e){Xe?.(),Xe=void 0;const t=e?.conversation?await ze(j):[],r=e&&ce?await Be(ce):void 0;if(e&&!Ee())return!1;ye?.detach(),ye=void 0,vt?.disconnect(),hn();const o=_.querySelector("#viewer-status"),i=_.querySelector("#viewer-head"),s=_.querySelector("#viewer-divider"),d=_.querySelector("#viewer-transcript"),c=_.querySelector("#topbar-title");let w;if(ce&&(w=e?r:await Be(ce)),!j){o.hidden=!0,ke(d,{icon:h.brokenFolder,heading:"No conversation was requested",body:"This viewer needs a conversation to open. Launch it from a search result or from your saved conversations."});return}const a=e?e.conversation:await ct(j);if(bt=ht(a),!a){o.hidden=!0,ke(d,{icon:h.brokenFolder,heading:"This conversation isn't in your index yet",body:"It may have been removed before it was captured, or it hasn't been indexed on this device. Open it once on the platform and LLMnesia will save a copy.",detail:j});return}const p=St(a.platform),y=_.querySelector("#viewer-app");y.style.setProperty("--p-accent",p.accent),y.style.setProperty("--p-card",p.card),y.style.setProperty("--p-pill-bg",p.pillBg),y.style.setProperty("--p-pill-border",p.pillBorder),y.style.setProperty("--p-pill-text",p.pillText);const g=e?t:await ze(j),v=a.contentUpdatedAt??a.updatedAt,f=a.indexedAt??a.lastSeenAt,E=a.localTitle||a.title||"Untitled conversation",$=g[0],M=a.platform==="claude_code"&&$?.role==="user"&&Ke($.formattedText??$.text)&&!a.localTitle?jt(E,a.createdAt):E;o.hidden=!0,i.hidden=!1;const P=document.createElement("div");P.className="head-eyebrow";const B=document.createElement("span");B.className="platform-badge",B.innerHTML=`<span class="dot"></span> ${A(p.label)}`,P.append(B);const C=Ve(a.captureProvenance);if(C){const n=document.createElement("span");n.className="source-badge",n.textContent=C,P.append(n)}const H=document.createElement("span");if(H.className="source-badge",H.textContent=`Model: ${ot(a.models)}`,P.append(H),w){const n=document.createElement("span");n.className="source-badge",n.innerHTML=`${h.pin} Saved memory`,P.append(n)}i.append(P);const N=document.createElement("h1");N.textContent=w?w.label:M,i.append(N),c.textContent=N.textContent;const F=document.createElement("div");F.className="meta-line";const I=[];w&&I.push(`from <b>${A(M)}</b>`),I.push(`<b>${g.length}</b> message${g.length===1?"":"s"}`),I.push(`captured <b>${A(et(f))}</b>`),I.push(`created <b>${A(et(a.createdAt))}</b>`),F.innerHTML=I.join('<span class="sep">·</span>'),i.append(F);const z=Pt(!0,dn,p.label),Y=document.createElement("p");if(Y.textContent=z.body,W.get("via")==="unavailable"){const n=document.createElement("p");n.className="helper-note",n.textContent="Couldn't open the original Google chat. Your saved copy is here. Open a signed-in Google AI Mode tab, then try again.",i.append(n)}const yt=a.url||a.baseUrl,Me=a.platform==="ai_studio"&&a.sourceId?.startsWith("drive-export-"),Ne=a.platform==="character_ai"&&a.sourceId?.startsWith("file-export-"),V=$t(a)||Me||Ne?null:yt,Re=n=>{if(a.platform==="google_ai_mode"){const m=l=>{l.button>1||l.altKey||(l.preventDefault(),chrome.runtime.sendMessage({type:"OPEN_RESULT",inNewTab:!0,background:l.button===1||l.metaKey||l.ctrlKey,result:{docId:a.docId,platform:a.platform,url:a.url,baseUrl:a.baseUrl,isDeeplinkable:!0}}).catch(()=>{n.textContent="Couldn't open Google. Your saved copy is here."}))};n.addEventListener("click",m),n.addEventListener("auxclick",m)}};if(g.some(n=>n.role==="unknown")&&V){const n=document.createElement("div");n.className="reindex-nudge",n.innerHTML=`
      <span class="assure-icon" aria-hidden="true">${h.refresh}</span>
      <p><strong>Some message roles could not be identified.</strong> <a href="${A(V)}" target="_blank" rel="noreferrer">Re-open it in ${A(p.label)}</a> to capture the current conversation again.</p>
    `;const m=n.querySelector("a");m&&Re(m),i.append(n)}const K=a.sourceId&&Ye[a.platform]?Ye[a.platform]:null,me=K&&a.sourceId?K.deepLink(a.sourceId,a.sourceCwd):null,ae=K?.searchButtonLabel,U=document.createElement("div");if(U.className="actions",V){const n=document.createElement("a");n.className="btn",n.href=V,n.target="_blank",n.rel="noreferrer",n.innerHTML=`${h.external}<span>Open in ${A(p.label)}</span>`,Re(n),U.append(n)}if(me){const n=document.createElement("a");n.className="btn",n.href=me,n.title=K.appHint,n.innerHTML=`${h.external}<span>${K.buttonLabel}</span>`,U.append(n)}if(ae&&a.sourceId){const n=g.find(b=>b.role==="user"),m=Gt(n?X(a.platform,n):null,M),l=document.createElement("button");l.type="button",l.className="btn subtle",l.title="Copies a phrase that finds this chat in ZCode's Command Center search",l.innerHTML=`${h.copy}<span>${ae}</span>`,l.addEventListener("click",()=>{navigator.clipboard.writeText(m).then(()=>{l.classList.add("is-done"),l.innerHTML=`${h.check}<span>Copied</span>`,setTimeout(()=>{l.classList.remove("is-done"),l.innerHTML=`${h.copy}<span>${ae}</span>`},1600)},()=>{l.innerHTML=`${h.copy}<span>Copy failed</span>`})}),U.append(l)}if(C){const n=document.createElement("div");n.className="viewer-no-original-note",n.style.cssText="margin: 1.1rem 0 0; color: var(--p-pill-text, #526771); font-size: 12.5px; line-height: 1.5; opacity: 0.9;",n.textContent=Mt,i.append(n)}if(Me){const n=document.createElement("p");n.className="helper-note",n.textContent="Imported from an AI Studio Drive download. The download does not include the original chat link.",i.append(n)}if(g.length>0){const n=document.createElement("button");if(n.type="button",n.className="btn subtle",n.textContent="Download transcript (.md)",n.addEventListener("click",()=>{const b=it(M,a.platform,p.label,g),u=URL.createObjectURL(new Blob([b],{type:"text/markdown;charset=utf-8"})),S=document.createElement("a");S.href=u,S.download=`${M.replace(/[<>:"/\\|?*\u0000-\u001f]/g,"_").slice(0,100)||"conversation"}.md`,S.click(),setTimeout(()=>URL.revokeObjectURL(u),1e3)}),U.append(n),Ne){const b=document.createElement("p");b.className="helper-note",b.textContent="Imported file snapshot. It has no verified original chat link. Unknown speakers stay labelled Unknown; account exports may include alternative replies. Dates reflect the file and may be export dates. Keep your source file and check this copy before relying on it.",i.append(b)}const m=document.createElement("button");m.className="btn subtle",m.innerHTML=`${h.copy}<span>Copy transcript</span>`,m.addEventListener("click",()=>{const b=it(M,a.platform,p.label,g);navigator.clipboard.writeText(b).then(()=>{m.classList.add("is-done"),m.innerHTML=`${h.check}<span>Copied</span>`,setTimeout(()=>{m.classList.remove("is-done"),m.innerHTML=`${h.copy}<span>Copy transcript</span>`},1600)},()=>{m.innerHTML=`${h.copy}<span>Copy failed</span>`})}),U.append(m);const l=document.createElement("button");l.type="button",l.className="btn subtle",l.innerHTML=`${h.external}<span>Continue in…</span>`,l.setAttribute("aria-haspopup","menu"),l.addEventListener("click",()=>{const b=g.filter(u=>u.role==="user"||u.role==="assistant").length;pn.show(l.getBoundingClientRect(),a.platform,(u,S)=>{const L=zt[u];if(!L)return;const T=fn(),q=g.map(D=>({role:D.role,text:X(a.platform,D)}));chrome.runtime.sendMessage({type:"PREPARE_CONTINUE_PAYLOAD",docId:a.docId,sourcePlatform:a.platform,targetPlatform:u,requestId:T,sourceLabel:p.label,mode:S,fallbackMessages:q}).then(D=>{D?.ok===!1&&(l.innerHTML=`${h.external}<span>Continue failed</span>`,G?.close(),setTimeout(()=>{l.innerHTML=`${h.external}<span>Continue in…</span>`},1800))}).catch(()=>{l.innerHTML=`${h.external}<span>Continue failed</span>`,G?.close(),setTimeout(()=>{l.innerHTML=`${h.external}<span>Continue in…</span>`},1800)});const G=window.open(gn(L.newChatUrl,T),"_blank");l.innerHTML=`${h.external}<span>Opening ${L.label}…</span>`,setTimeout(()=>{l.innerHTML=`${h.external}<span>Continue in…</span>`},1800)},{suggestSummary:b>Vt})}),U.append(l)}if(i.append(U),ae&&a.sourceId){const n=document.createElement("div");n.style.cssText="margin: 0.7rem 0 0; color: var(--p-pill-text, #526771); font-size: 12.5px; line-height: 1.5; opacity: 0.9;",n.textContent=Zt(!!me),i.append(n)}const ue=document.createElement("div");ue.className="head-extras";const he=document.createElement("div");he.className="head-extra-controls";const R=document.createElement("div");R.className="head-extra-panel",R.id="viewer-head-extra-panel",R.setAttribute("role","region"),R.hidden=!0;const Ie=[];function fe(n,m,l,b){const u=document.createElement("button");if(u.type="button",u.className=`head-extra-toggle ${l}`,u.setAttribute("aria-expanded","false"),u.setAttribute("aria-controls",R.id),b){const L=document.createElement("span");L.setAttribute("aria-hidden","true"),L.innerHTML=b,u.append(L)}const S=document.createElement("span");S.textContent=n,u.append(S),u.addEventListener("click",()=>{const L=u.getAttribute("aria-expanded")!=="true";for(const T of Ie)T.setAttribute("aria-expanded","false");R.replaceChildren(),R.hidden=!L,L&&(u.setAttribute("aria-expanded","true"),R.dataset.kind=l,R.setAttribute("aria-label",n),R.append(m))}),Ie.push(u),he.append(u)}fe(z.heading,Y,"assure",h.shieldCheck);const _e=K?.command;if(_e&&a.sourceId){const n=a.sourceCwd,m=_e(a.sourceId),l=Jt(m,n),b=document.createElement("div");b.className="resume-card";const u=document.createElement("p");u.textContent=en();const S=document.createElement("div");S.className="resume-cmd";const L=document.createElement("code");L.textContent=l;const T=document.createElement("button");T.className="btn subtle",T.innerHTML=`${h.copy}<span>Copy command</span>`,T.addEventListener("click",()=>{navigator.clipboard.writeText(l).then(()=>{T.classList.add("is-done"),T.innerHTML=`${h.check}<span>Copied</span>`,setTimeout(()=>{T.classList.remove("is-done"),T.innerHTML=`${h.copy}<span>Copy command</span>`},1600)},()=>{T.innerHTML=`${h.copy}<span>Copy failed</span>`})}),S.append(L,T),b.append(u,S),fe("Reopen in terminal",b,"resume-card")}const ge=document.createElement("dl");ge.className="details-grid";const be=[["Platform",a.platform],[a.models&&a.models.length>1?"Models":"Model",ot(a.models)],["Content updated",Je(v)],["Indexed",Je(f)],["docId",a.docId]],Pe=Ve(a.captureProvenance);Pe&&be.push(["Capture",Pe]),ee&&be.push(["Search query",ee]);for(const[n,m]of be){const l=document.createElement("div"),b=document.createElement("dt");b.textContent=n;const u=document.createElement("dd");u.textContent=m,l.append(b,u),ge.append(l)}if(fe("Details",ge,"details-toggle"),ue.append(he,R),i.append(ue),g.length===0){ke(d,{icon:h.brokenFolder,heading:"No messages were stored for this conversation",body:V?"LLMnesia has this conversation on record, but its transcript wasn't captured. Re-open it on the platform to fill in the text.":"LLMnesia has this conversation on record, but its transcript wasn't captured.",actionLabel:V?`Open in ${p.label}`:void 0,actionHref:V??void 0}),lt(N,c);return}s.hidden=!1;for(const n of g){const m=document.createElement("article");m.className=`turn ${n.role}`,m.dataset.msgIndex=String(n.msgIndex);const l=document.createElement("span");l.className="avatar",l.setAttribute("aria-hidden","true"),l.textContent=n.role==="user"?"You":n.role==="assistant"?p.label.charAt(0).toUpperCase():$e[n.role].charAt(0);const b=document.createElement("div");b.className="turn-body";const u=document.createElement("div");u.className="turn-meta";const S=document.createElement("span");S.className="turn-role",S.textContent=n.role==="user"?"You":n.role==="assistant"?p.label:$e[n.role];const L=document.createElement("span");if(L.className="turn-num",L.textContent=`#${n.msgIndex+1}`,u.append(S),n.role==="assistant"&&n.model){const x=document.createElement("span");x.className="turn-num",x.textContent=n.model,u.append(x)}u.append(L);const T=X(a.platform,n).trim();if(T){const x=document.createElement("button");x.type="button",x.className="turn-copy",x.title="Copy this message",x.setAttribute("aria-label",`Copy message ${n.msgIndex+1}`),x.innerHTML=h.copy,x.addEventListener("click",()=>{navigator.clipboard.writeText(T).then(()=>{x.classList.add("is-done"),x.innerHTML=h.check,setTimeout(()=>{x.classList.remove("is-done"),x.innerHTML=h.copy},1600)},()=>{x.classList.add("is-failed"),setTimeout(()=>x.classList.remove("is-failed"),1600)})}),u.append(x)}const q=document.createElement("div");q.className="bubble";const G=X(a.platform,n),D=a.platform==="claude_code"&&n.role==="user"?Ke(G):null;if(D){const x=document.createElement("details");x.className="scheduled-task";const Ue=document.createElement("summary");Q(Ue,`Scheduled task: ${D.name} (instructions)`,we),x.append(Ue);const De=document.createElement("div");at(De,D.body,we),x.append(De),q.append(x)}else at(q,G,we);Ft(q,n.images),b.append(u,q),m.append(l,b),d.append(m)}lt(N,c);const oe=w?.sourceMsgStart??(Qe!==null?parseInt(Qe,10):null);if(!e&&oe!==null&&Number.isFinite(oe)&&oe>=0){const n=d.querySelector(`[data-msg-index="${oe}"]`);if(n){const m=n.querySelector(".bubble")??n;requestAnimationFrame(()=>{if(n.scrollIntoView({behavior:"smooth",block:"center"}),m.style.outline="2px solid var(--teal)",m.style.outlineOffset="2px",setTimeout(()=>{m.style.outline="",m.style.outlineOffset=""},3e3),w?.text){const l=w.text.slice(0,120),b=window.find;typeof b=="function"&&b(l,!1,!1,!1,!1,!1,!1)}})}}if(await _t()){const n=new It({platform:a.platform,scopeRoot:d,resolveContext:()=>({platform:a.platform,docId:a.docId,conversationTitle:M,conversationUrl:a.url||a.baseUrl||""}),resolveMessageIndexes:m=>({start:tt(d,m.startContainer),end:tt(d,m.endContainer)})});n.attach(),ye=n}const ve=ee.length>0,Ae=document.querySelector("#vault-post-search"),kt=Ae&&ve?await At(Ae):!1,Oe=document.querySelector("#vault-footer");Oe&&await Ot(Oe),ve&&!te&&(te=await xt.maybeClaim());const He=document.querySelector("#review-post-search");He&&ve&&!kt&&!te&&cn(He)}const xt=Nt("viewer",()=>!!document.body&&!document.hidden);let te=!1;function wt(){te||ee.length===0||xt.maybeClaim().then(e=>{e&&(te=!0)})}document.addEventListener("visibilitychange",wt);window.addEventListener("focus",wt);function lt(e,t){if(!("IntersectionObserver"in window))return;const r=new IntersectionObserver(([o])=>{t.style.opacity=o.isIntersecting?"0":"1"},{rootMargin:"-48px 0px 0px 0px"});r.observe(e),vt=r}st().then(()=>{if(!j)return;const e=tn({initialRevision:bt,read:()=>ct(j),refresh:async t=>{const r=window.scrollX,o=window.scrollY,i=_.querySelector("details")?.open;if(await st({conversation:t})===!1)return!1;const s=_.querySelector("details");s&&i&&(s.open=!0),window.scrollTo(r,o)},onError:t=>console.warn("[LLMnesia] Could not refresh saved conversation",t)});window.addEventListener("pagehide",t=>{t.persisted||e()})}).catch(e=>{const t=e instanceof Error?e.message:"Unknown error";_.innerHTML=`
    <div style="max-width: 46rem; margin: 3rem auto; padding: 0 1.5rem; font: 14px/1.6 'IBM Plex Sans', ui-sans-serif, system-ui, sans-serif; color: #142430;">
      <h1 style="margin: 0 0 0.5rem; font-size: 1.4rem;">Transcript Viewer</h1>
      <p style="margin: 0; color: #9d2f2f;">Failed to load transcript: ${A(t)}</p>
    </div>
  `});
//# sourceMappingURL=viewer.js.map
