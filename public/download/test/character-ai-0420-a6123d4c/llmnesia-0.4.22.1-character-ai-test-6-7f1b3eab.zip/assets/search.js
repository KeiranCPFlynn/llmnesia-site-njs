import"./modulepreload-polyfill.js";import{S as d}from"./overlay.js";import{i as l}from"./theme.js";import"./google_ai_mode_page.js";import"./backfill.js";import"./outreach.js";import"./search_import_notice.js";import"./platform_styles.js";import"./capture_provenance.js";import"./prompt_coordinator.js";import"./organisation_scope.js";import"./claude_scheduled_task.js";import"./pin_state.js";import"./claude_code_promo.js";import"./error_logging.js";l("search_page","search");const s=document.querySelector("#app");if(!s)throw new Error("Search app root not found");s.innerHTML=`
  <style>
    :root {
      color-scheme: light;
    }

    body {
      margin: 0;
      min-height: 100vh;
      background:
        radial-gradient(120% 110% at 0% -10%, #e5f2ff 0%, #f6f9ff 50%, #f9f5ee 100%);
      color: #17263a;
      font: 14px/1.5 "IBM Plex Sans", "Segoe UI", sans-serif;
    }

    .shell {
      max-width: 860px;
      margin: 34px auto;
      padding: 0 16px;
    }

    .card {
      border: 1px solid #d7e0ea;
      border-radius: 14px;
      background: #ffffffd9;
      box-shadow: 0 10px 30px rgba(16, 40, 64, 0.08);
      padding: 16px;
    }

    h1 {
      margin: 0;
      font-size: 22px;
      line-height: 1.2;
    }

    p {
      margin: 8px 0 0;
      color: #425c70;
    }

    .actions {
      margin-top: 14px;
      display: flex;
      gap: 8px;
      flex-wrap: wrap;
    }

    .btn {
      appearance: none;
      border: 1px solid #bfd0df;
      background: #fff;
      color: #153249;
      border-radius: 9px;
      padding: 8px 12px;
      font: inherit;
      cursor: pointer;
    }

    .btn.primary {
      border-color: #2f7f99;
      background: #2f7f99;
      color: #fff;
      font-weight: 600;
    }

    kbd {
      display: inline-block;
      border: 1px solid #c0d0df;
      border-radius: 4px;
      background: #f4f8fc;
      padding: 1px 5px;
      font: 12px/1.3 "SF Mono", "Consolas", "DejaVu Sans Mono", monospace;
      box-shadow: 0 1px 0 rgba(0,0,0,0.08);
    }
  </style>
  <div class="shell">
    <section class="card">
      <h1>LLMnesia Search</h1>
      <p>Press <kbd id="search-shortcut"></kbd> (or <kbd id="search-shortcut-alt"></kbd>) to open search any time.</p>
      <div class="actions">
        <button id="reopen-search" class="btn primary" type="button">Open search box</button>
        <button id="open-options" class="btn" type="button">Open options</button>
        
      </div>
    </section>
  </div>
`;const n=document.querySelector("#search-shortcut"),i=document.querySelector("#search-shortcut-alt");chrome.commands.getAll().then(o=>{const a=o.find(r=>r.name==="open-search-palette"),t=o.find(r=>r.name==="open-search-palette-fallback");n&&(n.textContent=a?.shortcut||"Not set"),i&&(i.textContent=t?.shortcut||"Not set")});const e=new d;e.attach();const h=new URLSearchParams(window.location.search).get("q")??void 0;e.open(h);function f(o){const a=navigator.platform.toUpperCase().includes("MAC"),t=o.key.toLowerCase(),c=(a?o.metaKey:o.ctrlKey)&&o.shiftKey&&t==="9",p=o.altKey&&o.shiftKey&&t==="k";return c||p}window.addEventListener("keydown",o=>{f(o)&&(o.preventDefault(),e.open())});const u=document.querySelector("#reopen-search");u?.addEventListener("click",()=>{e.open()});const m=document.querySelector("#open-options");m?.addEventListener("click",()=>{chrome.runtime.openOptionsPage()});
//# sourceMappingURL=search.js.map
