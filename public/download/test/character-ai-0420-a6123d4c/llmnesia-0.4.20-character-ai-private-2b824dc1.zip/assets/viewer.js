import"./modulepreload-polyfill.js";import{s as xe}from"./search_invite.js";import{R as wt,b2 as De,U as it,O as Be,bV as yt,bW as kt}from"./db.js";import{i as Ct,T as k}from"./theme.js";import{g as Et}from"./platform_styles.js";import{c as ze,l as Lt,N as Tt}from"./capture_provenance.js";import{c as St,C as $t,S as Mt}from"./vault_payoff_card.js";import{o as qe,q as Ve,w as Nt}from"./conversation_counter.js";import{a as Rt}from"./public_storage_copy.js";import{m as _t,a as It,V as At}from"./vault_hook.js";import{F as ie}from"./founding.js";import{j as je,n as Pt}from"./backfill.js";import{c as Ot,r as Ht}from"./prompt_coordinator.js";import{C as Ut,g as Dt,e as Bt}from"./continue_targets.js";import{c as Fe,s as zt}from"./claude_scheduled_task.js";import"./organisation_scope.js";import"./error_logging.js";import"./vault_payoff.js";function qt(e,t){if(!t?.length)return;const r=document.createElement("div");r.className="message-images";for(const a of t){let i;try{i=new URL(xe(a.dataUrl)??a.url)}catch{continue}if(i.protocol!=="https:"&&i.protocol!=="http:"&&!xe(i.href))continue;const s=document.createElement("a");s.className="message-image";const c=xe(a.dataUrl);s.href=c?/^https?:\/\//.test(a.url)?a.url:"#":i.href,c&&s.addEventListener("click",x=>{x.preventDefault();const o=document.createElement("dialog");o.setAttribute("aria-label","Conversation image");const m=document.createElement("img");m.src=c,m.alt=a.alt||"Conversation image",m.style.maxWidth="90vw",m.style.maxHeight="85vh";const y=document.createElement("button");y.textContent="Close",y.addEventListener("click",()=>o.close()),o.addEventListener("close",()=>o.remove()),o.append(y,document.createElement("br"),m),document.body.append(o),o.showModal()}),s.target="_blank",s.rel="noreferrer",s.title="Open full-size image";const l=document.createElement("img");l.src=i.href,l.loading="lazy",l.alt=a.alt||"Conversation image",a.width&&(l.width=a.width),a.height&&(l.height=a.height),l.addEventListener("error",()=>{l.remove(),s.textContent="Image unavailable. Reopen the original chat to capture it again.",s.title="Open the original image"}),s.append(l),r.append(s)}r.childElementCount&&e.append(r)}function de(e){return`'${e.replace(/'/g,"'\\''")}'`}function pe(e){return`'${e.replace(/'/g,"''")}'`}function st(e){return/mac/i.test(e)}function te(e){return/win/i.test(e)}function ne(){return typeof navigator>"u"?"":navigator.userAgent}function lt(e){return`codex://threads/${encodeURIComponent(e)}`}function ct(e){return`claude://resume?session=${encodeURIComponent(e)}`}function Vt(e){return`zcode://workspace/open?path=${encodeURIComponent(e)}`}const jt=80;function Ke(e){return typeof e=="string"?e.replace(/\s+/g," ").trim():""}function Ft(e,t=jt){if(e.length<=t)return e;let r=t;e.charCodeAt(r-1)>=55296&&e.charCodeAt(r-1)<=56319&&(r-=1);const a=e.slice(0,r),i=a.lastIndexOf(" ");return(i>t/2?a.slice(0,i):a).trimEnd()}function Kt(e,t){return Ft(Ke(e)||Ke(t))}function Wt(e,t=ne()){const r=st(t)?"Command+K":"Ctrl+K";return`ZCode has no direct link to a chat yet. ${e?"Open the project":"Open ZCode"}, press ${r} in ZCode, paste the phrase, and pick the task.`}function dt(e,t,r,a){return te(a)?`if (Get-Command ${e} -ErrorAction SilentlyContinue) { ${t} } else { Start-Process ${pe(r)} }`:st(a)?`if command -v ${e} >/dev/null 2>&1; then ${t}; else open ${de(r)}; fi`:t}function Yt(e,t=ne()){const r=te(t)?pe(e):de(e);return dt("codex",`codex resume ${r}`,lt(e),t)}function Gt(e,t=ne()){const r=te(t)?pe(e):de(e);return dt("claude",`claude --resume ${r}`,ct(e),t)}function Zt(e,t,r=ne()){return t?te(r)?`Set-Location -LiteralPath ${pe(t)}; ${e}`:`cd ${de(t)} && ${e}`:e}function Qt(e=ne()){return te(e)?"Prefer PowerShell, or nothing opened? Run:":"Prefer the terminal, or nothing opened? Run:"}const We={claude_code:{heading:"Reopen in Claude Code.",buttonLabel:"Open in Claude Desktop",appHint:"Requires the Claude Desktop app",deepLink:ct,command:Gt},codex:{heading:"Reopen in Codex.",buttonLabel:"Open in ChatGPT",appHint:"Requires the ChatGPT desktop app",deepLink:lt,command:Yt},zcode:{heading:"Reopen in ZCode.",buttonLabel:"Open project in ZCode",appHint:"Opens this session's project in the ZCode desktop app (ZCode has no link to a specific chat yet)",deepLink:(e,t)=>t?Vt(t):null,searchButtonLabel:"Copy ZCode search phrase"}};function pt(e){if(!e)return"missing";const{indexedAt:t,lastSeenAt:r,estimatedBytes:a,searchDocLength:i,indexLevel:s,...c}=e;return JSON.stringify(c)}function Ce(){const e=window.getSelection();return document.visibilityState!=="hidden"&&(!e||e.isCollapsed)}function Xt(e){let t=e.initialRevision,r=!1,a=!1;const i=async()=>{if(!(a||r||!Ce())){r=!0;try{const l=await e.read(),x=pt(l);!a&&Ce()&&x!==t&&await e.refresh(l)!==!1&&(t=x)}catch(l){e.onError(l)}finally{r=!1}}},s=()=>{i()},c=window.setInterval(s,3e3);return window.addEventListener("focus",s),document.addEventListener("visibilitychange",s),()=>{a=!0,window.clearInterval(c),window.removeEventListener("focus",s),document.removeEventListener("visibilitychange",s)}}const G={enabled:!0,minSearchOpens:5,minInstallAgeDays:7,cooldownDays:60,maxImpressions:2},Jt="https://chromewebstore.google.com/detail/leekfgbdojiaabifbjbbgiiclannjdkf/reviews",se={headline:"Finding what you need?",body:"A quick review helps others discover LLMnesia.",cta:"Leave a review",dismiss:"Not now"},Ee="llmnesia.reviewPrompt.impressions",Le="llmnesia.reviewPrompt.lastShownAt",Te="llmnesia.reviewPrompt.clicked",Se="llmnesia.reviewPrompt.dismissedAt",Ye=1440*60*1e3;function X(e){const t=Number(e);return Number.isFinite(t)&&t>0?Math.floor(t):0}async function mt(){try{const e=await chrome.storage.local.get([Ee,Le,Te,Se]);return{impressions:X(e[Ee]),lastShownAt:X(e[Le]),clicked:e[Te]===!0,dismissedAt:X(e[Se])}}catch{return{impressions:0,lastShownAt:0,clicked:!1,dismissedAt:0}}}async function en(e=Date.now()){try{const t=await mt();await chrome.storage.local.set({[Ee]:t.impressions+1,[Le]:e})}catch{}}async function tn(){try{await chrome.storage.local.set({[Te]:!0})}catch{}}async function Ge(e=Date.now()){try{await chrome.storage.local.set({[Se]:e})}catch{}}function nn(e,t){const r=e.installTs>0?Math.floor((t-e.installTs)/Ye):0,a={searchOpenCount:e.searchOpenCount,installAgeDays:r,impressionNumber:e.impressions+1};if(!e.enabled)return{eligible:!1,reason:"disabled",...a};if(e.clicked)return{eligible:!1,reason:"clicked",...a};if(e.impressions>=G.maxImpressions)return{eligible:!1,reason:"cap_reached",...a};if(e.searchOpenCount<G.minSearchOpens)return{eligible:!1,reason:"too_few_opens",...a};if(!(e.checklistComplete||e.backfillComplete))return{eligible:!1,reason:"not_activated",...a};if(e.installTs<=0||r<G.minInstallAgeDays)return{eligible:!1,reason:"too_new",...a};const i=Math.max(e.lastShownAt,e.dismissedAt);return i>0&&t-i<G.cooldownDays*Ye?{eligible:!1,reason:"cooldown",...a}:{eligible:!0,...a}}async function rn(){const e=await mt();let t=0,r=0,a=!1,i=!1;try{const s=await chrome.storage.local.get([ie.installTs,ie.resultOpenCount,je,...qe.map(l=>Ve[l])]);t=X(s[ie.installTs]),r=X(s[ie.resultOpenCount]),a=qe.every(l=>s[Ve[l]]===!0);const c=Pt(s[je]);i=Object.values(c).some(l=>l?.hasBackfillRun===!0)}catch{}return{enabled:G.enabled,clicked:e.clicked,impressions:e.impressions,lastShownAt:e.lastShownAt,dismissedAt:e.dismissedAt,installTs:t,searchOpenCount:r,checklistComplete:a,backfillComplete:i}}async function an(e=Date.now()){const t=await rn();return nn(t,e)}function le(e,t,r){chrome.runtime.sendMessage({type:"TRACK_REVIEW_PROMPT_EVENT",event:e,impressionNumber:t.impressionNumber,searchOpenCount:t.searchOpenCount,installAgeDays:t.installAgeDays,dismissalType:r}).catch(()=>{})}async function on(e){const t=await an();if(!t.eligible||!await Ot("review"))return e.textContent="",!1;const r={impressionNumber:t.impressionNumber,searchOpenCount:t.searchOpenCount,installAgeDays:t.installAgeDays};await en(),await Ht("review"),le("review_prompt_shown",r),e.textContent="";const a=document.createElement("div");a.className="vault-hook";const i=document.createElement("button");i.className="vault-dismiss",i.type="button",i.setAttribute("aria-label","Dismiss"),i.textContent="✕",i.addEventListener("click",()=>{Ge(),le("review_prompt_dismissed",r,"close"),e.textContent=""}),a.append(i);const s=document.createElement("div");s.className="vault-headline",s.textContent=se.headline,a.append(s);const c=document.createElement("div");c.className="vault-body",c.textContent=se.body,a.append(c);const l=document.createElement("div");l.className="vault-wl-row";const x=document.createElement("button");x.className="vault-wl-btn",x.type="button",x.textContent=se.cta,x.addEventListener("click",()=>{tn(),le("review_prompt_clicked",r),chrome.tabs.create({url:Jt}),e.textContent=""}),l.append(x);const o=document.createElement("button");return o.className="vault-wl-btn ghost",o.type="button",o.textContent=se.dismiss,o.addEventListener("click",()=>{Ge(),le("review_prompt_dismissed",r,"not_now"),e.textContent=""}),l.append(o),a.append(l),e.append(a),!0}Ct("viewer_page","viewer");const ut=document.querySelector("#viewer");if(!ut)throw new Error("Viewer root not found");const _=ut,W=new URLSearchParams(window.location.search),j=W.get("docId")?.trim()??"",J=W.get("q")?.trim()??"",Ze=W.get("msg"),ce=W.get("memoryId")?.trim()??"",sn=W.get("via")==="deleted",we=wt(J),ln=new $t;let ht="missing",ye,gt;const $e={user:"User",assistant:"Assistant",system:"System",unknown:"Unknown"};function Qe(e){return new Date(e).toLocaleString()}function Xe(e){return new Date(e).toLocaleDateString(void 0,{year:"numeric",month:"short",day:"numeric"})}function P(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#39;")}function cn(e){return e.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")}function Je(e,t){let r=t instanceof HTMLElement?t:t.parentElement;for(;r&&r!==e;){if(r.dataset.msgIndex!==void 0)return parseInt(r.dataset.msgIndex,10);r=r.parentElement}return-1}function Z(e,t,r){if(!r.length){e.append(t);return}const a=new RegExp(`(${r.map(cn).join("|")})`,"gi");let i=0;for(const s of t.matchAll(a)){const c=s.index??0;c>i&&e.append(t.slice(i,c));const l=document.createElement("mark");l.textContent=s[0],e.append(l),i=c+s[0].length}i<t.length&&e.append(t.slice(i))}function et(e){return/^\s*\|.*\|\s*$/.test(e)}function dn(e){return/^\s*\|(?:\s*:?-{1,}:?\s*\|)+\s*$/.test(e)}function tt(e){return e.trim().replace(/^\|/,"").replace(/\|$/,"").split(new RegExp("(?<!\\\\)\\|")).map(t=>t.trim().replace(/\\\|/g,"|"))}function nt(e,t,r){const a=/```(\w*)\n?([\s\S]*?)```/g;let i=0,s;function c(m,y){const g=new RegExp("`([^`]+)`|\\*\\*(?=\\S)(.+?)(?<=\\S)\\*\\*|(?<![\\p{L}\\p{N}_])__(?=\\S)(.+?)(?<=\\S)__(?![\\p{L}\\p{N}_])|\\*(?=\\S)(.+?)(?<=\\S)\\*|(?<![\\p{L}\\p{N}_])_(?=\\S)(.+?)(?<=\\S)_(?![\\p{L}\\p{N}_])","gu");let v=0,h;for(;(h=g.exec(y))!==null;){if(h.index>v&&Z(m,y.slice(v,h.index),r),h[1]!==void 0){const C=document.createElement("code");C.textContent=h[1],m.append(C)}else if(h[2]!==void 0||h[3]!==void 0){const C=document.createElement("strong");Z(C,h[2]??h[3],r),m.append(C)}else{const C=document.createElement("em");Z(C,h[4]??h[5],r),m.append(C)}v=h.index+h[0].length}v<y.length&&Z(m,y.slice(v),r)}function l(m,y,g){if(!g)return!1;for(let v=y;v<m.length;v++){const h=m[v];if(h.trim()!=="")return g==="ul"?/^[-*]\s+/.test(h):/^\d+\.\s+/.test(h)}return!1}function x(m,y){const g=y.split(`
`);let v=0,h=null,C=null;function $(){h&&(m.append(h),h=null,C=null)}for(;v<g.length;){const O=g[v];if(et(O)&&v+1<g.length&&dn(g[v+1])){$();const E=document.createElement("table"),H=document.createElement("thead"),M=document.createElement("tr");for(const R of tt(O)){const B=document.createElement("th");c(B,R),M.append(B)}H.append(M),E.append(H),v+=2;const F=document.createElement("tbody");for(;v<g.length&&et(g[v]);){const R=document.createElement("tr");for(const B of tt(g[v])){const Y=document.createElement("td");c(Y,B),R.append(Y)}F.append(R),v++}E.append(F),m.append(E);continue}const I=O.match(/^(#{1,3})\s+(.*)/),A=O.match(/^[-*]\s+(.*)/),D=O.match(/^(\d+)\.\s+(.*)/);if(I){$();const E=I[1].length,H=["h1","h2","h3"][E-1],M=document.createElement(H);c(M,I[2]),m.append(M)}else if(A){(C!=="ul"||h===null)&&($(),h=document.createElement("ul"),C="ul");const E=document.createElement("li");c(E,A[1]),h.append(E)}else if(D){(C!=="ol"||h===null)&&($(),h=document.createElement("ol"),h.start=Number(D[1]),C="ol");const E=document.createElement("li");c(E,D[2]),h.append(E)}else if(O.trim()==="")l(g,v+1,C)||$();else{$();const E=document.createElement("p");c(E,O),m.append(E)}v++}$()}for(;(s=a.exec(t))!==null;){const m=t.slice(i,s.index);m&&x(e,m);const y=document.createElement("pre"),g=document.createElement("code");s[1]&&(g.className=`language-${s[1]}`),g.textContent=s[2].replace(/\n$/,""),y.append(g),e.append(y),i=s.index+s[0].length}const o=t.slice(i);o&&x(e,o)}const u={lens:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"></circle><path d="m21 21-4.3-4.3"></path></svg>',shieldTag:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2 4 5v6c0 5 3.4 7.8 8 9 4.6-1.2 8-4 8-9V5l-8-3Z"></path></svg>',shieldCheck:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3 5 6v5c0 4.4 3 6.9 7 8 4-1.1 7-3.6 7-8V6l-7-3Z"></path><path d="m9 12 2 2 4-4"></path></svg>',external:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path><path d="M15 3h6v6"></path><path d="M10 14 21 3"></path></svg>',copy:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="11" height="11" rx="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg>',check:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="m20 6-11 11-5-5"></path></svg>',brokenFolder:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M4 7V5a2 2 0 0 1 2-2h3l2 2h7a2 2 0 0 1 2 2v3"></path><path d="M4 11v6a2 2 0 0 0 2 2h11"></path><path d="m3 3 18 18"></path></svg>',pin:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M9 4h6l-1 5 3 3v2H7v-2l3-3-1-5Z"></path><path d="M12 15v5"></path></svg>',refresh:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a9 9 0 1 1-2.64-6.36"></path><path d="M21 4v5h-5"></path></svg>'};function pn(){_.innerHTML=`
    <style>
      :root {
        color-scheme: light;
        --paper: ${k.paper};
        --paper-2: ${k.paperSoft};
        --card: ${k.card};
        --rule: ${k.rule};
        --rule-soft: ${k.ruleSoft};
        --ink: ${k.ink};
        --ink-2: ${k.ink2};
        --ink-3: ${k.ink3};
        --teal: ${k.teal};
        --teal-soft: ${k.tealSoft};
        --teal-edge: ${k.tealEdge};
        --rust: #c6572f;
        --on-bg: ${k.onBg};
        --on-edge: ${k.onEdge};
        --on-ink: ${k.onInk};
        --font: "IBM Plex Sans", ui-sans-serif, system-ui, -apple-system, "Segoe UI", sans-serif;
        --mono: "IBM Plex Mono", ui-monospace, "SF Mono", "Cascadia Code", Menlo, monospace;
        /* Per-platform accent; overwritten once the conversation loads. */
        --p-accent: ${k.teal};
        --p-card: ${k.card};
        --p-pill-bg: ${k.tealSoft};
        --p-pill-border: ${k.tealEdge};
        --p-pill-text: ${k.ink2};
      }

      * { box-sizing: border-box; }

      body {
        margin: 0;
        background:
          radial-gradient(60rem 30rem at 82% -6%, rgba(47, 127, 153, 0.07), transparent 70%),
          var(--paper);
        color: var(--ink);
        font-family: var(--font);
        line-height: 1.6;
        -webkit-font-smoothing: antialiased;
      }

      /* ===== Slim page chrome ===== */
      .topbar {
        position: sticky;
        top: 0;
        z-index: 20;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 1rem;
        padding: 0.6rem 1.25rem;
        background: color-mix(in srgb, var(--paper) 88%, transparent);
        backdrop-filter: blur(8px);
        border-bottom: 1px solid var(--rule);
      }
      .brand {
        display: inline-flex;
        align-items: center;
        gap: 0.5rem;
        font-weight: 700;
        font-size: 0.9rem;
        letter-spacing: -0.01em;
        white-space: nowrap;
      }
      .brand .mark {
        display: inline-grid;
        place-items: center;
        width: 1.4rem;
        height: 1.4rem;
        border-radius: 6px;
        background: var(--teal-soft);
        border: 1px solid var(--teal-edge);
        color: var(--teal);
      }
      .brand .mark svg { width: 15px; height: 15px; }
      .brand b { font-family: var(--mono); font-weight: 600; }
      .topbar-title {
        flex: 1;
        min-width: 0;
        text-align: center;
        font-size: 0.8rem;
        color: var(--ink-3);
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        opacity: 0;
        transition: opacity 0.2s;
      }
      .offline-tag {
        display: inline-flex;
        align-items: center;
        gap: 0.4rem;
        padding: 0.28rem 0.6rem 0.28rem 0.5rem;
        border-radius: 999px;
        background: var(--on-bg);
        border: 1px solid var(--on-edge);
        color: var(--on-ink);
        font-family: var(--mono);
        font-size: 0.66rem;
        font-weight: 600;
        letter-spacing: 0.04em;
        text-transform: uppercase;
        white-space: nowrap;
      }
      .offline-tag svg { width: 13px; height: 13px; }

      /* ===== Reading column ===== */
      .wrap {
        max-width: 46rem;
        margin: 0 auto;
        padding: 1.4rem 1.5rem 4rem;
      }

      .status {
        margin: 2rem 0;
        color: var(--ink-3);
        text-align: center;
        font-size: 0.9rem;
      }

      /* ===== Provenance header ===== */
      .head { margin-bottom: 0.8rem; }
      .head[hidden] { display: none; }
      .head-eyebrow {
        display: flex;
        align-items: center;
        gap: 0.55rem;
        margin-bottom: 0.55rem;
        flex-wrap: wrap;
      }
      .platform-badge {
        display: inline-flex;
        align-items: center;
        gap: 0.4rem;
        padding: 0.26rem 0.6rem;
        border-radius: 999px;
        background: var(--p-pill-bg);
        border: 1px solid var(--p-pill-border);
        color: var(--p-pill-text);
        font-size: 0.72rem;
        font-weight: 600;
      }
      .platform-badge .dot {
        width: 0.5rem;
        height: 0.5rem;
        border-radius: 50%;
        background: var(--p-accent);
      }
      .source-badge {
        display: inline-flex;
        align-items: center;
        gap: 0.35rem;
        padding: 0.26rem 0.6rem 0.26rem 0.5rem;
        border-radius: 999px;
        background: var(--paper-2);
        border: 1px solid var(--rule);
        color: var(--ink-2);
        font-size: 0.72rem;
        font-weight: 600;
      }
      .source-badge svg { width: 13px; height: 13px; color: var(--teal); }
      .head h1 {
        margin: 0 0 0.45rem;
        font-size: clamp(1.55rem, 3.2vw, 2.05rem);
        line-height: 1.15;
        letter-spacing: -0.02em;
        font-weight: 700;
        text-wrap: balance;
      }
      .meta-line {
        display: flex;
        align-items: center;
        flex-wrap: wrap;
        gap: 0.5rem 0.7rem;
        font-family: var(--mono);
        font-size: 0.73rem;
        color: var(--ink-3);
        letter-spacing: 0.01em;
      }
      .meta-line .sep { opacity: 0.45; }
      .meta-line b { color: var(--ink-2); font-weight: 600; }

      /* ===== Optional header information ===== */
      .head-extras {
        margin-top: 0.65rem;
      }
      .head-extra-controls {
        display: flex;
        align-items: center;
        flex-wrap: wrap;
        gap: 0.25rem 1rem;
      }
      .head-extra-toggle {
        display: inline-flex;
        align-items: center;
        gap: 0.35rem;
        padding: 0;
        border: 0;
        background: transparent;
        cursor: pointer;
        color: var(--ink-3);
        font-family: var(--font);
        font-size: 0.75rem;
        font-weight: 600;
      }
      .head-extra-toggle::before { content: "+"; color: var(--teal); font-weight: 700; }
      .head-extra-toggle[aria-expanded="true"]::before { content: "−"; }
      .head-extra-toggle:hover { color: var(--teal); }
      .head-extra-toggle:focus-visible { outline: 2px solid var(--teal); outline-offset: 3px; border-radius: 3px; }
      .head-extra-toggle svg { width: 14px; height: 14px; color: var(--teal); }
      .head-extra-toggle.details-toggle {
        font-family: var(--mono);
        font-size: 0.7rem;
        letter-spacing: 0.06em;
        text-transform: uppercase;
      }
      .head-extra-panel {
        margin-top: 0.5rem;
        padding: 0.7rem 0.85rem;
        border: 1px solid var(--rule-soft);
        border-radius: 8px;
        background: var(--card);
        color: var(--ink-2);
        font-size: 0.82rem;
        line-height: 1.55;
      }
      .head-extra-panel[hidden] { display: none; }
      .head-extra-panel[data-kind="assure"] { border-color: var(--teal-edge); background: var(--teal-soft); }
      .head-extra-panel p { margin: 0; }
      .assure-icon {
        flex: none;
        display: inline-grid;
        place-items: center;
        width: 2rem;
        height: 2rem;
        border-radius: 8px;
        background: var(--card);
        border: 1px solid var(--teal-edge);
        color: var(--teal);
      }
      .assure-icon svg { width: 17px; height: 17px; }

      /* Shown when a saved transcript predates an extraction fix (e.g. turns
         stored with an "unknown" role). Warmer rust tone to read as an
         actionable heads-up rather than the reassuring teal banner above. */
      .reindex-nudge {
        display: flex;
        align-items: flex-start;
        gap: 0.75rem;
        margin: 0.75rem 0 0;
        padding: 0.85rem 1rem;
        border: 1px solid color-mix(in srgb, var(--rust) 35%, var(--rule));
        border-radius: 12px;
        background: color-mix(in srgb, var(--rust) 8%, var(--card));
      }
      .reindex-nudge .assure-icon {
        border-color: color-mix(in srgb, var(--rust) 35%, var(--rule));
        color: var(--rust);
      }
      .reindex-nudge p { margin: 0; font-size: 0.85rem; line-height: 1.55; color: var(--ink-2); }
      .reindex-nudge p strong { color: var(--ink); font-weight: 600; }
      .reindex-nudge a { color: var(--rust); font-weight: 600; text-decoration: none; }
      .reindex-nudge a:hover { text-decoration: underline; }

      /* ===== Terminal fallback for local sessions ===== */
      .resume-card p { margin-bottom: 0.5rem; }
      .resume-cmd { display: flex; align-items: center; gap: 0.5rem; flex-wrap: wrap; }
      .resume-cmd code {
        flex: 1 1 260px;
        min-width: 0;
        overflow-x: auto;
        white-space: nowrap;
        font-family: var(--mono);
        font-size: 0.78rem;
        padding: 0.5rem 0.65rem;
        border-radius: 8px;
        background: var(--card);
        border: 1px solid var(--rule);
        color: var(--ink);
      }

      /* ===== Actions ===== */
      .actions {
        display: flex;
        flex-wrap: wrap;
        gap: 0.5rem;
        margin: 0.75rem 0 0;
      }
      .btn {
        display: inline-flex;
        align-items: center;
        gap: 0.45rem;
        padding: 0.5rem 0.85rem;
        border-radius: 8px;
        border: 1px solid var(--teal-edge);
        background: transparent;
        color: var(--teal);
        font-family: var(--font);
        font-size: 0.82rem;
        font-weight: 600;
        cursor: pointer;
        text-decoration: none;
        transition: background 0.18s, border-color 0.18s, transform 0.18s;
      }
      .btn svg { width: 15px; height: 15px; }
      .btn:hover { background: var(--teal-soft); border-color: var(--teal); transform: translateY(-1px); }
      .btn.subtle { border-color: var(--rule); color: var(--ink-2); }
      .btn.subtle:hover { background: var(--paper-2); border-color: var(--ink-3); }
      .btn.is-done { color: var(--on-ink); border-color: var(--on-edge); background: var(--on-bg); }

      .details-grid {
        display: grid;
        gap: 0.4rem;
        margin: 0;
        font-size: 0.78rem;
      }
      .details-grid div {
        display: flex;
        gap: 0.6rem;
        flex-wrap: wrap;
      }
      .details-grid dt {
        min-width: 8.5rem;
        color: var(--ink-3);
        font-weight: 500;
      }
      .details-grid dd {
        margin: 0;
        color: var(--ink-2);
        font-family: var(--mono);
        word-break: break-all;
      }

      .divider {
        margin: 0.9rem 0 1.2rem;
        border: none;
        border-top: 1px solid var(--rule);
      }
      .divider[hidden] { display: none; }

      /* ===== Transcript ===== */
      .transcript { display: grid; gap: 1.1rem; }
      .turn {
        display: grid;
        grid-template-columns: 2rem minmax(0, 1fr);
        gap: 0.85rem;
      }
      .avatar {
        flex: none;
        display: inline-grid;
        place-items: center;
        width: 2rem;
        height: 2rem;
        border-radius: 8px;
        font-family: var(--mono);
        font-size: 0.72rem;
        font-weight: 700;
        margin-top: 0.15rem;
        background: var(--paper-2);
        border: 1px solid var(--rule);
        color: var(--ink-2);
      }
      .turn.assistant .avatar {
        background: var(--p-pill-bg);
        border-color: var(--p-pill-border);
        color: var(--p-pill-text);
      }
      .turn-body { min-width: 0; }
      .turn-meta {
        display: flex;
        align-items: center;
        gap: 0.5rem;
        margin-bottom: 0.4rem;
        font-family: var(--mono);
        font-size: 0.68rem;
        letter-spacing: 0.06em;
        text-transform: uppercase;
      }
      .turn-role { font-weight: 700; color: var(--ink-2); }
      .turn.assistant .turn-role { color: var(--p-pill-text); }
      .turn-num { color: var(--ink-3); opacity: 0.7; }

      /* Per-message copy button: tucked into the turn's meta row, invisible
         until the turn is hovered (or the button focused) so the reading
         column stays quiet. Touch devices have no hover, so keep it faintly
         visible there instead. */
      .turn-copy {
        margin-left: auto;
        display: inline-grid;
        place-items: center;
        width: 1.55rem;
        height: 1.55rem;
        padding: 0;
        border-radius: 6px;
        border: 1px solid var(--rule);
        background: var(--card);
        color: var(--ink-3);
        cursor: pointer;
        opacity: 0;
        transition: opacity 0.15s ease, color 0.15s ease, border-color 0.15s ease;
      }
      .turn-copy svg { width: 12px; height: 12px; }
      .turn:hover .turn-copy,
      .turn-copy:focus-visible { opacity: 1; }
      .turn-copy:hover { color: var(--teal); border-color: var(--teal-edge); }
      .turn-copy.is-done { opacity: 1; color: var(--teal); border-color: var(--teal-edge); }
      .turn-copy.is-failed { opacity: 1; color: var(--rust); border-color: color-mix(in srgb, var(--rust) 35%, var(--rule)); }
      @media (hover: none) {
        .turn-copy { opacity: 0.55; }
      }

      .bubble {
        border: 1px solid var(--rule);
        border-radius: 12px;
        padding: 0.85rem 1.05rem;
        background: var(--card);
        font-size: 0.94rem;
        line-height: 1.68;
        color: var(--ink);
        overflow-wrap: break-word;
      }
      .turn.user .bubble { background: var(--paper-2); border-color: var(--rule-soft); }
      .turn.assistant .bubble {
        border-left: 3px solid var(--p-accent);
        background: var(--p-card);
      }
      .bubble > :first-child { margin-top: 0; }
      .bubble > :last-child { margin-bottom: 0; }
      .bubble p { margin: 0 0 0.7rem; }
      .bubble .scheduled-task summary { cursor: pointer; color: var(--ink-2); font-weight: 600; }
      .bubble .scheduled-task[open] summary { margin-bottom: 0.8rem; }
      .bubble h1, .bubble h2, .bubble h3 {
        margin: 0.2rem 0 0.55rem;
        font-size: 1rem;
        font-weight: 700;
        letter-spacing: -0.01em;
        line-height: 1.3;
      }
      .bubble ul, .bubble ol { margin: 0 0 0.7rem; padding-left: 1.3rem; }
      .bubble li { margin: 0.2rem 0; }
      .bubble li::marker { color: var(--teal); }
      .bubble code {
        font-family: var(--mono);
        font-size: 0.83em;
        background: var(--paper-2);
        border: 1px solid var(--rule-soft);
        border-radius: 5px;
        padding: 0.08em 0.38em;
      }
      .bubble pre {
        margin: 0 0 0.7rem;
        padding: 0.8rem 0.9rem;
        background: #fbfaf3;
        border: 1px solid var(--rule);
        border-radius: 8px;
        overflow-x: auto;
      }
      .bubble pre code {
        background: none;
        border: none;
        padding: 0;
        font-size: 0.82rem;
        line-height: 1.6;
        color: var(--ink-2);
        white-space: pre;
      }
      .bubble table {
        display: block;
        width: 100%;
        margin: 0 0 0.7rem;
        border-collapse: collapse;
        overflow-x: auto;
        font-size: 0.86rem;
      }
      .bubble th, .bubble td {
        padding: 0.4rem 0.6rem;
        border: 1px solid var(--rule);
        text-align: left;
        vertical-align: top;
      }
      .bubble thead th {
        background: var(--paper-2);
        font-weight: 600;
        color: var(--ink);
      }
      .bubble tbody tr:nth-child(even) td {
        background: color-mix(in srgb, var(--paper-2) 45%, transparent);
      }
      .message-images {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(10rem, 1fr));
        gap: 0.6rem;
        margin: 0.1rem 0 0.7rem;
      }
      .message-image {
        display: block;
        min-width: 0;
        overflow: hidden;
        border: 1px solid var(--rule);
        border-radius: 8px;
        background: var(--paper-2);
      }
      .message-image:hover { border-color: var(--teal-edge); }
      .message-image img {
        display: block;
        width: 100%;
        max-height: 28rem;
        object-fit: contain;
        background: var(--paper-2);
      }
      mark {
        background: color-mix(in srgb, var(--rust) 16%, transparent);
        color: var(--ink);
        border-radius: 3px;
        padding: 0 2px;
      }

      /* ===== Empty / error states ===== */
      .empty-card {
        display: grid;
        place-items: center;
        text-align: center;
        gap: 0.55rem;
        padding: 2.6rem 1.5rem;
        margin: 1.5rem 0;
        border: 1px dashed var(--rule);
        border-radius: 14px;
        background: color-mix(in srgb, var(--paper-2) 55%, var(--card));
      }
      .empty-icon {
        display: inline-grid;
        place-items: center;
        width: 3rem;
        height: 3rem;
        border-radius: 12px;
        background: var(--card);
        border: 1px solid var(--rule);
        color: var(--ink-3);
        margin-bottom: 0.2rem;
      }
      .empty-icon svg { width: 22px; height: 22px; }
      .empty-card h2 { margin: 0; font-size: 1.1rem; font-weight: 700; }
      .empty-card p { margin: 0; max-width: 30rem; font-size: 0.88rem; color: var(--ink-3); line-height: 1.6; }
      .empty-card .actions { margin-top: 0.6rem; justify-content: center; }
      .empty-card code {
        font-family: var(--mono);
        font-size: 0.8rem;
        background: var(--paper-2);
        border: 1px solid var(--rule-soft);
        border-radius: 5px;
        padding: 0.08em 0.38em;
        word-break: break-all;
      }

      @media (max-width: 560px) {
        .turn { grid-template-columns: 1.7rem minmax(0, 1fr); gap: 0.6rem; }
        .topbar-title { display: none; }
      }
      ${At}
    </style>
    <header class="topbar">
      <span class="brand">
        <span class="mark" aria-hidden="true">${u.lens}</span>
        LLMnesia <b>viewer</b>
      </span>
      <span class="topbar-title" id="topbar-title"></span>
      <span class="offline-tag" title="This copy is stored on your device">
        ${u.shieldTag}
        Offline copy
      </span>
    </header>
    <main class="wrap" id="viewer-app">
      <p id="viewer-status" class="status">Loading transcript…</p>
      <div class="head" id="viewer-head" hidden></div>
      <div id="vault-post-search"></div>
      <div id="review-post-search"></div>
      <hr class="divider" id="viewer-divider" hidden />
      <div id="viewer-transcript" class="transcript"></div>
      <section id="vault-footer" class="vault-footer" data-visible="false"></section>
    </main>
  `}function ke(e,t){const r=document.createElement("div");r.className="empty-card";const a=document.createElement("span");a.className="empty-icon",a.setAttribute("aria-hidden","true"),a.innerHTML=t.icon;const i=document.createElement("h2");i.textContent=t.heading;const s=document.createElement("p");if(s.textContent=t.body,r.append(a,i,s),t.detail){const c=document.createElement("p"),l=document.createElement("code");l.textContent=t.detail,c.append(l),r.append(c)}if(t.actionLabel&&t.actionHref){const c=document.createElement("div");c.className="actions";const l=document.createElement("a");l.className="btn",l.href=t.actionHref,l.target="_blank",l.rel="noreferrer",l.innerHTML=`${u.external}<span>${P(t.actionLabel)}</span>`,c.append(l),r.append(c)}e.append(r)}function Q(e,t){const r=t.formattedText??t.text,a=e==="codex"&&yt(r)?kt(r)??"Question reply unavailable":r;return Bt(e,a)}function rt(e){return e?.length?e.join(", "):"Not reported by provider"}function mn(e,t,r,a){const i=[`# ${e||"Untitled"}`,`Platform: ${r}`,""];for(const s of a)i.push(`## ${$e[s.role]}`,Q(t,s).trim(),"");return i.join(`
`).trim()+`
`}function un(){return typeof crypto<"u"&&typeof crypto.randomUUID=="function"?crypto.randomUUID():`${Date.now()}-${Math.random().toString(36).slice(2,10)}`}function hn(e,t){const r="llmnesia-continue";try{const a=new URL(e);a.searchParams.set(r,t);const i=new URLSearchParams(a.hash.startsWith("#")?a.hash.slice(1):a.hash);return i.set(r,t),a.hash=i.toString(),a.toString()}catch{const a=`${r}=${encodeURIComponent(t)}`;return e.includes("#")?`${e}&${a}`:`${e}#${a}`}}async function at(e){const t=e?.conversation?await Be(j):[],r=e&&ce?await De(ce):void 0;if(e&&!Ce())return!1;ye?.detach(),ye=void 0,gt?.disconnect(),pn();const a=_.querySelector("#viewer-status"),i=_.querySelector("#viewer-head"),s=_.querySelector("#viewer-divider"),c=_.querySelector("#viewer-transcript"),l=_.querySelector("#topbar-title");let x;if(ce&&(x=e?r:await De(ce)),!j){a.hidden=!0,ke(c,{icon:u.brokenFolder,heading:"No conversation was requested",body:"This viewer needs a conversation to open. Launch it from a search result or from your saved conversations."});return}const o=e?e.conversation:await it(j);if(ht=pt(o),!o){a.hidden=!0,ke(c,{icon:u.brokenFolder,heading:"This conversation isn't in your index yet",body:"It may have been removed before it was captured, or it hasn't been indexed on this device. Open it once on the platform and LLMnesia will save a copy.",detail:j});return}const m=Et(o.platform),y=_.querySelector("#viewer-app");y.style.setProperty("--p-accent",m.accent),y.style.setProperty("--p-card",m.card),y.style.setProperty("--p-pill-bg",m.pillBg),y.style.setProperty("--p-pill-border",m.pillBorder),y.style.setProperty("--p-pill-text",m.pillText);const g=e?t:await Be(j),v=o.contentUpdatedAt??o.updatedAt,h=o.indexedAt??o.lastSeenAt,C=o.localTitle||o.title||"Untitled conversation",$=g[0],I=o.platform==="claude_code"&&$?.role==="user"&&Fe($.formattedText??$.text)&&!o.localTitle?zt(C,o.createdAt):C;a.hidden=!0,i.hidden=!1;const A=document.createElement("div");A.className="head-eyebrow";const D=document.createElement("span");D.className="platform-badge",D.innerHTML=`<span class="dot"></span> ${P(m.label)}`,A.append(D);const E=ze(o.captureProvenance);if(E){const n=document.createElement("span");n.className="source-badge",n.textContent=E,A.append(n)}const H=document.createElement("span");if(H.className="source-badge",H.textContent=`Model: ${rt(o.models)}`,A.append(H),x){const n=document.createElement("span");n.className="source-badge",n.innerHTML=`${u.pin} Saved memory`,A.append(n)}i.append(A);const M=document.createElement("h1");M.textContent=x?x.label:I,i.append(M),l.textContent=M.textContent;const F=document.createElement("div");F.className="meta-line";const R=[];x&&R.push(`from <b>${P(I)}</b>`),R.push(`<b>${g.length}</b> message${g.length===1?"":"s"}`),R.push(`captured <b>${P(Xe(h))}</b>`),R.push(`created <b>${P(Xe(o.createdAt))}</b>`),F.innerHTML=R.join('<span class="sep">·</span>'),i.append(F);const B=Rt(!0,sn,m.label),Y=document.createElement("p");if(Y.textContent=B.body,W.get("via")==="unavailable"){const n=document.createElement("p");n.className="helper-note",n.textContent="Couldn't open the original Google chat. Your saved copy is here. Open a signed-in Google AI Mode tab, then try again.",i.append(n)}const vt=o.url||o.baseUrl,Me=o.platform==="ai_studio"&&o.sourceId?.startsWith("drive-export-"),z=Lt(o)||Me?null:vt,Ne=n=>{if(o.platform==="google_ai_mode"){const d=p=>{p.button>1||p.altKey||(p.preventDefault(),chrome.runtime.sendMessage({type:"OPEN_RESULT",inNewTab:!0,background:p.button===1||p.metaKey||p.ctrlKey,result:{docId:o.docId,platform:o.platform,url:o.url,baseUrl:o.baseUrl,isDeeplinkable:!0}}).catch(()=>{n.textContent="Couldn't open Google. Your saved copy is here."}))};n.addEventListener("click",d),n.addEventListener("auxclick",d)}};if(g.some(n=>n.role==="unknown")&&z){const n=document.createElement("div");n.className="reindex-nudge",n.innerHTML=`
      <span class="assure-icon" aria-hidden="true">${u.refresh}</span>
      <p><strong>Some message roles could not be identified.</strong> <a href="${P(z)}" target="_blank" rel="noreferrer">Re-open it in ${P(m.label)}</a> to capture the current conversation again.</p>
    `;const d=n.querySelector("a");d&&Ne(d),i.append(n)}const K=o.sourceId&&We[o.platform]?We[o.platform]:null,me=K&&o.sourceId?K.deepLink(o.sourceId,o.sourceCwd):null,re=K?.searchButtonLabel,q=document.createElement("div");if(q.className="actions",z){const n=document.createElement("a");n.className="btn",n.href=z,n.target="_blank",n.rel="noreferrer",n.innerHTML=`${u.external}<span>Open in ${P(m.label)}</span>`,Ne(n),q.append(n)}if(me){const n=document.createElement("a");n.className="btn",n.href=me,n.title=K.appHint,n.innerHTML=`${u.external}<span>${K.buttonLabel}</span>`,q.append(n)}if(re&&o.sourceId){const n=g.find(b=>b.role==="user"),d=Kt(n?Q(o.platform,n):null,I),p=document.createElement("button");p.type="button",p.className="btn subtle",p.title="Copies a phrase that finds this chat in ZCode's Command Center search",p.innerHTML=`${u.copy}<span>${re}</span>`,p.addEventListener("click",()=>{navigator.clipboard.writeText(d).then(()=>{p.classList.add("is-done"),p.innerHTML=`${u.check}<span>Copied</span>`,setTimeout(()=>{p.classList.remove("is-done"),p.innerHTML=`${u.copy}<span>${re}</span>`},1600)},()=>{p.innerHTML=`${u.copy}<span>Copy failed</span>`})}),q.append(p)}if(E){const n=document.createElement("div");n.className="viewer-no-original-note",n.style.cssText="margin: 1.1rem 0 0; color: var(--p-pill-text, #526771); font-size: 12.5px; line-height: 1.5; opacity: 0.9;",n.textContent=Tt,i.append(n)}if(Me){const n=document.createElement("p");n.className="helper-note",n.textContent="Imported from an AI Studio Drive download. The download does not include the original chat link.",i.append(n)}if(g.length>0){const n=document.createElement("button");n.className="btn subtle",n.innerHTML=`${u.copy}<span>Copy transcript</span>`,n.addEventListener("click",()=>{const p=mn(I,o.platform,m.label,g);navigator.clipboard.writeText(p).then(()=>{n.classList.add("is-done"),n.innerHTML=`${u.check}<span>Copied</span>`,setTimeout(()=>{n.classList.remove("is-done"),n.innerHTML=`${u.copy}<span>Copy transcript</span>`},1600)},()=>{n.innerHTML=`${u.copy}<span>Copy failed</span>`})}),q.append(n);const d=document.createElement("button");d.type="button",d.className="btn subtle",d.innerHTML=`${u.external}<span>Continue in…</span>`,d.setAttribute("aria-haspopup","menu"),d.addEventListener("click",()=>{const p=g.filter(b=>b.role==="user"||b.role==="assistant").length;ln.show(d.getBoundingClientRect(),o.platform,(b,f)=>{const S=Ut[b];if(!S)return;const L=un(),T=g.map(V=>({role:V.role,text:Q(o.platform,V)}));chrome.runtime.sendMessage({type:"PREPARE_CONTINUE_PAYLOAD",docId:o.docId,sourcePlatform:o.platform,targetPlatform:b,requestId:L,sourceLabel:m.label,mode:f,fallbackMessages:T}).then(V=>{V?.ok===!1&&(d.innerHTML=`${u.external}<span>Continue failed</span>`,U?.close(),setTimeout(()=>{d.innerHTML=`${u.external}<span>Continue in…</span>`},1800))}).catch(()=>{d.innerHTML=`${u.external}<span>Continue failed</span>`,U?.close(),setTimeout(()=>{d.innerHTML=`${u.external}<span>Continue in…</span>`},1800)});const U=window.open(hn(S.newChatUrl,L),"_blank");d.innerHTML=`${u.external}<span>Opening ${S.label}…</span>`,setTimeout(()=>{d.innerHTML=`${u.external}<span>Continue in…</span>`},1800)},{suggestSummary:p>Dt})}),q.append(d)}if(i.append(q),re&&o.sourceId){const n=document.createElement("div");n.style.cssText="margin: 0.7rem 0 0; color: var(--p-pill-text, #526771); font-size: 12.5px; line-height: 1.5; opacity: 0.9;",n.textContent=Wt(!!me),i.append(n)}const ue=document.createElement("div");ue.className="head-extras";const he=document.createElement("div");he.className="head-extra-controls";const N=document.createElement("div");N.className="head-extra-panel",N.id="viewer-head-extra-panel",N.setAttribute("role","region"),N.hidden=!0;const Re=[];function ge(n,d,p,b){const f=document.createElement("button");if(f.type="button",f.className=`head-extra-toggle ${p}`,f.setAttribute("aria-expanded","false"),f.setAttribute("aria-controls",N.id),b){const L=document.createElement("span");L.setAttribute("aria-hidden","true"),L.innerHTML=b,f.append(L)}const S=document.createElement("span");S.textContent=n,f.append(S),f.addEventListener("click",()=>{const L=f.getAttribute("aria-expanded")!=="true";for(const T of Re)T.setAttribute("aria-expanded","false");N.replaceChildren(),N.hidden=!L,L&&(f.setAttribute("aria-expanded","true"),N.dataset.kind=p,N.setAttribute("aria-label",n),N.append(d))}),Re.push(f),he.append(f)}ge(B.heading,Y,"assure",u.shieldCheck);const _e=K?.command;if(_e&&o.sourceId){const n=o.sourceCwd,d=_e(o.sourceId),p=Zt(d,n),b=document.createElement("div");b.className="resume-card";const f=document.createElement("p");f.textContent=Qt();const S=document.createElement("div");S.className="resume-cmd";const L=document.createElement("code");L.textContent=p;const T=document.createElement("button");T.className="btn subtle",T.innerHTML=`${u.copy}<span>Copy command</span>`,T.addEventListener("click",()=>{navigator.clipboard.writeText(p).then(()=>{T.classList.add("is-done"),T.innerHTML=`${u.check}<span>Copied</span>`,setTimeout(()=>{T.classList.remove("is-done"),T.innerHTML=`${u.copy}<span>Copy command</span>`},1600)},()=>{T.innerHTML=`${u.copy}<span>Copy failed</span>`})}),S.append(L,T),b.append(f,S),ge("Reopen in terminal",b,"resume-card")}const fe=document.createElement("dl");fe.className="details-grid";const be=[["Platform",o.platform],[o.models&&o.models.length>1?"Models":"Model",rt(o.models)],["Content updated",Qe(v)],["Indexed",Qe(h)],["docId",o.docId]],Ie=ze(o.captureProvenance);Ie&&be.push(["Capture",Ie]),J&&be.push(["Search query",J]);for(const[n,d]of be){const p=document.createElement("div"),b=document.createElement("dt");b.textContent=n;const f=document.createElement("dd");f.textContent=d,p.append(b,f),fe.append(p)}if(ge("Details",fe,"details-toggle"),ue.append(he,N),i.append(ue),g.length===0){ke(c,{icon:u.brokenFolder,heading:"No messages were stored for this conversation",body:z?"LLMnesia has this conversation on record, but its transcript wasn't captured. Re-open it on the platform to fill in the text.":"LLMnesia has this conversation on record, but its transcript wasn't captured.",actionLabel:z?`Open in ${m.label}`:void 0,actionHref:z??void 0}),ot(M,l);return}s.hidden=!1;for(const n of g){const d=document.createElement("article");d.className=`turn ${n.role}`,d.dataset.msgIndex=String(n.msgIndex);const p=document.createElement("span");p.className="avatar",p.setAttribute("aria-hidden","true"),p.textContent=n.role==="user"?"You":n.role==="assistant"?m.label.charAt(0).toUpperCase():$e[n.role].charAt(0);const b=document.createElement("div");b.className="turn-body";const f=document.createElement("div");f.className="turn-meta";const S=document.createElement("span");S.className="turn-role",S.textContent=n.role==="user"?"You":n.role==="assistant"?m.label:$e[n.role];const L=document.createElement("span");if(L.className="turn-num",L.textContent=`#${n.msgIndex+1}`,f.append(S),n.role==="assistant"&&n.model){const w=document.createElement("span");w.className="turn-num",w.textContent=n.model,f.append(w)}f.append(L);const T=Q(o.platform,n).trim();if(T){const w=document.createElement("button");w.type="button",w.className="turn-copy",w.title="Copy this message",w.setAttribute("aria-label",`Copy message ${n.msgIndex+1}`),w.innerHTML=u.copy,w.addEventListener("click",()=>{navigator.clipboard.writeText(T).then(()=>{w.classList.add("is-done"),w.innerHTML=u.check,setTimeout(()=>{w.classList.remove("is-done"),w.innerHTML=u.copy},1600)},()=>{w.classList.add("is-failed"),setTimeout(()=>w.classList.remove("is-failed"),1600)})}),f.append(w)}const U=document.createElement("div");U.className="bubble";const V=Q(o.platform,n),oe=o.platform==="claude_code"&&n.role==="user"?Fe(V):null;if(oe){const w=document.createElement("details");w.className="scheduled-task";const He=document.createElement("summary");Z(He,`Scheduled task: ${oe.name} (instructions)`,we),w.append(He);const Ue=document.createElement("div");nt(Ue,oe.body,we),w.append(Ue),U.append(w)}else nt(U,V,we);qt(U,n.images),b.append(f,U),d.append(p,b),c.append(d)}ot(M,l);const ae=x?.sourceMsgStart??(Ze!==null?parseInt(Ze,10):null);if(!e&&ae!==null&&Number.isFinite(ae)&&ae>=0){const n=c.querySelector(`[data-msg-index="${ae}"]`);if(n){const d=n.querySelector(".bubble")??n;requestAnimationFrame(()=>{if(n.scrollIntoView({behavior:"smooth",block:"center"}),d.style.outline="2px solid var(--teal)",d.style.outlineOffset="2px",setTimeout(()=>{d.style.outline="",d.style.outlineOffset=""},3e3),x?.text){const p=x.text.slice(0,120),b=window.find;typeof b=="function"&&b(p,!1,!1,!1,!1,!1,!1)}})}}if(await Nt()){const n=new Mt({platform:o.platform,scopeRoot:c,resolveContext:()=>({platform:o.platform,docId:o.docId,conversationTitle:I,conversationUrl:o.url||o.baseUrl||""}),resolveMessageIndexes:d=>({start:Je(c,d.startContainer),end:Je(c,d.endContainer)})});n.attach(),ye=n}const ve=J.length>0,Ae=document.querySelector("#vault-post-search"),xt=Ae&&ve?await _t(Ae):!1,Pe=document.querySelector("#vault-footer");Pe&&await It(Pe),ve&&!ee&&(ee=await ft.maybeClaim());const Oe=document.querySelector("#review-post-search");Oe&&ve&&!xt&&!ee&&on(Oe)}const ft=St("viewer",()=>!!document.body&&!document.hidden);let ee=!1;function bt(){ee||J.length===0||ft.maybeClaim().then(e=>{e&&(ee=!0)})}document.addEventListener("visibilitychange",bt);window.addEventListener("focus",bt);function ot(e,t){if(!("IntersectionObserver"in window))return;const r=new IntersectionObserver(([a])=>{t.style.opacity=a.isIntersecting?"0":"1"},{rootMargin:"-48px 0px 0px 0px"});r.observe(e),gt=r}at().then(()=>{if(!j)return;const e=Xt({initialRevision:ht,read:()=>it(j),refresh:async t=>{const r=window.scrollX,a=window.scrollY,i=_.querySelector("details")?.open;if(await at({conversation:t})===!1)return!1;const s=_.querySelector("details");s&&i&&(s.open=!0),window.scrollTo(r,a)},onError:t=>console.warn("[LLMnesia] Could not refresh saved conversation",t)});window.addEventListener("pagehide",t=>{t.persisted||e()})}).catch(e=>{const t=e instanceof Error?e.message:"Unknown error";_.innerHTML=`
    <div style="max-width: 46rem; margin: 3rem auto; padding: 0 1.5rem; font: 14px/1.6 'IBM Plex Sans', ui-sans-serif, system-ui, sans-serif; color: #142430;">
      <h1 style="margin: 0 0 0.5rem; font-size: 1.4rem;">Transcript Viewer</h1>
      <p style="margin: 0; color: #9d2f2f;">Failed to load transcript: ${P(t)}</p>
    </div>
  `});
//# sourceMappingURL=viewer.js.map
