chrome.action.onClicked.addListener(async tab => {
  if (!tab.id) return;
  try {
    const [present] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, world: 'MAIN', func: () => Boolean(globalThis.llmnesiaGoogleDiagnostic) });
    if (!present?.result) await chrome.scripting.executeScript({ target: { tabId: tab.id }, world: 'MAIN', files: ['diagnostic.js'] });
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, world: 'MAIN', func: () => globalThis.llmnesiaGoogleDiagnostic.start() });
    await chrome.action.setBadgeText({ tabId: tab.id, text: '' });
  } catch {
    await chrome.action.setBadgeText({ tabId: tab.id, text: '!' });
    await chrome.action.setTitle({ tabId: tab.id, title: 'Open the affected Google AI Mode chat, then click this icon again.' });
  }
});
